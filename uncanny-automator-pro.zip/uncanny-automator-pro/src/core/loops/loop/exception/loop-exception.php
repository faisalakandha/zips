<?php
namespace Uncanny_Automator_Pro\Loops\Loop\Exception;

use Exception;

class Loops_Exception extends Exception {

}
