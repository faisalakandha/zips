<?php


namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Automator_Recipe_Process;

/**
 * Class Automator_Pro_Recipe_Process
 * @package Uncanny_Automator_Pro
 */
class Automator_Pro_Recipe_Process extends Automator_Recipe_Process {

	/**
	 * Automator_Pro_Recipe_Process constructor.
	 */
	public function __construct() {
	}

}