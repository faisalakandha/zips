<?php


namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Automator_Recipe_Process_User;

/**
 * Class Automator_Pro_Recipe_Process_User
 * @package Uncanny_Automator_Pro
 */
class Automator_Pro_Recipe_Process_User extends Automator_Recipe_Process_User {
	/**
	 * Automator_Pro_Recipe_Process_User constructor.
	 */
	public function __construct() {
	}
}