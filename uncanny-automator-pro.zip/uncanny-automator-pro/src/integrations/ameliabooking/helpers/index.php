<?php // Silent is golden.
