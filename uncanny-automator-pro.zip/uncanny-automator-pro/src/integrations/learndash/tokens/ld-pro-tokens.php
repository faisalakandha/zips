<?php

namespace Uncanny_Automator_Pro;

/**
 * Class Ld_Pro_Tokens
 *
 * @package Uncanny_Automator_Pro
 */
class Ld_Pro_Tokens {

	/**
	 *
	 */
	public function __construct( $load_action_hook = true ) {

		add_action( 'automator_before_trigger_completed', array( $this, 'save_token_data' ), 20, 2 );
		if ( true === $load_action_hook ) {

			add_filter(
				'automator_maybe_trigger_ld_ld_usercompletesgroupscourse_tokens',
				array(
					$this,
					'group_course_possible_tokens',
				),
				9999,
				2
			);

			add_filter(
				'automator_maybe_trigger_ld_ld_groupleaderremovedgroup_tokens',
				array(
					$this,
					'group_leader_possible_tokens',
				),
				9999,
				2
			);

			add_filter(
				'automator_maybe_trigger_ld_ld_groupleaderaddedgroup_tokens',
				array(
					$this,
					'group_leader_possible_tokens',
				),
				9999,
				2
			);

			add_filter(
				'automator_maybe_parse_token',
				array(
					$this,
					'ld_group_leader_token',
				),
				9999,
				6
			);
			add_filter(
				'automator_maybe_parse_token',
				array(
					$this,
					'ld_tokens',
				),
				22,
				6
			);
			add_filter( 'automator_maybe_parse_token', array( $this, 'ld_assignment_url_token' ), 20, 6 );

			add_filter(
				'automator_maybe_parse_token',
				array(
					$this,
					'ld_essayquiz_token',
				),
				99999,
				6
			);
		}
	}

	/**
	 * save_token_data
	 *
	 * @param mixed $args
	 * @param mixed $trigger
	 *
	 * @return void
	 */
	public function save_token_data( $args, $trigger ) {
		if ( ! isset( $args['trigger_args'] ) || ! isset( $args['entry_args']['code'] ) ) {
			return;
		}

		if ( 'LD_GROUP_OR_ITS_CHILD' === $args['entry_args']['code'] ) {
			$group_id          = $args['trigger_args'][1];
			$trigger_log_entry = $args['trigger_entry'];
			if ( ! empty( $group_id ) ) {
				Automator()->db->token->save( 'group_id', $group_id, $trigger_log_entry );
			}
		}

		if ( 'LD_QUESTIONS' === $args['entry_args']['meta'] ) {
			list( $correct, $question_id, $quiz_id ) = $args['trigger_args'];
			//$question_id       = $args['trigger_args'][1]['question_post_id'];
			$trigger_log_entry = $args['trigger_entry'];
			if ( ! empty( $question_id ) ) {
				Automator()->db->token->save( 'question_id', $question_id, $trigger_log_entry );
				Automator()->db->token->save( 'quiz_id', $quiz_id, $trigger_log_entry );
			}
		}
	}

	/**
	 * @param $value
	 * @param $pieces
	 * @param $recipe_id
	 * @param $trigger_data
	 * @param $user_id
	 * @param $replace_args
	 *
	 * @return mixed|string
	 */
	public function ld_group_leader_token( $value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_args = array() ) {

		if ( empty( $pieces ) || empty( $trigger_data ) || empty( $replace_args ) ) {
			return $value;
		}
		if ( ! isset( $pieces[2] ) ) {
			return $value;
		}
		if ( ! array_intersect(
			array(
				'GROUP_LEADER_ID',
				'GROUP_LEADER_NAME',
				'GROUP_LEADER_EMAIL',
			),
			$pieces
		) ) {
			return $value;
		}

		return Automator()->db->token->get( $pieces[2], $replace_args );
	}

	/**
	 * @param $tokens
	 * @param $args
	 *
	 * @return array|array[]
	 */
	public function group_course_possible_tokens( $tokens = array(), $args = array() ) {
		$trigger_meta = $args['meta'];

		$fields = array(
			array(
				'tokenId'         => 'GROUP_COURSES',
				'tokenName'       => __( 'Group courses', 'uncanny-automator-pro' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
		);

		$tokens = array_merge( $tokens, $fields );

		return $tokens;
	}

	/**
	 * @param $tokens
	 * @param $args
	 *
	 * @return array|array[]
	 */
	public function group_leader_possible_tokens( $tokens = array(), $args = array() ) {
		$trigger_meta = $args['meta'];

		$fields = array(
			array(
				'tokenId'         => 'GROUP_LEADER_ID',
				'tokenName'       => __( 'Group Leader ID', 'uncanny-automator-pro' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'GROUP_LEADER_NAME',
				'tokenName'       => __( 'Group Leader name', 'uncanny-automator-pro' ),
				'tokenType'       => 'text',
				'tokenIdentifier' => $trigger_meta,
			),
			array(
				'tokenId'         => 'GROUP_LEADER_EMAIL',
				'tokenName'       => __( 'Group Leader email', 'uncanny-automator-pro' ),
				'tokenType'       => 'email',
				'tokenIdentifier' => $trigger_meta,
			),
		);

		return array_merge( $tokens, $fields );
	}

	/**
	 * @param $value
	 * @param $pieces
	 * @param $recipe_id
	 * @param $trigger_data
	 * @param $user_id
	 * @param $replace_args
	 *
	 * @return false|int|mixed|string|\WP_Error
	 */
	public function ld_tokens( $value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_args ) {
		if ( empty( $pieces ) ) {
			return $value;
		}
		$trigger_codes = array(
			'LD_USERCOMPLETESGROUPSCOURSE',
			'LD_GROUPLEADERREMOVEDGROUP',
			'LD_GROUP_OR_ITS_CHILD',
			'LD_CORRECT_ANSWER',
			'LD_INCORRECT_ANSWER',
		);
		if ( ! array_intersect( $trigger_codes, $pieces ) ) {
			return $value;
		}

		if ( empty( $trigger_data ) ) {
			return $value;
		}
		foreach ( $trigger_data as $trigger ) {
			if ( empty( $trigger ) ) {
				continue;
			}

			$trigger_id     = $trigger['ID'];
			$trigger_log_id = $replace_args['trigger_log_id'];
			$meta_key       = 'COURSEINGROUP';
			$question_id    = '';
			$group_id       = Automator()->helpers->recipe->get_form_data_from_trigger_meta( $meta_key, $trigger_id, $trigger_log_id, $user_id );
			if ( 'LD_GROUP_OR_ITS_CHILD' === $pieces[1] ) {
				$group_id = Automator()->db->token->get( 'group_id', $replace_args );
			}
			if ( 'LD_CORRECT_ANSWER' === $pieces[1] || 'LD_INCORRECT_ANSWER' === $pieces[1] ) {
				$question_id = Automator()->db->token->get( 'question_id', $replace_args );
			}
			if ( ! empty( $group_id ) ) {
				if ( 'LDGROUPCOURSES_ID' === $pieces[2] || 'LDGROUP_ID' === $pieces[2] ) {
					$value = $group_id;
				} elseif ( 'LDCOURSE' === $pieces[2] || 'LDGROUP' === $pieces[2] ) {
					$value = get_the_title( $group_id );
				} elseif ( 'LDGROUPCOURSES_URL' === $pieces[2] || 'LDGROUP_URL' === $pieces[2] ) {
					$value = get_permalink( $group_id );
				} elseif ( 'LDGROUPCOURSES_THUMB_ID' === $pieces[2] || 'LDGROUP_THUMB_ID' === $pieces[2] ) {
					$value = get_post_thumbnail_id( $group_id );
				} elseif ( 'LDGROUPCOURSES_THUMB_URL' === $pieces[2] || 'LDGROUP_THUMB_URL' === $pieces[2] ) {
					$value = get_the_post_thumbnail_url( $group_id );
				} elseif ( 'LDGROUPLEADERID' === $pieces[2] ) {
					$value = $user_id;
				} elseif ( 'GROUP_COURSES' === $pieces[2] ) {
					$courses                          = array();
					$learndash_group_enrolled_courses = learndash_group_enrolled_courses( $group_id );
					foreach ( $learndash_group_enrolled_courses as $course_id ) {
						$courses[] = get_the_title( $course_id );
					}
					$value = join( ', ', $courses );
				} elseif ( 'LDGROUP_LEADERS' === $pieces[2] ) {
					$group_leaders       = learndash_get_groups_administrators( $group_id, true );
					$group_leader_emails = array();

					foreach ( $group_leaders as $leader ) {
						$group_leader_emails[ $leader->ID ] = $leader->user_email;
					}
					$value = join( ', ', $group_leader_emails );
				}
			}

			if ( isset( $question_id ) && ! empty( $question_id ) ) {
				if ( 'LD_QUIZZES_ID' === $pieces[2] ) {
					$value = Automator()->db->token->get( 'quiz_id', $replace_args );
				} elseif ( 'LD_QUIZZES' === $pieces[2] ) {
					$quiz_id = Automator()->db->token->get( 'quiz_id', $replace_args );
					$value   = get_the_title( $quiz_id );
				} elseif ( 'LD_QUIZZES_URL' === $pieces[2] ) {
					$quiz_id = Automator()->db->token->get( 'quiz_id', $replace_args );
					$value   = get_permalink( $quiz_id );
				} elseif ( 'LD_QUESTIONS' === $pieces[2] ) {
					$value = get_the_title( $question_id );
				}
			}
		}

		return $value;
	}

	/**
	 * @param $value
	 * @param $pieces
	 * @param $recipe_id
	 * @param $trigger_data
	 * @param $user_id
	 * @param $replace_args
	 *
	 * @return false|int|mixed|string|\WP_Error
	 */
	public function ld_assignment_url_token(
		$value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_args
	) {
		if ( empty( $pieces ) ) {
			return $value;
		}
		if ( ! in_array( 'ASSIGNMENT_URL', $pieces, true ) ) {
			return $value;
		}
		if ( empty( $trigger_data ) ) {
			return $value;
		}

		return Automator()->db->token->get( 'ASSIGNMENT_URL', $replace_args );
	}

	/**
	 * @param $value
	 * @param $pieces
	 * @param $recipe_id
	 * @param $trigger_data
	 * @param $user_id
	 * @param $replace_args
	 *
	 * @return mixed|string
	 */
	public function ld_essayquiz_token( $value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_args = array() ) {
		if ( empty( $pieces ) || empty( $trigger_data ) || empty( $replace_args ) ) {
			return $value;
		}

		if ( ! in_array( 'LD_SUBMITESSAYQUIZ', $pieces, true ) ) {
			return $value;
		}

		if ( empty( $trigger_data ) ) {
			return $value;
		}

		$trigger_id      = $replace_args['trigger_id'];
		$trigger_log_id  = $replace_args['trigger_log_id'];
		$trigger_user_id = $replace_args['user_id'];
		$ld_essay_id     = (int) Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDESSAY_ID', $trigger_id, $trigger_log_id, $user_id );

		if ( 0 === $ld_essay_id ) {
			return false;
		}

		$tokens = array(
			'LDESSAYQUIZ_ID',
			'LDESSAYQUIZ_TITLE',
			'LDESSAYQUIZ_SUBMISSION_DATE',
			'LDESSAYQUIZ_CONTENT',
			'LDESSAYQUIZ_LDQUIZ_ID',
			'LDESSAYQUIZ_LDQUIZ_TITLE',
			'LDESSAYQUIZ_LDCOURSE_ID',
			'LDESSAYQUIZ_LDCOURSE_TITLE',
			'LDESSAYQUIZ_LDLESSON_ID',
			'LDESSAYQUIZ_LDLESSON_TITLE',
			'LDESSAYQUIZ_LDQUESTION_ID',
			'LDESSAYQUIZ_LDQUESTION_TITLE',
		);

		$parse_token_key = $pieces[2];

		if ( in_array( $parse_token_key, $tokens, true ) ) {
			switch ( $parse_token_key ) {
				case 'LDESSAYQUIZ_ID':
					$value = $ld_essay_id;
					break;
				case 'LDESSAYQUIZ_TITLE':
					$value = get_the_title( $ld_essay_id );
					break;
				case 'LDESSAYQUIZ_SUBMISSION_DATE':
					$value = get_the_date( '', $ld_essay_id );
					break;
				case 'LDESSAYQUIZ_CONTENT':
					$value = wpautop( get_post_field( 'post_content', $ld_essay_id ) );
					break;
				case 'LDESSAYQUIZ_LDQUIZ_ID':
					$value = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDQUIZ', $trigger_id, $trigger_log_id, $user_id );
					break;
				case 'LDESSAYQUIZ_LDQUIZ_TITLE':
					$quiz_id = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDQUIZ', $trigger_id, $trigger_log_id, $user_id );
					$value   = get_the_title( $quiz_id );
					break;
				case 'LDESSAYQUIZ_LDCOURSE_ID':
					$value = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDCOURSE', $trigger_id, $trigger_log_id, $user_id );
					break;
				case 'LDESSAYQUIZ_LDCOURSE_TITLE':
					$course_id = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDCOURSE', $trigger_id, $trigger_log_id, $user_id );
					$value     = get_the_title( $course_id );

					break;
				case 'LDESSAYQUIZ_LDLESSON_ID':
					$value = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDLESSON', $trigger_id, $trigger_log_id, $user_id );
					break;
				case 'LDESSAYQUIZ_LDLESSON_TITLE':
					$lesson_id = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDLESSON', $trigger_id, $trigger_log_id, $user_id );
					$value     = get_the_title( $lesson_id );
					break;
				case 'LDESSAYQUIZ_LDQUESTION_ID':
					$value = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDESSAY_QUESTION_ID', $trigger_id, $trigger_log_id, $user_id );
					break;
				case 'LDESSAYQUIZ_LDQUESTION_TITLE':
					$question_id = Automator()->helpers->recipe->get_form_data_from_trigger_meta( 'LDESSAY_QUESTION_ID', $trigger_id, $trigger_log_id, $user_id );
					$value       = get_the_title( $question_id );
					break;
				default:
					$value = '';
					break;

			}

			$value = apply_filters( 'automator_ld_essayquiz_token_value', $value, $parse_token_key, $ld_essay_id );
		}

		return $value;
	}

	/**
	 * New tokens for Groups and Courses trigger.
	 *
	 * @return array[]
	 */
	public function group_course_tokens() {
		return array(
			'LD_COURSE_TITLE'              => array(
				'name' => __( 'Course title', 'uncanny-automator-pro' ),
			),
			'LD_COURSE_ID'                 => array(
				'name' => __( 'Course ID', 'uncanny-automator-pro' ),
			),
			'LD_COURSE_URL'                => array(
				'name' => __( 'Course URL', 'uncanny-automator-pro' ),
			),
			'LD_COURSE_FEATURED_IMAGE_ID'  => array(
				'name' => __( 'Course featured image ID', 'uncanny-automator-pro' ),
			),
			'LD_COURSE_FEATURED_IMAGE_URL' => array(
				'name' => __( 'Course featured image URL', 'uncanny-automator-pro' ),
			),
			'LD_GROUP_TITLE'               => array(
				'name' => __( 'Group title', 'uncanny-automator-pro' ),
			),
			'LD_GROUP_ID'                  => array(
				'name' => __( 'Group ID', 'uncanny-automator-pro' ),
			),
			'LD_GROUP_URL'                 => array(
				'name' => __( 'Group URL', 'uncanny-automator-pro' ),
			),
			'LD_GROUP_FEATURED_IMAGE_ID'   => array(
				'name' => __( 'Group featured image ID', 'uncanny-automator-pro' ),
			),
			'LD_GROUP_FEATURED_IMAGE_URL'  => array(
				'name' => __( 'Group featured image URL', 'uncanny-automator-pro' ),
			),
			'LDGROUP_LEADER_EMAIL'         => array(
				'name' => __( 'Group leader email', 'uncanny-automator-pro' ),
			),
		);
	}

	/**
	 * Hydrate tokens method for ban user trigger.
	 *
	 * @param $parsed
	 * @param $args
	 * @param $trigger
	 *
	 * @return array
	 */
	public function hydrate_group_course_tokens(
		$parsed, $args, $trigger
	) {

		list( $course_id, $group_id ) = $args['trigger_args'];

		$group_leaders       = learndash_get_groups_administrators( $group_id, true );
		$group_leader_emails = array();

		foreach ( $group_leaders as $leader ) {
			$group_leader_emails[ $leader->ID ] = $leader->user_email;
		}

		return $parsed + array(
			'LD_COURSE_TITLE'              => get_the_title( $course_id ),
			'LD_COURSE_ID'                 => absint( $course_id ),
			'LD_COURSE_URL'                => get_permalink( $course_id ),
			'LD_COURSE_FEATURED_IMAGE_ID'  => get_post_thumbnail_id( $course_id ),
			'LD_COURSE_FEATURED_IMAGE_URL' => get_the_post_thumbnail_url( $course_id ),
			'LD_GROUP_TITLE'               => get_the_title( $group_id ),
			'LD_GROUP_ID'                  => absint( $group_id ),
			'LD_GROUP_URL'                 => get_permalink( $group_id ),
			'LD_GROUP_FEATURED_IMAGE_ID'   => get_post_thumbnail_id( $group_id ),
			'LD_GROUP_FEATURED_IMAGE_URL'  => get_the_post_thumbnail_url( $group_id ),
			'LDGROUP_LEADER_EMAIL'         => implode( ',', $group_leader_emails ),
		);
	}

}
