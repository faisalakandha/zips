<?php

namespace Uncanny_Automator_Pro;

/**
 * Class Integromat_Tokens
 *
 * @package Uncanny_Automator_Pro
 */
class Integromat_Tokens {

	public function __construct() {
	}
}
