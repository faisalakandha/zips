<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Armember_Helpers;
use Uncanny_Automator\Recipe;

/**
 * Class ARMEMBER_ADD_TO_MEMBERSHIP_PLAN
 *
 * @package Uncanny_Automator_Pro
 */
class ARMEMBER_ADD_TO_MEMBERSHIP_PLAN {

	use Recipe\Actions;

	/**
	 * @var \ARM_subscription_plans|\ARM_subscription_plans_Lite|string
	 */
	private $armember_subscription_class = '';

	/**
	 * Set up Automator action constructor.
	 */
	public function __construct() {
		if ( ! class_exists( 'Uncanny_Automator\Armember_Helpers' ) ) {
			return;
		}
		// If LITE version is active
		if ( defined( 'MEMBERSHIPLITE_DIR_NAME' ) && ! defined( 'MEMBERSHIP_DIR_NAME' ) ) {
			$this->armember_subscription_class = new \ARM_subscription_plans_Lite();
		}
		// If Pro version is active
		if ( defined( 'MEMBERSHIP_DIR_NAME' ) ) {
			$this->armember_subscription_class = new \ARM_subscription_plans();
		}
		$this->setup_action();
	}

	/**
	 * Define and register the action by pushing it into the Automator object
	 */
	protected function setup_action() {
		$this->set_helpers( new Armember_Helpers() );
		$this->set_integration( 'ARMEMBER' );
		$this->set_action_code( 'ARM_ADD_TO_PLAN' );
		$this->set_action_meta( 'ARM_PLANS' );
		$this->set_requires_user( true );
		$this->set_is_pro( true );

		/* translators: Action - ARMember */
		$this->set_sentence( sprintf( esc_attr__( 'Add the user to {{a membership plan:%1$s}}', 'uncanny-automator-pro' ), $this->get_action_meta() ) );

		/* translators: Action - ARMember */
		$this->set_readable_sentence( esc_attr__( 'Add the user to {{a membership plan}}', 'uncanny-automator-pro' ) );

		$this->set_options_callback( array( $this, 'load_options' ) );
		$this->register_action();
	}

	/**
	 * load_options
	 *
	 * @return array
	 */
	public function load_options() {

		return Automator()->utilities->keep_order_of_options(
			array(
				'options' => array(
					$this->get_helpers()->get_all_plans(
						array(
							'option_code'           => $this->get_action_meta(),
							'supports_custom_value' => true,
						)
					),
				),
			)
		);

	}

	/**
	 * Process the action.
	 *
	 * @param $user_id
	 * @param $action_data
	 * @param $recipe_id
	 * @param $args
	 * @param $parsed
	 *
	 * @return void.
	 * @throws \Exception
	 */
	protected function process_action( $user_id, $action_data, $recipe_id, $args, $parsed ) {
		$plan_id = isset( $parsed[ $this->get_action_meta() ] ) ? sanitize_text_field( $parsed[ $this->get_action_meta() ] ) : '';

		if ( empty( $plan_id ) ) {
			$action_data['complete_with_errors'] = true;
			$message                             = __( 'Plan does not exist.', 'uncanny-automator-pro' );
			Automator()->complete->action( $user_id, $action_data, $recipe_id, $message );

			return;
		}

		$arm_plans = $this->armember_subscription_class;

		$membership_plan = array(
			'arm_user_plan'               => $plan_id,
			'payment_gateway'             => 'manual',
			'arm_selected_payment_mode'   => 'manual_subscription',
			'arm_primary_status'          => 1,
			'arm_secondary_status'        => 0,
			'arm_subscription_start_date' => date( 'm/d/Y' ),
			'action'                      => 'add_member',
		);
		$old_plan_ids    = get_user_meta( $user_id, 'arm_user_plan_ids', true );

		if ( ! empty( $old_plan_ids ) ) {
			if ( in_array( $plan_id, $old_plan_ids, true ) ) {
				$action_data['do-nothing']           = true;
				$action_data['complete_with_errors'] = true;
				$message                             = sprintf( __( 'The user is already a member of %s.', 'uncanny-automator-pro' ), $arm_plans->arm_get_plan_name_by_id( $plan_id ) );
				Automator()->complete->action( $user_id, $action_data, $recipe_id, $message );

				return;
			}

			$membership_plan['action'] = 'update_member';
		}

		do_action( 'arm_member_update_meta', $user_id, $membership_plan );

		Automator()->complete->action( $user_id, $action_data, $recipe_id );
	}

}
