<?php

if ( ! defined( 'ABSPATH' ) ) {
	return;
}

if ( ! class_exists( 'Uncanny_Automator_Pro\Integrations\Formatter\Formatter_Integration' ) ) {
	return;
}

new Uncanny_Automator_Pro\Integrations\Formatter\Formatter_Integration();

