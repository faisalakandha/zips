<?php
/**
 * Plugin Name: BuddyBoss App
 * Description: The BuddyBoss App plugin allows you to sync your community and courses into a native mobile app.
 * Version: 1.4.2
 * Author: BuddyBoss
 * Author URI:  https://www.buddyboss.com
 * Text Domain: buddyboss-app
 * Domain Path: /languages
 */

// Make sure we don't expose any info if called directly
if ( ! function_exists( 'add_action' ) ) {
	die( "Sorry, you can't access this directly - Security established" );
}

if ( ! defined( "bbapp_notification_server_api_url" ) ) {
	define( "bbapp_notification_server_api_url", false );
}

// Check Min php version
if ( version_compare( PHP_VERSION, '7.2', '<' ) ) {
	function bbapp_min_supported_php_admin_notices(){
		if ( version_compare( PHP_VERSION, '7.2', '<' ) ) {
			printf(
			/* translators: 1. div classes. 2. notice message. */
				'<div class="%1$s"><p>%2$s</p></div>',
				esc_attr( 'notice notice-error' ),
				__( 'The BuddyBoss App plugin requires a minimum PHP version 7.2.', 'buddyboss-app' )
			);
		}
	}
	add_action( 'admin_notices', 'bbapp_min_supported_php_admin_notices' );
	return false;
}

$base_dir = dirname( __FILE__ );

/**
 * Always Load BuddyBossApp Instance First!.
 */
bbapp::instance( __FILE__ );

// Load WP Core Extended API
\BuddyBossApp\Api\WpCore\Main::instance();

//Load Learndash API
\BuddyBossApp\Api\LearnDash\Main::instance();

\BuddyBossApp\Api\Core\Main::instance(); // if platform disable provide support.

// Deprecated rest feature provide support.
\BuddyBossApp\Api\Deprecated\Main::instance();

use BuddyBossApp\Admin\SetupAdmin;
use BuddyBossApp\App\App;
use BuddyBossApp\AppStores;
use BuddyBossApp\BuddyBossAppApi;
use BuddyBossApp\Build;
use BuddyBossApp\ClientApiPluginSupport;
use BuddyBossApp\ClientCommon;
use BuddyBossApp\Common\IconPicker;
use BuddyBossApp\DeepLinking\DeepLinking;
use BuddyBossApp\HealthCheck;
use BuddyBossApp\Integrations\PmPro\PmProForumSupport;
use BuddyBossApp\Integrations\PmPro\PmProMembershipSupport;
use BuddyBossApp\ItemMeta\CourseMeta;
use BuddyBossApp\ItemMeta\LessonMeta;
use BuddyBossApp\ItemMeta\MetaApi;
use BuddyBossApp\ItemMeta\TopicMeta;
use BuddyBossApp\Memberships\Memberships;
use BuddyBossApp\NativeAppPage;
use BuddyBossApp\Network;
use BuddyBossApp\SmartBanner;

class bbapp {
	private static $instance;
	public $plugin_url;
	public $plugin_dir;
	public $plugin_prefix; // should be char & _
	public $plugin_version;
	public $domain; // it's used for language domain.
	public $root_file;
	public $_network_activated = false;
	public $db_version = '11';
	public $transient_key = ''; //Transient Key

	public function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of the class.
	 *
	 * @param bool $root_file
	 *
	 * @return bbapp
	 */
	public static function instance( $root_file = false ) {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load( $root_file );
		}

		return self::$instance;
	}

	/**
	 * Function to load all essential components
	 *
	 * @param bool $root_file
	 */
	public function _load( $root_file = false ) {
		$this->root_file      = $root_file;
		$this->plugin_version = '1.4.2';
		$this->plugin_dir     = plugin_dir_path( $this->root_file );
		$this->plugin_url     = plugin_dir_url( $this->root_file );
		$this->plugin_prefix  = 'buddyboss_app';
		$this->domain         = 'buddyboss-app'; // it's used for language domain.
		$this->is_network_activated();
		define( "BUDDYBOSS_APP_PLUGIN_URL", $this->plugin_url );
		$this->transient_key = 'bbapp-';

		// Include Composer
		$this->require_composer();

		// Load Plugin Updater.
		new \BuddyBossApp\Updater( 'https://update.buddyboss.com/plugin', plugin_basename( __FILE__ ), 1133 );

		// Include functions
		require_once trailingslashit( plugin_dir_path( __FILE__ ) ) . 'include/functions.php';

		// Install Cron Jobs
		\BuddyBossApp\CronJobs::instance();
		\BuddyBossApp\Jobs::instance();

		// Register activation & deactivation hooks.
		register_activation_hook( $root_file, array( $this, 'on_plugin_activate' ) );
		register_deactivation_hook( $root_file, array( $this, 'on_plugin_deactivate' ) );

		// Initiate required classes.
		\BuddyBossApp\Auth\Auth::instance();

		add_action( 'plugins_loaded', array( $this, 'load' ), 0 );
	}

	/**
	 * plugin load
	 */
	public function load() {

		$is_min_requirement_match = true;

		// Check if BuddyBoss Platform plugin installed and meet min requirement.
		if ( defined( 'BP_PLATFORM_VERSION' ) && version_compare( BP_PLATFORM_VERSION, '1.5.7.3', '<' ) ) {
			$is_min_requirement_match = false;
		}

		// Check if BuddyBoss Platform plugin installed and meet min requirement.
		if ( empty( $is_min_requirement_match ) ) {
			add_action( 'admin_notices', array( $this, 'min_supported_plugin_admin_notices' ) );

			// Delete the redirect transient.
			delete_transient( '_bbapp_activation_redirect' );
			return;
		}

		// Database Updater.
		\BuddyBossApp\DBUpdate\Main::instance();

		// Upgrade db version value.
		update_option( "bbapp_db_version", $this->db_version );

		// Register the hooks
		$this->hooks();

		/**
		 * Load BuddyBossApp Components.
		 */
		$this->load_components();


		\BuddyBossApp\RestCDN::instance();

		BuddyBossAppApi::instance();

		ClientCommon::instance();

		// App
		App::instance();

		// Admin Setup
		SetupAdmin::instance();

		// Import Export
		\BuddyBossApp\Admin\ImportExport::instance();

		new ClientApiPluginSupport();

		// Multi Site Network
		Network::instance();

		// Integrations
		// -----------------------------------------------------------------------------
		BuddyBossApp\Integrations\Memberium\Main::instance();
		BuddyBossApp\Integrations\IMember360\Main::instance();
		BuddyBossApp\Integrations\S2Member\Main::instance();
		BuddyBossApp\Integrations\BbpPrivateGroups\Main::instance();
		\BuddyBossApp\BrowserAuth::instance();
		\BuddyBossApp\Logger\ApiLogger::instance();
		BuddyBossApp\Integrations\ForceLogin\Main::instance();
		BuddyBossApp\Integrations\AdvancedRecaptcha\Main::instance();
		BuddyBossApp\Integrations\BuddyBossPlatform\Main::instance();
		BuddyBossApp\Integrations\BuddyBossTheme\Main::instance();
		BuddyBossApp\Integrations\GamiPress\Main::instance();
		BuddyBossApp\Integrations\BadgeOs\Main::instance();
		BuddyBossApp\Integrations\Vimeo\Main::instance();
		BuddyBossApp\Integrations\IThemeSecurity\Main::instance();
//        BuddyBossApp\Integrations\GravityForm\Main::instance();

		BuddyBossApp\Integrations\Learndash\Main::instance();
		BuddyBossApp\Integrations\LearndashBBPress\Main::instance();
		BuddyBossApp\Integrations\LearndashBoss\Main::instance();
		BuddyBossApp\Integrations\LearndashBuddyPress\Main::instance();
		BuddyBossApp\Integrations\MemberPress\Main::instance();
		BuddyBossApp\Integrations\WcMembership\Main::instance();
		BuddyBossApp\Integrations\WishlistMember\Main::instance();
		BuddyBossApp\Integrations\RestrictContentPro\Main::instance();
		BuddyBossApp\Integrations\DiviTheme\Main::instance();

		// reCaptcha plugin support.
		BuddyBossApp\Integrations\GoogleCaptcha\Main::instance();
		BuddyBossApp\Integrations\SimpleGooglereCaptcha\Main::instance();
		BuddyBossApp\Integrations\Wordfence\Main::instance();

		// BuddyPress Groups tab creator pro plugin support.
		BuddyBossApp\Integrations\GroupTabCreatorPro\Main::instance();

		PmProForumSupport::instance();
		PmProMembershipSupport::instance();

		// AppStores API's
		AppStores::instance();

		// DeepLinking
		DeepLinking::instance();

		// Build
		Build::instance();

		// Smart Banner
		SmartBanner::instance();

		// IconPicker
		IconPicker::instance();

		// Health Check
		HealthCheck::instance();

		// Memberships
		// -----------------------------------------------------------------------------
		Memberships::instance();

		// ItemMeta
		// -----------------------------------------------------------------------------
		MetaApi::instance();
		CourseMeta::instance();
		LessonMeta::instance();
		TopicMeta::instance();

		// ToDo: Temp Migration file. we will remove once we final launch buddyboss-app.
		\BuddyBossApp\Migration\Migrate::instance();

		if ( true === \BuddyBossApp\ManageApp::instance()->is_app_disabled() ) {
			add_action( 'admin_notices', array( $this, 'app_disable_admin_notices' ) );
		}
	}

	/**
	 * Include composer auto loader.
	 */
	public function require_composer() {
		require trailingslashit( $this->plugin_dir ) . 'vendor/autoload.php';
	}

	/**
	 * Check if the plugin is activated network wide(in multisite)
	 *
	 * @return boolean
	 */
	public function is_network_activated() {
		if ( ! $this->_network_activated ) {
			$this->_network_activated = false;

			if ( is_multisite() ) {
				if ( ! function_exists( 'is_plugin_active_for_network' ) ) {
					require_once ABSPATH . '/wp-admin/includes/plugin.php';
				}

				if ( is_plugin_active_for_network( 'buddyboss-app/buddyboss-app.php' ) ) {
					$this->_network_activated = true;
				}
			}
		}

		return $this->_network_activated;
	}

	/**
	 * Register all hooks.
	 *
	 * @since 1.0,0
	 */
	public function hooks() {
		add_action( 'admin_menu', 'register_bbapp_menu_page' );
		/**
		 * Make Menu Available on WP Network if Plugin enabled in Network Mode.
		 */
		if ( bbapp()->is_network_activated() ) {
			add_action( 'network_admin_menu', 'register_bbapp_menu_page' );
		}

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_assets' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'enqueue_block_editor_assets', array( $this, 'block_editor_assets' ), 9999 );
		add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
		add_action( 'wp_footer', array( $this, 'wpFooter' ), 1 );
	}

	/**
	 * To add additional element in footer so app can get(post) title without any modification by third-party plugin
	 */
	public function wpFooter() {
		global $post;

		if ( ! empty( $post->post_title ) ) {
			echo "<span id='bbapp-title' style='display: none;'>" . $post->post_title . "</span>";
		}
	}

	/**
	 * Returns defaults app setting values.
	 * These defaults get added as default when key's are not exists on db.
	 * These settings get apply to individual app settings,
	 * @return array
	 */
	public function app_settings_defaults() {

		$defaults = array(
			"app_auth.enable_signup"       => true,
			"app_auth.signup_form"         => \BuddyBossApp\Auth\Auth::instance()->is_app_registration_form(), // Pass default registration form.
			"app_subscription.enabled"     => false,
			"learndash_course_downloading" => 0,
			"learndash_author_visible"     => 1,
			"learndash_date_visible"       => 1,
		);

		return $defaults;
	}

	/**
	 * Defaults for Auth Settings
	 * Auth Settings are global over all apps..
	 *
	 * @return array
	 */
	public function bbapp_default_settings() {

		$defaults = array(
			'app_auth.email_activation_body' => __( 'From a mobile device, enter the following code <b>( {{KEY_CODE}} )</b> in the app, or tap this link: <a href="{{KEY_CODE_LINK}}">Click here</a> to be sent to the app.', 'buddyboss-app' ),
		);

		return $defaults;
	}

	/**
	 * Load Components.
	 */
	public function load_components() {
		\BuddyBossApp\Components\AppPages\AppPages::instance();
		\BuddyBossApp\Components\PushNotification\PushNotification::instance();
		\BuddyBossApp\Components\InAppPurchases\InAppPurchases::instance();
		\BuddyBossApp\Components\Performance\Performance::instance();

		/**
		 * All Components load the code on this hook at 99.
		 * If you want to load any component before that please use priority less then 99.
		 */
		do_action( "bbapp_components_loaded" );
	}

	/**
	 * Register admin assets.
	 *
	 * @since 1.0.0
	 */
	public function admin_enqueue_assets() {

		global $post_type, $pagenow;

		$_get_var = function ( $getkey ) {
			return ( isset( $_GET[ $getkey ] ) ) ? $_GET[ $getkey ] : "";
		};

		if (
			$pagenow == "admin.php" && ( strpos( $_get_var( "page" ), "bbapp" ) !== false ) || // All BuddyBossApp Settings and Other Screens.
			( strpos( $_get_var( "page" ), "bbapp" ) !== false ) || // All bbApp Settings and Other Screens.
			in_array( $pagenow, array(
				'post-new.php',
				'edit.php',
				'post.php',
				'edit.php'
			) )  // Allow on all CPT edit pages. (App Editor)
		) {

			// load select2 library version 4.0.5
			wp_enqueue_script( 'bbapp_select2', $this->plugin_url . 'assets/libs/select2/select2.full.min.js', array( 'jquery' ), '4.0.5', true );
			wp_enqueue_style( 'bbapp_select2', $this->plugin_url . 'assets/libs/select2/select2.min.css', array(), '4.0.5' );

			// load croppie library version 2.6.4
			wp_register_script( 'bbapp_croppie', $this->plugin_url . 'assets/libs/croppie/croppie.min.js', array( 'jquery' ), '2.6.4', true );
			wp_register_style( 'bbapp_croppie', $this->plugin_url . 'assets/libs/croppie/croppie.min.css', array(), '2.6.4' );

			// load listjs library version 1.5.0
			wp_register_script( 'bbapp-list', $this->plugin_url . 'assets/libs/list.min.js', array( 'jquery' ), '1.5.0', true );

			// load fancybox library
			wp_enqueue_script( 'jquery-fancybox', bbapp()->plugin_url . 'assets/libs/fancybox/jquery.fancybox.js', array( 'jquery' ), '3.0.47', true );
			wp_enqueue_style( 'jquery-fancybox', bbapp()->plugin_url . 'assets/libs/fancybox/jquery.fancybox.css', array(), '3.0.47' );

			// Main js file @ admin backend.

			wp_enqueue_script( 'bbapp-script', $this->plugin_url . 'assets/js/admin.js', array(
				'jquery',
				'jquery-ui-dialog',
				'wp-i18n',
				'wp-util',
				'jquery-ui-autocomplete',
			), $this->plugin_version, true );

			/**
			 * Wp Color Picker.
			 */
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'wp-color-picker' );
			wp_register_script( 'wp-color-picker-alpha', $this->plugin_url . '/assets/libs/wp-color-picker-alpha.js', array( 'wp-color-picker' ), '3.0.0' );
			wp_enqueue_script( 'wp-color-picker-alpha' );

			// Register Tipsy version 1.0.3
			wp_register_script( 'bbapp-tipsy', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.tipsy/1.0.3/jquery.tipsy.js', array( 'jquery' ), '1.0.3' );
			wp_register_style( 'bbapp-tipsy', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.tipsy/1.0.3/jquery.tipsy.min.css', array(), '1.0.3' );

			// Register Bootstrap Date Picker version 1.0.3
			wp_register_script( 'bbapp-bootstrap-datepicker', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js', array( 'jquery' ), '1.9.0' );
			wp_register_style( 'bbapp-bootstrap-datepicker', 'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker3.standalone.min.css', array(), '1.9.0' );

			// Register AddClear. Read more @ : https://github.com/skorecky/Add-Clear version 2.0.6
			wp_register_script( 'bbapp-addclear', $this->plugin_url . '/assets/libs/addclear/addclear.min.js', array(), '2.0.6' );

			// Register ClipBoard. Read more @ : https://github.com/zenorocha/clipboard.js 2.0.4
			wp_register_script( 'bbapp-clipboard', $this->plugin_url . '/assets/libs/clipboard.min.js', array(), '2.0.4' );

			$icons_path = IconPicker::instance()->icon_picker_app_icon_url();

			$is_app_page = false;
			if ( 'app_page' === $post_type ) {
				$is_app_page = true;
			}

			// Help URL
			$bbapp_help_base_url = bbapp_get_super_admin_url( "admin.php?page=bbapp-help" );

			// Localize.
			wp_localize_script( 'bbapp-script', 'bbapp_ajax', array(
				'ajaxurl'               => admin_url( 'admin-ajax.php' ),
				'siteurl'               => site_url(),
				'resturl'               => get_rest_url(),
				'rest_nonce'            => wp_create_nonce( 'wp_rest' ),
				'sort_nonce'            => wp_create_nonce( 'bbapp_sort_nonce_' . get_current_user_id() ),
				'icon_path'             => $icons_path,
				'is_app_page'           => $is_app_page,
				'bbapp_help_url'        => $bbapp_help_base_url,
				'bbapp_help_title'      => __( 'Docs', 'buddyboss-app' ),
				'bbapp_help_no_network' => __( '<strong>You are offline.</strong> Documentation requires internet access.', 'buddyboss-app' ),
			) );

			wp_localize_script( 'bbapp-script', 'bbapp_list_multilanguages', bbapp_get_multi_languages_list() );

			if ( realpath( bbapp()->plugin_dir . '/include/Admin/JSTranslationsStrings.php' ) ) {
				wp_localize_script( 'bbapp-script', 'bbapp_translations_string', include_once( bbapp()->plugin_dir . '/include/Admin/JSTranslationsStrings.php' ) );
			}

		}

		$rtl_css = is_rtl() ? '.rtl' : '';
		// Main css file @ admin backend
		wp_enqueue_style( 'bbapp_style', $this->plugin_url . 'assets/css/admin' . $rtl_css . '.css', array( 'wp-jquery-ui-dialog' ), $this->plugin_version );

	}

	/**
	 * Gutenberg Editor Block assets.
	 */
	public function block_editor_assets() {

		global $post;
		if ( is_admin() ) {

			$post_type = $post->post_type;
			if ( 'app_page' === $post_type ) {

				if ( wp_style_is( 'et-builder-gutenberg' ) ) {
					wp_dequeue_style( 'et-builder-gutenberg' );
				}

				if ( wp_script_is( 'et-builder-gutenberg' ) ) {
					wp_dequeue_script( 'et-builder-gutenberg' );
				}
			}

			wp_enqueue_script( $this->plugin_prefix . 'gutenberg', $this->plugin_url . 'assets/js/gutenberg.js', array(
				'wp-blocks',
				'wp-editor',
				'wp-i18n',
				'wp-element',
				'wp-editor',
				'wp-components',
				'wp-api',
				'wp-data',
				'wp-edit-post',
				'lodash',
			), $this->plugin_version, true );

			$activity_component = false;
			if ( class_exists( 'BuddyPress' ) && bp_is_active( 'activity' ) ) {
				$activity_component = true;
			}

			$groups_component = false;
			if ( class_exists( 'BuddyPress' ) && bp_is_active( 'groups' ) ) {
				$groups_component = true;
			}

			$members_component = false;
			if ( class_exists( 'BuddyPress' ) && bp_is_active( 'members' ) ) {
				$members_component = true;
			}

			wp_localize_script( $this->plugin_prefix . 'gutenberg', 'bbapp_gutenberg', array(
				'is_bbpress_enabled'            => function_exists( 'bbpress' ),
				'is_buddypress_enabled'         => class_exists( 'BuddyPress' ),
				'is_learndash_enabled'          => defined( 'LEARNDASH_VERSION' ),
				'is_activity_component_enabled' => $activity_component,
				'is_groups_component_enabled'   => $groups_component,
				'is_members_component_enabled'  => $members_component,
				'is_h5p_enabled'                => class_exists( 'H5P_Plugin' ),
			) );

			if ( function_exists( 'wp_set_script_translations' ) ) {
				wp_set_script_translations( $this->plugin_prefix . 'action', 'buddyboss-app' );
			}
		}

	}

	/**
	 * Register admin assets.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {
		wp_enqueue_style( $this->plugin_prefix . 'style', $this->plugin_url . 'assets/css/main.css', array(), $this->plugin_version );

		// Main js file @ frontend backend.
		wp_enqueue_script( $this->plugin_prefix . 'action', $this->plugin_url . 'assets/js/main.js', array( 'jquery' ), $this->plugin_version, true );
	}

	/**
	 * Loads text domain.
	 *
	 * @since 1.0.0
	 */
	public function load_textdomain() {
		$locale = apply_filters( 'plugin_locale', get_locale(), $this->domain );

		// first try to load from wp-content/languages/plugins/ directory
		load_textdomain( $this->domain, WP_LANG_DIR . '/plugins/' . $this->domain . '-' . $locale . '.mo' );

		// if not found, then load from plugin_folder/languages directory
		load_plugin_textdomain( $this->domain, false, basename( $this->domain ) . '/languages' );

	}

	/**
	 * When plugin activates we do some required updates.
	 *
	 * @param $network_wide
	 */
	public function on_plugin_activate( $network_wide ) {

		$this->on_database_update($network_wide);

		/**
		 * Add About Redirect Trigger
		 */
		set_transient( '_bbapp_activation_redirect', true, 60 * 2 );

		/**
		 * End Update structure of app info data
		 * --------------------------------------------------------------------
		 */

		do_action( "{$this->plugin_prefix}_on_plugin_activate" );
		do_action( "bbapp_on_plugin_activate" );
	}

	public function on_database_update( $network_wide ) {
		//  only way to know if plugin is activated network wide.
		$this->_network_activated = $network_wide;

		global $wpdb;
		if ( bbapp()->is_network_activated() ) {

			// Get all blogs in the network and activate plugin on each one
			$blog_ids = $wpdb->get_col( "SELECT blog_id FROM $wpdb->blogs" );
			foreach ( $blog_ids as $blog_id ) {
				switch_to_blog( $blog_id );

				// Create Gutenberg Default Page for BuddyBossApp Editor.
				bbapp_get_default_app_page();

				// Network Wide Tables.
				if ( 1 == $blog_id ) {
					$this->create_network_table();
				}

				// Create default App Pages
				NativeAppPage::instance()->create_default_apppage();

				restore_current_blog();
			}

		} else {

			$this->create_network_table();

			// Create Gutenberg Default Page.
			bbapp_get_default_app_page();

			// Create default App Pages
			NativeAppPage::instance()->create_default_apppage();

		}

		// Install/Upgrade Defaults Settings.
		ClientCommon::instance()->merge_default_app_settings();

		// Install other Default Settings.
		ClientCommon::instance()->merge_default_auth_settings();
	}

	public function on_plugin_deactivate() {

		do_action( "{$this->plugin_prefix}_on_plugin_deactivate" );
		do_action( "bbapp_on_plugin_deactivate" );

	}

	/**
	 * Create Table function
	 */
	private function create_network_table() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE {$wpdb->prefix}bbapp_user_devices (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id bigint(20) NOT NULL,
            device_token varchar(500) NOT NULL,
            device_token_hash varchar(70) NOT NULL,
            auth_token_hash varchar(70) NOT NULL,
            platform varchar(10) NOT NULL,
            app_ver varchar(12) NOT NULL,
            push_type varchar(20) NOT NULL,
            device_id varchar(20) NOT NULL,
            device_model varchar(20) NOT NULL,
            data longtext DEFAULT NULL,
            date_registered datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_updated datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_active datetime DEFAULT '0000-00-00 00:00:00' NULL,
            KEY device_token_hash (device_token_hash),
            KEY auth_token_hash (auth_token_hash),
            KEY user_id (user_id),
            KEY date_registered (date_registered),
            KEY date_updated (date_updated),
            KEY date_active (date_active),
            KEY app_ver (app_ver),
            KEY push_type (push_type)
        ) {$charset_collate}";

		dbDelta( $sql );

		// Upgrade Table Data.
		bbapp_table_fix_wp_bbapp_user_devices();

		// Store all notification for backend purpose.
		$sql2 = "CREATE TABLE {$wpdb->prefix}bbapp_push_notifications (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            action varchar(30) NOT NULL,
            primary_text varchar(500) NOT NULL,
            secondary_text varchar(500) DEFAULT NULL,
            target_type varchar(30) DEFAULT NULL,
            target bigint(20) DEFAULT NULL,
            sent_as bigint(20) DEFAULT 0,
            data longtext DEFAULT NULL,
            agent varchar(100) DEFAULT 'event' NULL,
            status varchar(100) DEFAULT 'sent' NULL,
            is_schedule tinyint(1) DEFAULT '0' NULL,
            date_schedule datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_expire datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_updated datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_created datetime DEFAULT '0000-00-00 00:00:00' NULL,
            blog_id bigint(20) NOT NULL,
            KEY target (target),
            KEY date_created (date_created),
            KEY date_updated (date_updated),
            KEY is_schedule (is_schedule),
            KEY date_expire (date_expire),
            KEY sent_as (sent_as),
            KEY agent (agent)
        ) {$charset_collate}";

		dbDelta( $sql2 );

		// Stores all notification for notification endpoint purpose.
		$sql3 = "CREATE TABLE {$wpdb->prefix}bbapp_notifications (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            date_notified datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            action varchar(20) DEFAULT '' NOT NULL,
            namespace varchar(20) DEFAULT '' NOT NULL,
            primary_text varchar(500) DEFAULT '' NOT NULL,
            secondary_text varchar(500) DEFAULT '' DEFAULT NULL,
            component_name varchar(75) DEFAULT '' NOT NULL,
            component_action varchar(75) DEFAULT '' NOT NULL,
            user_id bigint(20) DEFAULT 0 NOT NULL,
            author_id bigint(20) DEFAULT 0 NOT NULL,
            item_id bigint(20) DEFAULT 0 NOT NULL,
            secondary_item_id bigint(20) DEFAULT 0 NOT NULL,
            blog_id bigint(20) DEFAULT 0 NOT NULL,
            unread tinyint(0) DEFAULT 1 NOT NULL,
            version tinyint(0) DEFAULT 1 NOT NULL,
            KEY action (action),
            KEY user_id (user_id),
            KEY item_id (item_id),
            KEY secondary_item_id (secondary_item_id),
            KEY blog_id (blog_id),
            KEY unread (unread),
            KEY component_name (component_name),
            KEY component_action (component_action),
            KEY version (version)
        ) $charset_collate;";

		if ( $wpdb->query( "SELECT * FROM information_schema.tables WHERE table_schema = '{$wpdb->dbname}' AND table_name = '{$wpdb->prefix}bbapp_notifications' LIMIT 1;" ) ) {
			// Set Default to Deprecated Columns.
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}bbapp_notifications ALTER COLUMN primary_text SET DEFAULT ''" );
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}bbapp_notifications ALTER COLUMN secondary_text SET DEFAULT ''" );
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}bbapp_notifications ALTER COLUMN namespace SET DEFAULT ''" );
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}bbapp_notifications ALTER COLUMN action SET DEFAULT ''" );
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}bbapp_notifications ALTER COLUMN author_id SET DEFAULT 0" );
			$wpdb->query( "ALTER TABLE {$wpdb->prefix}bbapp_notifications ALTER COLUMN blog_id SET DEFAULT 0" );
		}

		dbDelta( $sql3 );

		// Stores the queue
		$sql4 = "CREATE TABLE {$wpdb->prefix}bbapp_queue (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            modified datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            type varchar(20) NOT NULL,
            data text DEFAULT NULL,
            priority tinyint(2) NOT NULL,
            blog_id bigint(20) NOT NULL,
            KEY created (created),
            KEY modified (modified),
            KEY type (type),
            KEY priority (priority),
            KEY blog_id (blog_id)
        ) $charset_collate;";

		dbDelta( $sql4 );

		// Stores the push queue
		$sql5 = "CREATE TABLE {$wpdb->prefix}bbapp_push_queue (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            n_id bigint(20) NOT NULL,
            created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            device text DEFAULT NULL,
            unique_hash varchar(100) NOT NULL,
            user_id bigint(20) NOT NULL,
            type varchar(50) NOT NULL,
            agent varchar(50) NOT NULL,
            data text DEFAULT NULL,
            priority tinyint(2) NOT NULL,
            sent tinyint(1) NOT NULL,
            KEY created (created),
            KEY unique_hash (unique_hash),
            KEY user_id (user_id),
            KEY type (type),
            KEY agent (agent),
            KEY priority (priority),
            KEY sent (sent)
        ) $charset_collate;";

		dbDelta( $sql5 );

		// Stores the Logs
		$sql6 = "CREATE TABLE {$wpdb->prefix}bbapp_logs (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            ref_id bigint(20) NOT NULL,
            created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            type varchar(20) NOT NULL,
            blog_id bigint(20) NOT NULL,
            text text DEFAULT NULL,
            KEY ref_id (ref_id),
            KEY blog_id (blog_id),
            KEY created (created),
            KEY type (type)
        ) $charset_collate;";

		dbDelta( $sql6 );

		// UserSegment
		$sql7 = "CREATE TABLE {$wpdb->prefix}bbapp_user_segment (
			id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            user_id bigint(20) NOT NULL,
            segment_group varchar(30) NOT NULL,
            segment_id varchar(30) NOT NULL,
            created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            expire datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            KEY user_id (user_id),
            KEY segment_group (segment_group),
            KEY created (created),
            KEY expire (expire),
            KEY segment_id (segment_id)
        ) $charset_collate;";

		dbDelta( $sql7 );

		$max_index_length = 191;
		// push notification meta Table.
		$sql8 = "CREATE TABLE {$wpdb->prefix}bbapp_push_notifications_meta (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
			push_id bigint(20) NOT NULL,
			meta_key varchar(255) DEFAULT NULL,
			meta_value mediumtext DEFAULT NULL,
			KEY push_id (push_id),
			KEY meta_key (meta_key({$max_index_length}))
        ) {$charset_collate}";

		dbDelta( $sql8 );

		// Push notification history
		$sql9 = "CREATE TABLE {$wpdb->prefix}bbapp_push_notifications_history (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            type varchar(100) DEFAULT 'custom',
            status int(1) DEFAULT 0,
            user_id bigint(20) DEFAULT NULL,
            processed_at datetime DEFAULT '0000-00-00 00:00:00',
            item_id bigint(20) DEFAULT 0,
            secondary_id bigint(20) DEFAULT 0,
            device varchar(20) DEFAULT NULL,
            platform varchar(10) DEFAULT NULL,
            blog_id bigint(20) NOT NULL,
            KEY type (type),
            KEY status (status),
            KEY user_id (user_id),
            KEY processed_at (processed_at),
            KEY item_id (item_id)
        ) {$charset_collate};";
		dbDelta( $sql9 );

		// Create Auth Related Tables
		\BuddyBossApp\Auth\Auth::instance()->on_activation();

		// Create IAP Related Tables
		\BuddyBossApp\InAppPurchases\Controller::instance()->on_activation();
		\BuddyBossApp\InAppPurchases\Orders::instance()->on_activation();

		// Create Meta API Related Tables
		MetaApi::instance()->on_activation();

		if ( class_exists( '\BuddyBoss\Performance\Performance' ) ) {
			\BuddyBoss\Performance\Performance::instance()->on_activation();
		}
	}

	/**
	 * Add admin notice if non supported activated
	 */
	function min_supported_plugin_admin_notices() {

		if ( defined( 'BP_PLATFORM_VERSION' ) && version_compare( BP_PLATFORM_VERSION, '1.5.7.3', '<' ) ) {
			printf(
			/* translators: 1. div classes. 2. notice message. 3. Admin update page url. 4. link text.  */
				'<div class="%1$s"><p>%2$s <a href="%3$s">%4$s</a></p></div>',
				esc_attr( 'notice notice-error' ),
				__( 'The BuddyBoss App plugin requires a minimum BuddyBoss Platform version 1.5.7.3.', 'buddyboss-app' ),
				esc_url( admin_url( 'update-core.php' ) ),
				__( 'Please update BuddyBoss Platform.', 'buddyboss-app' )
			);
		}
	}

	/**
	 * Add admin notice if app center in app disabled.
	 */
	function app_disable_admin_notices() {
		echo "<div class='notice notice-error is-dismissible'>";
		include __DIR__ . '/views/settings/app-is-disabled.php';
		echo "</div>";
	}
}

/**
 * Easy to call function.
 * @return bbapp
 */
function bbapp() {
	return bbapp::instance();
}

/**
 * Easy to call function alias for bbapp() func.
 */
function bbapp_client() {
	return bbapp();
}

// Register BuddyBossApp Menu.
function register_bbapp_menu_page() {

	// Set position with odd number to avoid conflict with other plugin/theme.
	add_menu_page( 'BuddyBoss App', __( 'BuddyBoss App', 'buddyboss-app' ), 'manage_options',
		'bbapp-settings', '', bbapp()->plugin_url . 'assets/img/buddyboss-app-icon.svg', 4 );

	// To remove empty parent menu item.
	add_submenu_page( 'bbapp-settings', __( 'BuddyBoss App', 'buddyboss-app' ),
		__( 'BuddyBoss App', 'buddyboss-app' ), 'manage_options', 'bbapp-settings' );

	remove_submenu_page( 'bbapp-settings', 'bbapp-settings' );

}
