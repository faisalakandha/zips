<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Admin\Configure;
use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\Logger;
use Google_Client;
use Google_Exception;
use Google_Service_AndroidPublisher;
use WP_Error as WP_Error;

// use ReceiptValidator\GooglePlay\Validator;

final class Android extends StoreAbstract {

	private static $instance = null;

	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 * @return Controller|null
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Initialize IntegrationAbstract
	 */
	public function init() {

		// Device platform type
		$platform_type = "android";

		$store_product_types = Helpers::platformStoreProductTypes( $platform_type );

		// Register StoreAbstract Type
		parent::set_up( $platform_type, __( 'Android', 'buddyboss-app' ), $store_product_types );

		// Register instance
		bbapp_iap()->iap[ $platform_type ] = $this::instance();

		// Register integration
		bbapp_iap()->integration[ $platform_type ] = $store_product_types;
	}

	/**
	 * For rendering product settings
	 *
	 * @param $integration
	 * @param $item
	 */
	public function render_product_settings( $integration, $item ) {
	}

	/**
	 * For saving product settings
	 *
	 * @param $integration
	 * @param $item
	 */
	public function save_product_settings( $integration, $item ) {
	}

	/**
	 * Returns Android Publisher.
	 * @return \Google_Service_AndroidPublisher | WP_Error
	 * @throws Google_Exception
	 */
	public function get_android_publisher() {
		$file_name = Configure::instance()->option( 'publish.android.account_key' );

		$google_service_account_json = bbapp_get_upload_full_path( $file_name );

		$google_service_account_name = __( "Play Publisher", 'buddyboss-app' );

		if ( empty( $file_name ) || ! file_exists( $google_service_account_json ) ) {
			return new WP_Error( 'google_iap_not_configured', __( 'Google In-App Purchase setup is not configured. Please configure it on admin settings.', 'buddyboss-app' ) );
		}

		$google_client = new Google_Client();
		$google_client->setApplicationName( $google_service_account_name );
		$google_client->setScopes( "https://www.googleapis.com/auth/androidpublisher" );
		$google_client->setAuthConfig( $google_service_account_json );

		$google_android_publisher = new Google_Service_AndroidPublisher( $google_client );

		return $google_android_publisher;
	}

	/**
	 * Should be override by iap type.
	 *
	 * @param $data
	 *
	 * @return WP_Error
	 * @throws \Google_Exception
	 * @uses StoreAbstract::_process_payment()
	 */
	public function process_payment( $data ) {

		$bbapp_product_id = $data["bbapp_product_id"]; // BuddyBossAppProduct ID
		$store_product_type = $data["store_product_type"]; // Store Product Type
		$store_product_id   = trim( $data["store_product_id"] ); // Store Product ID
		$iap_receipt_token  = trim( $data["iap_receipt_token"] ); //Receipt Token

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", sprintf( "BuddyBossApp\InAppPurchases\Android->process_payment(),BuddyBossAppProductId: %s, storeProductType: %s, storeProductId: %s ", $bbapp_product_id, $store_product_type, $store_product_id ) );
		}

		//NOTE : Getting appnamespace(package name) stored in _options table
		$app_namespace = Configure::instance()->option( 'publish.android.namespace' );

		if ( ! isset( $app_namespace ) || empty( $app_namespace ) ) {
			return new WP_Error( 'configuration_error', __( 'No app configuration found. <a href="admin.php?page=bbapp-build">here</a>', 'buddyboss-app' ) );
		}

		$transaction_data = array(
			"transaction_date"      => null,
			"parent_transaction_id" => null,
			"transaction_id"        => null,
			"data"                  => array(),
			"expire_at"             => false, // should be given if product is recurring.
		);

		$google_android_publisher = $this->get_android_publisher();

		if ( is_wp_error( $google_android_publisher ) ) {
			return $google_android_publisher;
		}

		try {

			/**
			 * Managed Product have below types :
			 * 1. Consumable (We're not supporting it)
			 * 2. Non-Consumable.
			 */

			if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {

				$product_response = $google_android_publisher->purchases_subscriptions->get(
					$app_namespace, $store_product_id, $iap_receipt_token
				);

				//NOTE : Below is another way to validate
				// $validator = new Validator($googleAndroidPublisher);
			} else {
				$product_response = $google_android_publisher->purchases_products->get(
					$app_namespace, $store_product_id, $iap_receipt_token
				);

				//NOTE : Below is another way to validate
				// $validator = new Validator($googleAndroidPublisher);
			}

			// Validate if response is correct
			if ( ! isset( $product_response->orderId ) ) {

				$refId = @$data["order_id"];
				bbapp_iap_add_logs( "bbapp_iap_google", "Invalid Google InAppPurchase Response - \n\n " . print_r( $product_response, true ), $refId );

				return new WP_Error( 'error_iap_validation', __( 'Error while reading In-App Purchase Token. Response found to be invalid.', 'buddyboss-app' ) );
			}

			$order_id        = $product_response->orderId;
			$parent_order_id = $order_id;

			if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {
				// remove postfix if available to get original order_id
				$parent_order_id = explode( "..", $parent_order_id );
				$parent_order_id = $parent_order_id[0];

				$transaction_data["expire_at"] = date( "Y-m-d H:i:s", $product_response->expiryTimeMillis / 1000 );

				// Validate Expiry
				$time = strtotime( gmdate( "Y-m-d H:i:s" ) );
				if ( strtotime( $transaction_data["expire_at"] ) < $time ) {
					return new WP_Error( 'error_iap_validation', __( 'Google purchase has expired.', 'buddyboss-app' ) );
				}

			}

			// Check if it's nt exists.
			$iap_exists = $this->do_transaction_exists( $parent_order_id );

			if ( ! empty( $iap_exists ) ) {

				/**
				 * On none consumable product type. we allow one to be restore if user account is same.
				 */
				if ( ! in_array( $store_product_type, array( 'non_consumable', 'auto_renewable' ) ) ) {

					return new WP_Error( 'error_iap_validation', __( 'Matching product(s) found, but no usable transaction found.', 'buddyboss-app' ) );
				}

				if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {

					$subscription_order = false; // holds false until we found any useful order in existing order.

					foreach ( $iap_exists as $order ) {
						if ( in_array( $order->order_status, array( 'subscribed', 'completed' ) ) ) {
							$subscription_order = true; // found one valid 'subscribed' order.
						}
					}

					// looks like subscription is already being used by another order.
					if ( $subscription_order ) {
						return new WP_Error( 'error_iap_validation', __( 'Subscription is already being used on another order.', 'buddyboss-app' ) );
					}

				}

			}

			$transaction_data["data"]["sandbox"] = ( isset( $product_response->purchaseType ) && $product_response->purchaseType == "0" ) ? 1 : 0;

			$transaction_data["transaction_id"]        = $order_id;
			$transaction_data["parent_transaction_id"] = $parent_order_id;

			if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {
				$transaction_data["transaction_date"]    = date( 'Y-m-d H:i:s', $product_response->startTimeMillis / 1000 );
				$transaction_data["transaction_date_ms"] = $product_response->startTimeMillis;
			} else {
				$transaction_data["transaction_date"]    = date( 'Y-m-d H:i:s', $product_response->purchaseTimeMillis / 1000 );
				$transaction_data["transaction_date_ms"] = $product_response->purchaseTimeMillis;
			}

			// Extra data for future purpose.
			if ( isset( $product_response->purchaseTimeMillis ) ) {
				$transaction_data["data"]["transaction_date_ms"] = $product_response->purchaseTimeMillis;
			}
			if ( isset( $product_response->startTimeMillis ) ) {
				$transaction_data["data"]["transaction_date_ms"] = $product_response->startTimeMillis;
			}

			$transaction_data["data"]["purchase_kind"] = $product_response->kind;
			if ( isset( $product_response->purchaseState ) ) {
				$transaction_data["data"]["purchase_state"] = $product_response->purchaseState;
			}
			if ( isset( $product_response->paymentState ) ) {
				$transaction_data["data"]["payment_state"] = $product_response->paymentState;
			}
			if ( isset( $product_response->profileId ) ) {
				$transaction_data["data"]["profileId"] = $product_response->profileId;
			}
			if ( isset( $product_response->profileName ) ) {
				$transaction_data["data"]["profile_name"] = $product_response->profileName;
			}
			if ( isset( $product_response->linkedPurchaseToken ) ) {
				$transaction_data["data"]["linked_purchase_token"] = $product_response->linkedPurchaseToken;
			}

			$transaction_data["data"]["trial_period"] = false;

			if ( isset( $product_response->paymentState ) && $product_response->paymentState == "2" ) {
				$transaction_data["data"]["trial_period"] = true;
				$transaction_data["data"]["had_trial"]    = true;
			}

			return $transaction_data;

		} catch ( \Exception $e ) {

			$json = json_decode( $e->getMessage() );

			$reason = "";

			if ( isset( $json->error ) && isset( $json->error->errors ) && isset( $json->error->errors[0] ) ) {

				/**
				 * Possible/Known Reason
				 * purchaseTokenDoesNotMatchProductId || purchaseTokenDoesNotMatchSubscriptionId
				 */
				$reason = $json->error->errors[0]->reason;

			}

			$refId = @$data["order_id"];

			bbapp_iap_add_logs( "bbapp_iap_google", "Error while validation error - \n\n " . $reason, $refId );

			return new WP_Error( 'error_iap_validation', sprintf( __( 'Error while reading InAppPurchase token, could be invalid receipt token. Reason : %s.', 'buddyboss-app' ), $reason ) );

		}

	}

	/**
	 * Validates order payment status
	 *
	 * @param $data
	 *
	 * @return mixed
	 * @throws Google_Exception
	 */
	public function validate( $data ) {

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Android->validate()" );
		}

		$bbapp_product_id = $data["bbapp_product_id"]; // BuddyBossAppProduct ID
		$iap_receipt_token  = trim( $data["iap_receipt_token"] );
		$store_product_type = trim( $data["store_product_type"] );
		$store_product_id   = trim( $data["store_product_id"] );

		$transaction_data = array(
			'status'                => '',
			'transaction_date'      => '',
			'parent_transaction_id' => '',
			'transaction_id'        => '',
			'data'                  => array(),
			'expire_at'             => '',
			'history'               => array(),
		);

		$google_android_publisher = $this->get_android_publisher();

		if ( is_wp_error( $google_android_publisher ) ) {
			return $google_android_publisher;
		}

		//NOTE : Getting appnamespace(package name) stored in _options table
		$app_namespace = Configure::instance()->option( 'publish.android.namespace' );

		if ( ! isset( $app_namespace ) || empty( $app_namespace ) ) {
			return new WP_Error( 'configuration_error', __( 'Error while retrieving appnamespace, Android namespace not found(or configured). Configure <a href="admin.php?page=bbapp-build">here</a>', 'buddyboss-app' ) );
		}

		try {

			if ( ! in_array( $store_product_type, array( 'non_consumable', 'auto_renewable' ) ) ) {
				return new WP_Error( 'error_iap_validation', __( 'Error while reading InAppPurchase token, Invalid Product Type.', 'buddyboss-app' ) );
			}

			$product_response = $google_android_publisher->purchases_subscriptions->get(
				$app_namespace, $store_product_id, $iap_receipt_token
			);

			// validate the response is correct
			if ( ! isset( $product_response->orderId ) ) {
				return new WP_Error( 'error_iap_validation', __( 'Error while reading InAppPurchase token, Response found to be invalid.', 'buddyboss-app' ) );
			}

			$order_id        = $product_response->orderId;
			$parent_order_id = $order_id;

			if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {

				// remove postfix if available to get original order_id
				$parent_order_id = explode( "..", $parent_order_id );
				$parent_order_id = $parent_order_id[0];

				$transaction_data["expire_at"] = date( "Y-m-d H:i:s", $product_response->expiryTimeMillis / 1000 );

			}

			$transaction_data["data"]["sandbox"] = ( isset( $product_response->purchaseType ) && $product_response->purchaseType == "0" ) ? 1 : 0;

			$transaction_data["transaction_id"]        = $order_id;
			$transaction_data["parent_transaction_id"] = $parent_order_id;

			if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {
				$transaction_data["transaction_date"] = date( 'Y-m-d H:i:s', $product_response->startTimeMillis / 1000 );
			} else {
				$transaction_data["transaction_date"] = date( 'Y-m-d H:i:s', $product_response->purchaseTimeMillis / 1000 );
			}

			// Extra data for future purpose.
			if ( isset( $product_response->purchaseTimeMillis ) ) {
				$transaction_data["data"]["transaction_date_ms"] = $product_response->purchaseTimeMillis;
			}
			if ( isset( $product_response->startTimeMillis ) ) {
				$transaction_data["data"]["transaction_date_ms"] = $product_response->startTimeMillis;
			}

			if ( isset( $product_response->purchaseState ) ) {
				$transaction_data["data"]["purchase_state"] = $product_response->purchaseState;
			}
			if ( isset( $product_response->paymentState ) ) {
				$transaction_data["data"]["payment_state"] = $product_response->paymentState;
			}

			// Validate Expiry
			$time = strtotime( gmdate( "Y-m-d H:i:s" ) );

			if ( strtotime( $transaction_data["expire_at"] ) < $time ) {

				// Looks like transaction is expired.
				$transaction_data["status"] = "expired";

				// Check if it's not really cancel then give some retry.
				if ( isset( $product_response->autoRenewing ) && $product_response->autoRenewing && ! is_int( $product_response->cancelReason ) ) {
					$transaction_data["retrying"];

					return $transaction_data;
				}

				$expire_reason                                           = $this->get_cancel_text_reason( $product_response->cancelReason );
				$transaction_data["history"][]                           = sprintf( __( "Expire Reason : %s", 'buddyboss-app' ), $expire_reason );
				$transaction_data["data"]["last_expiration_reason_code"] = $product_response->cancelReason;

				if ( isset( $product_response->userCancellationTimeMillis ) ) {
					$transaction_data["data"]["userCancellationTimeMillis"] = $product_response->userCancellationTimeMillis;
				}

			} else {

				// Trial stuff
				$transaction_data["data"]["trial_period"] = false;
				if ( isset( $product_response->paymentState ) && $product_response->paymentState == "2" ) {
					$transaction_data["data"]["trial_period"]        = true;
					$transaction_data["data"]["transaction_history"] = __( "Transaction is renewed as free trial.", "buddyboss-app" );
				}

				$transaction_data["status"] = "subscribed";

			}

			return $transaction_data;

		} catch ( \Exception $e ) {

			$json   = json_decode( $e->getMessage() );
			$reason = "";

			if ( isset( $json->error ) && isset( $json->error->errors ) && isset( $json->error->errors[0] ) ) {

				/**
				 * Possible/Known Reason
				 * purchaseTokenDoesNotMatchProductId || purchaseTokenDoesNotMatchSubscriptionId
				 */
				$reason = $json->error->errors[0]->reason;

			}

			return new WP_Error( 'error_iap_validation', sprintf( __( 'Error while reading InAppPurchase token, could be invalid receipt token. Reason : %s.', 'buddyboss-app' ), $reason ) );

		}

	}

	/**
	 * Returns reason of cancel in text.
	 *
	 * @param $code
	 *
	 * @return mixed
	 */
	public function get_cancel_text_reason( $code ) {
		switch ( $code ) {
			case '0':
				return __( "User cancelled the subscription.", "buddyboss-app" );
				break;

			case '1':
				return __( "Subscription was cancelled by the system. For example, due to a billing problem.", "buddyboss-app" );
				break;

			case '2':
				return __( "Subscription was replaced with a new subscription.", "buddyboss-app" );
				break;

			case '3':
				return __( "Subscription was cancelled by the developer.", "buddyboss-app" );
				break;

			default:
				return __( 'Unknown', 'buddyboss-app' );
				break;
		}
	}

	/**
	 * Sync store product with local data.
	 */
	public function sync_store_product() {

		$products = \BuddyBossApp\AppStores\Android::instance()->_sync_store_product();

		update_option( "bbapp_{$this->type}_store_product", $products );

		return $products;
	}
}