<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\Admin\InAppPurchases\ProductHelper;
use BuddyBossApp\RestErrors;
use WP_Error as WP_Error;

final class Orders {

	private static $instance = null;

	public $table_name = "bbapp_iap_orders";
	public $table_meta_name = "bbapp_iap_ordermeta";

	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @return Orders
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->set_table_name();
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * Set database table name.
	 *
	 * @return void
	 */
	public function set_table_name() {
		global $wpdb;

		$prefix = $wpdb->prefix;

		if ( is_multisite() ) {
			switch_to_blog( 1 );
			$prefix = $wpdb->prefix;
			restore_current_blog();
		}

		$this->table_name      = $prefix . $this->table_name;
		$this->table_meta_name = $prefix . $this->table_meta_name;

	}

	/**
	 * All hooks here
	 * @return void
	 */
	public function hooks() {
		add_action( 'init', array( $this, 'handle_notification' ) );
		add_action( 'delete_user', array( $this, 'revoke_order_for_delete_user' ), 10, 1 );
		add_action( 'init', array( $this, 'web_login_check_pending_orders_make_as_complete' ), 15 );
		add_action( 'bp_rest_signup_create_item', array( $this, 'bp_rest_signup_create_item_with_order_id' ), 10, 3 );
		add_action( 'bbapp_auth_rest_user_registration_after', array(
			$this,
			'bbapp_auth_rest_user_registration_after_with_order_id'
		), 10, 2 );

	}

	/**
	 * This function checks user pending orders as soon as possible when they login & assign it.
	 * This is useful when user has purchased the product when user is not logged in phase.
	 * We find user orders by matching their email to iap unassigned orders and then we
	 * change product status to complete.
	 *
	 * Reference - check order IAP without user authentication.
	 *
	 * @param $user
	 */
	public function web_login_check_pending_orders_make_as_complete() {
		if ( is_user_logged_in() ) {
			// Get order is which has custom order status.
			$order_ids = Orders::instance()->get_orders_ids_by_meta( '_custom_order_status', 'pending_complete' );

			$user = wp_get_current_user();
			$orders_obj = $this->get_orders( array(
				"id"           => $order_ids,
				"order_status" => 'pending',
				"user_email"   => $user->user_email,
			) );

			if ( ! empty( $orders_obj ) ) {
				foreach ( $orders_obj as $order ) {
					$_iap_receipt_token = $this->get_meta( $order->id, "_iap_receipt_token" );
					$order_args         = array(
						'user_id'           => get_current_user_id(),
						'order_id'          => $order->id,
						'iap_receipt_token' => $_iap_receipt_token,
					);
					$completed_order    = $this->completing_order( $order_args );
					if ( ! is_wp_error( $completed_order ) && 'completed' === $completed_order->order_status ) {
						// Update Order Register user order custom status.
						// @todo always execute this after running completeing_order to avoid infinite loop.
						$this->update_meta( $order->id, "_custom_order_status", 'completed' );
					} else {
						$iap_error = is_wp_error( $completed_order ) ? $completed_order->get_error_message() : __( 'Something went wrong.', 'buddyboss-app' );
						$this->add_history( $order->id, 'iap-error', sprintf( __( 'Completing Error : %s', 'buddyboss-app' ), $iap_error ) );
						$this->update_meta( $order->id, "_custom_order_status", 'failed' );
					}
				}
			}
		}
	}

	/**
	 * When create new user update order user email.
	 *
	 * @param $signup
	 * @param $response
	 * @param $request
	 */
	public function bp_rest_signup_create_item_with_order_id( $signup, $response, $request ) {
		$order_id = $request->get_param( 'iap_order_id' );
		if ( ! empty( $order_id ) ) {
			$this->update_order( $order_id, array(
				"user_email" => $signup->user_email,
			) );
		}
	}

	/**
	 * When create new user update order user email.
	 *
	 * @param $user_id
	 * @param $request
	 */
	public function bbapp_auth_rest_user_registration_after_with_order_id( $user_id, $request ) {
		$order_id = $request->get_param( 'iap_order_id' );
		if ( ! empty( $order_id ) ) {
			$email = $request->get_param( 'email' );
			$this->update_order( $order_id, array(
				"user_email" => $email,
			) );
		}
	}

	/**
	 * Revoke order when user delete.
	 *
	 * @param $user_id
	 */
	public function revoke_order_for_delete_user( $user_id ) {
		$order_args = array(
			'order_status' => 'completed',
			'user_id'      => $user_id,
		);

		$orders_obj = $this->get_orders( $order_args );
		if ( ! empty( $orders_obj ) ) {
			foreach ( $orders_obj as $order ) {
				$success = Orders::instance()->cancel_order( $order->id, __( "Order has been cancelled. Because this user #$user_id is deleted.", "buddyboss-app" ) );
				if ( ! is_wp_error( $success ) ) {
					// Store cancel detail on meta.
					Orders::instance()->update_meta( $order->id, "order_cancelled_manually", 1 );
					Orders::instance()->update_meta( $order->id, "order_cancelled_user_id", $user_id );
				}
			}
		}
	}

	/**
	 * Creating the order.
	 * This Function is responsible for creating order.
	 * This function validates the all supported stores order receipt.
	 * This function keeps the order into pending state when product is purchased in none user authentication mode.
	 *
	 * @param $order_args
	 * @param $iap
	 *
	 * @return array|mixed|WP_Error
	 */
	public function creating_order( $order_args, $iap ) {

		$bbapp_product_id  = $order_args['bbapp_product_id'];
		$device_platform   = $order_args['device_platform'];
		$blog_id           = $order_args['blog_id'];
		$iap_receipt_token = $order_args['iap_receipt_token'];
		$user_id           = $order_args['user_id'];
		$user_email        = $order_args['user_email'];
		$test_mode         = $order_args['test_mode'];

		$bbapp_product     = $iap->get_product( $bbapp_product_id );
		$store_data        = unserialize( $bbapp_product['store_data'] );
		$store_product_ids = $store_data["store_product_ids"];
		$store_product_id  = $store_product_ids[ $device_platform ];

		$store_product_types = $store_data["store_product_types"];
		$store_product_type  = $store_product_types[ $device_platform ];

		$bbapp_product_type = $store_data["bbapp_product_type"];

		$is_recurring = Helpers::isRecurringType( $store_product_type );

		// Check if iap product id is not available OR Check if iap product is not trashed
		if ( empty( $bbapp_product ) || ( isset( $bbapp_product['status'] ) && 'trash' === $bbapp_product['status'] ) ) {
			return new WP_Error( 'purchase_not_available', __( "Product not found.", 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		$integration_data = unserialize( $bbapp_product['integration_data'] );
		$misc_settings    = unserialize( $bbapp_product['misc_settings'] );

		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings
		if ( bbapp()->is_network_activated() ) {
			$misc_settings    = $misc_settings[ $blog_id ];
			$integration_data = $integration_data[ $blog_id ];
		}

		$integration_types       = array();
		$item_ids                = array();
		$active_integration_slug = $misc_settings['integration_type'];
		$integration_slugs       = array_keys( $integration_data );
		$integration             = false;

		foreach ( $integration_slugs as $integration_slug ) {
			if ( $active_integration_slug == $integration_slug ) {
				if ( isset( bbapp_iap()->integrations[ $integration_slug ] ) ) {
					$integration_details = bbapp_iap()->integrations[ $integration_slug ];
					$integration_type    = $integration_details['type'];
					$integration         = Helpers::getIntegrationInstance( $integration_slug );
					if ( bbapp()->is_network_activated() ) {
						$integration_types[ $blog_id ] = $integration_type;
						$item_ids[ $blog_id ]          = array( $integration_type => serialize( $integration_data[ $integration_slug ] ) );
					} else {
						$integration_types[]           = $integration_type;
						$item_ids[ $integration_type ] = serialize( $integration_data[ $integration_slug ] );
					}
				}

			}

		}

		if ( ! $integration ) {
			return new WP_Error( 'purchase_not_available', __( "We don't have any supported integration available.", 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		if ( ! empty( $user_id ) ) {
			$userdata   = get_userdata( $user_id );
			$user_email = $userdata->user_email;
		}

		// Create a new order.
		$order = $this->create_order( array(
			"bbapp_product_id"  => $bbapp_product_id,
			"device_platform"   => $device_platform,
			"store_product_id"  => $store_product_id,
			"integration_types" => serialize( $integration_types ),
			"item_ids"          => serialize( $item_ids ),
			"is_recurring"      => $is_recurring,
			"user_id"           => $user_id,
			"user_email"        => $user_email,
			"blog_id"           => $blog_id,
		) );

		if ( empty( $order ) || is_wp_error( $order ) ) {
			$error = $order->get_error_message();

			return new WP_Error( 'error_creating_order', sprintf( __( "There is an error while creating purchase :- %s.", 'buddyboss-app' ), $error ), array(
				'status' => 500,
				'more'   => 'simple purchase creation failed'
			) );
		}

		if ( empty( $user_id ) ) {
			// Update Order Non register user order custom status.
			$this->update_meta( $order->id, "_custom_order_status", 'pending_complete' );
		}

		// Update Order Basic Information.
		$this->update_meta( $order->id, "_iap_receipt_token", $iap_receipt_token );
		//Eg : ios or android
		$this->update_meta( $order->id, "_device_platform", $device_platform );
		//Eg : auto-renewable or further
		$this->update_meta( $order->id, "_store_product_type", $store_product_type );
		//Eg : free-# or paid-#
		$this->update_meta( $order->id, "_bbapp_product_type", $bbapp_product_type );
		//Eg : com.example.ios-# or com.example.android-#
		$this->update_meta( $order->id, "_store_product_id", $store_product_id );
		//Eg : learndash-course and/or memberpress and/or wc-memberships
		$this->update_meta( $order->id, "_integration_types", serialize( $integration_types ) );
		//Eg: testmode enable or disable.
		$this->update_meta( $order->id, "_transaction_data_test_mode", $test_mode );

		//Process Token Validation Tests.
		$verify = $iap->_process_payment( array(
			"order_id"           => $order->id,
			"test_mode"          => $test_mode,
			"iap_receipt_token"  => $iap_receipt_token,
			"bbapp_product_id"   => $bbapp_product_id,
			"store_product_id"   => $store_product_id,
			"store_product_type" => $store_product_type,
			"bbapp_product_type" => $bbapp_product_type,
			"integration_types"  => serialize( $integration_types ),
			"item_ids"           => serialize( $item_ids ),
		) );

		if ( is_wp_error( $verify ) || empty( $verify ) ) {

			$error = sprintf( __( "Error while validating purchase : %s", 'buddyboss-app' ), $verify->get_error_message() );

			$this->add_history( $order->id, 'iap-error', $error, $error );

			return new WP_Error( 'error_processing_order', __( "There is an error while processing purchase.", 'buddyboss-app' ), array(
				'status' => 500,
				'more'   => "verify-payment have issues, purchase ID is : " . $order->id
			) );

		}

		// update meta information.
		$this->update_meta( $order->id, "_transaction_id", $verify["transaction_id"] );
		$this->update_meta( $order->id, "_parent_transaction_id", $verify["parent_transaction_id"] );
		if ( isset( $verify["transaction_date"] ) ) {
			$this->update_meta( $order->id, "_transaction_date", $verify["transaction_date"] );
			$this->update_meta( $order->id, "_transaction_date_ms", $verify["transaction_date_ms"] );
		} else {
			$this->update_meta( $order->id, "_transaction_date", gmdate( "Y-m-d H:i:s" ) );
			$this->update_meta( $order->id, "_transaction_date_ms", strtotime( gmdate( "Y-m-d H:i:s" ) ) * 1000 );
		}

		// Store extras data from processPayment
		foreach ( $verify["data"] as $key => $value ) {
			$this->update_meta( $order->id, "_transaction_data_{$key}", $value );
		}

		$expire_at = null;
		if ( ! empty( $verify['expire_at'] ) ) {
			$expire_at = $verify['expire_at'];
		}

		// 1+ day from expire date. so we be sure renew process has correctly done.
		$next_order_validation = date( "Y-m-d H:i:s", strtotime( "+1 day", strtotime( $expire_at ) ) );

		// sandbox check should be instant so we will not keep safe margin.
		if ( isset( $verify["data"]["sandbox"] ) && $verify["data"]["sandbox"] ) {
			$next_order_validation = date( "Y-m-d H:i:s", strtotime( "+1 minute", strtotime( $expire_at ) ) );
		}

		$this->update_meta( $order->id, "_next_order_check", $next_order_validation );

		// Add expire-at when available. usually it's available on recurring order type.
		if ( $expire_at !== null ) {
			$this->update_order( $order->id, array(
				"expire_at" => date( "Y-m-d H:i:s", strtotime( $expire_at ) ),
			) );
		}

		return $order;
	}

	/**
	 * Process to complete the order with payment.
	 * This includes steps where users get the permissions of integrated integration in product.
	 *
	 * @param $order_args
	 * @param $iap
	 *
	 * @return null|array|object|void|WP_Error
	 */
	public function completing_order( $order_args ) {
		$order_id          = $order_args['order_id'];
		$iap_receipt_token = $order_args['iap_receipt_token'];
		$user_id           = $order_args['user_id'];

		/**
		 * Check user logged in permissions.
		 */
		if ( ! is_user_logged_in() ) {
			return RestErrors::instance()->user_not_logged_in();
		}

		// Get order.
		$order = Orders::instance()->get_by_id( $order_id );

		if ( is_wp_error( $order ) ) {
			return $order;
		}

		if ( ! isset( bbapp_iap()->iap[ $order->device_platform ] ) ) {
			return new WP_Error( 'invalid_device_platform', sprintf( __( "InAppPurchase for Platform(%s) you requested is currently not available.", 'buddyboss-app' ), $order->device_platform ), array( 'status' => 404 ) );
		}

		if ( empty( $order->bbapp_product_id ) ) {
			return new WP_Error( 'iap_product_id_missing', __( "InAppPurchase bbapp_product_id shouldn't be empty.", 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		/**
		 * @var $iap StoreAbstract
		 */
		// Order Basic Information.
		$_iap_receipt_token = $this->get_meta( $order->id, "_iap_receipt_token" );

		// Database token and provided token verify.
		if ( $iap_receipt_token !== $_iap_receipt_token ) {
			return new WP_Error( 'error_receipt_token', __( "Error while purchase : Purchase receipt token mismatch.", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		// if order status is not pending and order status is subscribed or completed return the error.
		if ( ! is_user_logged_in() && $user_id !== $order->user_id ) {
			return new WP_Error( 'error_order_status', __( "Error while purchase: Purchase user mismatch.", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		if ( empty( $order->user_id ) ) {
			// Get current user login data and update order data and meta data.
			$userdata = get_userdata( $user_id );

			// if order status is not pending and order status is subscribed or completed return the error.
			if ( $userdata->user_email !== $order->user_email ) {
				return new WP_Error( 'error_order_status', __( "Error while purchase: Purchase user email mismatch.", 'buddyboss-app' ), array( 'status' => 500 ) );
			}

			$this->update_order( $order->id, array(
				"user_id"    => $user_id,
				"user_email" => $userdata->user_email,
			) );
		}

		// run order status hook on integration.
		$complete_order = $this->complete_order( $order->id );

		if ( is_wp_error( $complete_order ) ) {
			$error = $complete_order->get_error_message();
			$this->add_history( $order->id, 'iap-error', sprintf( __( "Error completing purchase : %s", "buddyboss-app" ), $error ), $complete_order );

			return new WP_Error( 'error_processing_order', $error, array(
				'status' => 500,
				'more'   => 'complete order had issues'
			) );
		}

		$this->add_history( $order->id, 'success', __( "Purchase has been completed successfully.", "buddyboss-app" ) );

		return $complete_order;
	}

	/**
	 * If user has already order return the order if not so return false.
	 *
	 * @param string $iap_receipt_token IAP receipt token.
	 * @param int $user_id User id.
	 * @param string $user_email User email.
	 *
	 * @return false|mixed
	 */
	public function user_already_has_order( $iap_receipt_token, $user_id, $user_email = '' ) {

		if ( ! empty( $user_id ) && empty( $user_email ) ) {
			// Get current user login data and update order data and meta data.
			$userdata   = get_userdata( $user_id );
			$user_email = $userdata->user_email;
		}

		// Get order is which same receipt token.
		$order_ids = Orders::instance()->get_orders_ids_by_meta( '_iap_receipt_token', $iap_receipt_token );
		// Filter orders which is pending and user id is zero.

		$order_status = array(
			'subscribed',
			'completed'
		);

		if ( ! is_user_logged_in() ) {
			$order_status[] = 'pending';
		}

		$orders = $this->get_orders( array(
			"id"           => $order_ids,
			"order_status" => $order_status,
			"user_id"      => $user_id,
			"user_email"   => $user_email,
		) );

		// Pending order should be complete first.
		if ( isset( $orders ) && ! empty( $orders ) ) {
			if ( is_array( $orders ) ) {
				foreach ( $orders as $order ) {
					return $order;
				}
			}
		}

		return false;
	}

	/**
	 * Complete Order.
	 *
	 * @param $order_id
	 *
	 * @return WP_Error | Object $order
	 */
	public function complete_order( $order_id ) {

		$orders = $this->get_orders( array(
			"id" => $order_id,
		) );

		if ( empty( $orders ) ) {
			return new WP_Error( 'error_completing_order', __( "Error while completing purchase : Purchase not found.", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		$order = $orders[0];

		/**
		 * @var $iap StoreAbstract
		 */
		$iap             = bbapp_iap()->iap[ $order->device_platform ];
		$bbapp_product = $iap->get_product( $order->bbapp_product_id );

		$expired = false;
		if ( ! empty( $order->is_recurring ) && strtotime( $order->expire_at ) <= strtotime( gmdate( "Y-m-d H:i:s" ) ) ) {
			$expired = true;
		}

		$integration_types = unserialize( $order->integration_types );
		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings

		foreach ( $integration_types as $integration_type ) {
			// @var $integration IntegrationAbstract
			$integration = bbapp_iap()->integration[ $integration_type ];

			if ( ! $integration ) {
				return new WP_Error( 'error_completing_order', sprintf( __( "Error while completing purchase : '{%s}' Integration not found.", 'buddyboss-app' ), $integration_type ), array( 'status' => 500 ) );
			}

			// NOTE : Triggers on order completed/expired hook on/from integration.
			if ( $expired ) {
				$integration->_on_order_expired( $order );
			} else {
				$integration->_on_order_completed( $order );
			}
		}

		$order_status = "completed";

		if ( $order->is_recurring ) {
			$order_status = $expired ? "expired" : "subscribed";
		}

		// Cancel Active order of same group if exist.
		if ( ! empty( $bbapp_product['iap_group'] ) ) {
			$group_active_order = $this->cancel_group_order( $bbapp_product, $order );
			$this->update_meta( $order->id, "_old_reference_order", $group_active_order );
			$this->update_meta( $group_active_order, "_new_reference_order", $order->id );
		}

		// Update status of order to completed.
		$update_status = $this->update_order( $order->id, array(
			"order_status" => $order_status,
		) );

		if ( ! $update_status ) {
			return new WP_Error( 'error_completing_order', __( "Error while completing purchase : Error while updating purchase status.", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		$order->order_status = $order_status;

		return $order;
	}


	/**
	 * Cancel the order.
	 *
	 * @param      $order_id
	 *
	 * @param bool $note
	 *
	 * @return WP_Error
	 */
	public function cancel_order( $order_id, $note = false ) {

		$orders = $this->get_orders( array(
			"id" => $order_id,
		) );

		if ( empty( $orders ) ) {
			return new WP_Error( 'error_canceling_order', __( "Error while cancelling purchase : Purchase not found.", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		$order = $orders[0];

		if ( ! in_array( $order->order_status, array( 'subscribed', 'completed' ) ) ) {
			return new WP_Error( 'error_canceling_order', __( "Error while cancelling purchase: Purchase not subscribed(active).", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		$integration_types = null;
		// Verify if it is serialized
		if ( is_serialized( $order->integration_types ) ) {
			$integration_types = unserialize( $order->integration_types );
		}

		// Verify if it is unserialized correctly
		if ( is_array( $integration_types ) ) {
			foreach ( $integration_types as $integration_type ) {
				$integration = false;
				if ( isset( bbapp_iap()->integration[ $integration_type ] ) ) {
					// Integration
					$integration = bbapp_iap()->integration[ $integration_type ];
				}

				if ( ! $integration ) {
					return new WP_Error( 'error_canceling_order', sprintf( __( "Error while cancelling purchase : '{%s}' Integration not found.", 'buddyboss-app' ), $integration_type ), array( 'status' => 500 ) );
				}

				// trigger on order cancelled hook on integration.
				$integration->_on_order_cancelled( $order );
			}
		} else {
			$no_integration_found = __( "No integration found.", 'buddyboss-app' );
			$this->add_history( $order_id, 'info', $no_integration_found );
		}

		$order_status = "cancelled";

		// update status of order to cancel.
		$update_status = $this->update_order( $order->id, array(
			"order_status" => $order_status,
		) );

		if ( $note ) {
			$this->add_history( $order_id, 'info', $note );
		}

		if ( ! $update_status ) {
			return new WP_Error( 'error_canceling_order', __( "Error while cancelling purchase : Error while updating purchase status.", 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		$order->order_status = $order_status;

		return $order;
	}

	/**
	 * Cancel group activeorder.
	 *
	 * @param object $new_product New Product
	 * @param object $new_order   New order
	 *
	 * @return WP_Error
	 */
	public function cancel_group_order( $new_product, $new_order ) {
		$user_id         = get_current_user_id();
		$active_order_id = ProductHelper::getGroupActiveOrderId( $new_product['iap_group'], $user_id );

		if ( ! empty( $active_order_id ) ) {
			$success = $this->cancel_order( $active_order_id, sprintf( __( "Purchase has been cancelled due to same group product: %s purchased, Purchase: <a target='_blank' href=%s>%d</a>", 'buddyboss-app' ), $new_product['name'], 'admin.php?page=bbapp-iap&action=view_order&order_id='. $new_order->id , $new_order->id ) );

			if ( ! is_wp_error( $success ) ) {
				// Store cancel detail on meta.
				Orders::instance()->update_meta( $active_order_id, "order_upgrade_downgrade", 1 );

				return $active_order_id;
			}
		}

		return false;
	}

	/**
	 * Creates the order in db.
	 *
	 * @param $order
	 *
	 * @return WP_Error|array
	 */
	public function create_order( $order ) {

		global $wpdb;

		$default = array(
			'blog_id'            => get_current_blog_id(),
			'user_id'            => 0,
			'bbapp_product_id' => 0,
			'device_platform'    => false,
			'order_status'       => 'pending',
			'integration_types'  => false,
			'item_ids'           => '',
			'is_recurring'       => 0,
			'secondary_id'       => 0,
			'date_created'       => current_time( 'mysql', 1 ),
			'date_updated'       => current_time( 'mysql', 1 ),
		);

		$order = array_merge( $default, $order );

		if ( ! $order["device_platform"] ) {
			return new WP_Error( 'missing_param', __( 'Please specify purchase type.', 'buddyboss-app' ), array( 'status' => 404 ) );
		}
		if ( empty( $order["order_status"] ) ) {
			return new WP_Error( 'missing_param', __( 'Please specify purchase status.', 'buddyboss-app' ), array( 'status' => 404 ) );
		}
		if ( empty( $order["integration_types"] ) ) {
			return new WP_Error( 'missing_param', __( 'Please specify integration type(s).', 'buddyboss-app' ), array( 'status' => 404 ) );
		}
		if ( empty( $order["item_ids"] ) ) {
			return new WP_Error( 'missing_param', __( 'Please specify item IDs.', 'buddyboss-app' ), array( 'status' => 404 ) );
		}

		$create = $wpdb->insert( $this->table_name, $order );

		$get_order = false;

		if ( $create ) {
			$get_order = $this->get_orders( array( "id" => $wpdb->insert_id ) );
		}

		if ( empty( $create ) || ! $get_order ) {
			return new WP_Error( 'error_creating', __( 'There is an error while creating the purchase.', 'buddyboss-app' ), array( 'status' => 500 ) );
		}

		return $get_order[0];

	}

	/**
	 * @param $order_id
	 * @param $data
	 *
	 * @return false|int
	 */
	public function update_order( $order_id, $data ) {
		global $wpdb;

		$columns = array(
			'blog_id'           => 1,
			'user_id'           => 1,
			'device_platform'   => 1,
			'order_status'      => 1,
			'integration_types' => '',
			'item_ids'          => '',
			'secondary_id'      => 1,
			'date_created'      => 1,
			'date_updated'      => 1,
			'user_email'        => 1,
			'expire_at'         => 1,
		);

		$new_vals = array();

		foreach ( $data as $k => $v ) {
			if ( isset( $columns[ $k ] ) ) {
				$new_vals[ $k ] = $v;
			}
		}

		$update = $wpdb->update(
			$this->table_name,
			$new_vals,
			array( "id" => $order_id )
		);

		return ( $update !== false ) ? true : false;

	}

	/**
	 * @param array $where provide option to get results by meta.
	 *
	 * @param array $args  provide options to orderby limit the results.
	 *
	 * @return array|bool|null|object
	 */
	public function get_orders( $where = array(), $args = array() ) {
		global $wpdb;

		$default_args = array(
			'device_platform' => 'any',
			'per_page'        => false,
			'current_page'    => 1,
			'orderby'         => 'id',
			'order'           => 'desc',
		);

		$args = array_merge( $default_args, $args );

		$columns = array(
			'id'                 => false,
			'blog_id'            => false,
			'user_id'            => false,
			'bbapp_product_id' => false,
			'device_platform'    => false,
			'order_status'       => false,
			'integration_types'  => false,
			'item_ids'           => '',
			'secondary_id'       => false,
			'date_created'       => false,
			'date_updated'       => false,
			'user_email'         => false,
		);

		$where_clause = array();

		foreach ( $where as $column => $value ) {
			if ( ! isset( $columns[ $column ] ) ) {
				return false;
			}
			if ( ! empty( $value ) ) {
				if ( is_array( $value ) ) {
					$value_str      = "'" . implode( "','", $value ) . "'";
					$where_clause[] = $wpdb->prepare( "{$column} IN ({$value_str})", null );
				} else {
					$where_clause[] = $wpdb->prepare( "{$column}=%s", $value );
				}
			}
		}

		if ( empty( $where_clause ) ) {
			$where_clause = "";
		} else {
			$where_clause = "WHERE " . implode( " AND ", $where_clause );
		}

		$LIMIT = "";

		if ( $args["per_page"] ) {
			$args["per_page"]     = (int) $args["per_page"];
			$args["current_page"] = (int) $args["current_page"];

			$LIMIT = " LIMIT {$args["per_page"]} ";
			$LIMIT .= ' OFFSET ' . ( $args["current_page"] - 1 ) * $args["per_page"];
		}

		$order = "";

		if ( ! empty( $args['orderby'] ) ) {
			$order .= ' ORDER BY ' . esc_sql( $args['orderby'] );
			$order .= ! empty( $args['order'] ) ? ' ' . esc_sql( $args['order'] ) : ' ASC';
		}

		$query = "SELECT *FROM {$this->table_name} {$where_clause} {$order} {$LIMIT}";

		$results = $wpdb->get_results( $query );

		if ( ! $results ) {
			return null;
		}

		return $results;

	}

	/**
	 * return total orders count.
	 *
	 * @param string $order_status
	 * @param string $iap_product
	 *
	 * @return string|null
	 */
	public function get_total_orders_count( $order_status = '', $iap_product = ''  ) {
		global $wpdb;
		$table_name   = bbapp_iap()->get_global_dbprefix() . 'bbapp_iap_orders';
		$where_clause = " WHERE 1=1";
		if ( ! empty( $order_status ) ) {
			$where_clause .= " AND order_status= " . "'" . $order_status . "'";
		}
		if ( ! empty( $iap_product ) ) {
			$where_clause .= " AND bbapp_product_id= " . $iap_product;
		}
		$sql = "SELECT COUNT(*) FROM {$table_name}{$where_clause}";
		return $wpdb->get_var( $sql );
	}

	/**
	 * @param $order_id
	 *
	 * @return WP_Error|array|null|object|void
	 */
	public function get_by_id( $order_id ) {

		global $wpdb;

		$get = $wpdb->get_row( $wpdb->prepare( "SELECT *FROM {$this->table_name} WHERE id=%d", $order_id ) );

		if ( ! $get ) {
			return new WP_Error( 'not_found', __( 'No purchase found.', 'buddyboss-app' ), array( 'status' => 404 ) );
		}

		return $get;

	}

	/**
	 * @param $order_id
	 * @param $meta_key
	 * @param $meta_value
	 *
	 * @return bool|false|int
	 */
	public function update_meta( $order_id, $meta_key, $meta_value ) {

		global $wpdb;

		$get_meta = $this->get_meta( $order_id, $meta_key, false );

		$meta_value = maybe_serialize( $meta_value );

		if ( empty( $get_meta ) ) {
			$insert = $wpdb->insert( $this->table_meta_name, array(
				'meta_key'   => $meta_key,
				'meta_value' => $meta_value,
				'order_id'   => $order_id,
			) );
			if ( $meta_value ) {
				return $meta_value;
			}
		} else {
			$update = $wpdb->update( $this->table_meta_name, array(
				'meta_value' => $meta_value,
			),
				array(
					'order_id' => $order_id,
					'meta_key' => $meta_key,
				) );

			if ( $update !== false ) {
				return $meta_value;
			}

		}

		return false;

	}

	/**
	 * @param      $order_id
	 * @param      $meta_key
	 * @param bool $only_value
	 *
	 * @return array|bool|mixed|null|object|void
	 */
	public function get_meta( $order_id, $meta_key, $only_value = true ) {
		global $wpdb;

		$get = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $this->table_meta_name WHERE order_id=%s AND meta_key=%s", $order_id, $meta_key ) );

		if ( ! empty( $get ) ) {
			$get->meta_value = maybe_unserialize( $get->meta_value );
			if ( $only_value ) {
				return $get->meta_value;
			}

			return $get;
		}

		return false;
	}

	/**
	 * @param $order_id
	 *
	 * @return WP_Error|array|null|object|void
	 */
	public function get_orders_ids_by_meta( $meta_key, $meta_value ) {
		global $wpdb;

		$get = $wpdb->get_col( $wpdb->prepare( "SELECT order_id FROM {$this->table_meta_name} WHERE meta_key=%s AND meta_value=%s ORDER BY order_id ASC", $meta_key, $meta_value ) );

		if ( ! empty( $get ) ) {
			return $get;
		}

		return array();
	}

	/**
	 * @param        $order_id
	 * @param string $type Eg :info | success | warning | error
	 * @param        $text
	 * @param bool   $debug
	 *
	 * @return array|bool|mixed|null|object|void
	 */
	public function add_history( $order_id, $type, $text, $debug = false ) {
		if ( empty( $type ) ) {
			$type = 'info';
		}

		$history = $this->get_history( $order_id );

		if ( $debug ) {
			$debug = print_r( $debug, true );
		}

		$history[] = array(
			"time"  => time(),
			"type"  => $type,
			"text"  => $text,
			"debug" => $debug,
		);

		$this->update_meta( $order_id, "_order_history", $history );

		return $history;

	}

	/**
	 * get order history
	 *
	 * @param $order_id
	 *
	 * @return array|bool|mixed|null|object|void
	 */
	public function get_history( $order_id ) {

		$history = $this->get_meta( $order_id, "_order_history" );

		if ( ! is_array( $history ) ) {
			$history = array();
		}

		return $history;

	}

	/**
	 * Update order next validation retry time.
	 *
	 * @param        $order_id
	 * @param string $string_time
	 * @param bool   $from
	 */
	public function update_order_next_validation_retry( $order_id, $string_time = "+2 hours", $from = false ) {
		if ( ! $from ) {
			$gmt_timestamp = strtotime( gmdate( "Y-m-d H:i:s" ) );
		} else {
			$gmt_timestamp = strtotime( $from );
		}
		$date = gmdate( "Y-m-d H:i:s", strtotime( $string_time, $gmt_timestamp ) );
		Orders::instance()->update_meta( $order_id, "_next_order_check", $date );
	}

	/**
	 * This handles the IAP s2s notification events from apple server.
	 */
	public function handle_notification() {
		$is_notification = filter_input( INPUT_GET, 'ios_s2s_notification', FILTER_SANITIZE_NUMBER_INT );

		// Check request is for ios_s2s_notification
		if ( ! empty( $is_notification ) ) {
			$json = file_get_contents( 'php://input' );

			$data            = json_decode( $json );
			$device_platform = 'ios';

			// Check required data get from S2S notification info.
			if ( ! empty( $data ) && ! empty( $data->notification_type ) && isset( bbapp_iap()->iap[ $device_platform ] ) && ! empty( $data->auto_renew_product_id ) ) {

				$store_product_id = $data->auto_renew_product_id;
				$iap = bbapp_iap()->iap[ $device_platform ];

				// Handle CANCEL and REFUND notification
				if ( in_array( $data->notification_type, array( 'CANCEL', 'REFUND' ) ) ) {

					// Check active order from latest_receipt_info
					if ( ! empty( $data->unified_receipt->latest_receipt_info ) ) {

						// Loop through latest_receipt_info
						foreach ( $data->unified_receipt->latest_receipt_info as $key => $purchase ) {

							// Check Receipt info is for store_product_id
							if ( $purchase->product_id === $store_product_id ) {
								if ( IAP_LOG ) {
									Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Order->handle_notification(),Store Product ID matched" );
								}

								// Check if it don't exists.
								$iap_exists = $iap->do_transaction_exists( $purchase->original_transaction_id );

								// If transaction_id is already present on db.
								if ( ! empty( $iap_exists ) ) {

									// Loop for all iap exists
									foreach ( $iap_exists as $order ) {

										// Check if order is active or not
										if ( in_array( $order->order_status, array(
											'subscribed',
											'completed'
										) ) ) {
											// found one valid 'subscribed' order. Cancel it.
											$this->cancel_order( $order->id, "Purchase cancelled by Apple Server Notification" );

										} // Check if order is active or not
									} // Loop for all iap exists
								} // If transaction_id is already present on db.
							} // Check Receipt info is for store_product_id
						} // Loop through latest_receipt_info
					} // Check active order from latest_receipt_info
				} // Handle CANCEL and REFUND notification
			} // // Check required data get from S2S notification info.
		} // Check request is for ios_s2s_notification
	}

	/**
	 * Install Database on plugin activate.
	 */
	public function on_activation() {

		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql1 = "CREATE TABLE {$this->table_name} (
        id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
        blog_id bigint(20) NOT NULL,
        user_id bigint(20) NOT NULL,
        bbapp_product_id bigint(20) NOT NULL,
        device_platform varchar(20) NOT NULL,
        order_status varchar(20) NOT NULL,
        store_product_id varchar(60) NOT NULL,
        integration_types longtext NOT NULL,
        item_ids longtext NOT NULL,
        is_recurring tinyint(1) NOT NULL,
        secondary_id bigint(20) NOT NULL,
        date_created datetime DEFAULT '0000-00-00 00:00:00' NULL,
        date_updated datetime DEFAULT '0000-00-00 00:00:00' NULL,
        expire_at datetime DEFAULT '0000-00-00 00:00:00' NULL,
        user_email varchar(255) NOT NULL,
        KEY  blog_id (blog_id),
        KEY  user_id (user_id),
        KEY  bbapp_product_id (bbapp_product_id),
        KEY  device_platform (device_platform),
        KEY  order_status (order_status),
        KEY  store_product_id (store_product_id),
        KEY  is_recurring (is_recurring),
        KEY  secondary_id (secondary_id),
        KEY  date_created (date_created),
        KEY  date_updated (date_updated),
        KEY  expire_at (expire_at)
        ) {$charset_collate}";

		dbDelta( $sql1 );

		$sql2 = "CREATE TABLE {$this->table_meta_name} (
		meta_id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
		order_id bigint(20) NOT NULL,
		meta_key varchar(255) NOT NULL,
		meta_value longtext NOT NULL
		) {$charset_collate}";

		dbDelta( $sql2 );

	}

}
