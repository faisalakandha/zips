<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\InAppPurchases\Controller;
use BuddyBossApp\Logger;

$uploadDir = wp_upload_dir();
/**
 * Get the main component object.
 * Note - This function is not available when component is disabled, instead of class on that time.
 * @return \BuddyBossApp\InAppPurchases\Controller the singleton object
 */
function bbapp_iap() {
	return Controller::instance();
}

/**
 * Return IAP Registered Integrations.
 *
 * @return mixed|void
 */
function bbapp_iap_get_integrations() {
	return apply_filters( "bbapp_iap_get_registered_integrations", array() );
}

/**
 * Return the IAP types.
 */
function bbapp_iap_get_types() {
	return apply_filters( "bbapp_iap_get_registered_iap", array() );
}

/**
 * @param $product direct object or array from db.
 *
 * @return array|direct
 */
function bbapp_iap_prepare_product_item( $product ) {
	$product = (array) $product;

	return $product;
}

/**
 * Process & format integration_data of iap product.
 *
 * @param $integrationData
 *
 * @return mixed
 */
function bbapp_iap_prepare_product_integration_data( $integrationData ) {

	$integrationData = maybe_unserialize( $integrationData );

	if ( ! is_array( $integrationData ) ) {
		$integrationData = array();
	}

	$integrationData["linked"] = ( ! isset( $integrationData["linked"] ) ) ? false : $integrationData["linked"];

	return $integrationData;

}

/**
 * Return the iap upload directory with relative path.
 *
 * @param $fullpath
 *
 * @return mixed
 */
function bbapp_iap_get_upload_relative_path( $fullpath ) {
	$uploadDir = wp_upload_dir();

	return str_replace( $uploadDir["basedir"], '', $fullpath );
}

/**
 * Return count of all products.
 *
 * @param string $status eg.published,trash
 *
 * @return null|string
 */
function bbapp_iap_get_products_count( $status = '' ) {
	global $wpdb;
	$globalPrefix = bbapp_iap()->get_global_dbprefix();

	$sql = "SELECT COUNT(*) FROM {$globalPrefix}bbapp_iap_products";
	if ( ! empty( $status ) ) {
		$sql .= $wpdb->prepare( " where status = '%s'", $status );
	} else {
		$sql .= $wpdb->prepare( " where status != '%s'", 'trash' );
	}

	return $wpdb->get_var( $sql );
}

/**
 * Returns iap products.
 *
 * @param $args
 *
 * @return array
 */
function bbapp_iap_get_products( $args ) {
	global $wpdb;

	$defaultArgs = array(
		'iap_type'     => 'any',
		'per_page'     => false,
		'current_page' => 1,
		'orderby'      => 'id',
		'order'        => 'desc',
		'status'       => 'all',
	);

	$args = array_merge( $defaultArgs, $args );

	$globalPrefix = bbapp_iap()->get_global_dbprefix();

	$whereClause = array();

	if ( $args["iap_type"] != "any" ) {
		$whereClause[] = $wpdb->prepare( "iap_type=%s", $args["iap_type"] );
	}

	if ( $args["status"] !== "all" ) {
		$whereClause[] = $wpdb->prepare( "status=%s", $args["status"] );
	} else {
		$whereClause[] = $wpdb->prepare( "status!=%s", 'trash' );
	}

	if ( ! empty( $whereClause ) ) {
		$whereClause = "WHERE " . implode( "AND", $whereClause );
	} else {
		$whereClause = "";
	}

	$limitClause = "";

	if ( $args["per_page"] ) {
		$args["per_page"]     = (int) $args["per_page"];
		$args["current_page"] = (int) $args["current_page"];

		$limitClause = " LIMIT {$args["per_page"]} ";
		$limitClause .= ' OFFSET ' . ( $args["current_page"] - 1 ) * $args["per_page"];
	}

	$orderByClause = "";

	if ( ! empty( $args['orderby'] ) ) {
		$orderByClause .= ' ORDER BY menu_order,' . esc_sql( $args['orderby'] );
		$orderByClause .= ! empty( $args['order'] ) ? ' ' . esc_sql( $args['order'] ) : ' ASC';
	}

	$sql = "SELECT * FROM {$globalPrefix}bbapp_iap_products {$whereClause} {$orderByClause} {$limitClause}";
	$getResults = $wpdb->get_results( $sql );

	$products = array();

	foreach ( $getResults as $product ) {
		$products[] = bbapp_iap_prepare_product_item( $product );
	}

	return $products;
}

/**
 * Returns single iap product.
 *
 * @param $productId
 *
 * @return array|bool|direct|null|object|void
 */
function bbapp_iap_get_product( $productId ) {
	global $wpdb;

	$productId = (int) $productId;

	$globalPrefix = bbapp_iap()->get_global_dbprefix();

	$product = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE id=%s", $productId ) );

	if ( ! $product ) {
		return false;
	}

	$product = bbapp_iap_prepare_product_item( $product );

	return $product;
}

/**
 * Returns single iap product by store product id .
 *
 * @param $storeProductID
 * @param $device_platform
 *
 * @return array|bool|direct|null|object|void
 */
function bbapp_iap_get_product_by_store_product_id( $storeProductID, $device_platform ) {
	global $wpdb;

	$lenStoreProductID = strlen( $storeProductID );
	$lenDevice_platform = strlen( $device_platform );
	$strStoreProductID = '%s:'. $lenDevice_platform .':"'. $device_platform .'";s:'. $lenStoreProductID .':"'. $storeProductID .'";%';

	$globalPrefix = bbapp_iap()->get_global_dbprefix();
	$product      = $wpdb->get_row( "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE store_data like '{$strStoreProductID}'"  );

	if ( ! $product ) {
		return false;
	}

	$product = bbapp_iap_prepare_product_item( $product );

	return $product;
}

/**
 * Create iap product.
 *
 * @param $product
 *
 * @return array|direct|WP_Error
 */
function bbapp_iap_create_product( $product ) {
	global $wpdb;

	if ( IAP_LOG ) {
		Logger::instance()->add( "iap_log", "include/InAppPurchases/functions.php->bbapp_iap_create_product()" );
	}

	$globalPrefix = bbapp_iap()->get_global_dbprefix();

	$default = array(
		'blog_id'           => get_current_blog_id(),
		'product_author_id' => get_current_user_id(),
		'name'              => '',
		'tagline'           => '',
		'description'       => '',
		'store_data'        => '',
		'misc_settings'     => array(),
		'integration_data'  => '',
		'date_created'      => current_time( 'mysql', 1 ),
		'date_updated'      => current_time( 'mysql', 1 ),
		'iap_group'         => 0,
	);

	$product = array_merge( $default, $product );

	if ( empty( $product["name"] ) ) {
		return new WP_Error( 'name_required', __( 'Product Name is missing.' ) );
	}

	try {
		$add = $wpdb->insert( "{$globalPrefix}bbapp_iap_products", $product );
	} catch ( Exception $e ) {
		if ( IAP_LOG ) {
//		    Logger::instance()->add("error_log", print_r($e, true));
		}

	}

	if ( ! $add ) {
		return new WP_Error( 'error_inserting',
			__( 'There is a database error while adding record.', 'buddyboss-app' ) );

	}

	$product       = (array) $product;
	$product["id"] = $wpdb->insert_id;

	return bbapp_iap_prepare_product_item( $product );

}

/**
 * Update iap product.
 *
 * @param $productId
 * @param $data
 *
 * @return bool
 */
function bbapp_iap_update_product( $productId, $data ) {
	global $wpdb;

	$globalPrefix = bbapp_iap()->get_global_dbprefix();

	$columns = array(
		'name'             => $data['name'],
		'tagline'          => $data['tagline'],
		'description'      => $data['description'],
		'store_data'       => $data['store_data'],
		'misc_settings'    => $data['misc_settings'],
		'integration_data' => $data['integration_data'],
		'date_updated'     => current_time( 'mysql', 1 ),
		'iap_group'        => $data['iap_group'],
	);

	$newVals = array();

	foreach ( $data as $k => $v ) {
		if ( isset( $columns[ $k ] ) ) {
			$newVals[ $k ] = $v;
		}
	}

	$update = $wpdb->update(
		"{$globalPrefix}bbapp_iap_products",
		$newVals,
		array( "id" => $productId )
	);

	return ( $update !== false ) ? true : false;

}

/**
 * add logs into database.
 *
 * @param      $type
 * @param      $text
 * @param bool $ref
 *
 * @return bool
 */
function bbapp_iap_add_logs( $type, $text, $ref = false ) {
	if ( ! class_exists( "Logger" ) ) {
		return false;
	}

	return Logger::instance()->add( $type, $text, $ref );
}

/**
 * @param $devicePlatform
 *
 * @return false|mixed|void
 */
function bbapp_iap_get_store_products( $device_platform ) {
	if ( empty( $device_platform ) ){
		return array();
	}
	return get_option( "bbapp_{$device_platform}_store_product", [] );
}

/**
 * @param $store_product_id
 * @param $device_platform
 *
 * @return array
 */
function bbapp_iap_get_store_product( $store_product_id, $device_platform, $field = false ) {
	if ( ! empty( $store_product_id ) && ! empty( $device_platform ) ) {
		$products = bbapp_iap_get_store_products( $device_platform );
		if ( ! empty( $products ) ) {
			$key     = array_search( $store_product_id, array_column( $products, 'id' ) );
			$product = $products[ $key ];
			if ( ! empty( $field ) ) {
				return ! empty( $product[ $field ] ) ? $product[ $field ] : '';
			}

			return $product;
		}
	}

	return '';
}

/**
 * Get metadata for a given iap item.
 *
 * @since 1.4.0
 *
 * @param int    $iap_id        ID of the iap item whose metadata is being requested.
 * @param string $meta_key      Optional. If present, only the metadata matching
 *                              that meta key will be returned. Otherwise, all metadata for the
 *                              iap item will be fetched.
 * @param bool   $single        Optional. If true, return only the first value of the
 *                              specified meta_key. This parameter has no effect if meta_key is not
 *                              specified. Default: true.
 *
 * @return mixed The meta value(s) being requested.
 */
function bbapp_iap_get_meta( $iap_id = 0, $meta_key = '', $single = true ) {
	global $wpdb;

	// WP_Meta_Query expects the table name at
	// $wpdb->iapmeta.
	$wpdb->iapmeta = \bbapp_iap()->get_global_dbprefix() . 'bbapp_iap_productmeta';

	$retval = get_metadata( 'iap', $iap_id, $meta_key, $single );

	/**
	 * Filters the metadata for a specified iap item.
	 *
	 * @since 1.4.0
	 *
	 * @param mixed  $retval   The meta values for the iap item.
	 * @param int    $iap_id   ID of the iap item.
	 * @param string $meta_key Meta key for the value being requested.
	 * @param bool   $single   Whether to return one matched meta key row or all.
	 */
	return apply_filters( 'bbapp_iap_get_meta', $retval, $iap_id, $meta_key, $single );
}

/**
 * Add a piece of iap metadata.
 *
 * @since 1.4.0
 *
 * @param int    $iap_id        ID of the iap item.
 * @param string $meta_key      Metadata key.
 * @param mixed  $meta_value    Metadata value.
 * @param bool   $unique        Optional. Whether to enforce a single metadata value for the
 *                              given key. If true, and the object already has a value for
 *                              the key, no change will be made. Default: false.
 *
 * @return int|bool The meta ID on successful update, false on failure.
 */
function bbapp_iap_add_meta( $iap_id, $meta_key, $meta_value, $unique = false ) {
	global $wpdb;

	// WP_Meta_Query expects the table name at
	// $wpdb->iapmeta.
	$wpdb->iapmeta = \bbapp_iap()->get_global_dbprefix() . 'bbapp_iap_productmeta';

	$retval = add_metadata( 'iap', $iap_id, $meta_key, $meta_value, $unique );

	return $retval;
}

/**
 * Update a piece of iap meta.
 *
 * @since 1.4.0
 *
 * @param int    $iap_id        ID of the iap item whose metadata is being updated.
 * @param string $meta_key      Key of the metadata being updated.
 * @param mixed  $meta_value    Value to be set.
 * @param mixed  $prev_value    Optional. If specified, only update existing metadata entries
 *                              with the specified value. Otherwise, update all entries.
 *
 * @return bool|int Returns false on failure. On successful update of existing
 *                  metadata, returns true. On successful creation of new metadata,
 *                  returns the integer ID of the new metadata row.
 */
function bbapp_iap_update_meta( $iap_id, $meta_key, $meta_value, $prev_value = '' ) {
	global $wpdb;

	// WP_Meta_Query expects the table name at
	// $wpdb->iapmeta.
	$wpdb->iapmeta = \bbapp_iap()->get_global_dbprefix() . 'bbapp_iap_productmeta';

	$retval = update_metadata( 'iap', $iap_id, $meta_key, $meta_value, $prev_value );

	return $retval;
}

/**
 * Delete a meta entry from the DB for an iap item.
 *
 * @since 1.4.0
 *
 * @param int    $iap_id        ID of the iap item whose metadata is being deleted.
 * @param string $meta_key      Optional. The key of the metadata being deleted. If
 *                              omitted, all metadata associated with the iap
 *                              item will be deleted.
 * @param string $meta_value    Optional. If present, the metadata will only be
 *                              deleted if the meta_value matches this parameter.
 * @param bool   $delete_all    Optional. If true, delete matching metadata entries
 *                              for all objects, ignoring the specified object_id. Otherwise,
 *                              only delete matching metadata entries for the specified
 *                              iap item. Default: false.
 *
 * @return bool True on success, false on failure.
 * @global wpdb  $wpdb          WordPress database abstraction object.
 */
function bbapp_iap_delete_meta( $iap_id, $meta_key = '', $meta_value = '', $delete_all = false ) {
	global $wpdb;

	// Legacy - if no meta_key is passed, delete all for the item.
	if ( empty( $meta_key ) ) {
		$all_meta = bbapp_iap_get_meta( $iap_id );
		$keys     = ! empty( $all_meta ) ? array_keys( $all_meta ) : array();

		// With no meta_key, ignore $delete_all.
		$delete_all = false;
	} else {
		$keys = array( $meta_key );
	}

	$retval = true;
	// WP_Meta_Query expects the table name at
	// $wpdb->iapmeta.
	$wpdb->iapmeta = \bbapp_iap()->get_global_dbprefix() . 'bbapp_iap_productmeta';

	foreach ( $keys as $key ) {
		$retval = delete_metadata( 'iap', $iap_id, $key, $meta_value, $delete_all );
	}

	return $retval;
}
