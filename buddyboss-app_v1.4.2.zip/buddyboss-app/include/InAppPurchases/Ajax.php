<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\Logger;
use WP_Error as WP_Error;

final class Ajax {

	private static $instance = null;

	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @return Controller|null
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->hooks();

		}

		return self::$instance;
	}

	/**
	 * Define all actions and filters here
	 */
	private function hooks() {
		add_action( 'wp_ajax_bbapp_iap_integration_ids', array( $this, "iap_integration_ids" ) );
		//add_action( 'wp_ajax_bbapp_delete_product', array( $this, "delete_bbapp_product" ) ); ToDo: will delete.
		add_action( 'wp_ajax_bbapp_iap_sync_store_product', array( $this, 'iap_sync_store_product' ) );

		// Run once a day to fetch the store products.
		add_action( "bbapp_every_day", array( $this, "bbapp_fetch_iap_store_products" ),99 );
	}

	/***
	 * Fetch all products from apple and google store.
	 *
	 * @return bool|void
	 */
	public function bbapp_fetch_iap_store_products() {
		if ( ! bbapp_is_active( 'iap' ) ) {
			return;
		}
		$_GET['platform'] = 'all';
		$_GET['selected'] = '';
		$this->iap_sync_store_product();

		return true;
	}

	/**
	 * Delete BuddyBossApp(InAppPurchase) product
	 *
	 * @param $request
	 *
	 * @return WP_Error {boolean} Status about deletion
	 */
	public function delete_bbapp_product( $request ) {

		global $wpdb;
		$id = isset( $_REQUEST['id'] ) ? $_REQUEST['id'] : false;

		if ( ! $id ) {
			return new WP_Error( 'missing_params', __( "Missing param. id required", 'buddyboss-app' ), array( 'status' => 400 ) );

		}

		$tableName = \bbapp_iap()->get_global_dbprefix() . "bbapp_iap_products";
		$status    = $wpdb->delete( $tableName, array( 'id' => $id ) );

		$data           = array();
		$data['status'] = $status;
		wp_send_json_success( $data, JSON_PRETTY_PRINT );

	}

	/**
	 * get posts
	 * @return {JSON} Published post
	 */
	public function getPostsAsObject() {
		global $wpdb;

		$postType = isset( $_REQUEST['post_type'] ) ? $_REQUEST['post_type'] : false;

		if ( ! $postType ) {
			return new WP_Error( 'missing_params', __( "Missing param. post_type required", 'buddyboss-app' ), array( 'status' => 400 ) );

		}

		$query = "SELECT * FROM $wpdb->posts posts WHERE posts.post_type = $postType AND posts.post_status = 'publish'";

		$results = $wpdb->get_results( $query, OBJECT );

		return $results;
	}

	/**
	 * Integrations Id(s) of integration such as learndash-course(sfwd-courses), memberpress(memberpressproduct) and woo-membership
	 * @return WP_Error {JSON} Results array with Id(s) and Text(s)
	 */
	public function iap_integration_ids() {

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", 'BuddyBossApp\InAppPurchases\Ajax->iap_integration_ids()' );
		}

		if ( ! isset( $_REQUEST['slug'] ) || ! isset( $_REQUEST['id'] ) ) {
			return new WP_Error( 'missing_params', __( "Missing params. slug and id is required", 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		$slug = $_REQUEST['slug'];
		$id   = $_REQUEST['id'];

		$iap_product      = bbapp_iap_get_product( $id );
		$integration_data = unserialize( $iap_product['integration_data'] );
		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings
		if ( bbapp()->is_network_activated() ) {
			$integration_data = $integration_data[ get_current_blog_id() ];
		}

		if ( is_array( $integration_data ) && ! empty( $integration_data ) ) {
			$integration_ids = $integration_data[ $slug ];

			/**
			 * Allow to update list integration names/label for items ids for 3rd party integration.
			 */
			$ui_friendly_results = apply_filters( 'bbapp_ajax_iap_integration_ids', [], $integration_ids, $slug );
			if ( empty( $ui_friendly_results ) ) {
				foreach ( $integration_ids as $key => $integration_id ) {
					$ui_friendly_results[ $key ]['id']   = $integration_id;
					$ui_friendly_results[ $key ]['text'] = get_the_title( $integration_id );
				}
			}

			if ( ! empty( $ui_friendly_results ) ) {
				wp_send_json_success( array( 'results' => $ui_friendly_results ) );

			} else {
				wp_send_json_error( __( "In-App Purchase product does not exist", 'buddyboss-app' ) );

			}

		} else {
			wp_send_json_error( __( "No integration found for current In-App Purchase product", 'buddyboss-app' ) );
		}

	}

	/**
	 * Sync Google/Apple Store product.
	 */
	public function iap_sync_store_product() {

		$stores_products = array();

		$platform = filter_input( INPUT_GET, 'platform', FILTER_SANITIZE_STRING  );
		$sleItem = filter_input( INPUT_GET, 'selected', FILTER_SANITIZE_STRING  );

		if ( ! empty( $platform ) && 'all' !== $platform ) {
			if ( ! empty( bbapp_iap()->iap[ $platform ] ) ) {
				$stores_products[ $platform ] = bbapp_iap()->iap[ $platform ]->sync_store_product();
			}
		} else {
			if ( ! empty( bbapp_iap()->iap ) ) {
				foreach ( bbapp_iap()->iap as $type => $devicePlatform ) {
					$stores_products[ $type ] = $devicePlatform->sync_store_product();
				}
			}
		}

		foreach (  $stores_products as $platform => $products  ) {
			$html = '';
			ob_start();
			?>
			<option
				value=""
				data-product_type_label=""
				data-product_type_desc=""
				data-data-product_status_label=""
				data-data-product_status_desc=""
			><?php _e( '- Select a product -', 'buddyboss-app' ); ?></option>
			<?php foreach ( $products as $store_product ) { ?>
				<option value="<?php echo esc_attr( $store_product['id'] ); ?>"
					data-product_type="<?php echo esc_attr( $store_product['type'] ); ?>"
					data-product_type_label="<?php echo sprintf( __( '<b>Type: </b>', 'buddyboss-app' ) ); ?><?php echo esc_attr( Helpers::getStoreProductInfo( $store_product['type'], $platform ) ); ?>"
					data-product_type_desc="<?php echo esc_attr( Helpers::getStoreProductInfo( $store_product['type'], $platform, 'description' ) ); ?>"
					data-product_status_label="<?php echo sprintf( __( '<b>Status: </b>', 'buddyboss-app' ) ); ?><?php echo esc_attr( Helpers::get_store_product_status_info( $store_product['status'], $platform ) ); ?>"
					data-product_status_desc="<?php echo esc_attr( Helpers::get_store_product_status_info( $store_product['status'], $platform, 'description' ) ); ?>"
					<?php isset( $sleItem ) ? selected( $store_product['id'], $sleItem ) : '' ?> >
					<?php echo esc_html( $store_product['name'] ); ?>
				</option>
			<?php }
			$html .= ob_get_clean();
			$stores_products[ $platform ] = $html;
		}

		wp_send_json_success( $stores_products );
	}

}