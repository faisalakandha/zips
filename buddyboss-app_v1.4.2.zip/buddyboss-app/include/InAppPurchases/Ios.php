<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Admin\Configure;
use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\AppStores\Apple;
use BuddyBossApp\Logger;
use Exception;
use ReceiptValidator\iTunes\Validator;
use WP_Error as WP_Error;

final class Ios extends StoreAbstract {

	private static $instance = null;

	/**
	 * Ios constructor.
	 */
	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @return Controller|null
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Initialize Integration
	 */
	public function init() {

		// Device Platform Type
		$platform_type = "ios";

		$store_product_types = Helpers::platformStoreProductTypes( $platform_type );

		// Register StoreAbstract Type
		parent::set_up( $platform_type, __( 'iOS', 'buddyboss-app' ), $store_product_types );

		// Register Instance
		bbapp_iap()->iap[ $platform_type ] = $this::instance();

		// Register Integration
		bbapp_iap()->integration[ $platform_type ] = $store_product_types;

	}

	/**
	 * For rendering product settings
	 *
	 * @param $integration
	 * @param $item
	 */
	public function render_product_settings( $integration, $item ) {
	}

	/**
	 * For saving product settings
	 *
	 * @param $integration
	 * @param $item
	 */
	public function save_product_settings( $integration, $item ) {
	}

	/**
	 * Validates order payment status
	 *
	 * @param $data
	 *
	 * @return mixed
	 * @throws \GuzzleHttp\Exception\GuzzleException
	 */
	public function validate( $data ) {

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Ios::validate()" );
		}

		$transaction_data = array(
			'status'                => '',
			'transaction_date'      => '',
			'parent_transaction_id' => '',
			'transaction_id'        => '',
			'data'                  => array(),
			'expire_at'             => '',
			'history'               => array(),
		);

		/**
		 * Sandbox will work on production mode also.
		 * ReceiptValidator tries with sandbox env when production fails on Sandbox Token.
		 * Check - https://github.com/aporat/store-receipt-validator/blob/master/src/iTunes/Validator.php#L213/
		 */
		$iap_env = Validator::ENDPOINT_PRODUCTION;

		$validator = new Validator( $iap_env );

		$iap_receipt_token  = trim( $data["iap_receipt_token"] );
		$store_product_type = trim( $data["store_product_type"] );
		$store_product_id   = trim( $data["store_product_id"] );

		$shared_secret = Configure::instance()->option( "publish.ios.shared_secret" );

		// ReceiptValidator Throw Exception.
		try {

			// Auto renewable requires shared secret.
			if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {
				$validator->setSharedSecret( $shared_secret );
			}

			$response = $validator->setReceiptData( $iap_receipt_token )->validate();

			if ( method_exists( $response, 'isValid' ) && $response->isValid() ) {

				$purchases = $response->getPurchases();

				// Auto renewable(auto_renewable) has purchases in latest receipts.
				if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {

					// NOTE : Below method returns an array of array (NOT arrays of PurchaseItem Object)
					$purchases = (array) $response->getLatestReceiptInfo();

					// Note : Need to loop in reverse
					foreach ( array_reverse( $purchases ) as $key => $purchase ) {

						// Match the product we are looking for.
						if ( $purchase['product_id'] == $store_product_id ) {

							if ( IAP_LOG ) {
								Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Ios->validate(),Store Product ID matched" );
							}

							// Meta-data for  : Auto-Renewable Subscription(auto_renewable)
							//$transactionData["data"]["transaction_history"] = $this->getAllRelatedReceipts($purchases, $storeProductId);
							$transaction_data["expire_at"] = $purchase['expires_date'];

							// Check if it don't exists.
							$iap_exists = $this->do_transaction_exists( $purchase['original_transaction_id'] );

							/**
							 * Allow Duplicate transaction_id Flow.
							 * non_auto_renewable - same transaction_id is never allowed (same as consumable).
							 */

							// If transaction_id is already present on db.
							if ( ! empty( $iap_exists ) ) {

								$do_skip            = true;
								$subscription_order = false; // holds false until we found any useful order in existing order.

								foreach ( $iap_exists as $order ) {
									if ( in_array( $order->order_status, array( 'subscribed', 'completed' ) ) ) {
										$subscription_order = true; // found one valid 'subscribed' order.
									}
								}

								if ( ! $subscription_order ) {
									// if no subscribed order found don't do this purchase.
									$do_skip = false;
								}


								if ( $do_skip ) {
									continue;
								}

								// disable $iapExists here. as we didn't skipped current purchase one.
								$iap_exists = false;

							}

							$found_usable = true;

							// Storing transaction id in db to avoid granting access twice
							$transaction_data["transaction_id"]        = $purchase['transaction_id'];
							$transaction_data["parent_transaction_id"] = $purchase['original_transaction_id'];
							$transaction_data["data"]["sandbox"]       = $response->isSandbox();

							// Storing all transaction related data
							if ( ! empty( $purchase['purchase_date'] ) ) {
								$transaction_data["transaction_date"] = $purchase['purchase_date'];
							}

							// Trial Period if applicable
							if ( isset( $purchase["is_trial_period"] ) ) {

								if ( is_string( $purchase["is_trial_period"] ) ) {
									$purchase["is_trial_period"] = ( $purchase["is_trial_period"] == "true" ) ? true : false;
								}

								$transaction_data["data"]["trial_period"] = $purchase["is_trial_period"];

								if ( $transaction_data["data"]["trial_period"] ) {
									$transaction_data["data"]["transaction_history"] = __( "Transaction started as free trial." );
									$transaction_data["data"]["had_trial"]           = true;
								}

							}

							// NOTE : Found usable don't mean it is not expired. Sandbox is unreliable
							if ( strtotime( $purchase['expires_date'] ) < strtotime( gmdate( "Y-m-d H:i:s" ) ) ) {
								$found_usable = false;
							}

							if ( $found_usable ) {
								// No need to continue the loop as we found the transaction.
								break;
							}

						}
					}


				} else {

					// NOTE : Apple returns more than one purchases,  we have to find the one we are looking for and assume.
					foreach ( $purchases as $purchase ) {

						// Match the product we looking for.
						if ( $purchase->getProductId() == $store_product_id ) {

							if ( IAP_LOG ) {
								Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Ios->validate(),Store Product ID matched" );
							}

							$found_usable = true;

							// We will store transaction id on db so we don't grant two access with on transaction ID.
							$transaction_data["transaction_id"]        = $purchase->getTransactionId();
							$transaction_data["parent_transaction_id"] = $purchase->getOriginalTransactionId();
							$transaction_data["data"]["sandbox"]       = $response->isSandbox();

							$raw_response = $purchase->getRawResponse();

							// Check for free trial thing.
							if ( isset( $raw_response["is_trial_period"] ) ) {

								if ( is_string( $raw_response["is_trial_period"] ) ) {
									$raw_response["is_trial_period"] = ( $raw_response["is_trial_period"] == "true" ) ? true : false;
								}

								$transaction_data["data"]["trial_period"] = $raw_response["is_trial_period"];

								if ( $transaction_data["data"]["trial_period"] ) {
									$transaction_data["data"]["transaction_history"] = __( "Transaction is renewed as free trial." );
								}

							}

							if ( ! empty( $purchase->getPurchaseDate() ) ) {
								$transaction_data["transaction_date"] = date( 'Y-m-d H:i:s', $purchase->getPurchaseDate()->getTimestamp() );
							}

							// NOTE : Found usable don't mean it is not expired. Sandbox is unreliable
							if ( strtotime( $purchase->getExpiresDate() ) < strtotime( gmdate( "Y-m-d H:i:s" ) ) ) {
								$found_usable = false;
							}

							break;

						}

					}

				}

				// Return data as it's found.
				if ( isset( $found_usable ) && $found_usable ) {
					$transaction_data["status"] = "subscribed";
				} else {

					// as we don't found any valid purchase we will expire the order.

					$transaction_data["history"][] = __( "Subscription has expired.", 'buddyboss-app' );

					// Get pending info of subscription.
					$subscription_renewal_info = false;
					$get_pending_renewals      = $response->getPendingRenewalInfo();

					foreach ( $get_pending_renewals as $pending_renewal ) {
						if ( $pending_renewal["product_id"] == $store_product_id ) {
							$subscription_renewal_info = $pending_renewal;
						}
					}

					// Log Expire Reason.
					if ( $subscription_renewal_info ) {
						if ( isset( $subscription_renewal_info['expiration_intent'] ) ) {
							$expire_reason                                           = $this->get_expiration_intent_text( $subscription_renewal_info['expiration_intent'] );
							$transaction_data["history"][]                           = sprintf( __( "Expire Reason : %s", 'buddyboss-app' ), $expire_reason );
							$transaction_data["data"]["last_expiration_reason_code"] = $subscription_renewal_info['expiration_intent'];
						}
					}

					// Check if apple is still retrying for payments. than give some grace time.
					if ( $subscription_renewal_info ) {
						if ( isset( $subscription_renewal_info['is_in_billing_retry_period'] )
						     && $subscription_renewal_info['is_in_billing_retry_period'] == "1" ) {

							$transaction_data["status"] = "retrying";

							return $transaction_data;

						}
					}

					// If there is no retrying happening finally release order as expired.
					$transaction_data["status"] = "expired";

				}

				return $transaction_data;

			} else {

				$statusCode = "00000";

				if ( method_exists( $response, "getResultCode" ) ) {
					$statusCode = $response->getResultCode();
				}

				return new WP_Error( 'error_iap_validation', $this->error_by_apple_status_code( $statusCode ) );

			}

		} catch ( Exception $e ) {
			return new WP_Error( 'error_iap_validation', __( 'Error while validating order, could be invalid receipt token.', 'buddyboss-app' ) );
		}

	}


	/**
	 * Process actual payment here
	 *
	 * @param $data
	 *
	 * @return array | WP_Error
	 * @throws \GuzzleHttp\Exception\GuzzleException
	 * @uses StoreAbstract::_process_payment()
	 */
	public function process_payment( $data ) {

		$bbapp_product_id   = $data["bbapp_product_id"]; // BuddyBossAppProduct ID
		$store_product_type = $data["store_product_type"]; // Store Product Type
		$store_product_id   = $data["store_product_id"]; // Store Product ID
		$iap_receipt_token  = trim( $data["iap_receipt_token"] ); //Receipt Token

		$transaction_data = array(
			"transaction_date"      => null,
			"parent_transaction_id" => null,
			"transaction_id"        => null,
			"data"                  => array(),
			"expire_at"             => false, // should be given if product is recurring.
		);

		/**
		 * Sandbox will work on production mode also.
		 * ReceiptValidator tries with sandbox env when production fails on Sandbox Token.
		 * Check - https://github.com/aporat/store-receipt-validator/blob/master/src/iTunes/Validator.php#L213/
		 */
		$iap_env = Validator::ENDPOINT_PRODUCTION;

		$validator     = new Validator( $iap_env );
		$shared_secret = Configure::instance()->option( "publish.ios.shared_secret" );

		// ReceiptValidator Throw Exception.
		try {

			// NOTE : Safe to put shared secret on all receipts check, else only auto_renewable requires it
			$validator->setSharedSecret( $shared_secret );
			$response = $validator->setReceiptData( $iap_receipt_token )->validate();

			if ( method_exists( $response, 'isValid' ) && $response->isValid() ) {

				// Auto renewable(auto_renewable) has purchases in latest receipts.
				if ( in_array( $store_product_type, array( 'auto_renewable' ) ) ) {

					// NOTE : Below method returns an array of array (NOT arrays of PurchaseItem Object)
					$purchases = (array) $response->getLatestReceiptInfo();

					error_log( print_r( array_reverse( $purchases ), 1 ) );

					// Note : Need to loop in reverse
					foreach ( $purchases as $key => $purchase ) {

						// Match the product we are looking for.
						if ( $purchase['product_id'] == $store_product_id ) {

							if ( IAP_LOG ) {
								Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Ios->process_payment(),Store Product ID matched" );
							}

							// Meta-data for  : Auto-Renewable Subscription(auto_renewable)
							//$transactionData["data"]["transaction_history"] = $this->getAllRelatedReceipts($purchases, $storeProductId);
							$transaction_data["expire_at"] = $purchase['expires_date'];

							// Check if it don't exists.
							$iap_exists = $this->do_transaction_exists( $purchase['original_transaction_id'] );

							/**
							 * Allow Duplicate transaction_id Flow.
							 * non_auto_renewable -Order has been renewed successfully. same transaction_id is never allowed (same as consumable).
							 */

							// If transaction_id is already present on db.
							if ( ! empty( $iap_exists ) ) {

								$do_skip            = true;
								$subscription_order = false; // holds false until we found any useful order in existing order.

								foreach ( $iap_exists as $order ) {
									if ( in_array( $order->order_status, array( 'subscribed', 'completed' ) ) ) {
										$subscription_order = true; // found one valid 'subscribed' order.
									}
								}

								if ( ! $subscription_order ) {
									// if no subscribed order found don't this purchase.
									$do_skip = false;
								}


								if ( $do_skip ) {
									continue;
								}

								// disable $iapExists here. as we didn't skipped current purchase one.
								$iap_exists = false;

							}

							$found_usable = true;

							// Storing transaction id in db to avoid granting access twice
							$transaction_data["transaction_id"]        = $purchase['transaction_id'];
							$transaction_data["parent_transaction_id"] = $purchase['original_transaction_id'];
							$transaction_data["data"]["sandbox"]       = $response->isSandbox();

							// Storing all transaction related data
							if ( ! empty( $purchase['purchase_date'] ) ) {
								$transaction_data["transaction_date"] = $purchase['purchase_date'];
								$transaction_data["transaction_date_ms"] = ! empty( $purchase['transaction_date_ms'] ) ? $purchase['transaction_date_ms'] : strtotime( $purchase['purchase_date'] ) * 1000;
							}

							// Trial Period if applicable
							if ( isset( $purchase["is_trial_period"] ) ) {

								if ( is_string( $purchase["is_trial_period"] ) ) {
									$purchase["is_trial_period"] = ( $purchase["is_trial_period"] == "true" ) ? true : false;
								}

								$transaction_data["data"]["trial_period"] = $purchase["is_trial_period"];

								if ( $transaction_data["data"]["trial_period"] ) {
									$transaction_data["data"]["transaction_history"] = __( "Transaction started as free trial." );
									$transaction_data["data"]["had_trial"]           = true;
								}

							}

							if ( $found_usable ) {
								// No need to continue the loop as we found the transaction.
								break;
							}

						}
					}

				} else {

					// NOTE : getPurchases() returns Arrays of PurchaseItem Object
					$purchases = $response->getPurchases();

					// NOTE : Apple returns more than one purchases,  we have to find the one we are looking for and assume.
					foreach ( $purchases as $key => $purchase ) {

						// Match the product we are looking for.
						if ( $purchase->getProductId() == $store_product_id ) {

							if ( IAP_LOG ) {
								Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Ios->process_payment(),Store Product ID matched" );
							}

							// Check if it don't exists in DB
							$iap_exists = $this->do_transaction_exists( $purchase->getOriginalTransactionId() );

							// If transaction_id is already present on db.
							if ( ! empty( $iap_exists ) ) {

								$do_skip = true;

								/**
								 * Allow Duplicate transaction_id Flow.
								 * non_consumable - we will allow same transaction_id if previous transaction user is same.
								 * consumable - same transaction_id is never allowed.
								 */

								/**
								 * On none consumable product type. we allow one to be restore if user account is same.
								 * Else they will use one none consumable to redeem same course on multiple wordpress user's account using same apple ID.
								 */
								if ( in_array( $store_product_type, array( 'non_consumable' ) ) ) {

									$found_invalid = false;

									foreach ( $iap_exists as $order ) {
										if ( $order->user_id != get_current_user_id() ) {
											$found_invalid = true;
										}
									}

									if ( ! $found_invalid ) {
										// if none invalid order found don't skip this purchase.
										$do_skip = false;
									}

								}

								if ( $do_skip ) {
									continue;
								}

								// Flagging it as false as we didn't skipped current purchase one.
								$iap_exists = false;

							}

							$found_usable = true;

							// Storing transaction id in db to avoid granting access twice
							$transaction_data["transaction_id"]        = $purchase->getTransactionId();
							$transaction_data["parent_transaction_id"] = $purchase->getOriginalTransactionId();
							$transaction_data["data"]["sandbox"]       = $response->isSandbox();

							if ( in_array( $store_product_type, array(
								'non_auto_renewable
							'
							) ) ) {

								// Meta-data for : Non-Renewing Subscription(non_auto_renewable)
								$subscription_duration                     = $data["subscription_duration"];
								$transaction_data["subscription_duration"] = $subscription_duration;

								$set_expiry = null;
								switch ( $subscription_duration ) {
									case '1-week':
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+1 week", time() ) );
										break;
									case '1-month':
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+1 month", time() ) );
										break;
									case '2-month':
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+2 month", time() ) );
										break;
									case '3-month':
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+3 month", time() ) );
										break;
									case '6-month':
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+6 month", time() ) );
										break;
									case '1-year':
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+365 day", time() ) );
										break;
									default:
										$set_expiry = date( "Y-m-d H:i:s", strtotime( "+365 day", time() ) );
										break;
								}
								$transaction_data["expire_at"] = $set_expiry;
							}

							if ( ! empty( $purchase->getPurchaseDate() ) ) {
								$transaction_data["transaction_date"] = gmdate( 'Y-m-d H:i:s', $purchase->getPurchaseDate()->getTimestamp() );
								$transaction_data["transaction_date_ms"] = $purchase->getPurchaseDate()->getTimestamp();
							}

							$raw_response = $purchase->getRawResponse();

							if ( isset( $raw_response["is_trial_period"] ) ) {

								if ( is_string( $raw_response["is_trial_period"] ) ) {
									$raw_response["is_trial_period"] = ( $raw_response["is_trial_period"] == "true" ) ? true : false;
								}

								$transaction_data["data"]["trial_period"] = $raw_response["is_trial_period"];

								if ( $transaction_data["data"]["trial_period"] ) {
									$transaction_data["data"]["transaction_history"] = __( "Transaction started as free trial." );
									$transaction_data["data"]["had_trial"]           = true;
								}

							}

							if ( $found_usable ) {
								// No need to continue the loop as we found the transaction.
								break;
							}

						}

					}

				}

				// Return data as it's found.
				if ( isset( $found_usable ) ) {
					return $transaction_data;
				}

				// When we didn't found any store_product_id having unused transaction_id we will throw here.
				if ( ! empty( $iap_exists ) ) {
					return new WP_Error( 'error_iap_validation', __( 'Matching product(s) found, but no usable transaction found.', 'buddyboss-app' ) );
				}

				return new WP_Error( 'error_iap_validation', __( 'No usable transaction found.', 'buddyboss-app' ) );

			} else {

				$status_code = "00000";

				if ( method_exists( $response, "getResultCode" ) ) {
					$status_code = $response->getResultCode();
				}

				return $this->error_by_apple_status_code( $status_code );

			}

		} catch ( Exception $e ) {
			return new WP_Error( 'error_iap_validation', __( 'Error while reading InAppPurchase token, could be invalid receipt token.', 'buddyboss-app' ) );
		}

	}


	/**
	 * Error handling
	 *
	 * @param $status_code
	 *
	 * @return WP_Error
	 */
	public function error_by_apple_status_code( $status_code ) {
		switch ( $status_code ) {

			case '21000':
				return new WP_Error( 'error_iap_validation', sprintf( __( "The App Store could not read the JSON object you provided. Error Code #%s.", 'buddyboss-app' ), $status_code ) );

				break;

			case '21002':
				return new WP_Error( 'error_iap_validation', sprintf( __( "The data in the receipt-data property was malformed or missing. Error Code #%s.", 'buddyboss-app' ), $status_code ) );
				break;

			case '21003':
				return new WP_Error( 'error_iap_validation', sprintf( __( "The receipt could not be authenticated. Error Code #%s.", 'buddyboss-app' ), $status_code ) );
				break;

			case '21004':
				return new WP_Error( 'error_iap_validation', sprintf( __( "The shared secret you provided does not match the shared secret on file for your account. Error Code #%s.", 'buddyboss-app' ), $status_code ) );
				break;

			case '21005':
				return new WP_Error( 'error_iap_validation', sprintf( __( "The receipt server is not currently available. Error Code #%s.", 'buddyboss-app' ), $status_code ) );

				break;

			case '21006':
				return new WP_Error( 'error_iap_validation', sprintf( __( "This receipt is valid but the subscription has expired. Error Code #%s.", 'buddyboss-app' ), $status_code ) );

				break;

			case '21007':
				return new WP_Error( 'error_iap_validation', __( "This receipt is from the test environment, but it was sent to the production environment for verification. Send it to the test environment instead. Error Code #$status_code.", 'buddyboss-app' ) );
				break;

			case '21008':
				return new WP_Error( 'error_iap_validation', __( "This receipt is from the production environment, but it was sent to the test environment for verification. Send it to the production environment instead. Error Code #$status_code.", 'buddyboss-app' ) );
				break;

			case '21010':
				return new WP_Error( 'error_iap_validation', sprintf( __( "This receipt could not be authorized. Treat this as if a purchase was never made. Error Code #%s.", 'buddyboss-app' ), $status_code ) );
				break;

			default:
				return new WP_Error( 'error_iap_validation',
					sprintf( __( 'Error while reading IAP token. Response found to be invalid. Error Code  #%s', 'buddyboss-app' ), $status_code ) );
				break;
		}

	}

	/**
	 * Returns all related receipts.
	 *
	 * @param $purchases
	 * @param $store_product_id
	 *
	 * @return array
	 */
	public function getAllRelatedReceipts( $purchases, $store_product_id ) {

		$receipts = array();

		foreach ( $purchases as $purchase ) {

			// Match the product we looking for.
			if ( $purchase->getProductId() == $store_product_id ) {

				$receipt = array(
					"transaction_date"      => false,
					"transaction_id"        => $purchase->getTransactionId(),
					"parent_transaction_id" => $purchase->getOriginalTransactionId(),
					"quantity"              => $purchase->getQuantity(),
					"expire_at"             => false,
				);

				if ( ! empty( $purchase->getPurchaseDate() ) ) {
					$receipt["transaction_date"] = $purchase->getPurchaseDate()->getTimestamp();
				}

				if ( ! empty( $purchase->getExpiresDate() ) ) {
					$receipt["expire_at"] = $purchase->getExpiresDate()->getTimestamp();
				}

				$receipts[] = $receipt;
			}

		}

		return $receipts;

	}


	/**
	 * Return Text Reason for expiration intent.
	 *
	 * @param $code
	 *
	 * @return mixed
	 */
	public function get_expiration_intent_text( $code ) {
		switch ( $code ) {
			case '1':
				return __( "Customer cancelled their subscription.", "buddyboss-app" );
				break;

			case '2':
				return __( "Billing error: for example, customer's payment information is no longer valid.", "buddyboss-app" );
				break;

			case '3':
				return __( "Customer did not agree to a recent price increase.", "buddyboss-app" );
				break;

			case '4':
				return __( "Product was not available for purchase at the time of renewal.", "buddyboss-app" );
				break;

			default:
				return __( "Unknown error.", "buddyboss-app" );
				break;
		}
	}

	/**
	 * Sync store product with local data.
	 */
	public function sync_store_product() {
		$products = Apple::instance()->_sync_store_product();

		update_option( "bbapp_{$this->type}_store_product", $products );

		return $products;
	}
}
