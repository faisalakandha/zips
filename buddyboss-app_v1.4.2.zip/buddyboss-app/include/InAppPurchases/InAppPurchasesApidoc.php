<?php

// Note : The soul purpose of this class is apidoc(documentation generator). By Ketan
class InAppPurchasesApidoc {

	private function apidocForGetIapProducts() {
		/**
		 * @apiDefine apidocForGetIapProducts
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Array} [include=array()] Limit result set to specific ids
		 */
	}

	private function apidocForGetIapProduct() {
		/**
		 * @apiDefine apidocForGetIapProduct
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id BuddyBossApp Product Id
		 */
	}

	private function apidocForGetIapProductBYIntegration() {
		/**
		 * @apiDefine apidocForGetIapProductBYIntegration
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=learndash-course, memberpress,woo-membership} integration_type Integration Type
		 */
	}

	private function apidocForGetIAPProductsByIntegrationItems() {
		/**
		 * @apiDefine apidocForGetIAPProductsByIntegrationItems
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=learndash-course, memberpress,woo-membership} integration_type Integration Type
		 * @apiParam {Number} item_id Item id (of selected/linked integration)
		 */
	}

	private function apidocForGetIAPProductsByItem() {
		/**
		 * @apiDefine apidocForGetIAPProductsByItem
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} item_id Item id (of selected/linked integration)
		 */
	}

	private function apidocForGetOrders() {
		/**
		 * @apiDefine apidocForGetOrders
		 *
		 * @apiHeader {String} accessToken Auth token
		 */
	}

}
