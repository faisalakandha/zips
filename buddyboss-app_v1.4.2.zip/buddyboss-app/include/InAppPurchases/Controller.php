<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\Admin\Settings;
use BuddyBossApp\Api\InAppPurchases\Main;
use BuddyBossApp\AppSettings;
use BuddyBossApp\Integrations\LearndashCourse\IAP as LearnDashCourseIAP;
use BuddyBossApp\Integrations\LearndashGroup\IAP as LearnDashGroupIAP;
use BuddyBossApp\Integrations\Memberium\IAP as MemberiumIAP;
use BuddyBossApp\Integrations\MemberPress\IAP as MemberPressIAP;
use BuddyBossApp\Integrations\PmProMembership\IAP as PmProMembershipIAP;
use BuddyBossApp\Integrations\RestrictContentPro\IAP as RestrictContentProIAP;
use BuddyBossApp\Integrations\S2Member\IAP as S2MemberIAP;
use BuddyBossApp\Integrations\WcMembership\IAP as WcMembershipIAP;
use BuddyBossApp\Integrations\WishlistMember\IAP as WishlistMemberIAP;

final class Controller {

	/**
	 * This options array is setup during class instantiation, holds
	 * default and saved options for the plugin.
	 *
	 * @var array
	 */
	protected $options = array();
	protected $admin = false;

	public $iap = array();

	//todo: this should be refactor.
	public $integration = array();

	public $integrations = array();
	public $option_setting = "bbapp_iap";

	private static $instance = null;

	public static $learndash_group_slug = 'learndash';
	public static $learndash_course_slug = 'learndash-course';
	public static $memberpress_slug = 'memberpressproduct';
	public static $wc_membership_slug = 'wc_membership_plan';
	public static $pmpro_membership_slug = 'pmpro_membership_levels';
	public static $wishlist_membership_slug = 'wishlist_member_level';
	public static $restrict_content_pro_slug = 'restrict_content_pro';
	public static $memberium_slug = 'memberium_level';
	public static $imember360_slug = 'imember360_level';
	public static $s2member_slug = 's2member_level';

	/**
	 * Controller constructor.
	 */
	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @param bool $loaderFile <string> of main plugin file used for detecting plugin directory and url.
	 *
	 * @return Controller|null
	 */
	public static function instance() {
		if ( null === self::$instance ) {

			// include functions(utils) file.
			require_once dirname( __FILE__ ) . "/functions.php";

			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->_setup_globals();
			self::$instance->_load_classes();
			self::$instance->_setup_actions();
			self::$instance->_setup_filters();
		}

		return self::$instance;
	}

	/**
	 * Setup Globals.
	 */
	protected function _setup_globals() {

		$savedOptions       = bbapp_get_network_option( $this->option_setting );
		$savedOptions       = maybe_unserialize( $savedOptions );
		$this->options      = $savedOptions;
		$this->integrations = array(
			/*self::$imember360_slug => array(
				'type'    => 'imember360',
				'label'   => __( 'iMember360', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
			),*/
			self::$learndash_course_slug     => array(
				'type'    => 'learndash-course',
				'label'   => __( 'LearnDash Course', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
			),
			self::$learndash_group_slug      => array(
				'type'    => 'learndash-group',
				'label'   => __( 'LearnDash Group', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$memberium_slug            => array(
				'type'    => 'memberium',
				'label'   => __( 'Memberium', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$memberpress_slug          => array(
				'type'    => 'memberpress',
				'label'   => __( 'MemberPress', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$pmpro_membership_slug     => array(
				'type'    => 'pm-pro-membership',
				'label'   => __( 'Paid Memberships Pro', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$restrict_content_pro_slug => array(
				'type'    => 'restrict-content-pro',
				'label'   => __( 'Restrict Content Pro', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$s2member_slug             => array(
				'type'    => 's2member',
				'label'   => __( 'S2Member', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$wishlist_membership_slug  => array(
				'type'    => 'wishlist-member',
				'label'   => __( 'Wishlist Member', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
			self::$wc_membership_slug        => array(
				'type'    => 'woo-membership',
				'label'   => __( 'WooCommerce Memberships', 'buddyboss-app' ),
				'enabled' => false,
				'class'   => null,
				'group'   => 'membership',
			),
		);
	}

	/**
	 *
	 */
	protected function _setup_actions() {
		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_action( 'init', array( $this, 'load_integrations' ), 1 );
	}

	/**
	 * Initiate the required classes.
	 */
	protected function _load_classes() {

		if ( ! defined( 'IAP_LOG' ) ) {
			$settings = Settings::instance()->get_settings();
			if ( bbapp_is_active( 'iap' ) && ( isset( $settings['logger.iap_log.enabled'] ) && $settings['logger.iap_log.enabled'] ) ) {
				define( 'IAP_LOG', true );
			} else {
				define( 'IAP_LOG', false );
			}
		}

		SubscriptionGroupTaxonomy::instance();
		Main::instance();
		Orders::instance();
		Ios::instance();
		Android::instance();
		Ajax::instance();
		LearnDashIapRest::instance();
	}

	/**
	 * Load the integrations.
	 */
	public function load_integrations() {

		if ( defined( 'LEARNDASH_VERSION' ) ) {
			LearnDashCourseIAP::instance()->set_up( $this->integrations[ self::$learndash_course_slug ]['type'], $this->integrations[ self::$learndash_course_slug ]['label'] );
			$this->integrations[ self::$learndash_course_slug ] ['enabled'] = true;
			$this->integrations[ self::$learndash_course_slug ] ['class']   = LearnDashCourseIAP::class;

			LearnDashGroupIAP::instance()->set_up( $this->integrations[ self::$learndash_group_slug ]['type'], $this->integrations[ self::$learndash_group_slug ]['label'] );
			$this->integrations[ self::$learndash_group_slug ] ['enabled'] = true;
			$this->integrations[ self::$learndash_group_slug ] ['class']   = LearnDashGroupIAP::class;
		}
		if ( function_exists( 'wc_memberships' ) ) {
			WcMembershipIAP::instance()->set_up( $this->integrations[ self::$wc_membership_slug ]['type'], $this->integrations[ self::$wc_membership_slug ]['label'] );
			$this->integrations[ self::$wc_membership_slug ] ['enabled'] = true;
			$this->integrations[ self::$wc_membership_slug ] ['class']   = WcMembershipIAP::class;
		}
		if ( class_exists( 'MeprTransaction' ) ) {
			MemberPressIAP::instance()->set_up( $this->integrations[ self::$memberpress_slug ]['type'], $this->integrations[ self::$memberpress_slug ]['label'] );
			$this->integrations[ self::$memberpress_slug ] ['enabled'] = true;
			$this->integrations[ self::$memberpress_slug ] ['class']   = MemberPressIAP::class;
		}
		if ( function_exists( "pmpro_changeMembershipLevel" ) ) {
			PmProMembershipIAP::instance()->set_up( $this->integrations[ self::$pmpro_membership_slug ]['type'], $this->integrations[ self::$pmpro_membership_slug ]['label'] );
			$this->integrations[ self::$pmpro_membership_slug ] ['enabled'] = true;
			$this->integrations[ self::$pmpro_membership_slug ] ['class']   = PmProMembershipIAP::class;
		}

		if ( class_exists( 'WishListMember' ) ) {
			WishlistMemberIAP::instance()->set_up( $this->integrations[ self::$wishlist_membership_slug ]['type'], $this->integrations[ self::$wishlist_membership_slug ]['label'] );
			$this->integrations[ self::$wishlist_membership_slug ] ['enabled'] = true;
			$this->integrations[ self::$wishlist_membership_slug ] ['class']   = WishlistMemberIAP::class;
		}

		if ( class_exists( 'Restrict_Content_Pro' ) ) {
			RestrictContentProIAP::instance()->set_up( $this->integrations[ self::$restrict_content_pro_slug ]['type'], $this->integrations[ self::$restrict_content_pro_slug ]['label'] );
			$this->integrations[ self::$restrict_content_pro_slug ] ['enabled'] = true;
			$this->integrations[ self::$restrict_content_pro_slug ] ['class']   = RestrictContentProIAP::class;
		}
		if ( defined( 'MEMBERIUM_SKU' ) ) {
			MemberiumIAP::instance()->set_up( $this->integrations[ self::$memberium_slug ]['type'], $this->integrations[ self::$memberium_slug ]['label'] );
			$this->integrations[ self::$memberium_slug ] ['enabled'] = true;
			$this->integrations[ self::$memberium_slug ] ['class']   = MemberiumIAP::class;
		}
		/*if ( function_exists( 'iMember360' ) ) {
			IMember360IAP::instance()->set_up( $this->integrations[ self::$imember360_slug ]['type'], $this->integrations[ self::$imember360_slug ]['label'] );
			$this->integrations[ self::$imember360_slug ] ['enabled'] = true;
			$this->integrations[ self::$imember360_slug ] ['class']   = IMember360IAP::class;
		}*/
		if ( defined( 'WS_PLUGIN__S2MEMBER_VERSION' ) ) {
			S2MemberIAP::instance()->set_up( $this->integrations[ self::$s2member_slug ]['type'], $this->integrations[ self::$s2member_slug ]['label'] );
			$this->integrations[ self::$s2member_slug ] ['enabled'] = true;
			$this->integrations[ self::$s2member_slug ] ['class']   = S2MemberIAP::class;
		}
	}

	/**
	 * Get all Integrations
	 * @return array Integrations list
	 */
	public function get_integrations() {
		return $this->integrations;
	}

	/**
	 * Get all Active Integrations.
	 *
	 * @return array
	 */
	public function get_enabled_integrations() {
		$all_integrations    = $this->integrations;
		$active_integrations = array();
		if ( ! empty( $all_integrations ) ) {
			foreach ( $all_integrations as $key => $integration ) {
				if ( ! empty( $integration['enabled'] ) && ! empty( $integration['label'] ) ) {
					$active_integrations[ $key ] = $integration;
				}
			}
		}

		return $active_integrations;
	}

	/**
	 *
	 */
	public function init() {
		// Admin
		if ( ( is_admin() || is_network_admin() ) && current_user_can( 'manage_options' ) ) {
			$this->load_admin();
		}
	}

	/**
	 *
	 */
	private function load_admin() {
		$this->admin = Admin::instance();
	}

	/**
	 * @param $key
	 *
	 * @return mixed|null
	 */
	public function option( $key ) {

		$key    = strtolower( $key );
		$option = isset( $this->options[ $key ] ) ? $this->options[ $key ] : null;
		$option = apply_filters( 'bbapp_iap_option_' . $key, $option );

		return $option;

	}

	/**
	 * Property
	 *
	 * @return \BuddyBossApp\InAppPurchases\Admin|bool
	 */
	public function admin() {
		return $this->admin;
	}

	/**
	 * @return mixed
	 */
	public function get_global_dbprefix() {
		return bbapp_get_global_db_prefix();
	}

	/**
	 * Return the rest Settings.
	 *
	 * @return array
	 */
	public function get_rest_settings() {

		$products                 = bbapp_is_active( 'iap' ) ? Helpers::getProducts() : array();
		$lockApp                  = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.lock_app" ) : false;
		$purchase_before_register = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.purchase_before_register" ) : false;
		$register_show_products   = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.register.show_products" ) : '';
		$register_show_products   = ! empty( $register_show_products ) ? $register_show_products : 'before_registration';
		$terms_page_id            = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.terms" ) : null;
		$policy_page_id           = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.policy" ) : null;
		$review_version_ios       = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.review_version.ios" ) : null;
		$subscribeMessage         = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.subscribe_message" ) : null;

		$has_access = true;
		if ( ! empty( $products ) ) {
			$has_access = false;
			foreach ( $products as $product ) {
				if ( $product['has_access'] ) {
					$has_access = true;
					break;
				}
			}
		}
		$has_access = bbapp_is_active( 'iap' ) ? $has_access : false;

		$properties = array(
			"has_access"               => $has_access,
			"lock_app"                 => $lockApp == 1,
			"purchase_before_register" => $purchase_before_register == 1,
			"register_show_products"   => ( $purchase_before_register == 1 ) ? $register_show_products : false,
			"terms_page_id"            => (int) $terms_page_id,
			"policy_page_id"           => (int) $policy_page_id,
			"review_version_ios"       => ! empty( $review_version_ios ) ? $review_version_ios : null,
			"subscribe_message"        => $subscribeMessage,
			"products"                 => $products,
		);

		return $properties;

	}

	/**
	 * When BuddyBoss App plugin is activated
	 */
	public function on_activation() {
		global $wpdb;

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();

		$charsetCollate = $wpdb->get_charset_collate();

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$tableName = "{$globalPrefix}bbapp_iap_products";

		$sql = "CREATE TABLE {$tableName} (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            blog_id bigint(20) NOT NULL,
            product_author_id bigint(20) NOT NULL,
            name varchar(100) NOT NULL,
            tagline longtext NOT NULL,
            description longtext NOT NULL,
            store_data longtext NOT NULL,
            misc_settings longtext NOT NULL,            
            integration_data longtext NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'published',
            date_created datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_updated datetime DEFAULT '0000-00-00 00:00:00' NULL,
            iap_group bigint(20) NOT NULL DEFAULT 0,
            menu_order int(11) NOT NULL default '0',
            KEY  blog_id (blog_id),
            KEY  product_author_id (product_author_id),
            KEY  date_created (date_created),
            KEY  date_updated (date_updated)
		    ) {$charsetCollate}";

		dbDelta( $sql );

		$meta_tableName = "{$globalPrefix}bbapp_iap_productmeta";

		$meta_sql = "CREATE TABLE {$meta_tableName} (
		    meta_id bigint(20) unsigned NOT NULL auto_increment,
			iap_id bigint(20) unsigned NOT NULL default '0',
			meta_key varchar(255) default NULL,
			meta_value longtext,
			PRIMARY KEY  (meta_id),
			KEY iap_id (iap_id),
        	KEY meta_key (meta_key(191))
		) {$charsetCollate}";

		dbDelta( $meta_sql );
	}

	/**
	 * When BuddyBoss App plugin is deactivated
	 */
	public function on_plugin_deactivate() {
	}

	/**
	 * Define all filter hooks.
	 *
	 * @since 1.3.7
	 *
	 * @return void
	 */
	protected function _setup_filters() {
		// Unlock the privacy and terms page When the Web and APP is private mode.
		add_filter( 'bp_private_network_pre_check', array( $this, 'unlock_restricted_page' ) );
	}

	/**
	 * Unlock the privacy and terms page for IAP products.
	 *
	 * @since 1.3.7
	 *
	 * @param bool $retval Access privacy mode for terms and privacy content.
	 *
	 * @return bool
	 */
	public function unlock_restricted_page( $retval ) {
		global $wp_query;

		$current_page_object = $wp_query->get_queried_object();
		$page_id             = isset( $current_page_object->ID ) ? $current_page_object->ID : get_the_ID();
		$page_id             = ( ! empty( $page_id ) ) ? $page_id : 0;

		if ( empty( $page_id ) ) {
			return $retval;
		}

		$terms_page_id  = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.terms" ) : '';
		$policy_page_id = bbapp_is_active( 'iap' ) ? AppSettings::instance()->get_setting_value( "iap.policy" ) : '';

		if ( ! empty( $terms_page_id ) && ( (int) $page_id === (int) $terms_page_id ) ) {
			return true;
		}

		if ( ! empty( $policy_page_id ) && ( (int) $page_id === (int) $policy_page_id ) ) {
			return true;
		}

		return $retval;
	}
}
