<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Admin Class
 */
final class Admin {

	private static $instance = null;

	/**
	 * Empty constructor function to ensure a single instance
	 */
	public function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Returns the Singleton of The Class.
	 *
	 * @return Admin|null
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
		}

		return self::$instance;
	}

	/**
	 * Returns the value by index key from options.
	 *
	 * @param string $key Key Name.
	 *
	 * @return mixed|null|void
	 */
	public function option( $key ) {
		return bbapp_iap()->option( $key );
	}
}
