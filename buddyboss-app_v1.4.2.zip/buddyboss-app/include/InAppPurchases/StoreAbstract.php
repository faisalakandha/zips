<?php

namespace BuddyBossApp\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Logger;
use WP_Error as WP_Error;

abstract class StoreAbstract {

	protected $type = false;
	protected $label = false;
	public $store_product_types = array();

	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @return void
	 */
	public static function instance() {
	}

	/**
	 * Integration label
	 * @return string
	 */
	public function get_label() {
		return $this->label;
	}

	/**
	 * Integration type
	 * @return string
	 */
	public function get_type() {
		return $this->type;
	}

	/**
	 * Function to be overridden in sub-class
	 *
	 * @param $integration_type
	 * @param $integration_label
	 * @param $store_product_types
	 */
	public function set_up( $integration_type, $integration_label, $store_product_types ) {

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", sprintf( "BuddyBossApp\InAppPurchases\Iap->set_up(), integrationType: %s, integrationLabel: %s", $integration_type, $integration_label ) );
		}
		$this->type                = $integration_type;
		$this->label               = $integration_label;
		$this->store_product_types = $store_product_types;
		$this->hooks();
	}

	/**
	 * Function to add actions/filters
	 */
	private function hooks() {
		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", "BuddyBossApp\InAppPurchases\Iap->hooks()" );
		}
		add_filter( "bbapp_iap_get_registered_iap", array( $this, 'register_iap' ) );
	}

	/**
	 * Register current instance iap type for easy access using the filter.
	 *
	 * @param $registered_iap
	 *
	 * @return mixed
	 */
	public function register_iap( $registered_iap ) {
		$registered_iap[ $this->type ] = $this->label;

		return $registered_iap;
	}

	/**
	 * Return IAP Product Type.
	 *
	 * @param $product_type
	 *
	 * @return bool|mixed
	 */
	public function get_product_type( $product_type ) {
		if ( isset( $this->store_product_types[ $product_type ] ) ) {
			return $this->store_product_types[ $product_type ];
		}

		return false;
	}

	/**
	 * Renders the product settings.
	 *
	 * @param $integration
	 * @param $item
	 */
	abstract function render_product_settings( $integration, $item );

	/**
	 * Save the product settings.
	 *
	 * @param $integration
	 * @param $item
	 */
	abstract function save_product_settings( $integration, $item );

	/**
	 * Quick access function for bbapp_iap_get_products
	 *
	 * @param $args
	 *
	 * @return array
	 */
	public function get_products( $args ) {
		return bbapp_iap_get_products( $args );
	}

	/**
	 * Quick access function for bbapp_iap_get_product
	 *
	 * @param $product_id
	 *
	 * @return array|bool|\direct
	 */
	public function get_product( $product_id ) {
		return bbapp_iap_get_product( $product_id );
	}

	/**
	 * Helper function default appending iap_type
	 *
	 * @param $product
	 *
	 * @return WP_Error|array
	 * @uses bbapp_iap_create_product
	 */
	public function create_product( $product ) {

		$default = array(
			'iap_type' => $this->type,
		);

		$product = array_merge( $default, $product );

		return bbapp_iap_create_product( $product );

	}

	/**
	 * Helper function to update product.
	 *
	 * @param $order_id
	 * @param $data
	 *
	 * @return bool
	 */
	public function update_product( $order_id, $data ) {
		return bbapp_iap_update_product( $order_id, $data );
	}

	/**
	 * Should be override by iap type.
	 *
	 * @param $data
	 *
	 * @return array
	 * @uses StoreAbstract::_process_payment()
	 */
	abstract function process_payment( $data );

	/**
	 * Process Payment Token.
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function _process_payment( $data ) {

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", 'BuddyBossApp\InAppPurchases\Iap->_process_payment()' );
		}
		/**
		 * Data Variable Structure.
		 * [order_id] << Unique identifier for order.
		 * [bbapp_product_id] << Unique identifier for BuddyBossAppProduct stored in db.
		 * [iap_receipt_token] << InAppPurchase token generated on front-end(mobile)
		 * [store_product_id] << Store product id for ios or android
		 * [store_product_type] << Type of Store Product eg. consumable, non_consumable.
		 * [bbapp_product_type] << Type of Product type eg. free,paid.
		 * [integration_type] << Integration type eg. learndash-course, memberpress, woo-membership,
		 */

		$default = array(
			"test_mode"          => false,
			"iap_receipt_token"  => null,
			"store_product_id"   => null,
			"store_product_type" => null,
			"bbapp_product_type" => null,
			"integration_types"  => null,
		);

		$data = array_merge( $default, $data );

		/**
		 * Test mode will help to test order flow without actual validation process.
		 * This is useful to test integration without doing actual payment.
		 */
		if ( ! empty( $data['test_mode'] ) ) {

			$transaction_data = array(
				"transaction_date"      => gmdate( "Y-m-d H:i:s" ),
				"transaction_date_ms"   => strtotime( gmdate( "Y-m-d H:i:s" ) ) * 1000,
				"parent_transaction_id" => sha1( time() ),
				"transaction_id"        => sha1( time() ),
				"data"                  => $data,
				"expire_at"             => false, // should be given if product is recurring.
			);

			// NOTE : Very
			if ( in_array( $data["store_product_type"], array( "auto_renewable" ) ) ) {

				$gmtime                        = strtotime( gmdate( "Y-m-d H:i:s" ) );
				$transaction_data["expire_at"] = date( "Y-m-d H:i:s", strtotime( "+5 minutes", $gmtime ) );
			}

			$transaction_data["data"]["sandbox"] = true;

			$transaction_data["data"]["transaction_history"] = __( "Generated using test transaction mode.", "buddyboss-app" );
			$transaction_data["data"]["test_mode"]           = 1;

			return $transaction_data;

		} else {
			// Trim the values to make sure no whitespace are there.
			if ( isset( $data["store_product_id"] ) ) {
				$data["store_product_id"] = trim( $data["store_product_id"] );
			}
			if ( isset( $data["store_product_type"] ) ) {
				$data["store_product_type"] = trim( $data["store_product_type"] );
			}
			if ( isset( $data["bbapp_product_type"] ) ) {
				$data["bbapp_product_type"] = trim( $data["bbapp_product_type"] );
			}
			if ( isset( $data["integration_types"] ) ) {
				$data["integration_types"] = trim( $data["integration_types"] );
			}
			if( isset( $data["bbapp_product_type"] ) && 'free' === $data["bbapp_product_type"] ){
				$transaction_data = array(
					"transaction_date"      => gmdate( "Y-m-d H:i:s" ),
					"transaction_date_ms"   => strtotime( gmdate( "Y-m-d H:i:s" ) ) * 1000,
					"parent_transaction_id" => sha1( time() ),
					"transaction_id"        => sha1( time() ),
					"data"                  => $data,
					"expire_at"             => false, // should be given if product is recurring.
				);

				$transaction_data["data"]["transaction_history"] = __( "Generated transaction for free product.", "buddyboss-app" );
				return  $transaction_data;
			} else {

				$data = $this->process_payment( $data );
			}

		}

		return $data;

	}

	/**
	 * Checks if transaction id is already present in db. Return orders..
	 *
	 * @param $origin_transaction_id
	 *
	 * @return array|bool|null|object|void
	 */
	public function do_transaction_exists( $origin_transaction_id ) {
		global $wpdb;

		$table = bbapp_iap()->get_global_dbprefix() . "bbapp_iap_ordermeta";

		$store_product_type_require = $wpdb->prepare( "(SELECT count(*) FROM `{$table}` WHERE meta_key = '_iap_type' AND meta_value=%s AND order_id=meta.order_id)", $this->type );

		$sql = $wpdb->prepare( "SELECT order_id FROM `{$table}` as meta WHERE meta_key='_parent_transaction_id' AND meta_value=%s AND {$store_product_type_require}=1", $origin_transaction_id );

		$results = $wpdb->get_results( $sql );

		if ( empty( $results ) ) {
			return false;
		}

		$orders = array();

		foreach ( $results as $r => $v ) {
			$orders[] = Orders::instance()->get_by_id( $v->order_id );
		}

		return $orders;
	}

	/**
	 * Validates the order id.
	 *
	 * @param $order_id
	 *
	 * @return bool
	 */
	public function _validate( $order_id ) {

		$order = Orders::instance()->get_by_id( $order_id );

		// if order doesn't exists.
		if ( empty( $order ) ) {
			return false;
		}

		// if no 'subscribed' order don't need to be validated as far as now.
		if ( ! in_array( $order->order_status, array( 'subscribed' ) ) ) {
			return false;
		}

		// if expire_at is greater then now UTC than don't do anything.
		if ( strtotime( $order->expire_at ) > strtotime( gmdate( "Y-m-d H:i:s" ) ) ) {
			Orders::instance()->update_order_next_validation_retry( $order->id, "+6 hours" );

			return false;
		}

		$iap_receipt_token  = Orders::instance()->get_meta( $order_id, "_iap_receipt_token" );
		$bbapp_product_id = $order->bbapp_product_id;
		$store_product_type = Orders::instance()->get_meta( $order_id, "_store_product_type" );
		$store_product_id   = Orders::instance()->get_meta( $order_id, "_store_product_id" );

		$test_mode = Orders::instance()->get_meta( $order_id, "_transaction_data_test_mode" );

		$integration_types = unserialize( $order->integration_types );

		foreach ( $integration_types as $integration_type ) {
			$integration = bbapp_iap()->integration[ $integration_type ];

			if ( empty( $iap_receipt_token ) || empty( $bbapp_product_id ) || empty( $store_product_type ) || empty( $store_product_id ) ) {
				Orders::instance()->update_order_next_validation_retry( $order->id, "+24 hours" );
				Orders::instance()->add_history( $order->id, 'iap-error', __( "Error renewing order data found invalid.", 'buddyboss-app' ) );

				return false;
			}

			if ( ! $integration ) {
				Orders::instance()->update_order_next_validation_retry( $order->id, "+24 hours" );
				Orders::instance()->add_history( $order->id, 'iap-error', __( "Error renewing order integration not present.", 'buddyboss-app' ) );

				return false;
			}

			$args = array(
				'order_id'           => $order_id,
				'iap_receipt_token'  => $iap_receipt_token,
				'bbapp_product_id' => $bbapp_product_id,
				'store_product_type' => trim( $store_product_type ),
				'store_product_id'   => trim( $store_product_id ),
				'integration_type'   => trim( $integration_type ),
			);

			// if it's a test mode than fake it & bail it now.
			if ( $test_mode == "1" ) {
				// does fake validates & return fake transaction data.
				$validate = $this->fakeValidate( $args, $order );

			} else {
				// else do the real validation.

				/**
				 * Should Return
				 * [status] // will determine if order is expired or not.
				 * [transaction_date]
				 * [parent_transaction_id]
				 * [transaction_id]
				 * [data] // will be stored in order meta.
				 * [expire_at]
				 */

				$validate = $this->validate( $args );
			}

			$order_status = 'subscribed';
			$expire_at    = $order->expire_at;

			// CASE : When there is error or something
			if ( is_wp_error( $validate ) || empty( $validate ) ) {

				Orders::instance()->update_order_next_validation_retry( $order->id, "+12 hours" );
				$error = $validate->get_error_message();
				Orders::instance()->add_history( $order->id, 'iap-error', sprintf( __( "Error Completing Order : %s", "buddyboss-app" ), $error ) );

				// NOTE : This case is when we get error from backend(something went wrong)
				Orders::instance()->add_history( $order->id, 'warning', __( "Order has expired or something went wrong.", 'buddyboss-app' ) );
				// trigger the item integration action.
				$integration->_on_order_expired( $order );

				return false;
			}

			// CASE : When subscription is expired but store is still retrying to renew.
			if ( $validate['status'] == 'retrying' ) {

				Orders::instance()->add_history( $order->id, 'warning', __( "Store is retrying for payment.", 'buddyboss-app' ) );
				Orders::instance()->update_order_next_validation_retry( $order->id, "+12 hours" );

				return false;
			}

			// CASE : When subscription is expired 100 %
			if ( $validate['status'] == 'expired' ) {

				$order_status = 'expired';

				$date_format = get_option( "date_format" ) . " @ " . get_option( "time_format" );
				$expired_at  = date( $date_format, strtotime( $order->expire_at ) ) . " GMT";
				Orders::instance()->add_history( $order->id, 'warning', __( 'Order expired at ' . $expired_at, 'buddyboss-app' ) );

				// trigger the item integration action.
				$integration->_on_order_expired( $order );
			}

			// CASE : When subscription is valid/active
			if ( $validate['status'] == 'subscribed' ) {

				$order_status = 'subscribed';

				// Update meta information.
				if ( isset( $validate['transaction_id'] ) ) {
					Orders::instance()->update_meta( $order->id, '_transaction_id', $validate['transaction_id'] );
				}
				if ( isset( $validate["parent_transaction_id"] ) ) {
					Orders::instance()->update_meta( $order->id, '_parent_transaction_id', $validate['parent_transaction_id'] );
				}
				if ( isset( $validate["transaction_date"] ) ) {
					Orders::instance()->update_meta( $order->id, '_transaction_date', $validate['transaction_date'] );
				}

				// Store extras data from processPayment
				foreach ( $validate["data"] as $k => $v ) {
					Orders::instance()->update_meta( $order->id, "_transaction_data_{$k}", $v );
				}

				Orders::instance()->add_history( $order->id, 'info', __( "Order has been renewed successfully.", 'buddyboss-app' ) );

				// Set next check time.
				$expire_at = $validate['expire_at'];


				if ( Orders::instance()->get_meta( $order->id, "_transaction_data_sandbox" ) == "1" ) {
					// next check +1 minute from expire_at only for sandbox.
					Orders::instance()->update_order_next_validation_retry( $order->id, "+1 minute",
						date( "Y-m-d H:i:s", strtotime( $expire_at ) ) );
				} else {
					// next check +1 day from expire_at
					Orders::instance()->update_order_next_validation_retry( $order->id, "+1 day",
						date( "Y-m-d H:i:s", strtotime( $expire_at ) ) );
				}

				// Make sure item is activated.
				$integration->_on_order_activate( $order );

			}

			// Update expire at anyway.
			Orders::instance()->update_order( $order->id, array(
				'expire_at'    => $expire_at,
				'order_status' => $order_status,
			) );
		}

		return true;

	}

	/**
	 * Validates order payment status
	 *
	 * @param $data
	 *
	 * @return mixed
	 */
	public function validate( $data ) {
		return new WP_Error( 'no_validation_implemented', __( 'No correct validation method has been implemented in IAP type.', 'buddyboss-app' ) );
	}

	/**
	 * Fake - Validates order payment status
	 *
	 * @param $data
	 * @param $order
	 *
	 * @return mixed
	 */
	final function fakeValidate( $data, $order ) {

		$validate = array(
			'status'                => 'subscribed',
			'transaction_date'      => gmdate( "Y-m-d H:i:s" ),
			'parent_transaction_id' => sha1( time() ),
			'transaction_id'        => sha1( time() ),
			'data'                  => array(),
			'expire_at'             => '',
			'history'               => array(),
		);

		$renewCountKey = "_transaction_data_test_mode_renew_count";

		$renewCount = (int) Orders::instance()->get_meta( $order->id, $renewCountKey );
		$renewCount ++;

		if ( $renewCount > 5 ) {
			$validate["status"] = "expired";
		} else {
			Orders::instance()->update_meta( $order->id, $renewCountKey, $renewCount );
		}

		if ( in_array( $data["store_product_type"], array( "auto_renewable" ) ) ) {

			// Prepare next fake expire at time.
			$_time = strtotime( $validate['transaction_date'] );

			$validate["expire_at"] = date( "Y-m-d H:i:s",
				strtotime( "+5 minutes", $_time ) ); // add more five minutes to last expire.

		}

		return $validate;

	}

}