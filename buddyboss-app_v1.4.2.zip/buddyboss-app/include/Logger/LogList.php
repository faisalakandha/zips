<?php

namespace BuddyBossApp\Logger;
if (!defined('ABSPATH')) {
    exit();
}

use \BuddyBossApp\Helpers\WP_List_Table;
use \BuddyBossApp\Logger;

class LogList extends WP_List_Table
{

    /** Class constructor */
    public function __construct()
    {
        parent::__construct(array(
            'singular' => __('Log', 'buddyboss-app'), //singular name of the listed records
            'plural' => __('Logs', 'buddyboss-app'), //plural name of the listed records
            'ajax' => false, //should this table support ajax?
        ));

    }

    /**
     * Get logs from database.
     *
     * @param string $types
     * @param int $per_page
     * @param int $page_number
     *
     * @return mixed
     */
    public static function get_logs( $types = '' ,$per_page = 5, $page_number = 1)
    {

        $args = array();
        $request = $_REQUEST;

        if (isset($request['orderby']) && !empty($request['orderby'])) {
            $args["orderby"] = $request['orderby'];
        }
        if (isset($request['order']) && !empty($request['order'])) {
            $args["order"] = $request['order'];
        }

        $args["per_page"] = $per_page;

        $args["current_page"] = $page_number;

        $args["types"] = $types;

        $results = Helpers::get_logs($args);

        // convert to array;
        foreach ($results as $k => $v) {
            $results[$k] = (array)$v;
        }

        return $results;

    }

    /**
     * Returns the count of records in the database.
     *
     * @return null|string
     */
    public static function record_count( $types = '' )
    {
        return Helpers::get_logs_count( $types );
    }

    /**
     * return the column available to this table list.
     * @return array
     */
    public function get_columns()
    {
	    return [
	        'created' => __('Date', 'buddyboss-app'),
	        'details' => __('Details', 'buddyboss-app'),
	    ];
    }

	/**
	 *
	 */
    public function no_items()
    {
        _e('No items found.', 'buddyboss-app');
    }

	/**
	 * @param object $item
	 * @param string $column_name
	 *
	 * @return int|string|void
	 */
    public function column_default($item, $column_name)
    {

        $date_format = get_option("date_format") . " @ " . get_option("time_format");

        switch ($column_name) {
            case 'created':
                $gmt_time = date($date_format, strtotime($item['created'])) . " GMT";
                return $gmt_time;
                break;
            case 'details':
                return nl2br( $item['text'] );
                break;
            default:
                return "N/A";
                break;
        }
    }

    /**
     * Handles data query and filter, sorting, and pagination.
     */
    public function prepare_items()
    {

        /**
         * Init column headers.
         */
        $this->_column_headers = array($this->get_columns(), array(), $this->get_sortable_columns());

        /* Process action */
        $this->process_actions();

        $per_page = 20;
        $current_page = $this->get_pagenum();

        $supported_types = Logger::get_logger_types();
        $supported_types = array_keys( $supported_types );
        $supported_types = array_filter( $supported_types );
        $types = (! empty( $_GET['log_filter'] ) && in_array( $_GET['log_filter'], $supported_types ) ) ? $_GET['log_filter'] : $supported_types;

        $total_items = self::record_count( $types );

        $this->set_pagination_args([
            'total_items' => $total_items, //WE have to calculate the total number of items
            'per_page' => $per_page, //WE have to determine how many items to show on a page
        ]);

        $this->items = self::get_logs($types, $per_page, $current_page);
    }

	/**
	 *
	 */
    public function process_actions()
    {
        if (!current_user_can("manage_options")) {
            wp_die("You don't have permission to access this page.", "buddyboss-app");
        }
    }

	/**
	 * @param $item
	 *
	 * @return string
	 */
    public function column_id($item)
    {
        $actions = array();
        return sprintf('%1$s %2$s', $item["id"], $this->row_actions($actions));
    }

	/**
	 * @return array
	 */
    public function get_sortable_columns()
    {
	    return array(
	        'created' => array('created', true),
	    );
    }

}
