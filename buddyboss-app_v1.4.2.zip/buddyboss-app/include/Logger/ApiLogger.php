<?php

namespace BuddyBossApp\Logger;

use BuddyBossApp\Logger;
use BuddyBossApp\Admin\Settings;

class ApiLogger
{
    private static $instance;

    /**
     * Using Singleton, see instance()
     */
    public function __construct()
    {
        //Using Singleton, see instance()
    }

    /**
     * Get the instance of the class.
     * @return object
     */
    public static function instance()
    {
        if (null === self::$instance) {
            $class_name = __CLASS__;
            self::$instance = new $class_name;
            self::$instance->load();
        }
        return self::$instance;
    }

    public function is_enabled(){
        $settings = Logger::get_settings();
        return ( ! empty( $settings['logger_enabled'] ) && ! empty( $settings['logger_api_log_enabled'] ) );
    }

    /**
     *
     */
    public function load()
    {
        if ( $this->is_enabled() ) {
            add_action( 'init', array( $this, 'create_log' ) );
        }
    }

    public function create_log()
    {
        if ( $this->is_rest_url() ) {
            $url = $_SERVER[ 'REQUEST_URI' ];
            if ( strpos( $url, 'wp-json/' ) !== false ) {
                $this->log( $_SERVER[ 'REQUEST_URI' ] );
            }
        }
    }

    /**
     * @param $text
     * @return WP_Error|bool
     */
    private function  log( $text )
    {
        if( is_array( $text ) || is_object( $text ) ) {
            $text = json_encode( $text );
        }

        $text = !empty( $text ) ? "Rest :: " . $text . "\n" : '';

        if ( ! empty( $_SERVER['HTTP_ACCESSTOKEN'] ) ){
            $text = $text . "AccessToken :: " . $_SERVER['HTTP_ACCESSTOKEN'] . "\n";
        }

        if ( ! empty( $_SERVER['REQUEST_METHOD'] ) && 'POST' == $_SERVER['REQUEST_METHOD'] && ! empty( $_POST ) ){
            $text = $text . "Data :: " . json_encode( $_POST ) . "\n\n";
        }

        Logger::instance()->add("api_log", $text);
        return true;
    }


    private function is_rest_url()
    {
        $is_rest = false;
        if ( function_exists( 'rest_url' ) && !empty( $_SERVER[ 'REQUEST_URI' ] ) ) {
            $rest_url_base = get_rest_url( get_current_blog_id(), '/' );
            $rest_path = trim( parse_url( $rest_url_base, PHP_URL_PATH ), '/' );
            $request_path = trim( $_SERVER[ 'REQUEST_URI' ], '/' );
            $is_rest = ( strpos( $request_path, $rest_path ) === 0 );
        }
        return $is_rest;
    }
}