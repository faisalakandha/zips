<?php

namespace BuddyBossApp\AppStores;

use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\Admin\Configure;
use BuddyBossApp\AppStores\Services\Android\AndroidPublisher;

class Android {

	private static $instance;
	private static $client = false;
	private static $error_messages;
	private static $google_client_error_messages = '';

	/**
	 * Get the instance of the class.
	 *
	 * @return Android
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * Build constructor.
	 */
	public function __construct() {

	}

	/**
	 *
	 */
	public function _load() {

	}

	/**
	 * Function to connect with android store.
	 */
	public function get_client() {

		$file_name = $this->get_private_key();

		if ( empty( $file_name ) ) {
			return new \WP_Error(
				'error_connecting_account',
				__( 'Error while connecting to your account, make sure you have configured correct android api service json.', 'buddyboss-app' )
			);
		}

		$google_service_account_json = bbapp_get_upload_full_path( $file_name );

		if ( ! file_exists( $google_service_account_json ) ) {
			return new \WP_Error(
				'error_connecting_account',
				__( 'Error while connecting to your account, make sure you have configured correct android api service json.', 'buddyboss-app' )
			);
		}

		if ( ! self::$client ) {

			try {
				$google_client = new \Google_Client();
				$google_client->setScopes( "https://www.googleapis.com/auth/androidpublisher" );
				$google_client->setAuthConfig( $google_service_account_json );
				$google_client->fetchAccessTokenWithAssertion();
				self::$client = $google_client;
			} catch ( \Throwable $e ) {
				self::$google_client_error_messages = $e->getMessage();
				return new \WP_Error( 'error_connecting_account', $e->getCode());
			}
		}

		return self::$client;
	}

	/**
	 * Function to check google connection.
	 *
	 * @param false $override_cache
	 *
	 * @return bool|mixed
	 */
	public function is_google_connected( $override_cache = false ) {

		$file_name = $this->get_private_key();
		$cache_key = "bbapp_android_is_google_client_connected_cache_" . md5( $file_name );

		if ( false !== ( $cached = get_site_transient( $cache_key ) ) && ! $override_cache ) {
			$is_token = $cached;
		} else {
			$google_acc_connection = $this->get_client();
			$token                 = ( ! is_wp_error( $google_acc_connection ) ) ? $google_acc_connection->getAccessToken() : '';
			$is_token              = ( ! empty( $token['access_token'] ) ) ? 1 : 0;
			set_site_transient( $cache_key, $is_token, 24 * HOUR_IN_SECONDS );
		}

		return $is_token;
	}

	/**
	 * Function to get google connection error.
	 *
	 * @return string
	 */
	public function get_google_connection_error() {
		return self::$google_client_error_messages;
	}

	/**
	 * Check if the GoogleStore is Connected.
	 *
	 * @param bool $override_cache
	 *
	 * @return bool|\WP_Error
	 */
	public function is_connected( $override_cache = false ) {

		$file_name = $this->get_private_key();

		$cache_key = "bbapp_android_is_connected_cache_" . md5( $file_name );

		if ( false !== ( $cached = get_site_transient( $cache_key ) ) && ! $override_cache ) {
			$connected = $cached;
		} else {
			// do api call here.
			$client = $this->get_client();

			if ( ! $client || is_wp_error( $client ) ) {
				return false;
			}

			$application_id = $this->get_namespace();
			$connected      = "not_connected";

			try {
				$google_client = new \Google_Client();
				$service       = new \Google_Service_AndroidPublisher( $client );
				$google_client->setApplicationName( $application_id );
				$products_list_response = $service->inappproducts->listInappproducts( $application_id );
				$response               = $products_list_response->getInappproduct();
				$connected              = "connected";
			} catch ( \Google\Service\Exception $e ) {
				self::$error_messages = $e->getErrors();
				return new \WP_Error( 'error_connecting_account', $e->getMessage() );
			}

			set_site_transient( $cache_key, $connected, 24 * HOUR_IN_SECONDS );
		}

		if ( $connected == "connected" ) {
			return true;
		}

		return false;
	}

	/**
	 * Function to check if package name is already take on google play store.
	 *
	 * @param string $package_name package name to check.
	 *
	 * @return int|string
	 */
	public function validate_package_name( $package_name ) {

		$request_uri = bbapp_remote_get( 'https://play.google.com/store/apps/details?id=' . $package_name );

		$request_response_code = wp_remote_retrieve_response_code( $request_uri );

		return $request_response_code;

	}

	/**
	 * Get connection error messages.
	 *
	 * @return mixed
	 */
	public function get_connection_error_messages() {
		return self::$error_messages;
	}


	/**
	 * Return the Namespace.
	 */
	public function get_namespace() {
		return Configure::instance()->option( 'publish.android.namespace' );
	}

    /**
     * Return the Get key ID.
     */
    public function get_private_key() {
        return Configure::instance()->option( 'publish.android.account_key' );
    }

	/**
	 * Sync store product with local data.
	 */
	public function _sync_store_product() {
		$google_service_account_name = __( "Play Publisher", 'buddyboss-app' );
		$android_app_id              = $this->get_namespace();
		$file_name                   = $this->get_private_key();
		$google_service_account_json = bbapp_get_upload_full_path( $file_name );

		$products = array();
		if ( ! file_exists( $google_service_account_json ) || empty( $android_app_id ) ) {
			return $products;
		}

		try {
			$google_client = new \Google_Client();
			$google_client->setApplicationName( $google_service_account_name );
			$google_client->setScopes( "https://www.googleapis.com/auth/androidpublisher" );
			$google_client->setAuthConfig( $google_service_account_json );

			$google_android_inappproduct = new \Google_Service_AndroidPublisher( $google_client );
			$products_list_response      = $google_android_inappproduct->inappproducts->listInappproducts( $android_app_id );

			$response = $products_list_response->getInappproduct();
		} catch ( \Throwable $e ) {
		}

		if ( ! empty( $response ) ) {
			foreach ( $response as $item ) {
				$products[] = array(
					'id'     => $item['sku'],
					'name'   => $item['listings'][ $item['defaultLanguage'] ]->getTitle(),
					'type'   => Helpers::platformStoreProductTypeslug( $item['purchaseType'] ),
					'status' => strtolower( $item['status'] ),
				);
			}
		}

		return $products;
	}

	/**
	 * Validate App.
	 *
	 * @param false $override_cache Override Cache.
	 */
	public function validate_app( $override_cache = false ) {
		$release_details = $this->get_release_data( $override_cache );

		$errors = array();

		$builds = \BuddyBossApp\Build::instance()->get_app_builds( 'android', 'live', false, 'completed', 1, 10, $override_cache );

		if ( ! is_wp_error( $builds ) && empty( $builds['data'] ) ) {
			$errors[] = array(
				'headline'    => __( 'No Android Release App Builds', 'buddyboss-app' ),
				'description' => __( 'Please generate an Android release app build to publish.', 'buddyboss-app' ),
				'link'        => esc_url( bbapp_get_admin_url( 'admin.php?page=bbapp-build&setting=request-build' ) ),
			);
		}

		$release_status = array(
			'status_unspecified',
			'halted',
		);

		if ( empty( $release_details ) || false === $release_details || in_array( $release_details['release_status'], $release_status, true ) ) {
			$errors[] = array(
				'headline'    => __( 'No Release Found', 'buddyboss-app' ),
				'description' => __( 'Your app doesn\'t have a new release ready for review. Please create and prepare a new release.', 'buddyboss-app' ),
				'link'        => esc_url( 'https://play.google.com/console/developers' ),
			);
		}

		if ( ( ! empty( $release_details ) || false === $release_details ) && 'completed' === $release_details['release_status'] ) {
			$errors[] = array(
				'headline'    => __( 'App Already Approved', 'buddyboss-app' ),
				'description' => __( 'our app has already been approved by Google. To publish an update, please create and prepare a new release.', 'buddyboss-app' ),
				'link'        => esc_url( 'https://play.google.com/console/developers' ),
			);
		}

		if ( ( ! empty( $release_details ) || false === $release_details ) && 'in_progress' === $release_details['release_status'] ) {
			$errors[] = array(
				'headline'    => __( 'App Release In Progress', 'buddyboss-app' ),
				'description' => __( 'Your app already has a release in progress. Please cancel the open release or wait for it to complete to start a new publish request.', 'buddyboss-app' ),
				'link'        => esc_url( 'https://play.google.com/console/developers' ),
			);
		}

		return $errors;
	}

	/**
	 * Function to get Release app details.
	 *
	 * @param boolean $override_cache whether override cache or not.
	 *
	 * @return array|false
	 */
	public function get_required_app_details( $override_cache ) {

		$cache_key = 'bbapp_google_app_details';
		$cached    = get_site_transient( $cache_key );

		if ( false !== $cached && empty( $override_cache ) ) {
			return $cached;
		} else {
			$connection = $this->is_connected( $override_cache );

			if ( ! $connection || is_wp_error( $connection ) ) {
				return false;
			}

			$app_details = AndroidPublisher::instance()->initialize();
			$app_data    = array();

			if ( ! empty( $app_details ) ) {
				$app_data['email']            = $app_details->contactEmail;
				$app_data['website']          = $app_details->contactWebsite;
				$app_data['phone']            = $app_details->contactPhone;
				$app_data['default_language'] = $app_details->defaultLanguage;
			}
			set_site_transient( $cache_key, $app_data, 24 * HOUR_IN_SECONDS );
		}

		return $app_data;
	}

	/**
	 * Function to get latest production release data.
	 *
	 * @param bool $override_cache Whether bypass the cache or not.
	 *
	 * @return array|false|mixed
	 */
	public function get_release_data( $override_cache = false ) {

		$cache_key = 'bbapp_google_release_data';
		$cached    = get_site_transient( $cache_key );
		if ( false !== $cached && empty( $override_cache ) ) {
			return $cached;
		} else {
			$connection = $this->is_connected( $override_cache );

			if ( ! $connection || is_wp_error( $connection ) ) {
				return false;
			}

			$release_tracks             = AndroidPublisher::instance()->initialize( 'EditsTracks' );
			$app_data                   = array();
			$app_data['has_release']    = false;
			$app_data['release_status'] = '';
			$app_data['release_notes']  = array();
			if ( ! empty( $release_tracks->tracks ) ) {
				foreach ( $release_tracks->tracks as $release_track ) {
					if ( ! empty( $release_track->track ) && 'production' === $release_track->track ) {
						$app_data['name']           = $release_track->releases[0]->name;
						$app_data['has_release']    = true;
						$app_data['release_status'] = $release_track->releases[0]->status;
						$count                      = 1;
						if ( ! empty( $release_track->releases[0]->releaseNotes ) ) {
							foreach ( $release_track->releases[0]->releaseNotes as $release_notes ) {
								$app_data['release_notes'][ $count ]['language'] = $release_notes->language;
								$app_data['release_notes'][ $count ]['notes']    = $release_notes->text;
								$count ++;
							}
						}
						break;
					}
				}
			}

			set_site_transient( $cache_key, $app_data, 24 * HOUR_IN_SECONDS );
		}

		return $app_data;
	}

	/**
	 * Function to get all production release data.
	 *
	 * @param bool $override_cache whether to bypass the cache
	 *
	 * @return array|false|mixed
	 */
	function get_all_production_release_data( $override_cache = false ) {

		$cache_key = 'bbapp_google_all_production_release_data';
		$cached    = get_site_transient( $cache_key );

		if ( false !== $cached && empty( $override_cache ) ) {
			return $cached;
		} else {
			$connection = $this->is_connected( $override_cache );

			if ( ! $connection || is_wp_error( $connection ) ) {
				return false;
			}

			$release_tracks = AndroidPublisher::instance()->initialize( 'EditsTracks' );
			$app_data       = array();
			$count          = 1;
			if ( ! empty( $release_tracks->tracks ) ) {
				foreach ( $release_tracks->tracks as $release_track ) {
					if ( ! empty( $release_track->track ) && 'production' === $release_track->track ) {
						if ( ! empty( $release_track->releases ) ) {
							foreach ( $release_track->releases as $release_item ) {
								$inr_count                    = 1;
								$app_data[ $count ]['name']   = $release_item->name;
								$app_data[ $count ]['status'] = $release_item->status;
								if ( ! empty( $release_item->releaseNotes ) ) {
									foreach ( $release_item->releaseNotes as $release_notes ) {
										$app_data[ $count ]['release_notes'][ $inr_count ]['language'] = $release_notes->language;
										$app_data[ $count ]['release_notes'][ $inr_count ]['notes']    = $release_notes->text;
										$inr_count ++;
									}
								}
								$count ++;
							}
						}
					}
				}
			}
			set_site_transient( $cache_key, $app_data, 24 * HOUR_IN_SECONDS );
		}

		return $app_data;
	}

	/**
	 * Return's the release bundle ID.
	 */
	public function get_release_bundle_id() {
		return Configure::instance()->option( 'publish.android.namespace' );
	}

	/**
	 * Return's the test bundle ID.
	 */
	public function get_test_release_bundle_id() {
		return  Configure::instance()->option( 'publish.android.dev.namespace' );
	}

	/**
	 * Function to get the App language.
	 *
	 * @param string $lang_code Language code
	 *
	 * @return string
	 */
	public function get_language( $lang_code = '' ) {

		$languages = array(
			'af'      => 'Afrikaans',
			'am'      => 'Amharic',
			'bg'      => 'Bulgarian',
			'ca'      => 'Catalan',
			'zh-HK'   => 'Chinese (Hong Kong)',
			'zh-CN'   => 'Chinese (PRC)',
			'zh-TW'   => 'Chinese (Taiwan)',
			'hr'      => 'Croatian',
			'cs'      => 'Czech',
			'da'      => 'Danish',
			'nl'      => 'Dutch',
			'en-GB'   => 'English (UK)',
			'en-US'   => 'English (US)',
			'et'      => 'Estonian',
			'fil'     => 'Filipino',
			'fi'      => 'Finnish',
			'fr-CA'   => 'French (Canada)',
			'fr-FR'   => 'French (France)',
			'de'      => 'German',
			'el'      => 'Greek',
			'he'      => 'Hebrew',
			'hi'      => 'Hindi',
			'hu'      => 'Hungarian',
			'is'      => 'Icelandic',
			'id / in' => 'Indonesian',
			'it'      => 'Italian',
			'ja'      => 'Japanese',
			'ko'      => 'Korean',
			'lv'      => 'Latvian',
			'lt'      => 'Lithuanian',
			'ms'      => 'Malay',
			'no'      => 'Norwegian',
			'pl'      => 'Polish',
			'pt-BR'   => 'Portuguese (Brazil)',
			'pt-PT'   => 'Portuguese (Portugal)',
			'ro'      => 'Romanian',
			'ru'      => 'Russian',
			'sr'      => 'Serbian',
			'sk'      => 'Slovak',
			'sl'      => 'Slovenian',
			'es-419'  => 'Spanish (Latin America)',
			'es-ES'   => 'Spanish (Spain)',
			'sw'      => 'Swahili',
			'sv'      => 'Swedish',
			'th'      => 'Thai',
			'tr'      => 'Turkish',
			'uk'      => 'Ukrainian',
			'vi'      => 'Vietnamese',
			'zu'      => 'Zulu'
		);

		return ( ! empty( $lang_code ) && isset( $languages[ $lang_code ] ) ? $languages[ $lang_code ] : $lang_code );
	}
}
