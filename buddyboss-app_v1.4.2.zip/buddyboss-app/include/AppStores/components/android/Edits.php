<?php

namespace BuddyBossApp\AppStores\Components\Android;

use BuddyBossApp\Admin\Configure;

class Edits {

	private static $package_name;

	/**
	 * Creates a new edit for an app.
	 * Read More : https://developers.google.com/android-publisher/api-ref/rest/v3/edits/insert
	 *
	 * @param $androidPublisherService
	 *
	 * @return mixed
	 */
	public static function insert( $androidPublisherService ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );

		if ( ! self::$package_name ) {
			return false;
		}

		$optParams = array();

		/**
		 * Creates a new edit for an app. (edits.insert)
		 *
		 * @param string                                  $packageName Package name of the app.
		 * @param /Google_Service_AndroidPublisher_AppEdit $postBody
		 * @param array                                   $optParams   Optional parameters.
		 *
		 * @return /Google_Service_AndroidPublisher_AppEdit
		 */
		$app_edit = new \Google_Service_AndroidPublisher_AppEdit();
		$app_edit->setId( 'initiate-app-edit' );
		// 5 mins (300 seconds)
		$app_edit->setExpiryTimeSeconds( 300 );
		try {
			$new_app_edit = $androidPublisherService->edits->insert( self::$package_name, $app_edit );

			return $new_app_edit;
		} catch ( \Google\Service\Exception $new_app_edit ) {
			return $new_app_edit->getErrors();
		}
	}

	/**
	 * Gets an app edit.
	 * Read More : https://developers.google.com/android-publisher/api-ref/rest/v3/edits/get
	 *
	 * @param $androidPublisherService
	 * @param $editId
	 *
	 * @return mixed
	 */
	public static function get( $androidPublisherService, $editId ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );

		$optParams = array();

		/**
		 * Gets an app edit. (edits.get)
		 *
		 * @param string $packageName Package name of the app.
		 * @param string $editId      Identifier of the edit.
		 * @param array  $optParams   Optional parameters.
		 *
		 * @return /Google_Service_AndroidPublisher_AppEdit
		 */
		return $androidPublisherService->edits->get( self::$package_name, $editId, $optParams );
	}
}
