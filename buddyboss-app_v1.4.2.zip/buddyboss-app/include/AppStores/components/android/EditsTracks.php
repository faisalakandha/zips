<?php

namespace BuddyBossApp\AppStores\Components\Android;

use BuddyBossApp\Admin\Configure;

class EditsTracks {

	private static $package_name;

	/**
	 *
	 *
	 * @param $androidPublisherService
	 * @param $editId
	 *
	 * @return mixed
	 */
	public static function get( $androidPublisherService, $editId ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );

		$optParams = array();

		// The track to read from.
		$track = 'internal-testing';

		/**
		 * Method  : Get
		 * Gets testers.
		 * Read More : https://developers.google.com/android-publisher/api-ref/rest/v3/edits.testers/get
		 */
		return $androidPublisherService->edits_tracks->listEditsTracks( self::$package_name, $editId );

	}

}
