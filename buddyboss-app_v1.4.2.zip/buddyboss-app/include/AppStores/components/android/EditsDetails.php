<?php

namespace BuddyBossApp\AppStores\Components\Android;

use BuddyBossApp\Admin\Configure;

class EditsDetails {

	public static $package_name;

	/**
	 * Gets details of an app.
	 * Read More : https://developers.google.com/android-publisher/api-ref/rest/v3/edits.details/get
	 *
	 * @param $androidPublisherService
	 * @param $editId
	 *
	 * @return mixed
	 */
	public static function get( $androidPublisherService, $editId ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );

		$optParams = array();

		/**
		 * Gets details of an app. (details.get)
		 *
		 * @param string $packageName Package name of the app.
		 * @param string $editId      Identifier of the edit.
		 * @param array  $optParams   Optional parameters.
		 *
		 * @return /Google_Service_AndroidPublisher_AppDetails
		 */
		return $androidPublisherService->edits_details->get( self::$package_name, $editId );
	}
}
