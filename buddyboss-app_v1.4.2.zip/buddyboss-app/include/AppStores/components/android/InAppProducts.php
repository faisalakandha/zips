<?php

namespace BuddyBossApp\AppStores\Components\Android;

use BuddyBossApp\Admin\Configure;

class InAppProducts {

	public static $package_name;

	/**
	 * Lists all localized store listings.
	 *
	 * @param $androidPublisherService
	 *
	 * @return mixed
	 */
	public static function list( $androidPublisherService ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );

		/**
		 * Method  : List
		 * Lists all localized store listings.
		 * Read More  : https://developers.google.com/android-publisher/api-ref/rest/v3/inappproducts/list
		 */
		$inappproducts = $androidPublisherService->inappproducts->listInappproducts( self::$package_name );

		return $inappproducts;
	}
}
