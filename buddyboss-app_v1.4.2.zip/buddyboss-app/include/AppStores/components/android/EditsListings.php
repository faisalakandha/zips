<?php

namespace BuddyBossApp\AppStores\Components\Android;

use BuddyBossApp\Admin\Configure;

class EditsListings {

	public static $package_name;

	/**
	 * Lists all localized store listings.
	 *
	 * @param $androidPublisherService
	 * @param $editId
	 *
	 * @return mixed
	 */
	public static function list( $androidPublisherService, $editId ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );

		$optParams = array();

		/**
		 * Method  : List
		 * Lists all localized store listings.
		 * Read More  : https://developers.google.com/android-publisher/api-ref/rest/v3/edits.listings/list
		 */
		return $androidPublisherService->edits_listings->listEditsListings( self::$package_name, $editId );
	}
}
