<?php

namespace BuddyBossApp\AppStores\Services\Android;

use BuddyBossApp\AppStores\Android;
use BuddyBossApp\Admin\Configure;
use BuddyBossApp\AppStores\Components\Android\Edits;
use BuddyBossApp\AppStores\Components\Android\EditsDetails;
use BuddyBossApp\AppStores\Components\Android\EditsListings;
use BuddyBossApp\AppStores\Components\Android\EditsTracks;
use BuddyBossApp\AppStores\Components\Android\InAppProducts;

class AndroidPublisher {

	private static $instance;
	private static $package_name;

	/**
	 * instance
	 * This will return instance of class
	 *
	 * @return string
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();

		}

		return self::$instance;
	}

	/**
	 * Initialize Service for Android Publisher
	 *
	 * @param string $operation
	 *
	 * @return false|mixed|string
	 */
	public function initialize( $operation = 'EditsDetails' ) {
		self::$package_name = Configure::instance()->option( 'publish.android.namespace' );
		
		if ( empty( self::$package_name ) ) {
			return false;
		}

		$client = Android::instance()->get_client();

		if ( is_wp_error( $client ) ) {
			return false;
		}

		$androidPublisherService = new \Google_Service_AndroidPublisher( $client );

		$android_publisher = '';

		// Step-1 : Get EditId to start making changes
		$edit_data = Edits::insert( $androidPublisherService );

		if ( empty( $edit_data->id ) ) {
			return false;
		}

		$editId = $edit_data->id;

		switch ( $operation ) {
			case 'Edits':
				// Operation : Get Edit Details
				$android_publisher = Edits::get( $androidPublisherService, $editId );
				break;
			case 'EditsTracks':
				// Operation : tracks
				$android_publisher = EditsTracks::get( $androidPublisherService, $editId );
				break;
			case 'EditsListings':
				// Operation : Listing
				$android_publisher = EditsListings::list( $androidPublisherService, $editId );
				break;
			case 'EditsDetails':
				// Operation : Get App Details
				$android_publisher = EditsDetails::get( $androidPublisherService, $editId );
				break;
			case 'InAppProducts':
				// Operation : InAppProducts
				$android_publisher = InAppProducts::list( $androidPublisherService );
				break;
		}

		return $android_publisher;
	}

	/**
	 * Function to check google account permissions.
	 *
	 * @return mixed
	 */
	public function operation_permission() {

		$operations = array(
			'Edits',
			'EditsTracks',
			'EditsListings',
			'EditsDetails',
			'InAppProducts',
		);

		foreach ( $operations as $operation ) {
			try {
				$operation = $this->initialize( $operation );
				$pass      = ( false === $operation ) ? false : true;
			} catch ( \Google\Service\Exception $e ) {
				$errors = $e->getMessage();
				$pass   = false;
			}

			if ( false === $pass ) {
				break;
			}
		}

		return $pass;
	}
}
