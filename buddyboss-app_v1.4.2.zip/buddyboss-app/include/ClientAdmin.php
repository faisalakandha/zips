<?php
namespace BuddyBossApp;

// @todo - Methods and vars needs to have PSR-4 standards. By Ketan, May-2019
// @FYI - old file name was : class.bbapp_admin.php

// use BuddyBossApp\ClientAdminSetup;

class ClientAdmin {

	public function __construct() {
		$this->hooks();
		ClientAdminSetup::instance();
	}

	/**
	 *
	 */
	public function hooks() {
		add_action('admin_init', array($this, 'adminInit'));
		add_action('admin_menu', array($this, 'adminMenu'), 21);
	}

	/**
	 *
	 */
	public function adminInit() {}

	/**
	 *
	 */
	public function adminMenu() {
		if (Permissions::instance()->can_manage_app()) {
			$menu_label = __("Connect App", 'buddyboss-app');

			add_submenu_page(
				'bbapp-settings', $menu_label, $menu_label, 'manage_options', 'bbapp-setup', array(ClientAdminSetup::instance(), 'page')
			);
		}
	}
}