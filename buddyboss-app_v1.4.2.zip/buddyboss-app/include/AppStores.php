<?php

namespace BuddyBossApp;

use BuddyBossApp\Admin\Configure;
use BuddyBossApp\AppStores\Apple;
use BuddyBossApp\Builds\Installer;
use BuddyBossApp\Builds\InstallerScreen;
use BuddyBossApp\ClientCommon;
use BuddyBossApp\ManageApp;

class AppStores {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return AppStores
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * Build constructor.
	 */
	public function __construct() {

	}

	/**
	 *
	 */
	public function _load() {
        Apple::instance();
	}

}
