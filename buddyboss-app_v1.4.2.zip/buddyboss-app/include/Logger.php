<?php
namespace BuddyBossApp;
// @todo - Methods and vars needs to have PSR-4 standards. By Ketan, May-2019
// @FYI - old file name was : class.bbapp_logger.php

// Helper to Logs Things Into DB

use BuddyBossApp\Admin\Settings;

class Logger {

	private static $instance;
	public static $settings = false;
	public $table = "bbapp_logs";

	public function __construct() {}

    /**
     * @return Logger
     */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->hooks(); // run the hooks.
            self::get_settings();
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function hooks() {

	}

	/**
	 * Add Queue Entry on Database.
	 *
	 * @param      $type
	 * @param      $text
	 *
	 * @param bool $ref_id
	 *
	 * @return bool
	 */
	public function add($type, $text, $ref_id = false) {
		global $wpdb;

		if (empty($type) || empty($text)) {
			return false;
		}

		if ( isset( self::$settings['logger_' . $type . '_enabled'] )
            && empty( isset( self::$settings['logger_' . $type . '_enabled'] ) ) ){
            return false;
        }

        $table = bbapp_get_network_table($this->table);

		return $wpdb->insert(
            $table,
			array(
				"created" => current_time('mysql', 1),
				"ref_id" => $ref_id,
				"blog_id" => get_current_blog_id(),
				"type" => $type,
				"text" => $text,
			)
		);
	}

	/**
	 * Delete queue item from database.
	 * @param $id
	 *
	 * @return bool
	 */
	public function delete($id) {
		global $wpdb;

		if (empty($id)) {
			return false;
		}

        $table = bbapp_get_network_table($this->table);

        return $wpdb->delete(
            $table,
			array("id" => $id)
		);
	}

	public static function get_logger_types()
    {
        $settings = self::$settings;
        $types = array( '' => __('All Logs','buddyboss-app') );

        if ( ! empty( $settings['logger_info_log_enabled'] ) ){
            $types['info_log'] = __( 'General Logs', 'buddyboss-app' );
        }

        if ( ! empty( $settings['logger_api_log_enabled'] ) ){
            $types['api_log'] = __( 'API Logs', 'buddyboss-app' );
        }
	    if ( bbapp_is_active( 'iap' ) ) {
		    if ( ! empty( $settings['logger_iap_log_enabled'] ) ) {
			    $types['iap_log'] = __( 'IAP Logs', 'buddyboss-app' );
		    }
	    }
        return $types;
    }

    /**
     * Returns the Offline Courses Settings.
     * @return array
     */
    public static function get_settings()
    {

        if(!self::$settings) {

            $settings = Settings::instance()->get_settings();

            self::$settings = array(
                "logger_enabled" => false,
                "logger_info_log_enabled" => false,
                "logger_api_log_enabled" => false,
                "logger_iap_log_enabled" => false,
            );

	        if (isset($settings['logger.info_log.enabled']) && $settings['logger.info_log.enabled']) {
	            self::$settings["logger_info_log_enabled"] = true;
	            self::$settings["logger_enabled"] = true;
	        }

	        if (isset($settings['logger.api_log.enabled']) && $settings['logger.api_log.enabled']) {
	            self::$settings["logger_api_log_enabled"] = true;
	            self::$settings["logger_enabled"] = true;
	        }

	        if (isset($settings['logger.iap_log.enabled']) && $settings['logger.iap_log.enabled']) {
	            self::$settings["logger_iap_log_enabled"] = true;
	            self::$settings["logger_enabled"] = true;
	        }

        }

        return self::$settings;
    }
}