<?php

namespace BuddyBossApp\HealthCheck;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * This is abstract Health Test Case class.
 * Extending this class will provide all logical feature to register test case for health check.
 *
 * Class HealthTestCaseAbstract
 * @package BuddyBossApp\HealthCheck
 */
abstract class TestAbstract {
	private static $instances = false;
	private $group = array();
	function __construct() {
		/** Nothing here */
	}

	static public function instance() {
		$class = get_called_class();
		if ( ! isset( self::$instances[ $class ] ) ) {
			self::$instances[ $class ] = new $class();
			self::$instances[ $class ]->_load();
		}

		return self::$instances[ $class ];
	}

	function _load() {
		add_action( "init", array( $this, "load" ), 99 );
		add_filter( 'bbapp_health_test_groups', array( $this, '_get_groups' ) );
	}

	function _get_groups( $groups ) {
		$groups[ $this->group['name'] ] = $this->group;
		return $groups;
	}

	function get_group_data() {
		return $this->group;
	}

	function get_test_cases_data() {
		return $this->test_cases;
	}

	/**
	 * This function need to call to register test group
	 * @return mixed
	 */
	abstract function load();

	/**
	 * This function helps to register test group.
	 *
	 * @param $group_name : Groups unique name
	 * @param $group_label : Group label
	 * @param $group_desc : Group description
	 *
	 * @return void
	 */
	function register( $group_name, $group_label, $group_desc ) {
		$this->group = array(
			'name'  => $group_name,
			'label' => $group_label,
			'desc'  => $group_desc,
			'tests' => array(),
		);
	}

	/**
	 * This function helps to add test case for test groups.
	 *
	 * @param string $test_name : Unique name for test
	 * @param string $test_label : Test case label
	 * @param string $test_desc : Test case description
	 * @param array $callback : Callback function for test case
	 * @param bool $async
	 */
	function add_test( $test_name, $test_label, $test_desc, $callback, $async = false ) {
		$test_name = str_replace( '_', '-', $test_name );
		$this->group['tests'][ $test_name ] = array(
			'label'    => $test_label,
			'desc'     => $test_desc,
			'callback' => $callback,
			'group'    => ( true === $async ) ? 'async' : 'direct',
		);
	}

	function expect_return( $status, $message = false ) {
		return array(
			"status"  => $status,
			"message" => $message
		);
	}
}

