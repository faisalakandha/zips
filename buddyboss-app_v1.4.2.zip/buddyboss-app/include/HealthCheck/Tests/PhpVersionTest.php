<?php

namespace BuddyBossApp\HealthCheck\Tests;

use BuddyBossApp\HealthCheck\TestAbstract;

class PHPVersionTest extends TestAbstract {

	protected static $instance;


	function load() {
		$this->register( "php_tests", "Php Requirements & Recommendations Tests", "These includes all php environments & recommendations tests" );
		$this->add_test( "check_php_version", "Check PHP Version", "Checking Required Min PHP Version", array(
			$this,
			"check_php_version_expect"
		), 'php_tests' );
	}

	function check_php_version_expect() {
		$check = false;
		$message = sprintf(
		/* translators: %s: The current PHP version. */
			__( 'Your site is running the current version of PHP (%s)' ),
			PHP_VERSION
		);

		if ( version_compare( PHP_VERSION, 7.1, '<=' ) || version_compare( PHP_VERSION, 7.4, '>' ) ) {
			return $this->expect_return( false, __( "You don't have supported php version support. Php version should be between 7.1 to 7.3" ) );
		} else {
			return $this->expect_return( true, sprintf(
			/* translators: %s: The current PHP version. */
				__( 'Your site is running with supported PHP version: (%s)' ),
				PHP_VERSION
			) );
		}
	}

}