<?php

namespace BuddyBossApp\HealthCheck\Tests;

use BuddyBossApp\Admin\SetupAdmin;
use BuddyBossApp\HealthCheck\TestAbstract;

abstract class RestTest extends TestAbstract {

	/**
	 * @var
	 */
	protected static $instance;

	/**
	 * @var string
	 */
	private $token_transient_key = 'bbapp_healthcheck_user_token';

	/**
	 * @var string
	 */
	protected $test_user_option_key = '_bbapp_healthcheck_user';

	/**
	 * Get Request
	 *
	 * @param $url : Rest endpoint url
	 * @param $data : Query parameter
	 * @param $is_auth : authentication required for this endpoint or not. default true.
	 *
	 * @return array|bool
	 */
	function get( $url, $data = array(), $is_auth = true ) {
		$args = array(
			'timeout'     => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => true,
			'headers'     => array(),
			'body'        => $data,
			'cookies'     => array(),
		);

		if ( $is_auth ){
			$token = $this->_get_token();
			$args['headers']['accessToken'] = $token;
		}

		$response = wp_remote_get( $url, $args );
		if ( is_wp_error( $response ) ) {
			return false;
		}

		$server_headers = wp_remote_retrieve_headers( $response )->getAll();

		return array(
			'status'       => wp_remote_retrieve_response_code( $response ),
			'headers'      => ( $server_headers instanceof \Requests_Utility_CaseInsensitiveDictionary ? $server_headers->getAll() : $server_headers ),
			'body'         => wp_remote_retrieve_body( $response ),
			'content_type' => wp_remote_retrieve_header( $response, 'content-type' ),
		);
	}

	/**
	 * Post Request
	 *
	 * @param $url : Rest endpoint url
	 * @param $data : Query parameter
	 * @param $is_auth : authentication required for this endpoint or not. default true.
	 *
	 * @return array|bool
	 */
	function post( $url, $data = array(), $is_auth = true ) {
		$args = array(
			'timeout'     => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => true,
			'headers'     => array(),
			'body'        => $data,
			'cookies'     => array(),
		);

		if ( $is_auth ){
			$token = $this->_get_token();
			$args['headers']['accessToken'] = $token;
		}

		$response = wp_remote_post( $url, $args );
		if ( is_wp_error( $response ) ) {
			return false;
		}

		$server_headers = wp_remote_retrieve_headers( $response )->getAll();

		return array(
			'status'       => wp_remote_retrieve_response_code( $response ),
			'headers'      => ( $server_headers instanceof \Requests_Utility_CaseInsensitiveDictionary ? $server_headers->getAll() : $server_headers ),
			'body'         => wp_remote_retrieve_body( $response ),
			'content_type' => wp_remote_retrieve_header( $response, 'content-type' ),
		);
	}

	/**
	 * @param array $response Response status
	 * @param int $expected_code Expected status
	 *
	 * @return array
	 */
	function expect_status( $response, $expected_code ) {
		if ( $this->_check_status_code( $response['status'], $expected_code ) ) {
			return $this->expect_return( true );
		}

		return $this->expect_return( false, sprintf(
			__( 'Response status code is not correct. Expected status code: (%d)', 'buddyboss-app' ),
			$expected_code
		) );
	}

	/**
	 * @param array $response
	 * @param string $expected_content_type Expected
	 *
	 * @return array
	 */
	function expect_content_type( $response, $expected_content_type ) {
		$content_type = explode( ';', $response['content_type'] );
		if ( $content_type[0] === $expected_content_type ) {
			return $this->expect_return( true );
		}

		return $this->expect_return( false, sprintf(
			__( 'Response content type is not correct. Expected content type: (%s)', 'buddyboss-app' ),
			$expected_content_type
		) );
	}

	/**
	 * @param array $response Response header
	 * @param array $expected_header Expected header
	 *
	 * @return array
	 */
	function expect_header( $response, $expected_header ) {
		if ( is_array( $response['headers'] ) && is_array( $expected_header ) ) {
			$wrong_header = array_diff( $expected_header, $response['headers'] );
			if ( empty( $wrong_header ) ) {
				return $this->expect_return( true );
			}

			return $this->expect_return( false, sprintf(
				__( 'Response header is not correct. Incorrect header: (%s)', 'buddyboss-app' ),
				http_build_query( $wrong_header, '', ', ' )
			) );
		}

		return $this->expect_return( false, __( 'Response/Expected header type is not correct', 'buddyboss-app' ) );
	}

	/**
	 * @param array $response Response body
	 * @param array $expected_property Expected property
	 */
	function expect_property( $response, $expected_property ) {
		if (  ! is_array( $response ) ){
			return $this->expect_return( false, __( 'Response content type is not supported for property check', 'buddyboss-app' ) );
		}

		$missing_property = array_diff_key( $expected_property, $response );
		if ( empty( $missing_property ) ) {
			return $this->expect_return( true );
		}

		return $this->expect_return( false, sprintf(
			__( 'Response property is not correct. Missing expected property: (%s)', 'buddyboss-app' ),
			implode( ',', array_keys( $missing_property ) )
			//http_build_query( $missing_property, '', ', ' )
		) );
	}

	/**
	 * Get test user token if exist in transient otherwise request for new token.
	 */
	private function _get_token(){
		$data =  get_transient( $this->token_transient_key );
		if ( false !== $data && isset( $data['token'] ) && ( ! empty( $data['token'] ) ) ){
			return $data['token'];
		}

		return $this->_request_auth_token();
	}

	/**
	 * Check Response status code
	 *
	 * @param $code Response status
	 * @param $expected_code expected status
	 *
	 * @return bool
	 */
	private function _check_status_code( $code, $expected_code ) {
		return $code === $expected_code;
	}

	/**
	 * Check Response content type
	 *
	 * @param $content_type
	 * @param $expected_content_type
	 *
	 * @return bool
	 */
	private function _check_content_type( $content_type, $expected_content_type ) {
		$content_type = explode( ';', $content_type );
		return $content_type[0] === $expected_content_type;
	}

	/**
	 * Generate test use token & store it in transient.
	 * @return bool|mixed
	 */
	private function _request_auth_token() {
		$test_user = $this->_get_test_user();
		if ( empty( $test_user ) ){
			return false;
		}

		$response = $this->post( rest_url( 'bbapp/auth/v1/jwt/token' ), array(
			'username'    => $test_user['username'],
			'password'    => $test_user['password'],
			'unique_id'   => $this->get_app_id(),
			'deviceToken' => '123',
		) );

		if ( $this->_check_status_code( $response['status'], 200 )
		     && $this->_check_content_type( $response['content_type'], 'application/json' ) ) {

			return $this->_setup_test_user_token( $response['body'] );
			$data = (array) json_decode( $response['body'] );
			if ( isset( $data['token']  ) ){
				return $data['token'];
			}
		}
		return false;
	}

	/**
	 * store test user auth data in transient & return token
	 *
	 * @param $response_body Response body
	 *
	 * @return bool|mixed
	 */
	protected function _setup_test_user_token( $response_body ){
		$data = (array) json_decode( $response_body );
		if ( isset( $data['token']  ) ){
			set_transient( $this->token_transient_key, $data, 10 * MINUTE_IN_SECONDS );
			return $data['token'];
		}
		return false;
	}

	/**
	 * get test user for auth data
	 * @return bool|mixed|void
	 */
	protected function _get_test_user(){
		return get_option( '_bbapp_healthcheck_user', false );
	}

	/**
	 * get current app id
	 * @return mixed|string
	 */
	protected function get_app_id(){
		$app = bbapp_get_app();

		return isset( $app['bbapp_app_id'] ) ? $app['bbapp_app_id'] : false;
	}

	/**
	 * Combine multiple error in one error.
	 *
	 * @param array $errors
	 * @param string $success_message
	 *
	 * @return array
	 */
	protected function combine_error( $errors, $success_message = '' ){
		$is_passed = true;
		$error_str = '';
		foreach ( $errors as $error ){
			if ( is_array( $error ) && true !== $error['status'] ) {
				$error_str .= $error['message'] . '<br/>' ;
				$is_passed = false;
			}
		}

		if ($is_passed ){
			$error_str = $success_message;
		}

		return $this->expect_return( $is_passed, $error_str );
	}
}