<?php

namespace BuddyBossApp\HealthCheck\Tests;

class ABCoreTest extends RestTest {

	protected static $instance;

	function load() {
		/* Temporary hide */
		//$this->_setup_test_user();
		$this->register( "bbapp_core_tests", "BuddyBoss App API Tests", "Includes all functional tests of base API's requires by BuddyBoss App." );

		$this->add_test(
			"auth_endpoint",
			__( 'Authentication Endpoint.', 'buddyboss-app' ),
			__( "Checking Authentication endpoints", 'buddyboss-app' ),
			array(
				$this,
				"check_auth_endpoint"
			),
			true
		);

		$this->add_test(
			"app_menu_endpoint",
			__( 'App Menu Endpoint.', 'buddyboss-app' ),
			__( "Checking App menu endpoints", 'buddyboss-app' ),
			array(
				$this,
				"check_app_menu_endpoint"
			),
			true
		);
	}

	/**
	 * @return array
	 */
	function check_auth_endpoint() {
		$test_user = $this->_get_test_user();
		if ( empty( $test_user ) ) {
			$this->expect_return( false, __( 'Test user not found', 'buddyboss-app' ) );
		}

		$response = $this->post( rest_url( 'buddyboss-app/auth/v1/jwt/token' ), array(
			'username'    => $test_user['username'],
			'password'    => $test_user['password'],
			'unique_id'   => $this->get_app_id(),
			'deviceToken' => '123',
		), false );

		$errors = [];

		/**
		 * Check endpoint assets
		 */
		$errors['status']       = $this->expect_status( $response, 200 );
		$errors['content_type'] = $this->expect_content_type( $response, 'application/json' );

		$data               = json_decode( $response['body'], true );
		$errors['property'] = $this->expect_property( $data, array(
			'token' => '',
		) );

		if ( is_array( $errors['property'] ) && true == $errors['property']['status'] ) {
			$this->_setup_test_user_token( $response['body'] );
		}

		return $this->combine_error( $errors, __( 'Authentication endpoint working fine!', 'buddyboss-app' ) );
	}

	/**
	 * @return array
	 */
	function check_app_menu_endpoint() {
		$endpoint = 'buddyboss-app/core/v1/menu/';
		$response = $this->get( rest_url( $endpoint ) );

		$errors = [];

		/**
		 * Check endpoint assets
		 */
		$errors['status']       = $this->expect_status( $response, 200 );
		$errors['content_type'] = $this->expect_content_type( $response, 'application/json' );
		$errors['header']       = $this->expect_header( $response, array(
			'bbapp-logged-in' => 'yes',
		) );

		$data               = json_decode( $response['body'], true );
		$errors['property'] = $this->expect_property( $data[0], array(
			'label' => '',
			'name'  => '',
		) );

		return $this->combine_error( $errors, __( 'App menu endpoint working fine!', 'buddyboss-app' ) );
	}

	/**
	 * Create test user from Site health check
	 */
//	private function _setup_test_user() {
//		$test_user = array(
//			'username' => 'bbapphealthcheck',
//		);
//		if ( false === username_exists( $test_user['username'] ) ) {
//			$test_user['password'] = wp_generate_password( 12, false );
//
//			$user_id              = wp_create_user( $test_user['username'], $test_user['password'], '' );
//			$test_user['user_id'] = $user_id;
//			update_option( $this->test_user_option_key, $test_user, false );
//		}
//	}
}