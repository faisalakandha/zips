<?php

namespace BuddyBossApp\HealthCheck\Tests;

use BuddyBossApp\HealthCheck\TestAbstract;

class CacheTest extends TestAbstract {

	protected static $instance;


	function load() {
		$this->register( "cache_tests", "API Availability Tests", "Includes all API availability tests." );


		$this->add_test( "check_cache_activated", "Blocked by Caching", "Check if the Proxy or Server Level Cache is blocking the App API.", array(
			$this,
			"check_cache_activated"
		), true );

	}

	/**
	 * API Test to check if it's not under any proxy cache or server level cache.
	 * @return array
	 */
	function check_cache_activated() {
		$val1 = $this->_request_api();
		sleep(1);
		$val2 = $this->_request_api();

		if ( $val1 === $val2 ) {
			return $this->expect_return( false, __( "API requests are being interrupted by some external cache. This can make your app work slower and some of the app features may not work properly." ) );
		} else {
			return $this->expect_return( true, __( "All good API is accessible without any interruption." ) );
		}
	}

	private function _request_api(){
		$response = wp_remote_get( rest_url( 'buddyboss-app/core/v1/cache_test' )  );
		if( is_wp_error( $response ) ) {
			return false;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body );
		return isset( $data->timestamp ) ? $data->timestamp : false;
	}

}