<?php

namespace BuddyBossApp\Helpers;

/**
 * Class contains all file handling functions.
 * @package BuddyBossApp\Helpers
 */
class BBAPP_File {
	/**
	 * Reads the file and return the data of it.
	 *
	 * @param $file
	 *
	 * @return bool|string
	 */
	public static function readFile( $file ) {
		if ( ! file_exists( $file ) ) {
			return false;
		}
		$handle = fopen( $file, 'r' );
		$data   = fread( $handle, filesize( $file ) );
		fclose($handle);

		return $data;
	}

	/**
	 * Helps to write file into the path.
	 *
	 * @param $path
	 * @param $content
	 *
	 * @return bool
	 */
	public static function WriteFile( $path, $content ) {

		// NOTE : Proceed with creation since no file exists yet.

		// if path already exists unlink it. avoid overwriting.
		if ( file_exists( $path ) && ! is_dir( $path ) ) {
			@unlink( $path );
		}

		$fp    = fopen( $path, "wb" );
		$write = fwrite( $fp, $content );
		fclose( $fp );

		return $write;
	}

	/**
	 * Helps to delete the directory recursively.
	 *
	 * @param $dir
	 */
	public static function DeleteDir( $dir ) {
		$dir = untrailingslashit( $dir );

		if ( is_dir( $dir ) ) {
			$objects = scandir( $dir );
			foreach ( $objects as $object ) {
				if ( $object != "." && $object != ".." ) {
					if ( is_dir( $dir . "/" . $object ) ) {
						self::DeleteDir( $dir . "/" . $object );
					} else {
						unlink( $dir . "/" . $object );
					}
				}
			}
			@rmdir( $dir );
		}
	}

	/**
	 * Copy Dir
	 * @param $source
	 * @param $target
	 */
	public static function CopyDir( $source, $target ) {
		if ( ! is_dir( $source ) ) {//it is a file, do a normal copy
			self::CopyFile( $source, $target );
		}

		//it is a folder, copy its files & sub-folders
		wp_mkdir_p( $target );
		$d          = dir( $source );
		$navFolders = array( '.', '..' );
		while ( false !== ( $fileEntry = $d->read() ) ) {//copy one by one
			//skip if it is navigation folder . or ..
			if ( in_array( $fileEntry, $navFolders ) ) {
				continue;
			}

			//do copy
			$s = "$source/$fileEntry";
			$t = "$target/$fileEntry";
			self::CopyFile( $s, $t );
		}
		$d->close();
	}

	/**
	 * Create and upload file with content.
	 *
	 * @param string $file        Uploaded File Absolute path with name.
	 * @param string $content     File content.
	 *
	 * @return bool
	 */
	public static function file_handler( $file, $content ) {
		if ( ! class_exists( '\WP_Filesystem_Direct' ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
			require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
		}

		$wp_files_system = new \WP_Filesystem_Direct( new \stdClass() );

		/* Now we can use $plugin_path in all our Filesystem API method calls */
		if ( ! $wp_files_system->is_dir( dirname($file) ) ) {
			/* directory didn't exist, so let's create it */
			$wp_files_system->mkdir( dirname($file) );
		}

		$chmod = defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644;

		return $wp_files_system->put_contents( $file, $content, $chmod );
	}

	public static function CreateDir( $dir_path ) {
		if ( ! is_dir( $dir_path ) ) {
			wp_mkdir_p( $dir_path );
		}
	}

	public static function CopyFile( $source_file, $target_file ) {
		if ( ! is_dir( $source_file ) ) {//it is a file, do a normal copy
			if ( ! class_exists( '\WP_Filesystem_Direct' ) ) {
				require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-base.php';
				require_once ABSPATH . 'wp-admin/includes/class-wp-filesystem-direct.php';
			}

			$wp_files_system = new \WP_Filesystem_Direct( new \stdClass() );
			$chmod           = defined( 'FS_CHMOD_FILE' ) ? FS_CHMOD_FILE : 0644;
			$copy            = $wp_files_system->copy( $source_file, $target_file, true, $chmod );
			if ( ! empty( $copy ) && ! is_wp_error( $copy ) ) {
				return false;
			}

			return true;
		}
	}

}