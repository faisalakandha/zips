<?php
namespace BuddyBossApp;

// Exit if accessed directly

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ManageApp {

	public static $app_info;
	private static $instance;

	/**
	 * Get the instance of class
	 *
	 * @return ManageApp
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * ManageApp constructor.
	 */
	public function __construct() {}

	/**
	 *
	 */
	public function _load() {}

	/**
	 * Get apps raw data from db
	 *
	 * @return array|mixed|void
	 */
	public function get_apps_data() {

		$data = bbapp_get_network_option( 'bbapps' );

		if ( ! is_array( $data ) ) {
			$data = array();
		}

		return $data;
	}

	/**
	 * Set app raw data to db.
	 *
	 * @param $data
	 *
	 * @return bool
	 */
	public function update_apps_data( $data ) {
		global $apps_data_cache;
		if ( ! is_array( $data ) ) {
			$data = array();
		}
		$apps_data_cache = null;

		return bbapp_set_network_option( 'bbapps', $data );
	}

	/**
	 * Return the App ID.
	 *
	 * @return bool|mixed
	 */
	public function get_app_id() {
		$app = $this->get_app();
		if ( $app ) {
			return isset( $app['bbapp_app_id'] ) ? $app['bbapp_app_id'] : false;
		}
		return false;
	}

	/**
	 * Returns the App Key.
	 *
	 * @return bool|mixed
	 */
	public function get_app_key() {
		$app = $this->get_app();
		if ( $app ) {
			return $app['bbapp_app_key'];
		}
		return false;
	}

	/**
	 * Returns the App Key.
	 *
	 * @return bool|mixed
	 */
	public function get_auth_app_key() {
		$app = $this->get_app();

		if ( $app && isset( $app['bbapp_app_key'] ) ) {
			return sha1( $app['bbapp_app_key'] );
		}
		return false;
	}

	/**
	 * Returns the app information of given app id.
	 * for reference
	 * app_id is the reference id of app stored in WordPress
	 * bbapp_app_id is the ID of app at bbapp.
	 *
	 * @return array
	 */
	public function get_app() {
		global $apps_data_cache; // helps to cache.

		if ( empty( $apps_data_cache ) ) {
			$apps_data_cache = $this->get_apps_data();
		}

		return $apps_data_cache;
	}

	/**
	 * Tells weather the app is connected as dev or not.
	 *
	 * @return bool
	 */
	public function is_current_primary_site() {

		$app = $this->get_app();

		if ( ! $app ) {
			return false;
		}

		if ( isset( $app['bbapp_site_type'] ) && 'primary' === $app['bbapp_site_type'] ) {
			return true;
		}

		return false;
	}

	/**
	 * Tells weather the app is connected as dev or not.
	 *
	 * @return bool
	 */
	public function is_current_secondary_site() {

		$app = $this->get_app();

		if ( ! $app ) {
			return false;
		}

		if ( isset( $app['bbapp_site_type'] ) && 'primary' !== $app['bbapp_site_type'] ) {
			return true;
		}

		return false;
	}

	/**
	 * Quick way to get app setting.
	 * @param $setting_name
	 * @param bool $network
	 *
	 * @return bool|mixed
	 */
	public function get_app_setting($setting_name, $network = false) {
		$settings = $this->get_app_settings($network);
		if(isset($settings[$setting_name])) {
			return $settings[$setting_name];
		} else {
			return false;
		}
	}

	/**
	 * Returns the settings of app.
	 *
	 * @param boolean $network
	 *
	 * @return array
	 */
	public function get_app_settings( $network = false ) {
		return $this->get_settings( $network );
	}

	/**
	 * Updates settings of app.
	 *
	 * @param string $settings
	 * @return void
	 */
	public function update_app_settings( $settings ) {
		return $this->update_settings( $settings );
	}

	/**
	 * @param false $network
	 *
	 * @return bool|mixed
	 */
	public function get_settings( $network = false ) {

		if ( true === $network && bbapp()->is_network_activated() ) {
			$apps_settings = get_blog_option( get_current_network_id(), 'bbapp_settings' );
		} else {
			$apps_settings = get_option( 'bbapp_settings' );
		}

		if ( ! is_array( $apps_settings ) ) {
			$apps_settings = array();
		}

		return $apps_settings;
	}

	/**
	 * Update App Settings.
	 *
	 * @param        $settings
	 *
	 * @return mixed
	 */
	public function update_settings( $settings ) {

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		update_option( 'bbapp_settings', $settings );

		return $settings;
	}


	/**
	 * Helper function to purge app sealed cache.
	 *
	 * @return bool
	 */
	public function purge_app_sealed_cache() {
		$cache_key    = "_bbapp_app_signed_details";
		return delete_site_transient( $cache_key );
	}

	/**
	 * Fetch the app information from BuddyBossApp server.
	 *
	 * @return array|bool|mixed|void
	 */
	public function get_app_sign_details() {

		if ( isset( $GLOBALS['get_app_signed_details_runtime_cache'] ) ) {
			return $GLOBALS['get_app_signed_details_runtime_cache'];
		}

		$bbapp_app_id = self::instance()->get_app_id();

		if ( empty( $bbapp_app_id ) ) {
			return array();
		}

		$cache_key = "_bbapp_app_signed_details";

		if ( false !== ( $cached = get_site_transient( $cache_key ) ) ) {
			$GLOBALS['get_app_signed_details_runtime_cache'] = $cached;

			return $cached;
		}

		$api_url = ClientCommon::instance()->get_center_api_url( 'v2' );

		$do_request = bbapp_remote_post(
			$api_url,
			array(
				'method'  => 'POST',
				'timeout' => 45,
				'body'    => array(
					'action'    => 'app_signature',
					'bbapp_id'  => $bbapp_app_id,
					'bbapp_key' => self::instance()->get_auth_app_key(),
				),
			)
		);

		if ( is_wp_error( $do_request ) || empty( $do_request ) ) {
			$GLOBALS['get_app_signed_details_runtime_cache'] = false;

			return false;
		}

		$body     = isset( $do_request['body'] ) ? $do_request['body'] : '';
		$response = json_decode( $body, true );

		if ( ! isset( $response['data'] ) || ! isset( $response['sign'] ) ) {
			$GLOBALS['get_app_signed_details_runtime_cache'] = false;
			set_site_transient( $cache_key, $response, 5 * 60 ); // cache it for 5 min.  // don't ping app center too often.

			return false;
		} else {
			set_site_transient( $cache_key, $response, 20 * DAY_IN_SECONDS ); // cache it for 20 days.
		}


		$GLOBALS['get_app_signed_details_runtime_cache'] = $response;

		return $response;

	}

	/**
	 * Connects the app with ab app id.
	 *
	 * @param string $bbapp_app_id BB App ID.
	 * @param string $bbapp_app_key BB App key.
	 * @param string $bbapp_site_type BB App Site Url. primary or secondary.
	 *
	 * @return bool|\WP_Error
	 */
	public function connect_app( $bbapp_app_id, $bbapp_app_key, $bbapp_site_type = 'primary' ) {

		$api_url = ClientCommon::instance()->get_center_api_url( 'v1', 'api-get/connect-site' );

		if ( empty( $bbapp_app_id ) || empty( $bbapp_app_key ) ) {
			return new \WP_Error(
				'value_missing',
				__( 'Please provide your App ID & Key.', 'buddyboss-app' )
			);
		}

		$url = $this->get_site_url();

		$body = array(
			'bbapp_id'  => $bbapp_app_id,
			'bbapp_key' => sha1( $bbapp_app_key ),
			'site_url'  => $url,
			'site_type' => $bbapp_site_type,
		);

		$this->purge_app_sealed_cache();

		$response = bbapp_remote_post(
			$api_url,
			array(
				'timeout'  => 60,
				'blocking' => true,
				'cookies'  => array(),
				'body'     => $body,
			)
		);

		if ( is_wp_error( $response ) ) {

			return new \WP_Error(
				'cannot_connect',
				__( 'Unable to connect to the BuddyBoss server.', 'buddyboss-app' )
			);
		} else {

			$body     = isset( $response['body'] ) ? $response['body'] : '';
			$response = json_decode( $body );

			if ( is_array( $response ) || is_object( $response ) ) {
				$response = (array) $response;

				if ( isset( $response['success'] ) && true === $response['success'] ) {

					// update & save data.
					$apps_data                    = $this->get_apps_data();
					$apps_data['bbapp_app_key']   = $bbapp_app_key;
					$apps_data['bbapp_app_id']    = $bbapp_app_id;
					$apps_data['bbapp_site_type'] = $bbapp_site_type;
					$apps_data['user_app_id']     = ! empty( $response['user_app_id'] ) ?? $response['user_app_id'];
					$apps_data['verified']        = true;
					$this->update_apps_data( $apps_data );

					return $apps_data;

				} else {
					if ( 'invalid_app' === $response['code'] ) {
						return new \WP_Error(
							'invalid_app',
							__( 'The key you entered is invalid.', 'buddyboss-app' )
						);
					} elseif ( in_array( $response['code'], array( 'primary_not_possible', 'secondary_not_possible' ), true ) ) {
						return new \WP_Error(
							$response['code'],
							$response['message']
						);
					} else {
						$message
							= sprintf(
								/* translators: %s is the response code */
								__(
									'We were not able to verify at the moment. Please contact BuddyBoss support with error code \'%s\'.',
									'buddyboss-app'
								),
								$response['code']
							);

						return new \WP_Error(
							'invalid_err',
							$message
						);
					}
				}
			} else {
				return new \WP_Error(
					'cannot_connect',
					__(
						'We were not able to verify the information added. Please contact BuddyBoss support.',
						'buddyboss-app'
					)
				);
			}
		}

		return false;
	}

	/**
	 * Unlink the app from WordPress if it's connected.
	 *
	 * @param string $bbapp_app_id BB App ID.
	 * @param string $bbapp_app_key BB App Key.
	 * @param string $bbapp_site_type BB App Site type, primary or secondary.
	 * @param string $bbapp_site_url BB Site Url.
	 *
	 * @return bool|\WP_Error
	 */
	public function disconnect_app( $bbapp_app_id = '', $bbapp_app_key = '', $bbapp_site_type = '', $bbapp_site_url = '' ) {

		$app = $this->get_app();

		if ( empty( $app ) ) {
			return false;
		}

		if ( ! $app['verified'] ) {
			return false;
		}

		if ( empty( $bbapp_app_id ) ) {
			$bbapp_app_id = isset( $app['bbapp_app_id'] ) ? $app['bbapp_app_id'] : '';
		}

		if ( empty( $bbapp_app_key ) ) {
			$bbapp_app_key = isset( $app['bbapp_app_key'] ) ? $app['bbapp_app_key'] : '';
		}

		if ( empty( $bbapp_site_type ) ) {
			$bbapp_site_type = isset( $app['bbapp_site_type'] ) ? $app['bbapp_site_type'] : 'primary';
		}

		$api_url = ClientCommon::instance()->get_center_api_url( 'v1', 'api-get/delete-site' );

		if ( empty( $bbapp_app_id ) || empty( $bbapp_app_key ) ) {
			return new \WP_Error( 'value_missing', __( 'Please provide your App ID & Key.', 'buddyboss-app' ) );
		}

		$this->purge_app_sealed_cache();

		$url = ! empty( $bbapp_site_url ) ? $bbapp_site_url : $this->get_site_url();

		$args = array(
			'timeout'  => 60,
			'blocking' => true,
			'cookies'  => array(),
			'body'     => array(
				'bbapp_id'  => $bbapp_app_id,
				'bbapp_key' => ManageApp::instance()->get_auth_app_key(),
				'site_url'  => $url,
				'site_type' => $bbapp_site_type,
			),
		);

		$response = bbapp_remote_post( $api_url, $args );

		if ( is_wp_error( $response ) ) {
			return new \WP_Error(
				'cannot_connect',
				__( 'Unable to connect to the BuddyBoss server.', 'buddyboss-app' )
			);
		} else {
			$response = wp_remote_retrieve_body( $response );
			$response = json_decode( $response, true );

			if ( is_array( $response ) && ! empty( $response ) ) {
				if ( ( isset( $response['success'] ) && true === $response['success'] ) || ( isset( $response['code'] ) && in_array( $response['code'], array( 'site_not_found', 'invalid_app' ), true ) ) ) {
					$apps_data                    = $this->get_apps_data();
					$apps_data['bbapp_app_key']   = '';
					$apps_data['bbapp_site_type'] = '';
					$apps_data['user_app_id']     = '';
					$apps_data['verified']        = false;
					$this->update_apps_data( $apps_data );

					return true;
				}
			} else {
				return new \WP_Error( 'cannot_connect', __( 'We were not able to verify the information added. Please contact BuddyBoss support.', 'buddyboss-app' ) );
			}
		}

		return false;
	}

	/**
	 * Get app info.
	 *
	 * @param bool $override_cache
	 *
	 * @return array|\WP_Error
	 */
	public function get_app_info( $override_cache = false ) {

		if ( ! empty( self::$app_info ) ) {
			return self::$app_info;
		}

		$cache_key = "_bbapp_get_app_info";

		if ( false !== ( $cached = get_site_transient( $cache_key ) ) && ! $override_cache) {
			self::$app_info = $cached;
			return $cached;
		}
		$app = $this->get_app();

		if ( empty( $app ) ) {
			return new \WP_Error(
				'app_not_found',
				__( 'There is no such app.', 'buddyboss-app' )
			);
		}

		if ( empty( $app['bbapp_app_id'] ) || empty( $app['bbapp_app_key'] ) ) {
			return new \WP_Error(
				'value_missing',
				__( 'Please provide your App ID & Key in the app.', 'buddyboss-app' )
			);
		}

		$bbapp_app_id = $app['bbapp_app_id'];

		$api_url = ClientCommon::instance()->get_center_api_url( 'v1', 'api-get/get-app-info' );

		$response = bbapp_remote_get(
			$api_url,
			array(
				'timeout'  => 60,
				'blocking' => true,
				'cookies'  => array(),
				'body'     => array(
					'bbapp_id'    => $bbapp_app_id,
					'bbapp_key'   => $this->get_auth_app_key(),
					'purge_cache' => $override_cache,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new \WP_Error(
				'cannot_connect',
				__( 'Unable to connect to the BuddyBoss server.', 'buddyboss-app' )
			);
		} else {
			$body     = isset( $response['body'] ) ? $response['body'] : '';
			$response = json_decode( $body );

			if ( is_array( $response ) || is_object( $response ) ) {
				self::$app_info = (array) $response;
				set_site_transient( $cache_key, self::$app_info, 10 * 60 ); // Set the cache for 10min.
				return self::$app_info;
			} else {
				return new \WP_Error(
					'cannot_connect',
					__(
						'We were not able to verify the information added. Please contact BuddyBoss support.',
						'buddyboss-app'
					)
				);
			}
		}
	}


	/**
	 * App is disabled.
	 *
	 * @return integer
	 */
	public function is_app_disabled() {
		$app_info = $this->get_app_info();

		if ( ! is_wp_error( $app_info ) && isset( $app_info['code'] ) && 'app_is_disabled' === $app_info['code'] ) {
			return true;
		}

		return false;
	}

	/**
	 * Verify app.
	 */
	public function verify_app() {
		$app = $this->get_app();

		if ( ! empty( $app ) && isset( $app['verified'] ) && true === $app['verified'] && ! empty( $app['bbapp_app_id'] ) && ! empty( $app['bbapp_app_key'] ) && ! empty( $app['bbapp_site_type'] ) ) {
			$bb_app_id    = $app['bbapp_app_id'];
			$bb_app_key   = $app['bbapp_app_key'];
			$bb_site_type = $app['bbapp_site_type'];

			$app_info = $this->get_app_info( true );

			if ( ! is_wp_error( $app_info ) ) {
				$url = $this->get_site_url();
				if ( 'primary' === $bb_site_type && ! empty( $app_info['primary_site']->url ) && ! $this->compare_site_url( $url, $app_info['primary_site']->url ) ) {
					$this->disconnect_app( $bb_app_id, $bb_app_key, $bb_site_type );
				} elseif ( 'secondary' === $bb_site_type && ! empty( $app_info['secondary_sites'] ) ) {
					$secondary_sites      = $app_info['secondary_sites'];
					$secondary_sites_list = array();
					foreach ( $secondary_sites as $secondary_site ) {
						$secondary_sites_list[] = preg_replace( "#^[^:/.]*[:/]+#i", "", trailingslashit( trim( $secondary_site->url ) ) );
					}
					if ( ! in_array( trailingslashit( trim( preg_replace( "#^[^:/.]*[:/]+#i", "", trailingslashit( trim( $url ) ) ) ) ), $secondary_sites_list, true ) ) {
						$this->disconnect_app( $bb_app_id, $bb_app_key, $bb_site_type );
					}
				}
			}
		}
	}

	/**
	 * Compare urls.
	 *
	 * @param string $url1 URL to compare.
	 * @param string $url2 URL to compare.
	 *
	 * @return bool
	 */
	public function compare_site_url( $url1, $url2 ) {
		$url1 = preg_replace( "#^[^:/.]*[:/]+#i", "", trailingslashit( trim( $url1 ) ) );
		$url2 = preg_replace( "#^[^:/.]*[:/]+#i", "", trailingslashit( trim( $url2 ) ) );

		if ( ! empty( $url1 ) && ! empty( $url2 ) && $url1 === $url2 ) {
			return true;
		}

		return false;
	}

	/**
	 * Tells if App Center is in Maintenance.
	 *
	 * @param bool $override_cache
	 *
	 * @return bool
	 */
	public function is_appcenter_under_maintenance( $override_cache = false ) {

		$override_cache = true;
		$retval         = false;

		$cache_key = 'bbapp_is_under_maintenance';

		if ( false !== ( $cached = get_site_transient( $cache_key ) ) && ! $override_cache ) {
			$retval = $cached;
		} else {

			$api_url = ClientCommon::instance()->get_center_api_url( 'v1', 'api-get/get-site-status' );
			$request = bbapp_remote_get( $api_url );

			$body = (is_array($request) && isset( $request['body'] ) ? json_decode( $request['body'], true ) : array() );
			if ( isset( $body['code'] ) && $body['code'] === 'maintenance_mode_enabled' ) {
				$retval = true;
				set_site_transient( $cache_key, $retval, 10 * 60 ); // cache it for 10 min.
			} elseif ( is_wp_error( $request ) || ! isset( $body['success'] ) || $body['success'] != true ) {
				$retval = new \WP_Error(
					'could_not_connect_to_appcenter',
					__( 'Couldn\'t contact to app center, please refresh the page.', 'buddyboss-app' ),
					array( 'status' => 400 )
				);
			}
		}

		return $retval;
	}

	/**
	 * Tells if App Center is in Maintenance.
	 *
	 * @param bool $override_cache
	 *
	 * @return bool
	 */
	public function get_appcenter_publisher_email_address( $override_cache = false ) {

		$override_cache = true;

		$cache_key = 'bbapp_publisher_email_address';

		if ( false !== ( $cached = get_site_transient( $cache_key ) ) && ! $override_cache ) {
			$retval = $cached;
		} else {

			$api_url = ClientCommon::instance()->get_center_api_url( 'v1', 'api-get/support-email-address' );
			$request = bbapp_remote_get( $api_url );

			$body = ( is_array( $request ) && isset( $request['body'] ) ? json_decode( $request['body'], true ) : array() );
			if ( isset( $body['support_email_address'] ) && ! empty( $body['support_email_address'] ) ) {
				$retval = $body['support_email_address'];
				set_site_transient( $cache_key, $retval, 10 * 60 ); // cache it for 10 min.
			} else {
				$retval = 'apphelp@buddyboss.com';
			}
		}

		return $retval;
	}

	/**
	 * Get Primary site URL.
	 */
	public function get_primary_site_url() {
		$app_info = $this->get_app_info();

		if ( is_wp_error( $app_info ) ) {
			return '';
		}

		if ( ! is_wp_error( $app_info ) ) {
			return ( isset( $app_info['primary_site']->url ) ? $app_info['primary_site']->url : '' );
		}

		return '';
	}

	/**
	 * Get Secondary sites URL.
	 */
	public function get_secondary_sites_url() {
		$app_info = $this->get_app_info();

		$sites = array();

		if ( is_wp_error( $app_info ) ) {
			return $sites;
		}

		if ( ! is_wp_error( $app_info ) && isset( $app_info['secondary_sites'] ) && is_array( $app_info['secondary_sites'] ) ) {
			foreach ( $app_info['secondary_sites'] as $site ) {
				$sites[] = ( isset( $site->url ) ? $site->url : '' );
			}
		}

		return $sites;
	}

	/**
	 * Validates the requests coming from BuddyBoss Server
	 *
	 * @param bool $token
	 *
	 * @return bool
	 */
	public function validate_app_id_request($token=false) {

		$info = ManageApp::instance()->get_app();

		if (sha1($info["bbapp_app_key"] . $info["bbapp_app_id"]) == $token) {
			return true;
		}

		return false;

	}

	/**
	 * Get site url.
	 *
	 * @return string|void
	 */
	public function get_site_url() {
		return bbapp()->is_network_activated() ? network_site_url() : site_url();
	}

	/**
	 * Check and verify Google/Apple connectivity.
	 */
	public function account_connectivity() {
		$api_url            = ClientCommon::instance()->get_center_api_url( 'v1', 'update-app-info' );
		$android_connection = \BuddyBossApp\AppStores\Android::instance()->is_google_connected( true );
		$apple_connection   = \BuddyBossApp\AppStores\Apple::instance()->is_connected( true );

		bbapp_remote_post(
			$api_url,
			array(
				'method'  => 'POST',
				'timeout' => 120,
				'body'    => array(
					'bbapp_is_google_connected' => ( is_wp_error( $android_connection ) ? false : (bool) $android_connection ),
					'bbapp_is_apple_connected'  => ( is_wp_error( $apple_connection ) ? false : (bool) $apple_connection ),
					'bbapp_id'                  => $this->get_app_id(),
					'bbapp_key'                 => $this->get_auth_app_key(),
				),
			)
		);
	}
}
