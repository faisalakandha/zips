<?php

namespace BuddyBossApp\DeepLinking\Type;

use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\DeepLinking\Screens;

/**
 * Class CoreType
 *
 * @package BuddyBossApp\DeepLinking\Type
 */
class CoreType extends TypeAbstract {

	/**
	 * Parse Term urls
	 *
	 * @param $url
	 *
	 * @return array|mixed|null
	 */
	public function parse( $url ) {
		$data = $this->get_url_data( $url );
		if ( ! empty( $data ) ) {
			return $data;
		}

		/**
		 * Parse homepage URL.
		 */
		if ( trim( $url, '/' ) === get_home_url() ) {
			return array(
				'action'    => 'open_home',
				'namespace' => 'core',
				'url'       => $url,
			);
		}

		/**
		 * Parse Posts Page URL.
		 */
		$page_for_posts = get_option( 'page_for_posts' );
		$link           = get_permalink( $page_for_posts );
		if ( untrailingslashit( $url ) === untrailingslashit( $link ) ) {
			return array(
				'action'    => 'open_archive',
				'namespace' => 'core',
				'url'       => $url,
				'post_type' => 'post',
			);
		}

		return null;

	}

	/**
	 * Get url data.
	 *
	 * @param $url
	 *
	 * @return array
	 */
	public function get_url_data( $url ) {
		$url_data   = array();
		$url_params = Screens::instance()->get_url_core_params( $url );
		if ( ! empty( $url_params ) && 'bbapp' === Screens::instance()->get_core_namespace( $url_params ) ) {
			$url_data         = array(
				'action'    => 'open_404',
				'namespace' => 'core',
				'item_id'   => '404',
				'url'       => $url,
			);
			$core_screen_name = Screens::instance()->get_core_screen( $url_params );
			if ( ! empty( $core_screen_name ) && in_array( $core_screen_name, Screens::instance()->bbapp_deeplinking_screens() ) ) {
				$url_data =  $this->bbapp_prepare_core_data( $core_screen_name, $url_params, $url_data );
			}
		}

		return $url_data;
	}

	/**
	 * Prepare Core data
	 *
	 * @param $screen_name
	 * @param $url_params
	 * @param $url_data
	 *
	 * @return mixed
	 */
	public function bbapp_prepare_core_data( $screen_name, $url_params, $url_data ) {
		$url_data['action']    = $this->get_action( $screen_name );
		$url_data['namespace'] = 'core';
		$url_data['item_id']   = Screens::instance()->get_core_screen_item_id( $url_params );
		if ( $id = Screens::instance()->get_core_screen_id( $url_params ) ) {
			$url_data['id'] = $id;
		}
		if ( in_array( $screen_name, apply_filters( 'bbapp_deep_screen_allow_user_embed_data', array( 'profile', 'settings' ) ) ) ) {
			$url_data['user_id']      = get_current_user_id();
			$url_data['_link_action'] = class_exists( 'BuddyPress' ) ? 'buddypress_member' : 'wp_user';
		}

		if ( bbapp_is_active( 'iap' ) && in_array( $screen_name, array( 'screen' ) ) && 'iap_products' === $url_data['item_id'] ) {
			$product_args   = array( 'global_subscription' => true );
			$bbapp_products = Helpers::getProducts( $product_args );
			if ( ! empty( $bbapp_products ) ) {
				$url_data["iap_products"] = array_column( $bbapp_products, 'product_id' );
			}
		}

		return apply_filters( 'bbapp_prepare_core_data', $url_data, $url_params );
	}

	/**
	 * Allow actions.
	 *
	 * @param $screen_name
	 *
	 * @return string
	 */
	public function get_action( $screen_name ) {
		$action         = 'open_';
		$current_screen = '404';
		if ( 'screen' === $screen_name ) {
			$current_screen = 'screen';
		}
		if ( 'page' === $screen_name ) {
			$current_screen = 'app_page';
		}
		if ( 'settings' === $screen_name ) {
			$current_screen = 'settings';
		}
		if ( 'products' === $screen_name ) {
			$current_screen = 'iap_product';
		}
		if ( 'profile' === $screen_name ) {
			$current_screen = 'profile';
		}

		return $action . $current_screen;
	}


}
