<?php

namespace BuddyBossApp\DeepLinking\Type;

class TermType extends TypeAbstract {

	/**
	 * Parse Term urls
	 *
	 * @param $url
	 *
	 * @return mixed|null
	 */
	public function parse( $url ) {
		$url_meta = $this->get_url_data( $url );
		foreach ( get_taxonomies( array(), 'objects' ) as $taxonomy => $t ) {
			if ( $t->query_var && isset( $url_meta[ $t->query_var ] ) ) {
				$term = get_term_by( 'slug', $url_meta[ $t->query_var ], $t->name );

				/**
				 * Filter terms deep linking namespace
				 */
				$namespace = apply_filters( 'bbapp_deeplinking_term_namespace', 'core', $term );

				/**
				 * Filter terms deep linking data
				 */
				return apply_filters(
					'bbapp_deeplinking_term',
					array(
						'action'    => 'open_term',
						'namespace' => $namespace,
						'url'       => $url,
						'term_id'   => $term->term_id,
						'taxonomy'  => $term->taxonomy,
					),
					$term
				);

			}
		}

		return null;
	}

}
