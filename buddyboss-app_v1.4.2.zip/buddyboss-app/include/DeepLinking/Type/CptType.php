<?php

namespace BuddyBossApp\DeepLinking\Type;

class CptType extends TypeAbstract {

	/**
	 * Parse custom post type urls
	 *
	 * @param $url
	 *
	 * @return array|null
	 */
	public function parse( $url ) {
		global $wp;
		$wp->add_query_var( 'app_page' );
		$urlID = url_to_postid( $url );
		if ( ! empty( $urlID ) ) {
			$post      = get_post( $urlID );
			$post_type = $post->post_type;

			/**
			 * Filter cpt deep linking action
			 */
			$action = apply_filters( 'bbapp_deeplinking_cpt_action', "open_{$post_type}", $post );

			/**
			 * Filter cpt deep linking namespace
			 */
			$namespace = apply_filters( 'bbapp_deeplinking_cpt_namespace', 'core', $post_type );

			/**
			 * Filter CPT deep linking data
			 */
			return apply_filters(
				'bbapp_deeplinking_cpt',
				array(
					'action'       => $action,
					'namespace'    => $namespace,
					'url'          => $url,
					'item_id'      => $post->ID,
					'_link_action' => 'core_' . $post_type . 's',
				),
				$post
			);
		}

		$url_meta = $this->get_url_data( $url );
		if ( isset( $url_meta['post_type'] ) ) {

			/**
			 * Filter cpt deep linking namespace
			 */
			$namespace = apply_filters( 'bbapp_deeplinking_cpt_namespace', 'core', $url_meta['post_type'] );

			return array(
				'action'    => 'open_archive',
				'namespace' => $namespace,
				'url'       => $url,
				'post_type' => $url_meta['post_type'],
			);
		}

		return null;

	}

}
