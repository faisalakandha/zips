<?php

namespace BuddyBossApp\DeepLinking\Type;

class BuddyPressType extends TypeAbstract {

	private static $url_data = array();

	/**
	 * Parse BuddyPress url
	 *
	 * @param $url
	 *
	 * @return array|mixed|null
	 */
	public function parse( $url ) {
		$data = $this->get_url_data( $url );

		if ( ! empty( $data ) ) {

			switch ( $data['component'] ) {
				case 'groups':
					$response = array(
						'action'    => 'open_' . $data['component'],
						'namespace' => 'buddypress',
						'url'       => $url,
					);

					if ( ! empty( $data['group_topic_id'] ) ) {
						// Handle Group Forum Topic link
						$response['action']       = $response['action'] . '_topic';
						$response['item_id']      = $data['group_topic_id'];
						$response['_link_action'] = 'bbpress_topic';
					} elseif ( ! empty( $data['group_forum_id'] ) ) {
						// Handle Group Forum link
						$response['action']       = $response['action'] . '_forum';
						$response['item_id']      = $data['group_forum_id'];
						$response['_link_action'] = 'bbpress_forum';
					} else {
						// Handle Group link
						if ( ! empty( $data['group_id'] ) ) {
							$response['item_id']      = $data['group_id'];
							$response['_link_action'] = 'buddypress_group';
						}
					}

					break;
				default:
					$response = array(
						'action'    => 'open_' . $data['component'],
						'namespace' => 'buddypress',
						'url'       => $url,
					);
			}

			if ( ! empty( $data['user_id'] ) ) {
				$response ['action']          = 'open_member_' . $data['component'];
				$response['item_id']          = $data['user_id'];
				$response['_link_action']     = 'buddypress_member';
				$response['_sub_link_action'] = 'buddypress_' . $data['component'];
				$is_component_active          = bp_is_active( $data['component'] );
				if ( function_exists( 'bp_ld_sync' ) && bp_ld_sync()->settings->get( 'course.courses_visibility' ) && 'courses' === $data['component'] ) {
					$is_component_active = true;
				}
				if ( in_array( $data['component'], array(
						'settings',
						'messages',
						'notifications',
						'courses'
					), true ) && ( ! $is_component_active || $data['user_id'] !== get_current_user_id() ) ) {
					$response ['action'] = 'open_member_profile';
					unset( $response['_sub_link_action'] );
				}
			}

			if ( ! empty( $data['activity_id'] ) ) {
				$response ['action']      = 'open_' . $data['component'];
				$response['item_id']      = $data['activity_id'];
				$response['_link_action'] = 'buddypress_activity';
			}

			if ( ! empty( $data['action'] ) ) {
				$response['tab'] = $data['action'];
				if ( isset( $data['group_id'] ) ) {
					$group = groups_get_group( $data['group_id'] );
					if ( ! empty( $data['group_id'] ) && $url === bp_get_group_permalink( $group ) ) {
						$response['tab'] = 'app_home';
					}
				}
			}

			if ( ! empty( $data['sub_action'] ) ) {
				$response['sub_tab'] = $data['sub_action'];
				// If message single thread deeplinking.
				if ( 'messages' === $data['component'] && ( bp_is_active( $data['component'] ) && $data['user_id'] === get_current_user_id() ) ) {
					$response['action'] = $response['action'] . '_thread';
				}
			}
			/**
			 * Filter BuddyPress deep linking data
			 */
			$response = apply_filters( 'bbapp_deeplinking_buddypress_' . $data['component'], $response, $data );
			$response = apply_filters( 'bbapp_deeplinking_buddypress', $response, $data );

			return $response;
		}

		return null;

	}

	/**
	 * Get BuddyPress data from url
	 * For Getting BuddyPress Global data we set up virtual url and then call BuddyPress function to setup globals data
	 * Once BuddyPress global data set we are using that data to determine whether given url is BuddyPress ulr or not
	 *
	 * @param $url
	 *
	 * @return array
	 */
	public function get_url_data( $url ) {

		// Check whether statics data already set or not
		if ( empty( self::$url_data[ $url ] ) ) {

			// Check whether Transient Cache set or not
			$hashURL   = md5( $url );
			$cacheData = get_transient( '_bbapp_deeplink_bp_url_data' );
			if ( empty( $cacheData ) || ! isset( $cacheData ) ) {
				$cacheData = array();
			}

			$cacheData = array();

			if ( empty( $cacheData ) || ( is_array( $cacheData ) && ! isset( $cacheData[ $hashURL ] ) ) ) {

				$url = preg_replace( '|https?\://[^/]+/|', '/', $url );

				$tempurl                = $_SERVER['REQUEST_URI'];
				$_SERVER['REQUEST_URI'] = $url;
				bp_core_set_uri_globals();
				bp_setup_globals();
				remove_action( 'bp_setup_canonical_stack', 'bp_late_include', 20 );
				bp_setup_canonical_stack();
				add_action( 'bp_setup_canonical_stack', 'bp_late_include', 20 );
				$_SERVER['REQUEST_URI'] = $tempurl;

				$component = bp_current_component();

				if ( ! empty( $component ) ) {
					$data = array(
						'component'  => $component,
						'action'     => bp_current_action(),
						'sub_action' => bp_action_variable( 0 ),
						'user_id'    => bp_displayed_user_id(),
					);

					if ( 'groups' == $component && bp_is_single_item() ) {
						$data['group_id'] = bp_get_current_group_id();

						// Handle Group Forum and it's topic links
						if ( isset( $data['action'] ) && ( 'forum' == $data['action'] || get_option( '_bbp_forum_slug', 'forum' ) == $data['action'] ) ) {
							if ( isset( $data['sub_action'] ) && ( 'topic' == $data['sub_action'] || get_option( '_bbp_topic_slug', 'discussion' ) == $data['sub_action'] ) ) {
								$topic                  = get_posts(
									array(
										'name'        => bp_action_variable( 1 ),
										'post_status' => 'publish',
										'post_type'   => bbp_get_topic_post_type(),
										'numberposts' => 1,
										'fields'      => 'ids'
									)
								);
								$data['group_topic_id'] = ( ! empty( $topic ) ? current( $topic ) : 0 );
							}
							$forum_ids              = bbp_get_group_forum_ids( bp_get_current_group_id() );
							$forum_id               = array_shift( $forum_ids );
							$data['group_forum_id'] = $forum_id;
						}
					}

					if ( 'activity' == $component && bp_is_single_activity() && ! bp_is_current_action( 'p' ) ) {
						$data['activity_id'] = bp_current_action();
					} elseif ( 'activity' == $component && is_numeric( bp_action_variable( 0 ) ) && bp_is_current_action( 'p' ) ) {
						$data['activity_id'] = bp_action_variable( 0 );
					} elseif ( 'page' == get_option( 'show_on_front' ) && get_option( 'page_on_front' ) ) {
						// If activity is front page that time blog post should be open post url.
						$url_components = parse_url( $url );
						if ( isset( $url_components['query'] ) ) {
							parse_str( $url_components['query'], $params );
							if ( isset( $params['p'] ) ) {
								$data = array(); // if we add blank array then the screen take open_post feature.
							}
							if ( isset( $params['document_type'] ) && 'document' === $params['document_type'] ) {
								$data = array(); // if we add blank array then the screen take open_page feature.
							}
						}
					}
					// set transient data
					$cacheData[ $hashURL ] = $data;
					set_transient( '_bbapp_deeplink_bp_url_data', $cacheData, 12 * HOUR_IN_SECONDS );

					// set data to static variable
					self::$url_data[ $url ] = $data;
				} else {
					$data = $this->bb_me_screen( $url );
					if ( ! empty( $data ) ) {
						// set data to static variable
						self::$url_data[ $url ] = $data;
					}
				}

				/* Reset buddypress data */
				buddypress()->unfiltered_uri        = '';
				buddypress()->unfiltered_uri_offset = 0;
				buddypress()->current_component     = '';
				buddypress()->displayed_user        = '';
				buddypress()->displayed_user        = new \stdClass();
				buddypress()->current_member_type   = '';
				buddypress()->current_action        = '';
				buddypress()->current_item          = '';
				buddypress()->action_variables      = '';

			} else {

				// set transient data to static variable
				self::$url_data[ $url ] = $cacheData[ $hashURL ];
			}
		}

		// Check Data is set or empty
		if ( ! empty( self::$url_data[ $url ] ) ) {
			return self::$url_data[ $url ];
		}

		return array();
	}

	/**
	 * BB me screens deeplinking.
	 * - /me/groups to /groups
	 * - /me to /members
	 *
	 * @param string $url
	 *
	 * @return array
	 */
	public function bb_me_screen( $url = '' ) {
		$data      = array();
		$url_param = explode( '/', $url );
		foreach ( $url_param as $key => $value ) {
			if ( empty( $value ) ) {
				unset( $url_param[ $key ] );
			}
		}
		$url_param = array_values( $url_param );
		if ( ! empty( $url_param ) ) {
			if ( ( isset( $url_param[0] ) && 'me' === $url_param[0] ) && isset( $url_param[1] ) && 'groups' === $url_param[1] ) {
				$data = array(
					'component'  => 'groups',
					'action'     => '',
					'sub_action' => '',
					'user_id'    => bp_displayed_user_id(),
				);
			} elseif ( isset( $url_param[0] ) && 'me' === $url_param[0] ) {
				$data = array(
					'component'  => 'members',
					'action'     => '',
					'sub_action' => '',
					'user_id'    => bp_displayed_user_id(),
				);
			}
		}

		return $data;
	}

}
