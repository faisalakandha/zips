<?php

namespace BuddyBossApp\DeepLinking\Type;

class AppPageType extends TypeAbstract {


	/**
	 * AppPageType constructor.
	 */
	public function __construct() {
		parent::__construct();
		add_filter( 'bbapp_deeplinking_cpt', array( $this, 'updateCptObject' ), 10, 2 );
	}

	/**
	 * Add item embed with response
	 *
	 * @param $response
	 * @param $post
	 *
	 * @return mixed
	 */
	public function updateCptObject( $response, $post ) {

		if ( $post->post_type == 'app_page' ) {
			$response['_link_action'] = 'app_page';
		}

		return $response;
	}

	public function parse( $url ) {
	}
}
