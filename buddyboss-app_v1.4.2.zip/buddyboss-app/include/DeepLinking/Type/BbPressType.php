<?php

namespace BuddyBossApp\DeepLinking\Type;

class bbPressType extends TypeAbstract {

	public $arrPostTypes = array();

	public function __construct() {

		add_action( 'init', array( $this, 'init' ) );
		parent::__construct();
		add_filter( 'bbapp_deeplinking_cpt', array( $this, 'updateCptObject' ), 10, 2 );
		add_filter( 'bbapp_deeplinking_cpt_namespace', array( $this, 'updateCptNamespace' ), 10, 2 );
	}

	/**
	 * Init all bbPress CPT into Array.
	 */
	public function init() {
		$forum_post_type    = bbp_get_forum_post_type();
		$topic_post_type    = bbp_get_topic_post_type();
		$reply_post_type    = bbp_get_reply_post_type();
		$this->arrPostTypes = array( $forum_post_type, $topic_post_type, $reply_post_type );
	}

	/**
	 * Add item embed with response
	 *
	 * @param $response
	 * @param $post
	 *
	 * @return mixed
	 */
	public function updateCptObject( $response, $post ) {

		if ( $post->post_type == bbp_get_forum_post_type() ) {
			$response['_link_action'] = 'bbpress_forum';
		}

		if ( $post->post_type == bbp_get_topic_post_type() ) {
			$response['_link_action'] = 'bbpress_topic';
		}

		if ( $post->post_type == bbp_get_reply_post_type() ) {
			$response['_link_action'] = 'bbpress_reply';
		}

		return $response;
	}

	/**
	 * Update bbPress's CPT namespace
	 *
	 * @param $namespace
	 * @param $post_type
	 *
	 * @return string
	 */
	public function updateCptNamespace( $namespace, $post_type ) {
		if ( isset( $post_type ) && in_array( $post_type, $this->arrPostTypes ) ) {
			return 'bbpress';
		}

		return $namespace;
	}

	public function parse( $url ) {
	}
}
