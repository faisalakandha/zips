<?php

namespace BuddyBossApp\DeepLinking\Type;

class LearnDashType extends TypeAbstract {

	public $arrPostTypes        = array();
	public $arrPostTypesMapping = array();
	public $arrTaxonomy         = array();

	public function __construct() {
		parent::__construct();
		add_action( 'init', array( $this, 'init' ) );
		add_filter( 'bbapp_deeplinking_cpt_action', array( $this, 'updateCptAction' ), 10, 2 );
		add_filter( 'bbapp_deeplinking_cpt_namespace', array( $this, 'updateCptNamespace' ), 10, 2 );
		add_filter( 'bbapp_deeplinking_term_namespace', array( $this, 'updateTermNamespace' ), 10, 2 );
		add_filter( 'bbapp_deeplinking_taxonomy_namespace', array( $this, 'updateTaxonomyNamespace' ), 10, 2 );
		add_filter( 'bbapp_deeplinking_cpt', array( $this, 'updateCptObject' ), 10, 2 );
	}

	/**
	 * Init all LearnDash maps.
	 */
	public function init() {
		$this->arrPostTypesMapping = array(
			'sfwd-courses'      => 'course',
			'sfwd-lessons'      => 'lesson',
			'sfwd-topic'        => 'topic',
			'sfwd-quiz'         => 'quiz',
			'sfwd-question'     => 'question',
			'sfwd-certificates' => 'certificate',
			'sfwd-essays'       => 'essay',
			'sfwd-assignment'   => 'assignment',
		);
		$this->arrPostTypes        = array_keys( $this->arrPostTypesMapping );
		$this->arrTaxonomy         = array(
			'ld_course_category',
			'ld_course_tag',
			'ld_lesson_category',
			'ld_lesson_tag',
			'ld_topic_category',
			'ld_topic_tag',
			'ld_quiz_category',
			'ld_quiz_tag',
			'ld_question_category',
			'ld_question_tag',
		);
	}

	/**
	 * Add item embed with response
	 *
	 * @param $response
	 * @param $post
	 *
	 * @return mixed
	 */
	public function updateCptObject( $response, $post ) {

		if ( $post->post_type == 'sfwd-courses' ) {
			$response['_link_action'] = 'ld_course';
		}

		if ( $post->post_type == 'sfwd-lessons' ) {
			$response['_link_action'] = 'ld_lesson';
		}

		if ( $post->post_type == 'sfwd-topic' ) {
			$response['_link_action'] = 'ld_topic';
		}

		if ( $post->post_type == 'sfwd-quiz' ) {
			$response['_link_action'] = 'ld_quiz';
		}

		return $response;
	}

	/**
	 * Update LearnDash's CPT action
	 *
	 * @param $action
	 * @param $post
	 *
	 * @return string
	 */
	public function updateCptAction( $action, $post ) {
		if ( $post instanceof \WP_Post && in_array( $post->post_type, $this->arrPostTypes ) ) {
			return 'open_' . $this->arrPostTypesMapping[ $post->post_type ];
		}

		return $action;
	}

	/**
	 * Update LearnDash's cpts namespace
	 *
	 * @param $namespace
	 * @param $post_type
	 *
	 * @return string
	 */
	public function updateCptNamespace( $namespace, $post_type ) {
		if ( isset( $post_type ) && in_array( $post_type, $this->arrPostTypes ) ) {
			return 'learndash';
		}

		return $namespace;
	}

	/**
	 * Update LearnDash's terms namespace
	 *
	 * @param $namespace
	 * @param $term
	 *
	 * @return string
	 */
	public function updateTermNamespace( $namespace, $term ) {
		if ( $term instanceof \WP_Term && in_array( $term->taxonomy, $this->arrTaxonomy ) ) {
			return 'learndash';
		}

		return $namespace;
	}

	/**
	 * Update LearnDash's taxonomy namespace
	 *
	 * @param $namespace
	 * @param $taxonomy
	 *
	 * @return string
	 */
	public function updateTaxonomyNamespace( $namespace, $taxonomy ) {
		if ( $taxonomy instanceof \WP_Taxonomy && in_array( $taxonomy->name, $this->arrTaxonomy ) ) {
			return 'learndash';
		}

		return $namespace;
	}

	public function parse( $url ) {
	}

}
