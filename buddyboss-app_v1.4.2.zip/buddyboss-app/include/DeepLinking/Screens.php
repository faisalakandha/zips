<?php

namespace BuddyBossApp\DeepLinking;

use BuddyBossApp\ClientCommon;

/**
 * Class Screens
 *
 * @package BuddyBossApp\DeepLinking
 */
class Screens {
	private static $instance;

	/**
	 * Using Singleton, see instance()
	 */
	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 *
	 * @return Screens
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$class_name     = __CLASS__;
			self::$instance = new $class_name;
			self::$instance->load();
		}

		return self::$instance;
	}

	/**
	 * Load hooks.
	 */
	public function load() {
		add_action( 'template_redirect', array( $this, 'load_deep_linking_screen' ), 9 );
		add_filter( 'bbapp_prepare_core_data', array( $this, 'filter_bbapp_prepare_core_data' ), 10, 2 );
	}

	/**
	 * Load and identify deeplinking screen.
	 */
	public function load_deep_linking_screen() {
		global $wp;
		if ( ! empty( $wp->request ) ) {
			$url_params = $this->get_url_core_params( $wp->request );
			if ( ! empty( $url_params ) && 'bbapp' === $this->get_core_namespace( $url_params ) ) {
				$core_screen_name = $this->get_core_screen( $url_params );
				if ( ! empty( $core_screen_name ) && in_array( $core_screen_name, $this->bbapp_deeplinking_screens() ) ) {
					wp_redirect( site_url() );
					exit;
				}
			}
		}
	}

	/**
	 * Body Class.
	 *
	 * @param $classes
	 *
	 * @return mixed
	 */
	public function body_class( $classes ) {
		$classes[] = 'bbapp-app-deeplinking-page';

		return $classes;
	}

	/**
	 * Change the deeplinking screen title.
	 *
	 * @param $title
	 * @param $sep
	 *
	 * @return string
	 */
	public function wp_title( $title, $sep ) {
		$title      .= get_bloginfo( 'name' );
		$title_text = sprintf( __( 'DeepLinking %1$s', "buddyboss-app" ), $this->get_core_screen() );
		$title      = "$title $sep $title_text";

		return $title;
	}

	/**
	 * Change the Deeplinking screen title.
	 *
	 * @return string
	 */
	public function wp_render_title_tag() {
		?>
        <title>
			<?php wp_title( '|', true, 'right' ); ?>
        </title>
		<?php
	}

	/**
	 * Deeplinking screens.
	 *
	 * @return string[]
	 */
	public function bbapp_deeplinking_screens() {
		return array(
			'page',
			'products',
			'screen',
			'settings',
			'profile',
		);
	}

	/**
	 * Get url core params.
	 *
	 * @param $url
	 *
	 * @return false|string[]
	 */
	public function get_url_core_params( $url ) {
		$url       = parse_url( $url );
		$url_param = array();
		if ( isset( $url['path'] ) ) {
			$url_param = explode( '/', $url['path'] );
			foreach ( $url_param as $key => $value ) {
				if ( empty( $value ) ) {
					unset( $url_param[ $key ] );
				}
			}
		}

		return array_values( $url_param );
	}

	/**
	 * Get core namespace.
	 *
	 * @param $url_params
	 *
	 * @return mixed|string
	 */
	public function get_core_namespace( $url_params ) {
		return isset( $url_params[0] ) ? $url_params[0] : '';
	}

	/**
	 * Get Screen name.
	 *
	 * @param $url_params
	 *
	 * @return mixed|string
	 */
	public function get_core_screen( $url_params ) {
		return isset( $url_params[1] ) ? $url_params[1] : '';
	}

	/**
	 * Get screen item id.
	 *
	 * @param $url_params
	 *
	 * @return mixed|string
	 */
	public function get_core_screen_item_id( $url_params ) {
		return isset( $url_params[2] ) ? $url_params[2] : '';
	}

	/**
	 * Get screen id.
	 *
	 * @param $url_params
	 *
	 * @return mixed|string
	 */
	public function get_core_screen_id( $url_params ) {
		return isset( $url_params[3] ) ? $url_params[3] : '';
	}

	/**
	 * Deeplinking url component checking.
	 *
	 * @param $url_data
	 * @param $url_params
	 *
	 * @return mixed
	 */
	public function filter_bbapp_prepare_core_data( $url_data, $url_params ) {
		$common = ClientCommon::instance();
		switch ( $url_data['action'] ) {
			case "open_screen":
				$url_data = $this->bbapp_menu_screens( $url_data );
				break;

			case "open_iap_product":
				if ( ! $common->is_active_logic( array( "bbapp_iap" ) ) || function_exists( 'bbapp_iap_get_product' ) && false === bbapp_iap_get_product( $url_data['item_id'] ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "open_app_page":
				$post = get_post( $url_data['item_id'] );
				if ( empty( $post ) || is_wp_error( $post ) || $post->post_status != "publish" ) {
					$url_data['action'] = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;
		}
		return $url_data;
	}

	/**
	 * Menu screens filter.
	 *
	 * @param $url_data
	 *
	 * @return mixed
	 */
	public function bbapp_menu_screens( $url_data ) {
		$common = ClientCommon::instance();

		switch ( $url_data['item_id'] ) {
			case "activity":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_activity" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}

				break;

			case "members":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_members" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}

				break;

			case "profile":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_profile" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}

				break;

			case  "messages":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_messages" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case  "documents":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_documents" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case  "videos":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_videos" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case  "photos":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_photos" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "topics":
			case "forums":

				if ( ! $common->is_active_logic( array( "bbapp_bbpress_api", "bbpress" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}

				break;

			case "notifications":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_notifications" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "settings":
				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_settings" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "groups":

				if ( ! $common->is_active_logic( array( "buddypress", "buddypress_groups" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "courses":
			case "courses_all":
			case "course_certificates":
			case "courses_category":
				if ( ! $common->is_active_logic( array( "bbapp_learner_api" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;
			case "my_library":
				if ( ! $common->is_active_logic( array( "bbapp_learner_course_downloading" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "iap_products":
				if ( ! $common->is_active_logic( array( "bbapp_iap" ) ) ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
				}
				break;

			case "app_page":
			case "page":
				$post = get_post( $url_data['id'] );
				if ( empty( $post ) || is_wp_error( $post ) || $post->post_status != "publish" ) {
					$url_data['action']  = 'open_404';
					$url_data['item_id'] = '404';
					unset( $url_data['id'] );
				}
				break;
		}

		return $url_data;
	}
}