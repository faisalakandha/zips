<?php
/**
 * DeepLinking Rest Endpoint.
 *
 * @package BuddyBossApp\DeepLinking
 */

namespace BuddyBossApp\DeepLinking;

use BuddyBossApp\Api\DeepLinking\Main;
use BuddyBossApp\DeepLinking\Type;
use WP_REST_Request;

/**
 * Class DeepLinking
 *
 * @package BuddyBossApp\DeepLinking
 */
class DeepLinking {

	/**
	 * Class instance.
	 *
	 * @var object $instance .
	 */
	private static $instance;

	/**
	 * API Namespace.
	 *
	 * @var string
	 */
	protected $namespace = 'buddyboss-app/core/v1';

	/**
	 * DeepLinking constructor.
	 */
	public function __construct() {
	}

	/**
	 * Get the instance of the class.
	 *
	 * @return DeepLinking
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->load();
		}

		return self::$instance;
	}

	/**
	 * Load deep linking types
	 */
	public function load() {
		add_action( 'rest_api_init', array( $this, 'load_types' ), 99 );
		Main::instance();
		Screens::instance();
		add_action( "init", array( $this, 'inline_page_embed' ) );
		add_action( "wp_footer", array( $this, 'inline_page_embed' ) );
		add_action( 'wp_ajax_bbapp_linkd_embed_data', array( $this, 'bbapp_linkd_embed_data' ) );
		add_action( 'wp_ajax_nopriv_bbapp_linkd_embed_data', array( $this, 'bbapp_linkd_embed_data' ) );

		// Groups and member deeplinking url.
		add_filter( 'bbapp_deeplinking_buddypress_groups', array( $this, 'deeplinking_buddypress_groups' ), 10, 2 );
		add_filter( 'bbapp_deeplinking_buddypress_members', array( $this, 'deeplinking_buddypress_members' ), 10, 2 );
	}

	/**
	 * Load all Deep Linking URLs Types.
	 */
	public function load_types() {
		new Type\CoreType();

		if ( function_exists( 'bbpress' ) ) {
			new Type\bbPressType();
		}

		if ( defined( 'LEARNDASH_VERSION' ) && version_compare( LEARNDASH_VERSION, '3.1', '>=' ) ) {
			new Type\LearnDashType();
		}

		if ( function_exists( 'bp_is_active' ) ) {
			new Type\BuddyPressType();
		}

		new Type\CptType();
		new Type\AuthorType();
		new Type\TaxonomyType();
		new Type\TermType();
		new Type\AppPageType();
	}

	/**
	 * Output the deeplink embeds into the page using js template tag.
	 *
	 * @return bool
	 */
	public function inline_page_embed() {

		if ( ! bbapp_is_loaded_from_inapp_browser() || is_admin() ) {
			return false;
		}

		if ( current_action() == "init" ) {
			ob_start();
		}

		if ( current_action() == "wp_footer" ) {

			$content       = ob_get_contents();
			$web_page_urls = $this->bbapp_get_urls_from_content( $content );
			$deep_links_data = self::instance()->bbapp_linkd_embed_data( $web_page_urls );
			?>
            <script>
                if (typeof window.bbapp_embed_data === 'undefined') {
                    window.bbapp_webpage_links = [];
                    window.bbapp_embed_data = [];
                }
                window.bbapp_webpage_links = <?php echo wp_json_encode( $web_page_urls ); ?>;
                window.bbapp_embed_data = <?php echo wp_json_encode( $deep_links_data ); ?>;
                window.bbapp_embed_last_anchor_count = 0;
                jQuery(document).ready(function () {

                    bbapp_add_embed_tags();
                    window.bbapp_embed_last_anchor_count = jQuery("a").length;
                    setInterval(function () {
                        if (window.bbapp_embed_last_anchor_count !== jQuery("a").length) {
                            window.bbapp_embed_last_anchor_count = jQuery("a").length;
                            bbapp_add_embed_tags();
                            bbapp_load_embeds_data();
                        }

                    }, 5000);


                });

                // load new links find using ajax.
                function bbapp_load_embeds_data() {
                    jQuery.ajax({
                        type: 'POST',
                        url: window.ajaxurl,
                        data: {
                            'action': 'bbapp_linkd_embed_data',
                            'urls': window.bbapp_webpage_links
                        },
                        success: function (response) {
                            // successful request; do something with the data
                            window.bbapp_embed_data = response;
                            bbapp_add_embed_tags(); // now again mark all links with hasembed tag.
                        },
                        error: function (jqxhr, exception) {
                            console.log('error:' + jqxhr + ' ! ' + exception);
                        },
                    });
                }

                // tag the links with hasembed tag.
                function bbapp_add_embed_tags() {
                    // loop thru each link in window.bbapp_embed_data and add their link in document with attr hasembed=1
                    jQuery('a').each(function (index) {
                        if (jQuery.inArray(jQuery(this).attr('href'), window.bbapp_webpage_links) !== -1) {
                            jQuery(this).addClass('has-deep');
                        } else {
                            if (bbapp_is_valid_url(jQuery(this).attr('href')) === 1) {
                                window.bbapp_webpage_links.push(jQuery(this).attr('href'));
                            }
                        }
                    });
                }

                function bbapp_is_valid_url(url) {

                    if (/^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i.test(url)) {
                        return 1;
                    } else {
                        return -1;
                    }
                }
            </script>
			<?php
		}

	}

	/**
	 * Get all urls from content.
	 *
	 * @param $content
	 *
	 * @return array
	 */
	public function bbapp_get_urls_from_content( $content ) {
		$dom = new \DOMDocument();
		@$dom->loadHTML( $content );
		$xpath = new \DOMXPath( $dom );
		$hrefs = $xpath->evaluate( "/html/body//a" );
		$urls  = array();
		for ( $i = 0; $i < $hrefs->length; $i ++ ) {
			$href = $hrefs->item( $i );
			$url  = $href->getAttribute( 'href' );
			$url  = filter_var( $url, FILTER_SANITIZE_URL );
			// validate url
			if ( bbapp_is_valid_url( $url ) ) {
				$urls[] = $url;
			}
		}

		return $urls;
	}

	/**
	 * Lets BuddyBoss App Server know which that app client is configured properly.
	 *
	 * @param array $urls
	 *
	 * @return array
	 */
	public function bbapp_linkd_embed_data( $urls = array() ) {
	    $is_ajax = false;
		if ( ! empty( $_POST['urls'] ) ) {
			$urls = $_POST['urls'];
			$is_ajax = true;
		} else {
			if ( empty( $urls ) ) {
				return array();
			}
		}
		$request_curl = new WP_REST_Request( 'POST', '/buddyboss-app/core/v1/bulk-url-details' );
		$request_curl->set_param( 'urls', $urls );
		if ( isset( $_GET['_bbapp_embed'] ) && true === (bool) $_GET['_bbapp_embed'] ) {
			$query_params           = $request_curl->get_query_params();
			$query_params["_embed"] = 'true';
			$request_curl->set_query_params( $query_params );
		}

		$server   = rest_get_server();
		$response = $server->dispatch( $request_curl );

		$status   = $response->get_status();

		$deep_links_data = array();
		if ( 200 === $status ) {
			$deep_links_data = $response->get_data();
		}
		if ( true === $is_ajax ) {
			wp_send_json( $deep_links_data );
		} else {
			return $deep_links_data;
		}
	}

	/**
	 * Groups deeplinking url update.
	 * /me/groups url update to groups url.
	 *
	 * @param $response
	 * @param $data
	 *
	 * @return mixed
	 */
	public function deeplinking_buddypress_groups( $response, $data ) {
		if ( empty( $response['url'] ) ) {
			return $response;
		}

		$response['url'] = preg_replace( "/me\?/", '', $response['url'] );

		return $response;
	}

	/**
	 * Members deeplinking url update.
	 * /me url update to members url.
	 *
	 * @param $response
	 * @param $data
	 *
	 * @return mixed
	 */
	public function deeplinking_buddypress_members( $response, $data ) {
		$parse_url = parse_url( $response['url'] );
		if ( '/me' === $parse_url['path'] ) {
			$response['url'] = str_replace( '/me', '/members', $response['url'] );
		}

		return $response;
	}
}
