<?php
namespace BuddyBossApp;
// @todo - Methods and vars needs to have PSR-4 standards. By Ketan, May-2019
// @FYI - old file name was : class.bbapp_api_plugin_support.php

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

class ClientApiPluginSupport {
	/**
	 * ClientApiPluginSupport constructor.
	 */
	public function __construct() {
		add_action('rest_api_init', array($this, 'apiInit'));
	}

	/**
	 *
	 */
	public function apiInit() {
		//add visual composer shortcode support
		add_filter('the_content', array($this, 'addVisualComposerSupport'), 0);

		// Elementor plugin json encode creating issue withs slider.
		if( ! bbapp_is_rest() ){
			return;
		}

		//Fixed html special charector encoded issue
		add_filter('the_title', array($this, 'htmlDecodeEntity'), 999);
		add_filter('the_content', array($this, 'htmlDecodeEntity'), 999);
		add_filter('the_excerpt', array($this, 'htmlDecodeEntity'), 999);
		add_filter('wp_trim_excerpt', array($this, 'htmlDecodeEntity'), 999);
	}

	/**
	 * @param $content
	 *
	 * @return mixed
	 */
	public function addVisualComposerSupport($content) {
		static $wpvc_mapped_loaded;
		if ($wpvc_mapped_loaded != 1 && class_exists('\WPBMap')) {
			\WPBMap::addAllMappedShortcodes(); // This does all the work
			$wpvc_mapped_loaded = 1;
		}
		return $content;
	}

	/**
	 * @param $string
	 *
	 * @return string
	 */
	public function htmlDecodeEntity($string) {
		return html_entity_decode($string, ENT_QUOTES);
	}
}
