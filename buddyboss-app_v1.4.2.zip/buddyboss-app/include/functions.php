<?php

use BuddyBossApp\Logger;
use BuddyBossApp\ManageApp;

if (!defined('ABSPATH')) {
    exit();
}

/**
 * return true or false based on private app is enabled or not.
 * @return bool
 */
function bbapp_is_private_app_enabled() {
	$settings = \BuddyBossApp\ManageApp::instance()->get_settings();
	$enabled  = ( isset( $settings['private_app.enabled'] ) && $settings['private_app.enabled'] );
	return $enabled;
}

/**
 * Just a function to validate a URL.
 * @param $url
 *
 * @return bool
 */
function bbapp_is_valid_url($url)
{

    // Must start with http:// or https://.
    if (0 !== strpos($url, 'http://') && 0 !== strpos($url, 'https://')) {
        return false;
    }

    // Must pass validation.
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return false;
    }

    return true;
}

/**
 * It's a alias for wp_remote_get but allows filters.
 *
 * @param $url
 * @param $args
 *
 * @return array|WP_Error
 */
function bbapp_remote_get($url, $args = array())
{
    $url = apply_filters("bbapp_remote_get_url", $url, $args);
    $args = apply_filters("bbapp_remote_get_args", $args, $url);
    $response = wp_remote_get($url, $args);
    $response = apply_filters("bbapp_remote_get_response", $response, $url, $args);
    return $response;
}

/**
 * func to be used with bbapp_remote_post_multipart.
 * @param $path
 *
 * @return array
 */
function bbapp_remote_post_file($path) {
    if(!file_exists($path)) {
	    $path = false;
    }
    return array("bbapp_file" => $path);
}

/**
 * Function allows to post multipart type request using bbapp_remote_post function.
 * Note. You need to wrap file field with bbapp_remote_post_file function in order to include file.
 *
 * @param $url
 * @param array $args
 *
 * @return array|WP_Error
 */
function bbapp_remote_post_multipart( $url, $args = array() ) {

	$boundary = bbapp_generate_password( 24 );

	$headers = array(
		'content-type' => 'multipart/form-data; boundary=' . $boundary,
	);

	$payload = '';

	$fields = $args["body"];

	if ( ! is_array( $fields ) ) {
		return bbapp_remote_post( $url, $args );
	}

	// First, add the standard POST fields:
	foreach ( $fields as $name => $value ) {

		// check if it's file.
		if ( is_array( $value ) && isset( $value["bbapp_file"] ) && $value["bbapp_file"] ) {
			$mime = '';
			if ( function_exists( 'mime_content_type' ) ) {
				$mime = mime_content_type( $value["bbapp_file"] );
			} elseif ( class_exists( 'finfo' ) ) {
				$finfo = new finfo();

				if ( is_resource( $finfo ) === true ) {
					$mime = $finfo->file( $value["bbapp_file"], FILEINFO_MIME_TYPE );
				}
			} else {
				$filetype = wp_check_filetype( $value["bbapp_file"] );
				$mime     = $filetype['type'];
			}
			$payload .= '--' . $boundary;
			$payload .= "\r\n";
			$payload .= 'Content-Disposition: form-data; name="' . $name .
			            '"; filename="' . basename( $value["bbapp_file"] ) . '"' . "\r\n";
			if ( $mime ) {
				$payload .= 'Content-Type: ' . $mime . "\r\n";
			}

			$payload .= "\r\n";
			$payload .= file_get_contents( $value["bbapp_file"] );
			$payload .= "\r\n";
		} else { // for normal data.
			$payload .= '--' . $boundary;
			$payload .= "\r\n";
			$payload .= 'Content-Disposition: form-data; name="' . $name .
			            '"' . "\r\n\r\n";
			$payload .= $value;
			$payload .= "\r\n";
		}
	}

	$payload .= '--' . $boundary . '--';

	$args["headers"] = $headers;
	$args["body"] = $payload;

	return bbapp_remote_post( $url, $args );
}

/**
 * it's a alias for wp_remote_post but allows filters.
 *
 * @param       $url
 * @param array $args
 *
 * @return array|WP_Error
 */
function bbapp_remote_post($url, $args = array())
{

    $url = apply_filters("bbapp_remote_post_url", $url, $args);
    $args = apply_filters("bbapp_remote_post_args", $args, $url);
    $response = wp_remote_post($url, $args);
    $response = apply_filters("bbapp_remote_post_response", $response, $url, $args);
    return $response;
}

/**
 * Alias Function for accessing all apps.
 * @return array|mixed|void
 */
function bbapp_get_app()
{
    return \BuddyBossApp\ManageApp::instance()->get_app();
}

/**
 * Return the registered var from header
 *
 * @param $name
 *
 * @return bool
 */
function bbapp_get_var($name)
{
    global $bbapp_var;

    if (!isset($bbapp_var[$name])) {
        return false;
    }

    return $bbapp_var[$name];

}

/**
 * Returns JWT jti.
 *
 * @param $token
 *
 * @return bool
 */
function bbapp_get_jwt_jti($token)
{
    $token = explode(".", $token);
    $token = (array)json_decode(base64_decode($token[1]));
    if (!isset($token["jti"])) {
        $token["jti"] = false;
    }

    return $token["jti"];
}

/**
 * Download URL into WordPress attachment.
 * @param $url
 * @return array|mixed|WP_Error
 */
function bbapp_download_to_media($url)
{

    require_once ABSPATH . 'wp-admin/includes/file.php';

    $timeout_seconds = 5;

    $temp_file = download_url($url, $timeout_seconds);

    if (!is_wp_error($temp_file)) {

        // Array based on $_FILE as seen in PHP file uploads
        $file = array(
            'name' => basename($url), // ex: wp-header-logo.png
            'type' => 'image/png',
            'tmp_name' => $temp_file,
            'error' => 0,
            'size' => filesize($temp_file),
        );

        $overrides = array(
            'test_form' => false,
            'test_size' => true,
        );

        // Move the temporary file into the uploads directory
        $results = wp_handle_sideload($file, $overrides);

        if (!empty($results['error'])) {

            return new \WP_Error('error_uploading', __($results['error'], 'buddyboss-app'), array('status' => 500));

        } else {

            return $results;

            // Perform any actions here based in the above results
        }

    }

    return $temp_file;

}

/**
 * Get Networks Options.
 * @param $option
 *
 * @return mixed|void
 */
function bbapp_get_network_option($option)
{
    if (bbapp()->is_network_activated()) {
        $values = get_network_option(1, $option);
    } else {
        $values = get_option($option);
    }

    return $values;
}

/**
 * Update Network options
 *
 * @param      $option
 * @param      $value
 * @param null $autoload
 *
 * @return bool
 */
function bbapp_set_network_option($option, $value,$autoload = null)
{
    if (bbapp()->is_network_activated()) {
        return update_network_option(1, $option, $value);
    } else {
        return update_option($option, $value,$autoload);
    }
}

/**
 * Delete Network options
 *
 * @param $option
 *
 * @return bool
 */
function bbapp_delete_network_option( $option ) {
	if ( bbapp()->is_network_activated() ) {
		return delete_network_option( 1, $option );
	} else {
		return delete_option( $option );
	}
}

/**
 * Return the BuddyBossApp Network Table.
 * @param $table_name
 *
 * @return string
 */
function bbapp_get_network_table($table_name)
{
	$table_name = bbapp_get_global_db_prefix() . $table_name;
    return $table_name;
}

/**
 * Return the global db prefix.
 * @return mixed
 */
function bbapp_get_global_db_prefix() {
	global $wpdb;
	static $bbapp_global_prefix;

	if(!isset($bbapp_global_prefix)) {
		$bbapp_global_prefix = $wpdb->prefix;

		if ( is_multisite() ) {
			switch_to_blog( 1 );
			$bbapp_global_prefix = $wpdb->prefix;
			restore_current_blog();
		}
	}
	return $bbapp_global_prefix;
}

/**
 * Upgrade & fix the table data.
 */
function bbapp_table_fix_wp_bbapp_user_devices()
{

    global $wpdb;

    $table = bbapp_get_network_table( 'bbapp_user_devices' );

    //Upgrade hashes of tokens
    $wpdb->query("UPDATE {$table} SET device_token_hash=SHA2(device_token,256) WHERE length(device_token_hash) < 64 ");

    // if found empty column change them to firebase as they probably old one.
    $wpdb->query("UPDATE {$table} SET push_type='firebase' WHERE push_type = ''");
}

/**
 * Upgrade & fix the table data.
 */
function bbapp_table_fix_remove_dublicates_device_tokens()
{

    global $wpdb;

    $table = bbapp_get_network_table( 'bbapp_user_devices' );

    //Removes duplicates device tokens by device token. because there can be only 1 device token uniquely
    $wpdb->query("DELETE t1 FROM {$table} t1, {$table} t2 WHERE t1.id < t2.id AND t1.device_token = t2.device_token");

    // Remove dublicates auth tokens as there can be only 1 auth token per device and per push notification assigned.
    $wpdb->query("DELETE t1 FROM {$table} t1, {$table} t2 WHERE t1.id < t2.id AND t1.user_id = t2.user_id AND t1.auth_token_hash = t2.auth_token_hash");
}

/**
 * Delete all the notification device table rows.
 */
function bbapp_table_remove_all_device_tokens()
{

	global $wpdb;

	$table = bbapp_get_network_table( 'bbapp_user_devices' );

	$exec = $wpdb->query("DELETE FROM {$table}");

	if(!empty($exec)) {
		Logger::instance()->add("all_device_tokens", sprintf(__("Deleted all device tokens.", 'buddyboss-app'), $exec));
	}

}

/**
 * Converts a relative url scheme to current used one.
 *
 * @param string $url
 *
 * @return string
 */
function bbapp_fix_url_scheme($url)
{

    if (substr($url, 0, 2) == "//") {
        $url = str_replace("//", "", $url);
    }

    $url = str_replace(array("http://", "https://"), "", $url);

    if (is_ssl()) {
        $url = "https://{$url}";
    } else {
        $url = "http://{$url}";
    }

    return $url;
}

/**
 * Get a list of all Multi Languages.
 *
 * @return array List of all multi languages.
 */
function bbapp_get_multi_languages_list()
{

    $languages = array();

    return apply_filters('bbapp_multi_languages_list', $languages);
}

/**
 * Return whether string has lang string contains.
 *
 * @param string $string
 *
 * @return bool
 */
function bbapp_has_language($string)
{

    $reg = '/<!--:-->/';
    if (preg_match($reg, $string)) {
        return true;
    }

    return false;
}

/**
 * Filter the language string based on given lang code.
 *
 * @param $string
 * @param bool $lang_code
 * @param bool $default_lang_code
 *
 * @return string
 */
function bbapp_get_language($string, $lang_code = false, $default_lang_code = false)
{

    // Get Current Lang Code if not requested.
    if (empty($lang_code)) {
        $lang_code = bbapp_get_current_lang_code();
    }

    $has_language = bbapp_has_language($string);

    // Return Actual string if not have language code.
    if (empty($has_language)) {
        return $string;
    }

    // Set Default lang code if true.
    if ($default_lang_code) {
        $lang_code = 'en';
    }

    // Get Current Lang Code.
    $current_lang_code = bbapp_get_current_lang_code();

    // Get Lang posh default lang code.
    $default_lang_code = bbapp_get_default_lang_code();

    // Check if Lang code match in string then user that lang code.
    if (preg_match("/:$current_lang_code/m", $string)) {
        $lang_code = $current_lang_code;
    } elseif (preg_match("/:$default_lang_code/m", $string)) {
        $lang_code = $default_lang_code;
    } else {
        if (preg_match('/<!--:/m', $string)) {
            $explodedString = explode('-->', $string);
            $langCodeStringExplode = explode('<!--:', $explodedString[0]);
            $lang_code = $langCodeStringExplode[1];
        }
    }

    $exposedStrings = explode('<!--:' . $lang_code . '-->', $string);

    if (count($exposedStrings) > 1) {
        $moreStrings = $exposedStrings[1];
        $finalExplode = explode('<!--:-->', $moreStrings);
        $finalLangString = $finalExplode[0];

    } else {
        $finalLangString = $exposedStrings[0];
    }

    /**
     * Modify Language string.
     *
     * @param string $finalLangString Modified string
     * @param string $string Actual string
     * @param string $lang_code Lang Code
     *
     * @return string $finalLangString Modified string
     */
    return apply_filters('bbapp_get_language_string', $finalLangString, $string, $lang_code);
}

/**
 * Get Current Lang Code.
 *
 * @return string
 */
function bbapp_get_current_lang_code()
{

    /**
     * Modify Current Lang code.
     *
     * @param string
     *
     * @return string
     */
    return apply_filters('bbapp_get_current_lang_code', 'en');
}

/**
 * Modify default Lang code.
 *
 * @return string
 */
function bbapp_get_default_lang_code()
{
    /**
     * Modify default Lang code.
     *
     * @param string
     *
     * @return string
     */
    return apply_filters('bbapp_get_default_lang_code', 'en');
}

/**
 * Get default APP Page.
 *
 * @return int|bool
 */
function bbapp_get_default_app_page() {
    $bbapp_default_apppage = get_option('bbapp_default_apppage', false);
    $post = get_post( $bbapp_default_apppage );

    if( empty($bbapp_default_apppage) || empty( $post ) ) {

        // Insert Default APP Page.
        $appPage = array(
            'post_title'  => __( 'App Editor Helper', 'buddyboss-app' ),
            'post_status' => 'publish',
            'post_type'   => 'app_page',
        );

        // insert the post into the database
        $app_page_id = wp_insert_post( $appPage );
        update_option( 'bbapp_default_apppage', $app_page_id, false );
        $bbapp_default_apppage = get_option('bbapp_default_apppage', false);

    } else if( ! empty($bbapp_default_apppage) && ! empty( $post ) && 'publish' != $post->post_status ) {

         $bbapp_default_apppage_post = array(
              'ID'           => $bbapp_default_apppage,
              'post_status'  => 'publish'
          );

        // Update the post into the database
        wp_update_post( $bbapp_default_apppage_post );
    }

    if (!empty($bbapp_default_apppage)) {
        return absint($bbapp_default_apppage);
    }

    return $bbapp_default_apppage;
}

/**
 * Parse Gutenberg Content into App Page Parser.
 *
 * @param string $content
 *
 * @return array $new_app_page_data
 */
function bbapp_parse_gutenberg_content($content)
{

    $blocks = parse_blocks($content);

    return bbapp_parse_inner_block($blocks);

}

/**
 * Parse Blocks of App Editor.
 *
 * @param array $blocks
 * @param array $parent_style
 *
 * @return array
 */
function bbapp_parse_inner_block( $blocks, $parent_style = array() ) {

	$new_app_page_data = \BuddyBossApp\NativeAppPage\ParseBlocks::parse_gutenberg_blocks( $blocks, $parent_style );

    return $new_app_page_data;
}

/**
 * Create excerpt form Blocks of App Editor
 * We will checking if any paragraph added in bbapp editor. Using first paragraph text as excerpt
 *
 * @param $content
 *
 * @return string|string[]
 */
function bbapp_parse_gutenberg_excerpt( $content ){
	$content = strip_tags($content);
	$content = trim($content);

    if(empty($content)){
        return $content;
    }

	return wp_trim_words( $content , 55, '...' );
}

/**
 * Return the formatted ajax error.
 *
 * @param $code
 * @param $message
 */
function bbapp_ajax_error_response($code, $message)
{
    $data = array(
        'code' => $code,
        'message' => $message,
    );
    wp_send_json_error($data);
}

/**
 * Return the formatted ajax error.
 *
 * @param $code
 * @param $message
 */
function bbapp_ajax_success_response($code, $message)
{
    $data = array(
        'message' => $message,
        'code' => $code,
    );
    wp_send_json_success($data);
}

/**
 * Converts given text to camelcase based on given separator.
 * @param        $input
 * @param string $separator
 *
 * @return mixed
 */
function bbapp_camelize($input, $separator = '_')
{
    return str_replace($separator, '', ucwords($input, $separator));
}

/**
 * Function let you know that particular feature is available on wordpress.
 * @param        $feature
 * @param string $platform
 *
 * @return bool
 */
function bbapp_is_feature_available($feature, $platform = "both")
{
    $app_class = new \BuddyBossApp\App\App();
    $available_features = $app_class->get_app_features_availability();

    if (!$available_features || !isset($available_features[$feature])) {
        return false;
    }

    if ($platform == "both") {
        // if both. one of platform is true will return true.
        if (
            isset($available_features[$feature]["is_enabled_android"]) &&
            isset($available_features[$feature]["is_enabled_ios"]) &&
            ($available_features[$feature]["is_enabled_android"] || $available_features[$feature]["is_enabled_ios"])
        ) {
            return true;
        }
        return false;
    }

    if ($platform == "android") {
        if (
            isset($available_features[$feature]["is_enabled_android"]) &&
            $available_features[$feature]["is_enabled_android"]
        ) {
            return true;
        }
        return false;
    }

    if ($platform == "ios") {
        if (
            isset($available_features[$feature]["is_enabled_ios"]) &&
            $available_features[$feature]["is_enabled_ios"]
        ) {
            return true;
        }
        return false;
    }

    return false;
}

/**
 * Returns the registered services.
 * @return mixed
 */
function bbapp_get_push_services()
{
    global $bbapp_push_notification_services;

    if (!is_array($bbapp_push_notification_services)) {
        $bbapp_push_notification_services = array();
    }

    return $bbapp_push_notification_services;
}

/**
 * Returns the selected push service instance for app.
 *
 * @return bool|\BuddyBossApp\Notification\Services\ServiceAbstract
 */
function bbapp_get_app_push_instance()
{
	// Get main network id's data for push notification.
	$settings                     = \BuddyBossApp\Notification\Push::instance()->get_settings();
	$push_services                = bbapp_get_push_services();
	$settings["selected_service"] = apply_filters( 'bbapp_get_app_push_service', 'firebase' );
	if ( isset( $push_services[ $settings["selected_service"] ] ) ) {
		return $push_services[ $settings["selected_service"] ]["controller"];
	}
	return false;

}

/**
 * Returns the selected push service instance for app.
 *
 * @return bool|string
 */
function bbapp_get_app_push_firebase_key() 
{
	// Get main network id's data for push notification.
	$global_settings = ManageApp::instance()->get_settings( true );
	if ( ! empty( $global_settings['push.firebase_server_key'] ) ) {
		return $global_settings['push.firebase_server_key'];
	}
	return false;

}

/**
 * Get the instance of Notification class.
 *
 * @return \BuddyBossApp\Notification\Notification
 */
function bbapp_notifications()
{
    return \BuddyBossApp\Notification\Notification::instance();
}

/**
 * Helper function to send push notification to users.
 *
 * @param $notification
 * @return WP_Error
 */
function bbapp_send_push_notification($notification)
{
    return \BuddyBossApp\Notification\Push::instance()->send($notification);
}

/**
 * Return object of Auth Feature.
 * @return mixed
 */
function bbapp_auth()
{
    return \BuddyBossApp\Auth\Auth::instance();
}

/**
 * Returns multidimensional array unique for any single key index.
 * Reason : array_unique() is not intended to work on multi dimensional arrays.
 * @param $multidimensionalArray
 * @param $key
 * @return array
 */
function bbapp_unique_multidim_array($multidimensionalArray, $key)
{
    $temp_array = array();
    $i = 0;
    $key_array = array();

    foreach ($multidimensionalArray as $val) {
        if (!in_array($val[$key], $key_array)) {
            $key_array[$i] = $val[$key];
            $temp_array[$i] = $val;
        }
        $i++;
    }
    return $temp_array;
}

/**
 * Tells if the site is loaded from InApp Browser or not.
 *
 * @param bool $set_cookie
 *
 * @return bool
 */
function bbapp_is_loaded_from_inapp_browser( $set_cookie = false ) {
	if ( in_array( \BuddyBossApp\ClientCommon::instance()->get_page_mode( $set_cookie ), array( "template" ) ) || bbapp_get_page_mode_param() ) {
		return true;
	}
}

/**
 * Mobile page mode param used same as pagemode header
 * @return false|mixed
 */
function bbapp_get_page_mode_param() {
	if ( isset( $_GET["mobile-page-mode"] ) ) {
		return $_GET["mobile-page-mode"];
	}

	return false;
}

/**
 * This function will allow developer to disable the default template load from BuddyBossApp App.
 * It's a API function provded to be used by 3rd party codebase.
 */
function bbapp_disable_default_inapp_browser_template() {
    add_filter('bbapp_perform_pagemode_action',function($value){
        return false;
    });
}

/**
 * Get Default Menu Icons.
 *
 * @param $item_name
 * @param $type
 *
 * @return array
 */
function bbapp_get_menu_icon( $item_name, $type ) {
	switch ( $item_name ) {
		case 'home':
			$default_icon = array(
				'uri' => 'bbapp/home',
			);
			break;
		case 'more':
			$default_icon = array(
				'uri' => 'bbapp/list',
			);
			break;
		case 'custom':
			$default_icon = array(
				'uri' => 'bbapp/web-link',
			);
			break;
		default:
			$default_icon = array(
				'uri' => 'bbapp/file',
			);
	}

	$default_icon = apply_filters_deprecated( 'bbapp_get_default_menu_icons', array(
		$default_icon,
		$item_name,
		$type
	), '1.3.6', 'bbapp_get_menu_icon' );

	return apply_filters( 'bbapp_get_menu_icon', $default_icon, $item_name, $type );
}

function bbapp_get_current_route_url(){
	$current_path = add_query_arg( null, null );
	if ( strpos( $current_path, "wp-json/" ) !== false ) {

		$current_path = explode( "wp-json/", $current_path );
		$current_path = $current_path[1];

		// remove query vars.
		if ( strpos( $current_path, "?" ) !== false ) {
			$current_path = explode( "?", $current_path );
			$current_path = $current_path[0];
		}

		return trim( $current_path );

	}
	return false;
}
/**
 * Get default tab color.
 *
 * @return array
 */
function bbapp_get_default_tab_color() {

	$stylingObj     = new \BuddyBossApp\Styling();
	$stylingOptions = $stylingObj->get_options();
	
	$defaultStylingOptionData = $stylingObj->get_styling_colors();
	$defaultStylingOption     = isset( $defaultStylingOptionData['colors'] ) ? $defaultStylingOptionData['colors'] : array();
	$default_color            = isset( $defaultStylingOption['bottomTabsColor'] ) ? $defaultStylingOption['bottomTabsColor'] : '';
	$default_active_color     = isset( $defaultStylingOption['bottomTabsActiveColor'] ) ? $defaultStylingOption['bottomTabsActiveColor'] : '';
	
	// For Color Options.
	$stylingOptionColors = array();
	
	if ( isset( $stylingOptions['styles'] ) ) {
		foreach ( $stylingOptions['styles'] as $style_key => $style_val ) {
			$style_keys                        = explode( '.', $style_key );
			$style_key                         = $style_keys[2];
			$stylingOptionColors[ $style_key ] = $style_val;
		}
	}
	
	if ( isset( $stylingOptionColors ) && ! empty( $stylingOptionColors ) && is_array( $stylingOptionColors ) ) {
		$default_color        = $stylingOptionColors['bottomTabsColor'];
		$default_active_color = $stylingOptionColors['bottomTabsActiveColor'];
	}
	
	return array( 'default_color' => $default_color, 'default_active_color' => $default_active_color );
}

/**
 * Get selected Icon Path.
 *
 * @param string $icon_value
 *
 * @return string $selected Icon path.
 */
function bbapp_tabbar_get_selected_icon( $icon_value,$icon_style = false ) {
	
	$icons_path        = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_app_icon_url();
	$custom_icons_path = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_dir();
	$custom_icons_url  = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_url();
	
	$selected_icon = '';
	
	if ( strpos( $icon_value, "custom/" ) !== false ) {
		// if it's custom uploaded icon.
		$selected_icon_path = $custom_icons_path . "/" . str_replace( "custom/", "", $icon_value );
		$selected_icon      = $custom_icons_url . "/" . str_replace( "custom/", "", $icon_value );
		
		if ( ! file_exists( $selected_icon_path ) ) {
			$selected_icon = $icons_path . "/file-" . $icon_style . ".png";
		}
		
	} elseif ( ! empty( $icon_value ) ) {
		if(strpos($icon_value, 'bbapp/') !== false && false !== $icon_style){
			$selected_icon = $icons_path . $icon_value . "-" . $icon_style . ".png";
		} else {
			$selected_icon = $icons_path . $icon_value;
		}

	} elseif ( empty( $icon_value ) ) {
		$selected_icon = $icons_path . "/file-" . $icon_style . ".png";
	}
	
	return $selected_icon;
}

/**
 * Fetch Forums though API for Admin Preview.
 *
 * @param int $user_id User ID.
 *
 * @return array
 */
function bbapp_get_profile_tabs( $user_id = 0 ) {

    $profile_tabs = get_transient( 'bbapp_preview_profile_tabs' );
	$show_tabs = true;

	if ( empty( $profile_tabs ) ) {
		$tabs_request          = new WP_REST_Request( 'GET', '/buddyboss/v1/members/' . $user_id . '/detail' );
		$server       = rest_get_server();
		$item         = $server->dispatch( $tabs_request );
		$server_status = $item->get_status();

		$profile_tabs = array();

		if ( 200 === $server_status ) {
			$profile_tabs = $item->get_data();
		}

		set_transient( 'bbapp_preview_profile_tabs', $profile_tabs, 12 * HOUR_IN_SECONDS );
	}

	if ( empty( $profile_tabs ) ) {
		$show_tabs = false;
	}

	return array( $profile_tabs, $show_tabs );
}

/**
 * Profile tabs icons.
 *
 * @return array
 */
function bbapp_profile_tabs_svg() {
	return array(
		'activities' => '<svg width="24" height="22" xmlns="http://www.w3.org/2000/svg"><g stroke="#000" stroke-width="1.5" fill="none" fill-rule="evenodd"><rect x=".75" y=".75" width="22.5" height="20.5" rx="4"/><path d="M5 12.199h2.349a.583.583 0 00.514-.308L9.32 9.167h0l2.33 7.333 2.515-11 2.174 6.306a.583.583 0 00.552.393H19" stroke-linecap="round" stroke-linejoin="round"/></g></svg>',
		'xprofile'   => '<svg width="20" height="24" xmlns="http://www.w3.org/2000/svg"><defs><path d="M15 16.09c5.523 0 10 2.443 10 5.455C25 24.558 25 27 15 27c-9.61 0-9.985-2.256-10-5.105v-.35c0-3.012 4.477-5.454 10-5.454zM15 3c3.37 0 6.111 2.691 6.111 6 0 3.308-2.74 6-6.11 6S8.89 12.309 8.888 9c0-3.309 2.741-6 6.111-6z" id="a"/></defs><path stroke="#000" stroke-width="1.5" d="M10 13.84c-5.164 0-9.25 2.23-9.25 4.704v.347c.018 3.37 1.41 4.359 9.25 4.359 4.538 0 7.104-.504 8.285-1.436.806-.637.965-1.3.965-3.269 0-2.475-4.086-4.704-9.25-4.704zM10 .75C7.041.75 4.64 3.109 4.64 6S7.042 11.25 10 11.25c2.959 0 5.361-2.359 5.361-5.25 0-2.892-2.402-5.25-5.36-5.25z" fill="none" fill-rule="evenodd"/></svg>',
		'friends'    => '<svg width="26" height="24" xmlns="http://www.w3.org/2000/svg"><g stroke="#000" stroke-width="1.5" fill="none" fill-rule="evenodd"><path d="M9.5 13.795c-4.888 0-8.75 2.126-8.75 4.476v.346c.018 3.197 1.331 4.133 8.75 4.133 4.302 0 6.732-.481 7.845-1.368.756-.602.905-1.23.905-3.11 0-2.351-3.863-4.477-8.75-4.477zm0-12.545c-2.789 0-5.056 2.245-5.056 5 .001 2.755 2.268 5 5.056 5 2.789 0 5.056-2.245 5.056-5s-2.267-5-5.056-5z"/><g stroke-linecap="round"><path d="M21.5 5v7M18 8.5h7"/></g></g></svg>',
		'groups'     => '<svg width="26" height="22" xmlns="http://www.w3.org/2000/svg"><g fill-rule="nonzero" stroke="#000" stroke-width="1.5" fill="none"><path d="M16.4 12.65c-4.612 0-8.25 2.005-8.25 4.208v.346c.02 2.988 1.254 3.864 8.25 3.864 4.067 0 6.362-.455 7.407-1.289.704-.56.843-1.148.843-2.92 0-2.203-3.639-4.208-8.25-4.208zm0-11.9c-2.62 0-4.75 2.112-4.75 4.704 0 2.593 2.13 4.705 4.75 4.705s4.75-2.112 4.75-4.704C21.15 2.862 19.02.75 16.4.75z"/><path d="M8.729 11.984a7.911 7.911 0 00-2.329-.333c-2.761 0-5 .788-5 2.432 0 1.56 0 2.839 4.276 2.965" stroke-linecap="round"/><path d="M6.4 9.505c1.407 0 2.55-1.134 2.55-2.523 0-1.39-1.143-2.523-2.55-2.523-1.407 0-2.55 1.134-2.55 2.523 0 1.389 1.143 2.523 2.55 2.523z"/></g></svg>',
		'courses'    => '<svg width="27" height="23" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path d="M-2-4h30v30H-2z"/><path d="M1.057 7.309C1.495 3.845 4.624 1 8.117 1h6.597c3.857 0 6.97 3.53 6.854 7.414-.112 3.753-3.388 6.646-7.142 6.646h-2.132c-.514 0-1.013.173-1.416.491l-3.644 2.876h0v-3.166c0-.13-.097-.24-.227-.257 0 0 0 0 0 0a6.857 6.857 0 01-5.95-7.695z" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M14.096 18.514h1.868c.474 0 .933.163 1.3.463l3.225 2.629v-2.914a.23.23 0 01.201-.229c3.264-.417 5.728-3.493 5.29-7.065a6.557 6.557 0 00-.801-2.418" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.857 7.06a1.143 1.143 0 110 2.285 1.143 1.143 0 010-2.285zm3.429 0a1.143 1.143 0 110 2.285 1.143 1.143 0 010-2.285zm3.428 0a1.143 1.143 0 110 2.285 1.143 1.143 0 010-2.285z" fill="#000"/></g></svg>',
		'photos'     => '<svg width="24" height="20" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path d="M-3-5h30v30H-3z"/><g transform="translate(1 1)" stroke="#000" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"><path d="M3.826 0h14.348A3.826 3.826 0 0122 3.826v10.522a3.826 3.826 0 01-3.826 3.826H3.826A3.826 3.826 0 010 14.348V3.826A3.826 3.826 0 013.826 0z"/><path d="M.29 11.03L3.3 8.069a2.87 2.87 0 014.025 0l2.658 2.615h0l1.781 1.752M10.335 14.192l3.948-3.953a2.87 2.87 0 014.041-.02l3.414 3.353h0"/><circle cx="12.196" cy="5.5" r="1.674"/></g></g></svg>',
		'forums'     => '<svg width="27" height="23" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><path d="M-2-4h30v30H-2z"/><path d="M1.057 7.309C1.495 3.845 4.624 1 8.117 1h6.597c3.857 0 6.97 3.53 6.854 7.414-.112 3.753-3.388 6.646-7.142 6.646h-2.132c-.514 0-1.013.173-1.416.491l-3.644 2.876h0v-3.166c0-.13-.097-.24-.227-.257 0 0 0 0 0 0a6.857 6.857 0 01-5.95-7.695z" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M14.096 18.514h1.868c.474 0 .933.163 1.3.463l3.225 2.629v-2.914a.23.23 0 01.201-.229c3.264-.417 5.728-3.493 5.29-7.065a6.557 6.557 0 00-.801-2.418" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M7.857 7.06a1.143 1.143 0 110 2.285 1.143 1.143 0 010-2.285zm3.429 0a1.143 1.143 0 110 2.285 1.143 1.143 0 010-2.285zm3.428 0a1.143 1.143 0 110 2.285 1.143 1.143 0 010-2.285z" fill="#000"/></g></svg>'
	);
}

/**
 * Fetch Forums though API for Admin Preview.
 *
 * @return array
 */
function bbapp_get_forums() {
	
	$forums = get_transient( 'bbapp_preview_forums' );
	$show_forums = true;
	
	if ( false === $forums || empty( $forums ) ) {
		$forum_request          = new WP_REST_Request( 'GET', '/buddyboss/v1/forums' );
		$forums_per_page        = ( function_exists( 'bbp_get_forums_per_page' ) ? bbp_get_forums_per_page() : get_option( '_bbp_forums_per_page', 15 ) );
		$query_args['per_page'] = $forums_per_page;
		$query_args['orderby']  = 'activity';
		$query_args['order']    = 'desc';
		$forum_request->set_query_params( $query_args );
		
		$server       = rest_get_server();
		$item         = $server->dispatch( $forum_request );
		$forum_status = $item->get_status();
		
		$forums = array();
		
		if ( 200 === $forum_status ) {
			$forums = $item->get_data();
		}
		
		set_transient( 'bbapp_preview_forums', $forums, 12 * HOUR_IN_SECONDS );
	}
	
	if ( empty( $forums ) ) {
		$show_forums = false;
	}
	
	return array( $forums, $show_forums );
}

/**
 * Fetch Topics though API for Admin Preview.
 *
 * @return array
 */
function bbapp_get_topics() {
	$forum_request          = new WP_REST_Request( 'GET', '/buddyboss/v1/forums' );
	$query_args['per_page'] = 1;
	$query_args['orderby']  = 'activity';
	$query_args['order']    = 'desc';
	$forum_request->set_query_params( $query_args );
	$forum_request->set_query_params( $query_args );
	
	$server       = rest_get_server();
	$item         = $server->dispatch( $forum_request );
	$forum_status = $item->get_status();
	
	$show_topic = true;
	
	$forums = array();
	if ( 200 === $forum_status ) {
		$forums = $item->get_data();
	}
	
	if ( empty( $forums ) ) {
		$show_topic = false;
	}
	
	$first_forum = isset( $forums[0] ) ? $forums[0] : array();
	
	if ( empty( $first_forum ) ) {
		$show_topic = false;
	}
	
	$topic_id = isset( $first_forum['last_topic_id'] ) ? $first_forum['last_topic_id'] : 0;
	
	if ( empty( $topic_id ) ) {
		$show_topic = false;
	}
	
	$topics = get_transient( 'bbapp_preview_topics' );
	
	if ( $show_topic && ( false === $topics || empty( $topics ) ) ) {
		$topic_request          = new WP_REST_Request( 'GET', '/buddyboss/v1/topics/' . $topic_id );
		$topic_query_args['per_page'] = 1;
		$topic_request->set_query_params( $topic_query_args );
		
		$server     = rest_get_server();
		$topic_item = $server->dispatch( $topic_request );
		$status     = $topic_item->get_status();
		
		$topics = array();
		if ( 200 === $status ) {
			$topics = $topic_item->get_data();
		}
		
		set_transient( 'bbapp_preview_topics', $topics, 12 * HOUR_IN_SECONDS );
	}
	
	if ( empty( $topics ) ) {
		$topics = array();
		$show_topic = false;
	}
	
	$reply = array();
	if ( ! empty( $topic_id ) ) {
		$reply_request = new WP_REST_Request( 'GET', '/buddyboss/v1/reply' );
		$reply_query_args['parent'] = $topic_id;
		$reply_request->set_query_params( $reply_query_args );
		
		$server     = rest_get_server();
		$reply_item = $server->dispatch( $reply_request );
		$status     = $reply_item->get_status();
		
		if ( 200 === $status ) {
			$reply = $reply_item->get_data();
		}
		
	}
	
	return array( $topics, $reply, $show_topic );
}

/**
 * Fetch Lesson though API for Admin Preview.
 *
 * @return array
 */
function bbapp_get_lessons() {
	$course_request         = new WP_REST_Request( 'GET', '/buddyboss-app/learndash/v1/courses' );
	$query_args['per_page'] = 1;
	$course_request->set_query_params( $query_args );

	$server        = rest_get_server();
	$course_item   = $server->dispatch( $course_request );
	$course_status = $course_item->get_status();

	$show_lesson = true;
	$courses     = array();
	if ( 200 === $course_status ) {
		$courses = $course_item->get_data();
	}

	if ( empty( $courses ) ) {
		$show_lesson = false;
	}
	
	$first_course = isset( $courses[0] ) ? $courses[0] : array();

	if ( empty( $first_course ) ) {
		$show_lesson = false;
	}
	
	$first_course_id = isset( $first_course['id'] ) ? $first_course['id'] : 0;
	
	if ( empty( $first_course_id ) ) {
		$show_lesson = false;
	}
	
	$no_of_lessons = isset( $first_course['lessons'] ) ? count( $first_course['lessons'] ) : 0;
	
	$lessons = get_transient( 'bbapp_preview_single_lesson' );
	if ( $show_lesson ) {
		if ( false === $lessons || empty( $lessons ) ) {
			$course_request          = new WP_REST_Request( 'GET', '/buddyboss-app/learndash/v1/lessons' );

			$query_args['course_id'] = $first_course_id;
			$course_request->set_query_params( $query_args );

			$server = rest_get_server();
			$item   = $server->dispatch( $course_request );
			$status = $item->get_status();
			
			$lessons = array();
			
			if ( 200 === $status ) {
				$lessons = $item->get_data();
			}
			
			set_transient( 'bbapp_preview_single_lesson', $lessons, 12 * HOUR_IN_SECONDS );
		}
	}
	
	if ( empty( $lessons ) ) {
		$lessons     = array();
		$show_lesson = false;
	}
	
	$first_lesson = isset( $lessons[0] ) ? $lessons[0] : array();
	
	if ( empty( $first_lesson ) ) {
		$show_lesson = false;
	}
	
	return array( $lessons, $show_lesson, $no_of_lessons );
}

/**
 * Get Styling Color by Key.
 *
 * @param string $key
 *
 * @return mixed|string
 */
function bbapp_get_default_color( $key ) {

	// Read from JSON file.
	$defaultStylingOptionData = BuddyBossApp\Styling::instance()->get_styling_colors();
	$defaultStylingOption     = isset( $defaultStylingOptionData['colors'] ) ? $defaultStylingOptionData['colors'] : array();
	$defaultIconColor         = isset( $defaultStylingOption[ $key ] ) ? $defaultStylingOption[ $key ] : '';
	
	// Get value from DB.
	$styling_options = BuddyBossApp\Styling::instance()->get_options();
	$values          = isset( $styling_options["styles"] ) ? $styling_options["styles"] : array();
	
	if ( isset( $values ) && ! empty( $values ) ) {
		$defaultIconColor = $values[ 'styles.colors.' . $key ];
	}
	
	return $defaultIconColor;
}

/**
 * Helper function to get app rest language for preview.
 * @return mixed
 */
function bbapp_get_rest_app_languages_for_preview() {

	$languages      = BuddyBossApp\AppLanguages::instance();
	$languages_data = $languages->get_languages_for_rest();
	if ( is_wp_error( $languages_data ) ) {
		$languages_data = array();
	}

	return $languages_data['en_US'];
}

/**
 * Tells if user is seeing super admin page.
 * Cases are.
 * 1. Return true when plugin activated in network mode & it is network admin area
 * 2. Return true when plugin activated in normal mode it's wp-admin.
 */
function bbapp_is_super_admin_page()
{

    if (bbapp()->is_network_activated()) {
        if (is_network_admin()) {
            return true;
        }
    } else {
        if (is_admin()) {
            return true;
        }
    }

    return false;

}

/**
 * Check if user is on admin page.
 * Cases are.
 * 1. Returns true when plugin activated in network mode & it is not network admin area.
 * 2. Returns true when plugin activated in normal mode and it's wp-admin page.
 * @return bool
 */
function bbapp_is_admin_page()
{
    if (bbapp()->is_network_activated()) {
        if (is_network_admin()) {
            return false;
        }
    }

    return is_admin();
}

/**
 * Return the super admin URL.
 * @param $path
 * @return string|void
 */
function bbapp_get_admin_url($path = "") {
    if ( bbapp()->is_network_activated() && is_network_admin() ) { // links are diff for pages.
        $link = network_admin_url( $path );
    } else {
        $link = admin_url( $path );
    }
    return $link;
}

/**
 * Return the super admin URL.
 * If network mode is enabled and user viewing link on normal dashboard he will get direct to network admin.
 * @param string $path
 * @return string|void
 */
function bbapp_get_super_admin_url($path = "") {
    if ( bbapp()->is_network_activated() ) { // links are diff for pages.
        $link = network_admin_url( $path );
    } else {
        $link = admin_url( $path );
    }
    return $link;
}

/**
 * Tells weather the component is active or not.
 * @param $component_id
 *
 * @return bool
 */
function bbapp_is_active($component_id){
    return BuddyBossApp\Components::instance()->is_active($component_id);
}



/**
 * Return the iap upload path.
 *
 * @param $relativepath
 *
 * @return string
 */
function bbapp_get_upload_full_path( $relativepath ) {
	static $uploadDir;

	if ( empty( $relativepath ) ) {
		return null;
	}

	if ( ! is_array( $uploadDir ) ) {
		if ( bbapp()->is_network_activated() ) { // Plugin is activated on network mode.
			switch_to_blog( 1 );
			$uploadDir = wp_upload_dir();
			restore_current_blog();
		} else {
			$uploadDir = wp_upload_dir();
		}
	}

	$path = trailingslashit( $uploadDir["basedir"] ) . $relativepath;

	return preg_replace( '#/+#', '/', $path );
}

/**
 * Render the register fields.
 *
 * @param object $field Field Object.
 * @param array $language Language set.
 *
 * @return false|string
 */
function bbapp_render_registration_field( $field, $language = array() ) {
	if ( empty( $field ) ) {
		return '';
	}

	$type = $field->type;

	ob_start();

	switch ( $type ) {
		case 'text':
		case 'email':
		case 'password':
		case 'textbox':
		case 'telephone':
		case 'url':
		case 'number':
		case 'datebox':
			?>
            <div class="app-field-set bbapp-style-bodyText login-label regFieldTextColor color-attr">
                <label><?php echo sprintf( __( '%1$s %2$s', 'buddyboss-app' ), $field->label, ( $field->required !== true ? '(optional)' : '' ) ); ?></label>
                <div class="app-field<?php echo ( 'password' === $type ) ? ' pass-icon-wrap' : '' ?>">
					<?php
					if ( 'password' !== $type ) {
						echo sprintf( __( '<span class="placeholder">Enter %s</span>', 'buddyboss-app' ), strtolower( $field->label ) );
					} elseif ( 'password' === $type ) {
						echo '<svg width="18" height="16" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd" opacity=".77"><path d="M-2-3h22v22H-2z"/><path d="M9 14.417a6.364 6.364 0 01-2.295-.454M17.142 8.429c-1.735 3.207-4.938 5.988-8.142 5.988M15.49 5.178c.632.741 1.195 1.55 1.652 2.394a.905.905 0 010 .857M2.583 14.417L15.417 1.583M6.959 10.041a2.888 2.888 0 014.083-4.083" stroke="#FFF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M13.624 3.376C12.206 2.28 10.602 1.583 9 1.583c-3.204 0-6.407 2.78-8.142 5.989a.905.905 0 000 .857c.867 1.603 2.101 3.1 3.518 4.196" stroke="#FFF" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></g></svg>';
					}
					?>
                </div>
				<?php
				if ( ! empty( $field->description ) ) {
					echo '<div class="app-field-description">' . $field->description . '</div>';
				}
				?>
            </div>
			<?php
			break;

		case 'gender':
		case 'radio':

			$options = $field->options;
			?>
            <div class="app-field-set bbapp-style-bodyText login-label regFieldTextColor color-attr">
                <label><?php echo sprintf( __( '%1$s %2$s', 'buddyboss-app' ), $field->label, ( $field->required !== true ? '(optional)' : '' ) ); ?></label>
                <div class="app-field radio-icon-wrap">
					<?php
					foreach ( $options as $option ) {
						echo '<div class="app-field field-options">' .
						     $option->name .
						     (
						     true === $option->is_default_option
							     ? '<svg width="22" height="22" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><circle stroke="#FFF" stroke-width="1.5" fill="#FFF" cx="11" cy="11" r="10.25"/><circle fill="#385DFF" cx="11" cy="11" r="6"/></g></svg>'
							     : '<svg width="22" height="22" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><circle stroke-opacity=".7" stroke="#FFF" stroke-width="1.5" cx="11" cy="11" r="10.25"/><circle cx="11" cy="11" r="7"/></g></svg>'
						     ) .
						     '</div>';
					}
					?>
                </div>
				<?php
				if ( ! empty( $field->description ) ) {
					echo '<div class="app-field-description">' . $field->description . '</div>';
				}
				?>
            </div>
			<?php
			break;

		case 'checkbox':
			$options = $field->options;
			?>
            <div class="app-field-set bbapp-style-bodyText login-label regFieldTextColor color-attr">
                <label><?php echo sprintf( __( '%1$s %2$s', 'buddyboss-app' ), $field->label, ( $field->required !== true ? '(optional)' : '' ) ); ?></label>
                <div class="app-field checkbox-icon-wrap">
					<?php
					foreach ( $options as $option ) {
						echo '<div class="app-field field-options">' .
						     $option->name .
						     (
						     true === $option->is_default_option
							     ? '<svg width="22" height="22" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><rect stroke="#FFF" stroke-width="1.5" fill="#FFF" x=".75" y=".75" width="20.5" height="20.5" rx="10.25"/><path stroke="#385DFF" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M6.6 11.656l2.992 2.672 6.254-6.408"/></g></svg>'
							     : '<svg width="22" height="22" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><circle stroke-opacity=".7" stroke="#FFF" stroke-width="1.5" cx="11" cy="11" r="10.25"/><circle cx="11" cy="11" r="7"/></g></svg>'
						     ) .
						     '</div>';
					}
					?>
                </div>
				<?php
				if ( ! empty( $field->description ) ) {
					echo '<div class="app-field-description">' . $field->description . '</div>';
				}
				?>
            </div>
			<?php
			break;

		case 'selectbox':
		case 'multiselectbox':
			?>
            <div class="app-field-set bbapp-style-bodyText login-label regFieldTextColor color-attr">
                <label><?php echo sprintf( __( '%1$s %2$s', 'buddyboss-app' ), $field->label, ( $field->required !== true ? '(optional)' : '' ) ); ?></label>
                <div class="app-field selectbox-field">
					<?php
					echo sprintf( __( 'Select %s', 'buddyboss-app' ), strtolower( $field->label ) );
					?>
                </div>
				<?php
				if ( ! empty( $field->description ) ) {
					echo '<div class="app-field-description">' . $field->description . '</div>';
				}
				?>
            </div>
			<?php
			break;

		case 'socialnetworks':
			$options = $field->options;
			?>
            <div class="app-field-set bbapp-style-bodyText login-label regFieldTextColor color-attr">
                <label><?php echo sprintf( __( '%1$s %2$s', 'buddyboss-app' ), $field->label, ( $field->required !== true ? '(optional)' : '' ) ); ?></label>
				<?php
                foreach ( $options as $social ) {
					echo '<div class="app-field social-field">' .
					     sprintf( __( '<span class="placeholder">Enter %s URL</span>', 'buddyboss-app' ), strtolower( $social->name ) ) .
					     '</div>';

				}

				if ( ! empty( $field->description ) ) {
					echo '<div class="app-field-description">' . $field->description . '</div>';
				}
				?>
            </div>
			<?php
			break;

		case 'textarea':
			?>
            <div class="app-field-set bbapp-style-bodyText login-label regFieldTextColor color-attr">
                <label><?php echo sprintf( __( '%1$s %2$s', 'buddyboss-app' ), $field->label, ( $field->required !== true ? '(optional)' : '' ) ); ?></label>
                <div class="app-field field-textarea">
					<?php echo sprintf( __( '<span class="placeholder">Enter %s</span>', 'buddyboss-app' ), strtolower( $field->label ) ); ?>
                </div>
				<?php
				if ( ! empty( $field->description ) ) {
					echo '<div class="app-field-description">' . $field->description . '</div>';
				}
				?>
            </div>
			<?php
			break;

	}

	return ob_get_clean();
}


function bbapp_render_default_images( $type ) {

    $image = '';

    switch( $type ) {
        case 'group':
            $image = bbapp()->plugin_url . 'assets/img/default-group-img.png';
            break;
	    case 'group-r':
		    $image = bbapp()->plugin_url . 'assets/img/default-group-img-r.png';
		    break;
	    case 'forum':
		    $image = bbapp()->plugin_url . 'assets/img/default-forum-img.png';
		    break;
	    case 'member':
		    $image = bbapp()->plugin_url . 'assets/img/default-member-img.png';
		    break;
    }

    return $image;

}

/**
 * returns the bool value
 *
 * @param $google_font_key
 *
 * @return mixed
 */
function is_google_api_valid( $google_font_key ) {

	$response = bbapp_remote_get( 'https://www.googleapis.com/webfonts/v1/webfonts?key=' . $google_font_key );

	if ( ! is_wp_error( $response ) ) {
		// Retrieve body
		$response_body = wp_remote_retrieve_body( $response );
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_data = json_decode( $response_body );

		if ( '200' == wp_remote_retrieve_response_code( $response ) ) {
			return true;
		}
		$response_message = isset( $response_data->error ) && isset( $response_data->error->message ) ? $response_data->error->message : wp_remote_retrieve_response_message( $response );

		return new WP_Error( 'google_font_json_error', $response_message, array( 'status' => $response_code ) );
	}

	return new WP_Error( 'google_font_json_error', __( 'There was a problem with the Vimeo API', 'buddyboss-app' ), array( 'status' => 400 ) );
}

/**
 * Check the vimeo auth code is valid or not.
 *
 * @param string $vimeo_auth_code Vimeo authentication code.
 *
 * @return bool|WP_Error
 *
 *
 * @since 1.3.6
 *
 */
function is_vimeo_api_valid( $vimeo_auth_code ) {

	$args = array(
		'user-agent' => isset( $request['user_agent'] ) ? $request['user_agent'] : $_SERVER['HTTP_USER_AGENT'],
		'method'     => 'GET',
		'headers'    => array( 'Authorization' => 'Bearer ' . $vimeo_auth_code ),
	);

	$response = wp_remote_request(
		'https://api.vimeo.com/oauth/verify',
		$args
	);

	if ( ! is_wp_error( $response ) ) {
		// Retrieve body
		$response_body = wp_remote_retrieve_body( $response );
		$response_code = wp_remote_retrieve_response_code( $response );
		$response_data = json_decode( $response_body );

		if ( '200' == wp_remote_retrieve_response_code( $response ) ) {
			return true;
		}
		$response_message = isset( $response_data->error ) ? $response_data->error : wp_remote_retrieve_response_message( $response );

		return new WP_Error( 'vimeo_json_error', $response_message, array( 'status' => $response_code ) );
	}

	return new WP_Error( 'vimeo_json_error', __( 'There was a problem with the Vimeo API', 'buddyboss-app' ), array( 'status' => 400 ) );
}

/**
 * array_key_last function Support for PHP < 7.3
 */
if ( ! function_exists( "array_key_last" ) ) {
	function array_key_last( $array ) {
		if ( ! is_array( $array ) || empty( $array ) ) {
			return null;
		}
		return array_keys( $array )[ count( $array ) - 1 ];
	}
}

/**
 * array_key_first function Support for PHP < 7.3.
 */
if (! function_exists( 'array_key_first' ) ) {
	function array_key_first( array $arr ) {
		foreach ( $arr as $key => $unused ) {
			return $key;
		}

		return null;
	}
}

/**
 * Get app version core.
 *
 * @param bool   $use_cache
 *
 * @return array App version code.
 */
function bbapp_get_app_core( $use_cache = true ) {

	$cache = get_transient( 'bbapp_get_app_core' );

	if ( ! empty( $cache ) && $use_cache ) {
		return $cache;
	}

	// Get response.
	$app_core_response = wp_remote_get( 'https://buddyboss.com/resources/wp-json/wp/v2/releases-app?per_page=1' );

	$app_core_data = array();

	if ( ! is_wp_error( $app_core_response ) ) {

		// Retrieve body
		$response_body = wp_remote_retrieve_body( $app_core_response );

		// Get version.
		if ( ! empty ( $response_body ) ) {
			$app_code_data = json_decode( $response_body );
			if ( ! empty( $app_code_data[0] ) ) {
				$app_core_data['version'] = isset( $app_code_data[0]->title->rendered ) ? $app_code_data[0]->title->rendered : '';
				$app_core_data['link']    = isset( $app_code_data[0]->link ) ? $app_code_data[0]->link : '';
				$app_core_data['slug']    = isset( $app_code_data[0]->slug ) ? $app_code_data[0]->slug : '';
			}
		}
	}
	set_transient( 'bbapp_get_app_core', $app_core_data, 12 * HOUR_IN_SECONDS ); // 12 hours of cache.

	return $app_core_data;
}

if ( ! function_exists( 'bbapp_is_rest' ) ) {
	/**
	 * Check the request is REST or not.
	 *
	 * @return bool
	 */
	function bbapp_is_rest() {
		return ( strpos( $_SERVER['REQUEST_URI'], '/wp-json' ) !== false );
	}
}

if ( ! function_exists( 'bbapp_delete_transients' ) ) {
	/**
	 * Delete transient based option name.
	 * Function will remove transient from DB when click on clear Transient button( Tools -> Transients ).
	 *
	 * @param string|array $bbapp_options
	 */
	function bbapp_delete_transients( $bbapp_options ) {
		global $wpdb;
		$sql_condition = '';
		if ( is_array( $bbapp_options ) && ! empty( $bbapp_options ) ) {
			foreach ( $bbapp_options as $option_key => $option_val ) {
				if ( 0 === $option_key ) {
					$sql_condition .= ' WHERE option_name LIKE "%' . $option_val . '%"';
				} else {
					$sql_condition .= ' OR option_name LIKE "%' . $option_val . '%"';
				}
			}
		} else {
			$sql_condition .= ' WHERE option_name LIKE "%' . $bbapp_options . '%"';
		}
		$sql       = 'SELECT option_name FROM ' . $wpdb->options;
		$sql       .= $sql_condition;
		$all_cache = $wpdb->get_col( $sql );
		if ( ! empty( $all_cache ) ) {
			foreach ( $all_cache as $cache_name ) {
				$cache_name = str_replace( '_site_transient_', '', $cache_name );
				$cache_name = str_replace( '_transient_', '', $cache_name );
				delete_transient( $cache_name );
				delete_site_transient( $cache_name );
			}
		}
	}
}

if ( ! function_exists( 'bbapp_generate_password' ) ) {

	/**
	 * Copy of wp_generate_password excluding the filter hook.
	 *
	 * @param int $length
	 * @param bool $special_chars
	 * @param bool $extra_special_chars
	 *
	 * @return string
	 */
	function bbapp_generate_password( $length = 12, $special_chars = true, $extra_special_chars = false ) {
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		if ( $special_chars ) {
			$chars .= '!@#$%^&*()';
		}
		if ( $extra_special_chars ) {
			$chars .= '-_ []{}<>~`+=,.;:/?|';
		}

		$password = '';
		for ( $i = 0; $i < $length; $i ++ ) {
			$password .= substr( $chars, wp_rand( 0, strlen( $chars ) - 1 ), 1 );
		}

		return $password;
	}
}

if ( ! function_exists( 'bbapp_untrailingslashit' ) ) {
	/**
	 * Url un trailing slash it
	 *
	 * @param string $url url
	 *
	 * @sicne 1.3.7
	 *
	 * @return mixed|string
	 */
	function bbapp_untrailingslashit( $url ) {
		$parse_url = wp_parse_url( $url );

		if ( ! empty( $parse_url['query'] ) ) {
			$url = untrailingslashit( $url );
		}

		return $url;
	}
}

if ( ! function_exists( 'bbapp_tooltip' ) ) {
	/**
	 * Load tooltip html.
	 *
	 * @param        $text
	 * @param string $html
	 *
	 * @since 1.4.1
	 */
	function bbapp_tooltip( $text, $html = '' ) {
		?>
        <div class="bbapp-tooltip">
            <span class="bbapp-tooltip-text" id="bbapp-span-tooltip"
                  data-tooltip="<?php echo wp_kses_post( $text ) ?>"></span>
			<?php
			echo wp_kses_post( $html );
			?>
        </div>
		<?php
	}
}

/**
 * Function to get the user display name.
 *
 * @param int|string $user_id_or_username user id or username.
 *
 * @since 1.4.1
 *
 * @return false|mixed|void
 */
function bbaap_get_user_display_name( $user_id_or_username ) {

	if ( empty( $user_id_or_username ) ) {
		return false;
	}

	if ( function_exists( 'bp_core_get_user_displayname' ) && class_exists( 'BuddyPress' ) ) {
		$name = bp_core_get_user_displayname( $user_id_or_username );
		if ( ! is_numeric( $user_id_or_username ) ) {
			$user    = get_user_by( 'login', $user_id_or_username );
			$user_id = ! empty( $user->ID ) ? $user->ID : null;
		} else {
			$user_id = $user_id_or_username;
		}
	} else {
		if ( ! is_numeric( $user_id_or_username ) ) {
			$user_data = get_user_by( 'login', $user_id_or_username );
			$user_id   = ! empty( $user_data->ID ) ? $user_data->ID : null;
			$name      = get_the_author_meta( 'display_name', $user_id );
		} else {
			$user_id = $user_id_or_username;
			$name    = get_the_author_meta( 'display_name', $user_id );
		}
	}

	/**
	 * Function to filter the display name.
	 *
	 * @since 1.4.1
	 *
	 * @param string $name    Display name for the user.
	 * @param int    $user_id ID of the user to check.
	 *
	 */
	return apply_filters( 'bbaap_get_user_display_name', trim( $name ), $user_id );
}
