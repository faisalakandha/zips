<?php

namespace BuddyBossApp\DBUpdate;

use BuddyBossApp\Admin\Configure;
use BuddyBossApp\Branding;
use BuddyBossApp\Helpers\BBAPP_File;
use BuddyBossApp\ManageApp;
use BuddyBossApp\Styling;

class Main {

	private static $instance;

	/**
	 *
	 */
	public function __construct() {
	}

	/**
	 *
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {


		if ( 4 > get_option( 'bbapp_db_version' ) ) {
			$this->bbapp_update_1_0_4();
		}
		if ( 5 > get_option( 'bbapp_db_version' ) ) {
			$this->bbapp_update_1_0_5();
		}

		if ( 6 > get_option( 'bbapp_db_version' ) ) {
			$this->bbapp_update_1_1_0();
		}

		if ( 7 > get_option( 'bbapp_db_version' ) ) {
			$this->bbapp_update_1_1_3_1();
		}

		if ( 8 > get_option( 'bbapp_db_version' ) ) {
			bbapp()->on_database_update( bbapp()->is_network_activated() );
			$this->bbapp_update_1_3_6();
		}

		if ( 9 > get_option( 'bbapp_db_version' ) ) {
			$this->bbapp_update_1_3_7();
		}

		if ( 10 > get_option( 'bbapp_db_version' ) ) {
			// Update devices table.
			bbapp()->on_database_update( bbapp()->is_network_activated() );
		}

		if ( bbapp()->db_version > get_option( 'bbapp_db_version' ) ) {
			$this->bbapp_update_1_4_2();
		}


		add_action( 'admin_init', array( $this, 'admin_init' ) );
	}

	/**
	 * Remove Configuration setting for Buddyboss app 1.0.4 version.
	 */
	public function bbapp_update_1_0_4() {
		$remove_options_list = array(
			//iOS
			'publish.ios.namespace', //Release App Bundle ID
			'publish.ios.dev.namespace',//Test App Bundle ID
			'publish.ios.signing_certificates_automatic',//Generate Certificates
			'publish.ios.signing_certificate',//Release App Signing Certificate - file
			'publish.ios.signing_certificate_id',//Release App Signing Certificate ID
			'publish.ios.signing_certificate_password',//Release App Signing Certificate Password
			'publish.ios.dev.signing_certificate',//Test App Signing Certificate - file
			'publish.ios.dev.signing_certificate_password',//Test App Signing Certificate Password
			'publish.ios.provisioning_profile_automatic',//Generate Profiles
			'publish.ios.provisioning_profile',//Release App Provisioning Profile - file
			'publish.ios.dev.provisioning_profile',//Test App Provisioning Profile - file
			// Android
			'publish.android.namespace',//Application ID
			'publish.android.namespace.registered',//Register Application ID
			'publish.android.keystore',//KeyStore - file
			'publish.android.keystore_pwd',//KeyStore Password
			'publish.android.keystore_alias',//KeyStore Alias
			'publish.android.keystore_key_pwd',//KeyStore Key Password
		);
		$file_keys = array(
			'publish.ios.signing_certificate',//Release App Signing Certificate - file
			'publish.ios.dev.signing_certificate',//Test App Signing Certificate - file
			'publish.ios.provisioning_profile',//Release App Provisioning Profile - file
			'publish.ios.dev.provisioning_profile',//Test App Provisioning Profile - file
			'publish.android.keystore',//KeyStore - file
		);
		$upload_dir = wp_upload_dir();
		$settings = Configure::instance()->get_settings();
		foreach ( $file_keys as $file_key ) {
			if ( isset( $settings[ $file_key ] ) ) {
				$file = $upload_dir["basedir"] . $settings[ $file_key ];
				if ( file_exists( $file ) ) {
					wp_delete_file( $file );
				}
			}
		}
		foreach ( $remove_options_list as $remove_option ) {
			$settings[ $remove_option ] = '';
		}

		ManageApp::instance()->update_app_settings( $settings );
	}

	/**
	 * Remove Performance table for update primary key of performance table.
	 */
	public function bbapp_update_1_0_5(){
		global $wpdb;

		$table_name      = "{$wpdb->prefix}bb_performance_cache";
		if ( null !== $wpdb->get_var( "SHOW TABLES LIKE '{$table_name}'" ) ) {
			$wpdb->query( "DROP TABLE  {$table_name};" );
		}
	}

	/**
	 * IAP product migration for product type.
	 */
	public function bbapp_update_1_1_0() {
		// IAP terms page make empty for app page to wp pages changes.
		$bbapp_settings = ManageApp::instance()->get_app_settings();
		$settings       = ( isset( $bbapp_settings ) ) ? $bbapp_settings : array();
		if ( isset( $settings["iap.terms"] ) ) {
			$settings["iap.terms"] = 0;
		}
		ManageApp::instance()->update_app_settings( $settings );

		if ( bbapp_is_active( 'iap' ) && function_exists( 'bbapp_iap_get_products' ) ) {
			// IAP product migration.
			$results = bbapp_iap_get_products( array() );
			foreach ( $results as $result ) {
				$storeData = unserialize( $result["store_data"] );
				$is_paid   = false;
				if ( $storeData['store_product_ids']['ios'] ) {
					$is_paid = true;
				}
				if ( $storeData['store_product_ids']['android'] ) {
					$is_paid = true;
				}
				unset( $storeData['bbapp_product_types'] );
				$storeData['bbapp_product_type'] = ( true === $is_paid ) ? 'paid' : 'free';
				$result['store_data']            = serialize( $storeData );
				$id                              = $result["id"];
				bbapp_iap_update_product( $id, $result );
			}
		}
	}

	/**
	 * Auto Connect Apple Account if detail filled.
	 */
	public function bbapp_update_1_1_3_1() {
		\BuddyBossApp\AppStores\Apple::instance()->is_connected( true );
	}

	/**
	 * Branding login setting copy for registration screens.
	 */
	public function bbapp_update_1_3_6() {
		// Settings migration code.
		$clone_fields = array(
			'styles' => array(
				'styles.colors.authBgColor'         => 'styles.colors.regBgColor',
				'styles.colors.authTextColor'       => 'styles.colors.regTextColor',
				'styles.colors.authFieldBgColor'    => 'styles.colors.regFieldBgColor',
				'styles.colors.authFieldTextColor'  => 'styles.colors.regFieldTextColor',
				'styles.colors.authButtonBgColor'   => 'styles.colors.regButtonBgColor',
				'styles.colors.authButtonTextColor' => 'styles.colors.regButtonTextColor',
			),
			'images' => array(
				'login_background_img' => 'register_background_img'
			)
		);
		$styles       = Styling::instance()->get_options();
		if ( isset( $styles['styles'] ) && ! empty( $styles['styles'] ) ) {
			foreach ( $clone_fields['styles'] as $original => $copy ) {
				if ( ! isset( $styles['styles'][ $copy ] ) ) {
					$styles['styles'][ $copy ] = $styles['styles'][ $original ];
				}
			}
			Styling::instance()->set_options( $styles );
		}

		// Files
		$branding         = Branding::instance();
		$branding_options = $branding->get_options();
		$fields           = $branding->get_app_branding_fields();
		$files_dir        = $branding->get_branding_upload_dir();
		if ( isset( $branding_options['uploads_hash'] ) ) {
			foreach ( $clone_fields['images'] as $original => $copy ) {
				if ( isset( $branding_options['uploads_hash'][ $original . '.png' ] ) ) {
					$branding_options['uploads_hash'][ $copy . "." . $fields[ $copy ]["format"] ] = $branding_options['uploads_hash'][ $original . "." . $fields[ $original ]["format"] ];

					$original_filename = $original . "." . $fields[ $original ]["format"];
					$copy_filename     = $copy . "." . $fields[ $copy ]["format"];
					if ( ( file_exists( $files_dir . "/" . $original_filename ) ) ) {
						$original_to_file_path = trailingslashit( $files_dir ) . $original_filename;
						$copy_to_file_path     = trailingslashit( $files_dir ) . $copy_filename;
						BBAPP_File::CopyFile( $original_to_file_path, $copy_to_file_path );
					}
				}
			}
			$branding->set_options( $branding_options );
		}
	}

	/**
	 * Product meta table create.
	 */
	public function bbapp_update_1_3_7(){
		\BuddyBossApp\InAppPurchases\Controller::instance()->on_activation();
	}

	/**
	 * admin_init hook callback.
	 */
	public function admin_init(){
		add_action( 'admin_notices', array( $this, 'admin_notice' ) );
		add_action( 'wp_ajax_bbapp_dismiss_notice', array($this,'bbapp_core_admin_notice_dismiss_callback') );
	}

	/**
	 * Admin notice show.
	 */
	public function admin_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$notice_id = 'configure_data_reset';

		if ( get_option( "bbapp-dismissed-notice-$notice_id" ) ) {
			return;
		}

		$notice = sprintf(
			__( 'You can now build your iOS and Android apps. To ensure your builds are successful, we have reset any existing iOS or Android app configuration settings to ensure the information provided is compatible with our build process. Please configure your apps in the <a href="%1$s">Configure section</a> to start generating builds.', 'buddyboss-app' ),
			admin_url( 'admin.php?page=bbapp-configure' )
		);

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<div class="notice notice-info is-dismissible bbapp-is-dismissible" data-noticeid="' . esc_attr( $notice_id ) . '">' . wpautop( $notice ) . wp_nonce_field( "bbapp-dismissible-notice-$notice_id", "bbapp-dismissible-nonce-$notice_id" ) . '</div>';

	}

	/**
	 * Catch and process an admin notice dismissal.
	 *
	 * @since BuddyBoss App 1.0.4
	 */
	public function bbapp_core_admin_notice_dismiss_callback() {
		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_send_json_error();
		}

		if ( empty( $_POST['nonce'] ) || empty( $_POST['notice_id'] ) ) {
			wp_send_json_error();
		}

		$notice_id = wp_unslash( $_POST['notice_id'] );

		if ( ! wp_verify_nonce( $_POST['nonce'], 'bbapp-dismissible-notice-' . $notice_id ) ) {
			wp_send_json_error();
		}

		update_option( "bbapp-dismissed-notice-$notice_id", 1 );

		wp_send_json_success();
	}

	/**
	 * Update to version 1.4.2
	 *
	 * @since 1.4.2
	 */
	public function bbapp_update_1_4_2() {
		$this->bbapp_update_notifications_devices();
	}

	/**
	 * Update bbapp_notifications_devices table to bbapp_user_devices.
	 *
	 * @since 1.4.2
	 */
	public function bbapp_update_notifications_devices() {
		global $wpdb;

		$old_table_name = bbapp_get_network_table( 'bbapp_notifications_devices' );
		if ( null !== $wpdb->get_var( "SHOW TABLES LIKE '{$old_table_name}'" ) ) {
			$new_table_name = bbapp_get_network_table( 'bbapp_user_devices' );
			$wpdb->query( "ALTER TABLE  {$old_table_name} RENAME TO {$new_table_name};" );
		}
	}

}