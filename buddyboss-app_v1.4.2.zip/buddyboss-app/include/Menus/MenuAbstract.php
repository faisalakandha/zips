<?php

namespace BuddyBossApp\Menus;

/**
 * Class MenuAbstract
 *
 * @package BuddyBossApp\Menus
 * @deprecated We don't recommend to use this class.
 */
class MenuAbstract {

	protected $menu;

	public function __construct() {
		add_filter( 'bbapp_custom_app_screen', array( $this, 'add_custom_screen' ) );
		add_filter( 'bbapp_get_menu_icon', array( $this, 'menu_icon' ), 10, 2 );
		add_action( 'bbapp_menu_metabox_render', array( $this, '_metabox_render' ), 10, 3 );
		add_filter( 'bbapp_get_menu_result', array( $this, '_get_menu_result' ), 10, 3 );
	}

	/**
	 * Add custom menu.
	 *
	 * @param array $custom_app_screens Custom app screens.
	 *
	 * @return mixed
	 */
	public function add_custom_screen( $custom_app_screens ) {
		$custom_app_screens[] = $this->menu;

		return $custom_app_screens;
	}


	/**
	 * Update default menu icon.
	 *
	 * @param array  $iconDefaults Icon data.
	 * @param string $item_name    Item name.
	 *
	 * @return mixed|string[]
	 */
	public function menu_icon( $iconDefaults, $item_name ) {
		if ( $this->menu['object'] == $item_name ) {
			$iconDefaults = $this->menu['icon'];
		}

		return $iconDefaults;
	}

	/**
	 * Prepare menu item.
	 *
	 * @param string $name  Menu name.
	 * @param string $label Menu label.
	 * @param string $icon  Menu icon.
	 */
	public function register_custom_app_screen( $name, $label, $icon ) {

		$default_menu = array(
			'id'   => uniqid(),
			'type' => 'custom_screen',
			'data' => array(),
		);

		$this->menu = wp_parse_args( array(
			'object'   => $name,
			'label'    => $label,
			'original' => $label,
			'icon'     => array(
				'uri'                => $icon,
				'monochrome_setting' => array(),
			),
		), $default_menu );
	}

	/**
	 * Add metabox for menu.
	 *
	 * @param $menu_id
	 * @param $menu
	 */
	public static function metabox( $menu_id, $menu ) {

	}

	/**
	 * Result for menu response.
	 *
	 * @param $menu
	 * @param $request
	 *
	 * @return mixed
	 */
	public static function get_results( $menu, $request ) {
		unset( $menu["settings"] );
		return $menu;
	}

	/**
	 * Metabox callback
	 *
	 * @param $menu_id
	 * @param $menu
	 * @param $menu_name
	 */
	public function _metabox_render( $menu_id, $menu, $menu_name ) {
		if ( $this->menu['type'] === $menu['type'] && $menu_name === $this->menu['object'] ) {
			if ( method_exists( get_parent_class( $this ), 'metabox' ) ) {
				static::metabox( $menu_id, $menu );
			}
		}
	}

	/**
	 * Metabox callback
	 *
	 * @param $menu
	 * @param $request
	 * @param $menu_name
	 */
	public function _get_menu_result( $menu, $request, $menu_name ) {

		if ( ! empty( $menu ) && $menu_name === $this->menu['object'] ) {
			if ( method_exists( get_parent_class( $this ), 'get_results' ) ) {
				return static::get_results( $menu, $request );
			}
		}

		return $menu;
	}
}
