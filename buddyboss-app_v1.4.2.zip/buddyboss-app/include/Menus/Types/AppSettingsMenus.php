<?php

namespace BuddyBossApp\Menus\Types;

use BuddyBossApp\AppSettings;

/**
 * Class App Settings menus.
 *
 * @package BuddyBossApp\Menus\Types
 */
class AppSettingsMenus extends CoreAbstract {

	/**
	 * AppSettingsMenus constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * @return mixed|void
	 */
	public function setup() {
		$this->register_screen_group( 'app_settings', __( 'Settings', 'buddyboss-app' ), array( 'deeplink_base' => 'settings' ) );
		$this->load_menus();
	}

	/**
	 * Load all menus.
	 */
	public function load_menus() {
		$this->register_screen( 'app_settings', __( 'Settings', 'buddyboss-app' ), 'bbapp/settings', array( 'deeplink_slug' => 'settings' ) );
		if ( bbapp_is_active( 'push_notification' ) ) {
			$this->register_screen( 'push_notification_preferences', __( 'Push notifications', 'buddyboss-app' ), 'bbapp/push-notifications', array( 'deeplink_slug' => 'push-notifications' ) );
		}
		if ( defined( 'BP_PLATFORM_VERSION' ) ) {
			$this->register_screen( 'email_preferences', __( 'Email Preferences', 'buddyboss-app' ), 'bbapp/email-preferences', array( 'deeplink_slug' => 'email-preferences' ) );
			$this->register_screen( 'privacy_settings', __( 'Privacy Settings', 'buddyboss-app' ), 'bbapp/privacy-settings', array( 'deeplink_slug' => 'privacy-settings' ) );
			$this->register_screen( 'export_data', __( 'Export Data', 'buddyboss-app' ), 'bbapp/export-data', array( 'deeplink_slug' => 'export-data' ) );
		}
		$this->register_screen( 'app_about', __( 'About', 'buddyboss-app' ), 'bbapp/about', array( 'deeplink_slug' => 'about' ) );
		if ( AppSettings::instance()->get_setting_value( 'support_email.enabled' ) ) {
			$this->register_screen( 'app_feedback', __( 'Feedback', 'buddyboss-app' ), 'bbapp/feedback', array( 'deeplink_slug' => 'feedback' ) );
		}
	}

}