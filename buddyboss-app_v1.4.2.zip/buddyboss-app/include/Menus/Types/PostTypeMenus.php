<?php

namespace BuddyBossApp\Menus\Types;

/**
 * Class Post Type Menus
 *
 * @package BuddyBossApp\Menus\Types
 */
class PostTypeMenus extends CoreAbstract {


	/**
	 * PostTypeMenus constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * @return mixed|void
	 */
	public function setup() {

		// Custom cpt menu metabox
		$_wp_post_types = get_post_types( array(), 'object' );
		if ( $_wp_post_types ) {
			$allowed_post_type = array( "page" );
			$allowed_post_type = apply_filters( "bbapp_app_menus_allowed_post_types", $allowed_post_type );
			foreach ( $_wp_post_types as $_wp_post_type ) {
				if ( ! in_array( $_wp_post_type->name, $allowed_post_type ) ) {
					continue;
				}
				/**
				 * Filter whether a menu items meta box will be added for the current
				 * object type.
				 **/
				//$_wp_post_type = apply_filters( 'nav_menu_meta_box_object', $_wp_post_type );
				if ( $_wp_post_type ) {
					// Give App Pages a higher priority.
					$post_type_label = ( $_wp_post_type->labels->name === 'Pages' ) ? __( 'WordPress Pages', 'buddyboss-app' ) : $_wp_post_type->labels->name;
					$this->register_screen_group( $_wp_post_type->name, $post_type_label, array(
						'callback' => 'wp_nav_menu_item_post_type_meta_box',
						$_wp_post_type
					) );
				}
			}
		}
	}


}