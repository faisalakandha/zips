<?php

namespace BuddyBossApp\Menus\Types;

/**
 * Class Custom link Menus
 *
 * @package BuddyBossApp\Menus\Types
 */
class CustomLinkMenus extends CoreAbstract {

	/**
	 * Book constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * @return mixed|void
	 */
	public function setup() {

		$this->register_screen_group( 'custom_link', __( 'Custom Links', 'buddyboss-app' ), array( 'callback' => 'wp_nav_menu_item_link_meta_box' ) );
	}
}