<?php

namespace BuddyBossApp\Menus\Types;

use BuddyBossApp\Admin\Settings;
use BuddyBossApp\Menus\IapProducts;

/**
 * Class Core Menus
 *
 * @package BuddyBossApp\Menus\Types
 */
class CoreMenus extends CoreAbstract {

	/**
	 * CoreMenus constructor.
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * @return mixed|void
	 */
	public function setup() {

		$this->register_screen_group( 'core', __( 'Core App', 'buddyboss-app' ), array(
			'deeplink_base' => 'screen',
			'desc'          => __( 'Core App Screens are used for displaying core content that is built into the app.', 'buddyboss-app' )
		) );
		$this->load_menus();
	}

	/**
	 * Load all menus.
	 */
	public function load_menus() {
		$this->register_screen( 'settings', __( 'Settings', 'buddyboss-app' ), 'bbapp/settings' );
		$this->register_screen( 'blog', __( 'Blog', 'buddyboss-app' ), 'bbapp/blog' );
		if ( bbapp_is_active( 'push_notification' ) ) {
			$this->register_screen( 'notifications', __( 'Notifications', 'buddyboss-app' ), 'bbapp/notification' );
		}
		if ( bbapp_is_active( 'iap' ) ) {
			$this->register_screen( 'iap_products', __( 'Products', 'buddyboss-app' ), 'bbapp/products', '',
				array( IapProducts::instance(), 'menu_metabox' ),
				array( IapProducts::instance(), 'menu_result' )
			);
		}

		// Learndash
		if ( defined( 'LEARNDASH_VERSION' ) && version_compare( LEARNDASH_VERSION, '3.1', '>=' ) ) {
			$settings          = Settings::instance()->get_settings( true );
			$courseDownloading = isset( $settings['learndash_course_downloading'] ) ? $settings['learndash_course_downloading'] : 0;
			if ( isset( $courseDownloading ) && $courseDownloading ) {
				$this->register_screen( 'my_library', __( 'My Library', 'buddyboss-app' ), 'bbapp/library' );
			}
			$this->register_screen( 'courses_all', __( 'Courses', 'buddyboss-app' ), 'bbapp/book-open' );
			$this->register_screen( 'course_certificates', __( 'Course Certificates', 'buddyboss-app' ), 'bbapp/certificates' );
			$this->register_screen( 'courses_category', __( 'Course Categories', 'buddyboss-app' ), 'bbapp/category' );
		}

		// BuddyBoss Platform Menus.
		if ( function_exists( 'bp_is_active' ) ) {
			if ( bp_is_active( 'groups' ) ) {
				$this->register_screen( 'groups', __( 'Groups', 'buddyboss-app' ), 'bbapp/groups' );
			}
			if ( bp_is_active( 'members' ) ) {
				$this->register_screen( 'members', __( 'Members', 'buddyboss-app' ), 'bbapp/people' );
			}
			if ( bp_is_active( 'activity' ) ) {
				$this->register_screen( 'activity', __( 'Activity', 'buddyboss-app' ), 'bbapp/activity' );
			}
			if ( bp_is_active( 'messages' ) ) {
				$this->register_screen( 'messages', __( 'Messages', 'buddyboss-app' ), 'bbapp/messages' );
			}
			if ( bp_is_active( 'xprofile' ) ) {
				$this->register_screen( 'profile', __( 'Profile', 'buddyboss-app' ), 'bbapp/people' );
			}

			if ( bp_is_active( 'media' ) ) {
				$this->register_screen( 'photos', __( 'Photos', 'buddyboss-app' ), 'bbapp/photos' );

				if ( bp_is_group_document_support_enabled() || bp_is_profile_document_support_enabled() ) {
					$this->register_screen( 'documents', __( 'Documents', 'buddyboss-app' ), 'bbapp/documents' );
				}
				if ( ( function_exists( 'bp_is_group_video_support_enabled' ) && bp_is_group_video_support_enabled() ) || ( function_exists( 'bp_is_profile_video_support_enabled' ) && bp_is_profile_video_support_enabled() ) ) {
					$this->register_screen( 'videos', __( 'Videos', 'buddyboss-app' ), 'bbapp/videos' );
				}
			}
			if ( function_exists( 'bbpress' ) || ( function_exists( 'bp_is_active' ) && bp_is_active( 'forums' ) ) ) {
				$this->register_screen( 'forums', __( 'Forums', 'buddyboss-app' ), 'bbapp/forums' );
				$this->register_screen( 'topics', __( 'Discussions', 'buddyboss-app' ), 'bbapp/topics' );
			}
		}

		if ( class_exists( 'GamiPress' ) ) {
			$monochrome_setting = array(
				'icon_monochrome_checkbox' => 'yes',
				'monochrome_option'        => 'default',
				'icon_monochrome_color'    => bbapp_get_default_color( 'bottomTabsColor' ),
			);
			$this->register_screen( 'gamipress_achievements', __( "GamiPress Achievements", 'buddyboss-app' ), 'bbapp/achievement', $monochrome_setting );
		}
	}

}