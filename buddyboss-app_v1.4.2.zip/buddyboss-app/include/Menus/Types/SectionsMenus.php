<?php

namespace BuddyBossApp\Menus\Types;

use BuddyBossApp\Menu;

/**
 * Class Sections
 *
 * @package BuddyBossApp\Menus\Types
 */
class SectionsMenus extends CoreAbstract {

	/**
	 * SectionsMenus constructor.
	 */
	public function __construct() {
		parent::__construct();
		add_filter( 'bbapp_register_menu_metaboxes', array( $this, '_hide_on_tabbar' ), 99 );
	}

	/**
	 * @return mixed|void
	 */
	public function setup() {
		$this->register_screen_group( 'section', __( 'Sections', 'buddyboss-app' ),
			array(
				'desc'    => __( 'On the More Screen only, you can visually group menu items together by indenting them within Sections.', 'buddyboss-app' ),
				'is_hide' => true
			)
		);
	}

	/**
	 * Hide section menu from tabbar.
	 */
	public function _hide_on_tabbar( $metaboxes ) {

		if ( 'more' !== Menu::instance()->get_current_menu() ) {
			unset( $metaboxes['section'] );
		}

		return $metaboxes;
	}

}