<?php

namespace BuddyBossApp\Migration;

class Integrations {

	private static $instance;

	/**
	 *
	 */
	public function __construct() {
	}

	/**
	 *
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {
		\BuddyBossApp\Migration\Integrations\BadgeOs\Main::instance();
		\BuddyBossApp\Migration\Integrations\BbPress\Main::instance();
		\BuddyBossApp\Migration\Integrations\BuddyBossMedia\Main::instance();
		\BuddyBossApp\Migration\Integrations\GamiPress\Main::instance();
		\BuddyBossApp\Migration\Integrations\H5P\Main::instance();
		\BuddyBossApp\Migration\Integrations\Vimeo\Main::instance();
	}

}
