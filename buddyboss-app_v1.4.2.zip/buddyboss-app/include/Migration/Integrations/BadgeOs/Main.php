<?php

namespace BuddyBossApp\Migration\Integrations\BadgeOs;

class Main {

	private static $instance;

	/**
	 *
	 */
	public function __construct() {
	}

	/**
	 *
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {
		RestAPI::instance();
	}
}
