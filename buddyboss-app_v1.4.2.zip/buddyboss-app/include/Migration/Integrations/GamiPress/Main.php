<?php

namespace BuddyBossApp\Migration\Integrations\GamiPress;

class Main {

	private static $instance;

	/**
	 * Main constructor.
	 */
	public function __construct() {
	}

	/**
	 * @return mixed
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {
		add_action( 'init', array( $this, 'init' ) );
	}


	public function init() {
		if ( class_exists( 'GamiPress' ) ) {
			RestAPIPoint::instance();
			RestAPIAchievement::instance();
			RestAPIRank::instance();
		}
	}
}
