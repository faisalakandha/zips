<?php
namespace BuddyBossApp\Api\Learner\LearnDash;
use \LD_QuizPro as LD_QuizPro;

// use LD_QuizPro;

// NOTE : Old classname was class.bbapp_learner_learndash_ld_quizpro. By Ketan, Oct-2019
/**
 * Ref_Files: bbapp-learner-learndash/include/class.bbapp_learner_learndash_ld_quizpro.php
 *
 * Remove Exit in completedQuiz method;
 */

class LdQuizpro extends LD_QuizPro {
	/**
	 * LdQuizpro constructor.
	 */
	public function __construct() {}
}