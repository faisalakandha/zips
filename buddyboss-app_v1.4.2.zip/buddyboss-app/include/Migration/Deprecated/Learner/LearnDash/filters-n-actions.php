<?php
if (!defined('ABSPATH')) {
	exit();
}
// Note : All functions using(overriding) filters/actions for learner-learndash component should reside here