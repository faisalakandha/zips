<?php
if (!defined('ABSPATH')) {
	exit();
}

// Note : All functions using(overriding) filters/actions for learner component should reside here
