<?php

namespace BuddyBossApp\Api\Learner;

use BuddyBossApp\Api\Learner\Rest;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

// NOTE : Old classname was class.bbapp_learner_quiz_rest. By Ketan, Oct-2019
// (v1 Standard) Contain functionality for required additional rest api endpoints for learndash.
class QuizRest extends Rest {

	protected static $instance;
	protected $quiz_helper;

	/**
	 * QuizRest constructor.
	 */
	public function __construct() {
		$this->rest_base = 'quiz';
		parent::__construct();
	}

	/**
	 * @return mixed
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function hooks() {
	}

	/**
	 * @return void|WP_Error
	 */
	public function register_routes() {

		$this->quiz_helper = bbapp_learner_learndash()->c->bbapp_learner_learndash_quiz_rest;

		register_rest_route( $this->namespace, '/' . $this->rest_base, array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_items' ),
				'permission_callback' => array( $this, 'get_items_permissions_check' ),
				'args'                => $this->get_collection_params(),
			),
			'schema' => array( $this, 'get_public_item_schema' ),
		) );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/(?P<id>[\d]+)', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_item' ),
				'permission_callback' => array( $this, 'get_item_permissions_check' ),
				'args'                => $this->get_collection_params(),
			),
			'schema' => array( $this, 'get_public_item_schema' ),
		) );

		register_rest_route( $this->namespace, '/' . $this->rest_base . '/user_quizdata', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'get_user_quizdata' ),
				'permission_callback' => array( $this, 'get_items_permissions_check' ),
				'args'                => $this->get_collection_params(),
			),
			'schema' => array( $this, 'get_public_item_schema' ),
		) );
	}

	/**
	 * Get the Post's schema, conforming to JSON Schema.
	 *
	 * @return array
	 */
	public function get_item_schema() {
		$schema                       = array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => $this->rest_base,
			'type'       => 'object',
			/*
				 * Base properties for every Post.
			*/
			'properties' => array(
				'id'             => array(
					'description' => __( 'Unique identifier for the object.', 'buddyboss-app' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit', 'embed' ),
					'readonly'    => true,
				),
				'title'          => array(
					'description' => __( 'The title for the object.', 'buddyboss-app' ),
					'type'        => 'object',
					'context'     => array( 'view', 'edit', 'embed', 'buddyboss-app' ),
					'properties'  => array(
						'raw'      => array(
							'description' => __( 'Title for the object, as it exists in the database.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'edit' ),
						),
						'rendered' => array(
							'description' => __( 'HTML title for the object, transformed for display.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit', 'embed' ),
						),
					),
				),
				'content'        => array(
					'description' => __( 'The content for the object.', 'buddyboss-app' ),
					'type'        => 'object',
					'context'     => array( 'view', 'edit' ),
					'properties'  => array(
						'raw'      => array(
							'description' => __( 'Content for the object, as it exists in the database.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'edit' ),
						),
						'rendered' => array(
							'description' => __( 'HTML content for the object, transformed for display.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit' ),
						),
					),
				),
				'date'           => array(
					'description' => __( "The date the object was published, in the site's timezone.", 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'date_gmt'       => array(
					'description' => __( 'The date the object was published, as GMT.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit' ),
				),
				'modified'       => array(
					'description' => __( "The date the object was last modified, in the site's timezone.", 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
				'modified_gmt'   => array(
					'description' => __( 'The date the object was last modified, as GMT.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit' ),
					'readonly'    => true,
				),
				'link'           => array(
					'description' => __( 'URL to the object.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'uri',
					'context'     => array( 'view', 'edit', 'embed' ),
					'readonly'    => true,
				),
				'password'       => array(
					'description' => __( 'A password to protect access to the post.', 'buddyboss-app' ),
					'type'        => 'string',
					'context'     => array( 'edit' ),
				),
				'slug'           => array(
					'description' => __( 'An alphanumeric identifier for the object unique to its type.', 'buddyboss-app' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit', 'embed' ),
					'arg_options' => array(
						'sanitize_callback' => 'sanitize_title',
					),
				),
				'author'         => array(
					'description' => __( 'The id for the author of the object.', 'buddyboss-app' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'excerpt'        => array(
					'description' => __( 'The excerpt for the object.', 'buddyboss-app' ),
					'type'        => 'object',
					'context'     => array( 'view', 'edit', 'embed' ),
					'properties'  => array(
						'raw'      => array(
							'description' => __( 'Excerpt for the object, as it exists in the database.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'edit' ),
						),
						'rendered' => array(
							'description' => __( 'HTML excerpt for the object, transformed for display.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit', 'embed' ),
						),
					),
				),
				'featured_media' => array(
					'description' => __( 'Feature media object containing thumb and full URL of image.', 'buddyboss-app' ),
					'type'        => 'array',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'menu_order'     => array(
					'description' => __( 'The order of the object in relation to other object of its type.', 'buddyboss-app' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit' ),
				),
			),
		);
		$schema['properties']['mode'] = array(
			'description' => __( 'Mode of the object.', 'buddyboss-app' ),
			'type'        => 'string',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		$schema['properties']['has_course_access']  = array(
			'description' => __( 'Whether or not user have the object access.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['has_content_access'] = array(
			'description' => __( 'Whether or not user have the object content access.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['can_take_again']     = array(
			'description' => __( 'Whether or not user can take the object again.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['course_id']          = array(
			'description' => __( 'Course id.', 'buddyboss-app' ),
			'type'        => 'integer',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['lesson_id']          = array(
			'description' => __( 'lesson id.', 'buddyboss-app' ),
			'type'        => 'integer',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['topic_id']           = array(
			'description' => __( 'topic id.', 'buddyboss-app' ),
			'type'        => 'integer',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['completed']          = array(
			'description' => __( 'The object is completed by current user or not.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit', 'embed' ),
		);
		$schema['properties']['form']               = array(
			'description' => __( 'Pre request form for object.', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view' ),
		);
		$schema['properties']['settings']           = array(
			'description' => __( 'Settings for object.', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view' ),
		);
		$schema['properties']['error_message']      = array(
			'description' => __( 'Error message for this object.', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		return $this->add_additional_fields_schema( $schema );
	}

	/**
	 * Get the query params for collections of attachments.
	 *
	 * @return array
	 */
	public function get_collection_params() {
		$params = parent::get_collection_params();

		$params['after'] = array(
			'description'       => __( 'Limit response to resources published after a given ISO8601 compliant date.', 'buddyboss-app' ),
			'type'              => 'string',
			'format'            => 'date-time',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['author']         = array(
			'description'       => __( 'Limit result set to posts assigned to specific authors.', 'buddyboss-app' ),
			'type'              => 'array',
			'default'           => array(),
			'sanitize_callback' => 'wp_parse_id_list',
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['author_exclude'] = array(
			'description'       => __( 'Ensure result set excludes posts assigned to specific authors.', 'buddyboss-app' ),
			'type'              => 'array',
			'default'           => array(),
			'sanitize_callback' => 'wp_parse_id_list',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['before']  = array(
			'description'       => __( 'Limit response to resources published before a given ISO8601 compliant date.', 'buddyboss-app' ),
			'type'              => 'string',
			'format'            => 'date-time',
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['exclude'] = array(
			'description'       => __( 'Ensure result set excludes specific ids.', 'buddyboss-app' ),
			'type'              => 'array',
			'default'           => array(),
			'sanitize_callback' => 'wp_parse_id_list',
		);
		$params['include'] = array(
			'description'       => __( 'Limit result set to specific ids.', 'buddyboss-app' ),
			'type'              => 'array',
			'default'           => array(),
			'sanitize_callback' => 'wp_parse_id_list',
		);

		$params['menu_order'] = array(
			'description'       => __( 'Limit result set to resources with a specific menu_order value.', 'buddyboss-app' ),
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['offset']            = array(
			'description'       => __( 'Offset the result set by a specific number of items.', 'buddyboss-app' ),
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['order']             = array(
			'description'       => __( 'Order sort attribute ascending or descending.', 'buddyboss-app' ),
			'type'              => 'string',
			'default'           => 'desc',
			'enum'              => array( 'asc', 'desc' ),
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['orderby']           = array(
			'description'       => __( 'Sort collection by object attribute.', 'buddyboss-app' ),
			'type'              => 'string',
			'default'           => 'date',
			'enum'              => array(
				'date',
				'id',
				'include',
				'title',
				'slug',
				'relevance',
			),
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['orderby']['enum'][] = 'menu_order';

		$params['parent']         = array(
			'description'       => __( 'Limit result set to those of particular parent ids.', 'buddyboss-app' ),
			'type'              => 'array',
			'sanitize_callback' => 'wp_parse_id_list',
			'default'           => array(),
		);
		$params['parent_exclude'] = array(
			'description'       => __( 'Limit result set to all items except those of a particular parent id.', 'buddyboss-app' ),
			'type'              => 'array',
			'sanitize_callback' => 'wp_parse_id_list',
			'default'           => array(),
		);

		$params['slug']   = array(
			'description'       => __( 'Limit result set to posts with a specific slug.' ),
			'type'              => 'string',
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['filter'] = array(
			'description' => __( 'Use WP Query arguments to modify the response; private query vars require appropriate authorization.' ),
		);

		return $params;
	}

	/**
	 * @param $request
	 *
	 * @return WP_Error
     * @apiPrivate
	 * @api            {GET} /wp-json/appboss/learner/v1/quiz Quizzes
	 * @apiName        GetLearnerAllQuiz
	 * @apiGroup       LearnerQuiz
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiDescription Get all Quiz of learner's component
	 * @apiDeprecated  Retrieve Quizzes. Check (#Quiz:GetLDQuizzes)
	 * @apiUse         apidocForLearnerAllQuizV1
	 */
	public function get_items( $request ) {

		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'rest_not_logged_in', __( 'You are not currently logged in.' ), array( 'status' => 400 ) );
		}

		$request = apply_filters_deprecated( 'bbapp_learner_get_quizes_request', array( $request ), '1.0.0', 'bbapp_ld_get_quizzes_request' );
		$request = apply_filters( 'bbapp_ld_get_quizzes_request', $request );

		// Retrieve the list of registered collection query parameters.
		$registered = $this->get_collection_params();

		$args = array();

		/*
			 * This array defines mappings between public API query parameters whose
			 * values are accepted as-passed, and their internal WP_Query parameter
			 * name equivalents (some are the same). Only values which are also
			 * present in $registered will be set.
		*/
		$parameter_mappings = array(
			'author'         => 'author__in',
			'author_exclude' => 'author__not_in',
			'exclude'        => 'post__not_in',
			'include'        => 'post__in',
			'menu_order'     => 'menu_order',
			'offset'         => 'offset',
			'order'          => 'order',
			'orderby'        => 'orderby',
			'page'           => 'paged',
			'parent'         => 'post_parent__in',
			'parent_exclude' => 'post_parent__not_in',
			'search'         => 's',
			'slug'           => 'post_name__in',
			'status'         => 'post_status',
		);

		/*
			 * For each known parameter which is both registered and present in the request,
			 * set the parameter's value on the query $args.
		*/
		foreach ( $parameter_mappings as $api_param => $wp_param ) {
			if ( isset( $registered[ $api_param ], $request[ $api_param ] ) ) {
				$args[ $wp_param ] = $request[ $api_param ];
			}
		}

		// Check for & assign any parameters which require special handling or setting.
		$args['date_query'] = array();

		// Set before into date query. Date query must be specified as an array of an array.
		if ( isset( $registered['before'], $request['before'] ) ) {
			$args['date_query'][0]['before'] = $request['before'];
		}

		// Set after into date query. Date query must be specified as an array of an array.
		if ( isset( $registered['after'], $request['after'] ) ) {
			$args['date_query'][0]['after'] = $request['after'];
		}

		// Ensure our per_page parameter overrides any provided posts_per_page filter.
		if ( isset( $registered['per_page'] ) ) {
			$args['posts_per_page'] = $request['per_page'];
		}

		if ( isset( $registered['sticky'], $request['sticky'] ) ) {
			$sticky_posts = get_option( 'sticky_posts', array() );
			if ( ! is_array( $sticky_posts ) ) {
				$sticky_posts = array();
			}
			if ( $request['sticky'] ) {
				/*
					 * As post__in will be used to only get sticky posts,
					 * we have to support the case where post__in was already
					 * specified.
				*/
				$args['post__in'] = $args['post__in'] ? array_intersect( $sticky_posts, $args['post__in'] ) : $sticky_posts;

				/*
					 * If we intersected, but there are no post ids in common,
					 * WP_Query won't return "no posts" for post__in = array()
					 * so we have to fake it a bit.
				*/
				if ( ! $args['post__in'] ) {
					$args['post__in'] = array( 0 );
				}
			} elseif ( $sticky_posts ) {
				/*
					 * As post___not_in will be used to only get posts that
					 * are not sticky, we have to support the case where post__not_in
					 * was already specified.
				*/
				$args['post__not_in'] = array_merge( $args['post__not_in'], $sticky_posts );
			}
		}

		$query_args = $this->prepare_items_query( $args, $request );

		$query_result = $this->quiz_helper->get_quizes( array(), $query_args, $request );
		$query_result = apply_filters_deprecated( 'bbapp_learner_get_quizes', array(
			$query_result,
			$query_args,
			$request
		), '1.0.0', 'bbapp_ld_get_quizzes' );
		$query_result = apply_filters( 'bbapp_ld_get_quizzes', $query_result, $query_args, $request );

		$posts = array();
		foreach ( $query_result['posts'] as $post ) {
			if ( ! $this->check_read_permission( $post ) ) {
				continue;
			}

			$data    = $this->prepare_item_for_response( $post, $request );
			$posts[] = $this->prepare_response_for_collection( $data );
		}
		$total_posts = $query_result['total_posts'];

		$max_pages = ceil( $total_posts / (int) $query_args['posts_per_page'] );

		$page = (int) $query_args['paged'];

		if ( $page > $max_pages && $total_posts > 0 ) {
			return new WP_Error( 'rest_post_invalid_page_number', __( 'The page number requested is larger than the number of pages available.' ), array( 'status' => 400 ) );
		}

		$response = rest_ensure_response( $posts );
		$response->header( 'X-WP-Total', (int) $total_posts );
		$response->header( 'X-WP-TotalPages', (int) $max_pages );

		$request_params = $request->get_query_params();
		$base           = add_query_arg( $request_params, rest_url( sprintf( '/%s/%s', $this->namespace, $this->rest_base ) ) );

		if ( $page > 1 ) {
			$prev_page = $page - 1;
			if ( $prev_page > $max_pages ) {
				$prev_page = $max_pages;
			}
			$prev_link = add_query_arg( 'page', $prev_page, $base );
			$response->link_header( 'prev', $prev_link );
		}
		if ( $max_pages > $page ) {
			$next_page = $page + 1;
			$next_link = add_query_arg( 'page', $next_page, $base );
			$response->link_header( 'next', $next_link );
		}

		return $response;
	}

	/**
	 * @param $request
	 *
	 * @return WP_Error
     * @apiPrivate
	 * @api            {GET} /wp-json/appboss/learner/v1/quiz/:id Quiz
	 * @apiName        GetLearnerQuiz
	 * @apiGroup       LearnerQuiz
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiDescription Get single Quiz of learner's component
	 * @apiHeader {String} accessToken Auth token
	 * @apiParam {Number} id Quiz ID (Valid post id)
	 * @apiDeprecated  Retrieve single Quiz. Check (#Quiz:GetLDQuiz)
	 */
	public function get_item( $request ) {
		$id = (int) $request['id'];

		$post = $this->quiz_helper->get_quiz( array(), $id );
		$post = apply_filters_deprecated( 'bbapp_learner_get_quiz', array(
			$post,
			$id
		), '1.0.0', 'bbapp_ld_get_quiz' );
		$post = apply_filters( "bbapp_ld_get_quiz", $post, $id );

		if ( empty( $id ) || empty( $post->ID ) ) {
			return new WP_Error( 'rest_post_invalid_id', __( 'Invalid post ID.' ), array( 'status' => 404 ) );
		}

		$data     = $this->prepare_item_for_response( $post, $request );
		$response = rest_ensure_response( $data );

		return $response;
	}

	/**
	 * @param $request
	 *
	 * @return WP_Error
     * @apiPrivate
	 * @api            {GET} /wp-json/appboss/learner/v1/quiz/user_quizdata User quizdata
	 * @apiName        GetUserQuizData
	 * @apiGroup       LearnerQuiz
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiDescription Get user's quiz-data
	 * @apiHeader {String} accessToken Auth token
	 * @apiParam {Number} page
	 * @apiParam {Number} per_page
	 * @apiDeprecated  Get Quiz user data. Check (#Quiz:GetLDQuizUserData)
	 */
	public function get_user_quizdata( $request ) {

		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'rest_not_logged_in', __( 'You are not currently logged in.' ), array( 'status' => 400 ) );
		}

		$query_result = $this->quiz_helper->get_user_quizdata( array(), $request );
		$query_result = apply_filters( 'bbapp_learner_get_user_quizdata', $query_result, $request );

		$total_posts = $query_result['total_posts'];
		$max_pages   = ceil( $total_posts / (int) $request['per_page'] );

		$page = (int) $request['page'];

		if ( $page > $max_pages && $total_posts > 0 ) {
			return new WP_Error( 'rest_post_invalid_page_number', __( 'The page number requested is larger than the number of pages available.' ), array( 'status' => 400 ) );
		}

		$response = rest_ensure_response( $query_result['posts'] );
		$response->header( 'X-WP-Total', (int) $total_posts );
		$response->header( 'X-WP-TotalPages', (int) $max_pages );

		return $response;
	}

	/**
	 * Prepare a single post output for response.
	 *
	 * @param WP_Post         $post    Post object.
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response $data
	 */
	public function prepare_item_for_response( $post, $request ) {
		$GLOBALS['post'] = $post;
		setup_postdata( $post );

		// Base fields for every post.
		$data = array();

		if ( ! $post->has_content_access ) {
			$post->post_content = '';
			$post->post_excerpt = '';
		}

		if ( isset( $post->ID ) ) {
			$data['id'] = $post->ID;
		} else {
			return new WP_Error( 'learndash_json_internal_error', __( 'Required field "ID" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		if ( isset( $post->post_date_gmt ) && isset( $post->post_date ) ) {
			$data['date']     = $this->prepare_date_response( $post->post_date_gmt, $post->post_date );
			$data['date_gmt'] = $this->prepare_date_response( $post->post_date_gmt );
		} else {
			return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Date or GMT Date" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		if ( isset( $post->post_modified_gmt ) && isset( $post->post_modified ) ) {
			$data['modified']     = $this->prepare_date_response( $post->post_modified_gmt, $post->post_modified );
			$data['modified_gmt'] = $this->prepare_date_response( $post->post_modified_gmt );
		} else {
			return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Modified Date or GMT Date" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		if ( isset( $post->post_name ) ) {
			$data['slug'] = $post->post_name;
		} else {
			return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Slug" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
		}

		$data['link'] = $post->link;

		$schema = $this->get_item_schema();

		if ( ! empty( $schema['properties']['title'] ) ) {
			if ( isset( $post->post_title ) ) {
				$data['title'] = array(
					'raw'      => $post->post_title,
					'rendered' => get_the_title( $post->ID ),
				);
			} else {
				return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Title" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
			}
		}

		if ( ! empty( $schema['properties']['content'] ) ) {

			if ( isset( $post->post_content ) ) {
				$data['content'] = array(
					'raw'      => bbapp_learners_fix_relative_urls_protocol( $post->post_content ),
					/** This filter is documented in wp-includes/post-template.php */
					'rendered' => bbapp_learners_fix_relative_urls_protocol( apply_filters( 'the_content', $post->post_content ) ),
				);
			} else {
				return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Content" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
			}

		}

		if ( ! empty( $schema['properties']['excerpt'] ) ) {
			$data['excerpt'] = array(
				'raw'      => $post->post_excerpt,
				'rendered' => $this->prepare_excerpt_response( $post->post_excerpt ),
			);
		}

		if ( ! empty( $schema['properties']['author'] ) ) {
			if ( isset( $post->post_author ) ) {
				$data['author'] = (int) $post->post_author;
			} else {
				return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Author" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
			}
		}

		/**
		 * Feature Media
		 */
		$data['featured_media']          = array();
		$data['featured_media']["small"] = ( is_array( $post->featured_media ) && isset( $post->featured_media["small"] ) ) ? $post->featured_media["small"] : null;
		$data['featured_media']["large"] = ( is_array( $post->featured_media ) && isset( $post->featured_media["large"] ) ) ? $post->featured_media["large"] : null;

		$data['parent']     = (int) $post->post_parent;
		$data['menu_order'] = (int) $post->menu_order;
		$data['mode']       = $post->mode;

		if ( ! empty( $schema['properties']['has_course_access'] ) ) {
			if ( isset( $post->has_course_access ) ) {
				$data['has_course_access'] = (boolean) $post->has_course_access;
			} else {
				return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Has course access" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
			}
		}

		if ( ! empty( $schema['properties']['has_content_access'] ) ) {
			if ( isset( $post->has_content_access ) ) {
				$data['has_content_access'] = (boolean) $post->has_content_access;
			} else {
				return new WP_Error( 'learndash_json_internal_error', __( 'Required field "Has content access" missing by add-on plugin', 'buddyboss-app' ), array( 'status' => 400 ) );
			}
		}

		if ( ! empty( $schema['properties']['can_take_again'] ) ) {
			$data['can_take_again'] = (boolean) $post->can_take_again;
		}

		if ( ! empty( $schema['properties']['completed'] ) ) {
			$data['completed'] = (boolean) $post->completed;
		}

		if ( ! empty( $schema['properties']['course_id'] ) ) {
			$data['course_id'] = (int) $post->course_id;
		}

		if ( ! empty( $schema['properties']['lesson_id'] ) ) {
			$data['lesson_id'] = (int) $post->lesson_id;
		}

		if ( ! empty( $schema['properties']['topic_id'] ) ) {
			$data['topic_id'] = (int) $post->topic_id;
		}

		if ( ! empty( $schema['properties']['form'] ) ) {
			if ( ! empty( $post->form ) ) {
				$data['form'] = $post->form;
			}
		}

		if ( ! empty( $schema['properties']['settings'] ) ) {
			$data['settings'] = $post->settings;
		}

		if ( ! empty( $schema['properties']['error_message'] ) ) {
			if ( ! empty( $post->error_message ) ) {
				$data['error_message'] = $post->error_message;
			} else {
				$data['error_message'] = array();
			}
		}

		$context = ! empty( $request['context'] ) ? $request['context'] : 'view';
		$data    = $this->add_additional_fields_to_object( $data, $request );
		$data    = $this->filter_response_by_context( $data, $context );

		// Wrap the data in a response object.
		$response = rest_ensure_response( $data );

		$response->add_links( $this->prepare_links( $data ) );

		/**
		 * Filter the post data for a response.
		 *
		 * The dynamic portion of the hook name, $this->post_type, refers to post_type of the post being
		 * prepared for the response.
		 *
		 * @param WP_REST_Response $response The response object.
		 * @param WP_Post          $post     Post object.
		 * @param WP_REST_Request  $request  Request object.
		 */
		$response = apply_filters_deprecated( 'rest_prepare_quiz', array(
			$response,
			$post,
			$request
		), '1.0.0', 'bbapp_ld_rest_prepare_quiz' );

		return apply_filters( "bbapp_ld_rest_prepare_quiz", $response, $post, $request );
	}

}