<?php
if (!defined('ABSPATH')) {
	exit();
}

function boss_bbpress_api_domain($slag) {
	return $slag . '_bbpress_api';
}