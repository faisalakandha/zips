<?php
namespace BuddyBossApp\Api\BuddyPress;
// NOTE : The soul purpose of this class is apidoc(documentation generator). By Ketan
class ApidocV1 {

	private function apidocForGetBuddyPressXprofileV1() {
		/**
		 * @apiDefine apidocForGetBuddyPressXprofileV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id xProfile Id
		 */
	}

	private function apidocForUpdateBuddyPressXprofileV1() {
		/**
		 * @apiDefine apidocForUpdateBuddyPressXprofileV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} user_id
		 * @apiParam {Number} displayed_user_id
		 */
	}

	private function apidocForGetBuddypressMembersItemV1() {
		/**
		 * @apiDefine apidocForGetBuddypressMembersItemV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Unique identifier
		 */
	}

	private function apidocForGetMembersPageDetailsV1() {
		/**
		 * @apiDefine apidocForGetMembersPageDetailsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=active,newest,alphabetical} [type="active"] Filter by.. active(Last Active), newest(Newest Registered), alphabetical(Alphabetical)
		 */
	}

	private function apidocForGetBpGroupsPageDetailsV1() {
		/**
		 * @apiDefine apidocForGetBpGroupsPageDetailsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=active,popular,newest,alphabetical} [type="active"] Filter by.. active(Last Active), popular(Most Members), newest(Newly Created), alphabetical(Alphabetical)
		 */
	}

	private function apidocForGetBpGroupsSettingsV1() {
		/**
		 * @apiDefine apidocForGetBpGroupsSettingsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Group Id
		 * @apiParam {String} name Name of group.
		 * @apiParam {String} description Description of group.
		 * @apiParam {String} notify Whether members notify for changes or not.
		 */
	}

	private function apidocForGetBpGroupsManageDetailsV1() {
		/**
		 * @apiDefine apidocForGetBpGroupsManageDetailsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Group Id
		 */
	}

	private function apidocForGetBpGroupsForumSettingsV1() {
		/**
		 * @apiDefine apidocForGetBpGroupsForumSettingsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Group Id
		 */
	}

	private function apidocForGetBpCoreSettingsV1() {
		/**
		 * @apiDefine apidocForGetBpCoreSettingsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 */
	}

	private function apidocForGetBpCoreItemV1() {
		/**
		 * @apiDefine apidocForGetBpCoreItemV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 */
	}

	private function apidocForListActivityCommentsV1() {
		/**
		 * @apiDefine apidocForListActivityCommentsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Activity ID
		 */
	}

	private function apidocForGetBpActivityV1() {
		/**
		 * @apiDefine apidocForGetBpActivityV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {Number} id
		 * @apiParam {Number} [object] Filters by the `component` column in the database.
		 * @apiParam {Number} [primary_id] Filters by the `item_id` column in the database.
		 */
	}

	private function apidocForGetBpPageDetailsV1() {
		/**
		 * @apiDefine apidocForGetBpPageDetailsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 */
	}

	private function apidocForGetBpActivitiesV1() {
		/**
		 * @apiDefine apidocForGetBpActivitiesV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {Number} [per_page=20]
		 * @apiParam {Number} max Maximum number of results to return.
		 * @apiParam {String} fields Activity fields to retrieve.
		 * @apiParam {String=asc,desc} [sort=desc] Order sort attribute ascending or descending.
		 * @apiParam {Array} include Array of exact activity IDs to query.
		 * @apiParam {Array} exclude Array of activity IDs to exclude.
		 * @apiParam {Array} meta_query Limit by activity meta by passing an array of meta_query.
		 * @apiParam {Array} date_query Limit by date by passing an array of date_query condition.
		 * @apiParam {String} search_terms Limit results by a search term.
		 * @apiParam {String} scope Use a BuddyPress pre-built filter.
		 * @apiParam {String} [user_id=0] The ID(s) of user(s) whose activity should be fetched.
		 * @apiParam {String} object Filters by the `component` column in the database.
		 * @apiParam {String} action Filters by the `type` column in the database.
		 * @apiParam {Number} primary_id Filters by the `item_id` column in the database.
		 * @apiParam {Number} secondary_id Filters by the `secondary_item_id` column in the database.
		 * @apiParam {Number} offset Return only activity items with an ID greater than or equal to this one.
		 * @apiParam {String=threaded,stream,false} display_comments How to handle activity comments.
		 * @apiParam {String=ham_only,spam_only,false} spam Spam status for activity.
		 */
	}

	private function apidocGetVisibilityLevelV1() {
		/**
		 * @apiDefine apidocGetVisibilityLevelV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 */
	}

	private function apidocForUpdateBuddyPressAccountV1() {
		/**
		 * @apiDefine apidocForUpdateBuddyPressAccountV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} displayed_user_id Displayed user id.
		 * @apiParam {String} email User email id.
		 * @apiParam {String} pwd User current password.
		 * @apiParam {String} pass1 New password.
		 * @apiParam {String} pass2 Confirm password.
		 */
	}

	private function apidocForGetNotificationSettingsV1() {
		/**
		 * @apiDefine apidocForGetNotificationSettingsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} displayed_user_id Displayed user id.
		 */
	}

	private function apidocForUpdateNotificationSettingsV1() {
		/**
		 * @apiDefine apidocForUpdateNotificationSettingsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} displayed_user_id ID of the user whose settings are being updated.
		 * @apiParam {Object} notifications Notification settings.
		 * @apiParam {Array} settings Settings array.
		 */
	}

	private function apidocForGeneralSettingsFieldsV1() {
		/**
		 * @apiDefine apidocForGeneralSettingsFieldsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} displayed_user_id Displayed user id.
		 */
	}

	private function apidocForGetAttachmentAvatarV1() {
		/**
		 * @apiDefine apidocForGetAttachmentAvatarV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} [item_id="current user id if logged-in"] User Id.
		 * @apiSuccessExample {String} Success-Response:
		 *	"//www.gravatar.com/avatar/bd7df5b67c5ba7d084df64f2c002ef3b?s=50&#038;r=g&#038;d=mm"
		 */
	}

	private function apidocForCreateGroupInvitesV1() {
		/**
		 * @apiDefine apidocForCreateGroupInvitesV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Group Id
		 * @apiParam {String[]} users User ids for invite
		 */
	}

	private function apidocForUpdateFriendActionV1() {
		/**
		 * @apiDefine apidocForUpdateFriendActionV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id Member(User) Id
		 * @apiParam {String=add_friend,remove_friend,withdraw_friendship,accept_friend,reject_friend} [action=add_friend] Action to perform
		 */
	}

	private function apidocForAllFriendsV1() {
		/**
		 * @apiDefine apidocForAllFriendsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {Number} [per_page=0] Maximum number of items to be returned in result set.
		 * @apiParam {String=recently_active,newest,alphabetical} [sort=recently_active] Sorting option.
		 * @apiParam {String} [user_id=get_current_user_id()] ID of the user whose friends are being retrieved
		 * @apiParam {String} [filter=""] Limit results to those matching a search string.
		 */
	}

	private function apidocForCreateGroupV1() {
		/**
		 * @apiDefine apidocForCreateGroupV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} [group_id=false,0] Group id
		 * @apiParam {String} [step=group-details] Name of group step.
		 * @apiParam {String} group-name Name of group.
		 * @apiParam {String} group-desc Description of group.
		 * @apiParam {String} group-status Group id
		 * @apiParam {String} group-types Types of group.
		 * @apiParam {String=true,false,''} hasforum Whether the Group has a forum or not.
		 * @apiParam {String} group-invite-status Invite status of group.
		 * @apiParam {Array[][]} friends User ids of group invitees.
		 */

	}

	private function apidocForGetBuddypressGroupsV1() {
		/**
		 * @apiDefine apidocForGetBuddypressGroupsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=personal,all} scope Scope of group.
		 * @apiParam {String} type Object sorting type.
		 * @apiParam {Number} user_id User ID
		 * @apiParam {String=asc,desc} [order=desc] Order sort attribute ascending or descending.(Backend WP_Query: order)
		 * @apiParam {String} [orderby] Sort collection by object attribute.Sort collection by object attribute.(Backend WP_Query: orderby)
		 * @apiParam {Number} [page] Particular page for query var
		 * @apiParam {Number} [per_page] Maximum number of items to be returned in result set.
		 * @apiParam {String} user_id Limit results to specific user.
		 * @apiParam {Array} [include=array()] Limit result set to specific ids.(Backend WP_Query: post__in)
		 * @apiParam {Array} [exclude=array()] Ensure result set excludes specific ids.(Backend WP_Query: post__not_in)
		 * @apiParam {String} only_forum Limit results of object which has forum.
		 * @apiParam {String} extras Shows Extras Values Depending Available (admins,mods)
		 * @apiParam {String} search Limit results to those matching a string.
		 */
	}

	private function apidocForGetGroupsMembersV1() {
		/**
		 * @apiDefine apidocForGetGroupsMembersV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Number} id
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {Boolean} [exclude_admins=false] Exclude admin user from results.
		 * @apiParam {Boolean} [exclude_banned=false] Exclude banned user from results.
		 * @apiParam {Number{1-100}} [per_page=20] Maximum number of items to be returned in result set.
		 * @apiParam {Number{1-∞}} [page=1] Current page of the collection.
		 * @apiParam {String} [search_terms=false] Limit results to those matching a string.
		 * @apiParam {String} [group_role=array()] Limit results to specific group role.
		 * @apiParam {String} [type=last_joined] Sort the order of results.
		 */

	}

	private function apidocForGetGroupsMemberRequestsV1() {
		/**
		 * @apiDefine apidocForGetGroupsMemberRequestsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {Number{1-∞}} [page=1] Current page of the collection.
		 * @apiParam {Number} [per_page=20] Maximum number of items to be returned in result set.
		 */

	}

	private function apidocForGetBuddpressMembersItemsV1() {
		/**
		 * @apiDefine apidocForGetBuddpressMembersItemsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {String=requests,friends,all} [scope=all] Scope of member.
		 * @apiParam {String=active,newest,alphabetical,random,popular} type Sort order.
		 * @apiParam {Number} [user_id=0] Limit results to friends of a user.
		 * @apiParam {String} [type=''] Limit results to friends of a user.
		 * @apiParam {Array[][]} [exclude=array()] IDs to exclude from results.
		 * @apiParam {Array[][]} [include=array()] Limit results by user IDs.
		 * @apiParam {String} [search_terms=""] Limit to users matching search terms.
		 * @apiParam {String} [meta_key=false] Limit to users with a meta_key.
		 * @apiParam {String} [meta_value=false] Limit to users with a meta_value.
		 * @apiParam {String} member_type Limit results by member types.
		 * @apiParam {String} member_type__in Limit results by member types.
		 * @apiParam {String} member_type__not_in Member types to be excluded from result.
		 * @apiParam {Number} [per_page=20] Items per page
		 * @apiParam {Number} [page] Current page of the collection.
		 * @apiParam {String} populate_extras Fetch optional extras.
		 * @apiParam {Number} count_total How to do total user count.
		 */

	}

	private function apidocForCreateBuddypressMessageV1() {
		/**
		 * @apiDefine apidocForCreateBuddypressMessageV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {Array[][]} [recipients=array()] Message recipients user ids
		 * @apiParam {Number} [thread_id=0] Message thread id for reply
		 * @apiParam {Number} [sender_id=0] Message sender user id
		 * @apiParam {String} [subject=""] Message Subject text for new message
		 * @apiParam {String} [content=""] Message Content
		 * @apiParam {String} [date_sent=""] Message Send date
		 */
	}

	private function apidocForGetBuddyPressNotificationsV1() {
		/**
		 * @apiDefine apidocForGetBuddyPressNotificationsV1
		 *
		 * @apiHeader {String} accessToken Auth token
		 * @apiParam {String=view,edit,embed} [context=view]
		 * @apiParam {String=both,true,false} [is_new=both] Notification field for new
		 * @apiParam {Number} [per_page] Maximum number of items to be returned in result set.
		 * @apiParam {Number} [page] Current page of the collection.
		 * @apiParam {String=desc,asc} [sort_order=desc] Order sort attribute ascending or descending.(Backend WP_Query: order)
		 * @apiParam {String} type
		 */
	}
}
