<?php

namespace BuddyBossApp\Migration\LearnDash\V1\Quiz;

use \LD_QuizPro as LD_QuizPro;

/**
 * Ref_Files: sfwd-lms/includes/quiz/ld-quiz-pro.php
 */
class LdQuizpro extends LD_QuizPro {
	/**
	 * LdQuizpro constructor.
	 */
	public function __construct() {
	}
}