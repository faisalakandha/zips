<?php

namespace BuddyBossApp\Migration\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}


final class Controller {

	private static $instance = null;

	/**
	 * Controller constructor.
	 */
	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @return Controller|null
	 */
	public static function instance() {
		if ( null === self::$instance ) {

			$class_name     = __CLASS__;
			self::$instance = new $class_name();
			self::$instance->_load_classes();

		}

		return self::$instance;
	}

	/**
	 * Initiate the required classes.
	 */
	protected function _load_classes() {
		Orders::instance();
		Products::instance();
	}
}
