<?php
/**
 * Note: This is temp migration file. on the final merge of this repo on master this should be moved into dadicated migration plugin.
 */

namespace BuddyBossApp\Migration;

use BuddyBossApp\Helpers\BBAPP_File;
use BuddyBossApp\Helpers\File;
use BuddyBossApp\ManageApp;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Branding' ) ) {
	class Branding {

		private static $instance;

		/**
		 * Get the instance of the class.
		 *
		 * @return Branding
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) ) {
				$class          = __CLASS__;
				self::$instance = new $class;
				self::$instance->_load();
			}

			return self::$instance;
		}

		/**
		 * Migrate constructor.
		 */
		public function __construct() {
		}

		/**
		 * Migrate load method.
		 */
		public function _load() {
			// this hook should load first.
			$this->rename_upload_folder();
			add_action( 'plugins_loaded', array( $this, 'migrate_load' ), 1 );
		}

		/**
		 * Migrate the options name.
		 */
		public function migrate_load() {
		}

		/**
		 * Migrate old branding icons to new folder location.
		 */
		public function rename_upload_folder() {
			if ( bbapp_get_network_option( "bbapp_migrate_branding_path" ) != "1" ) {
				$upload_dir = wp_upload_dir();
				$apps_data  = ManageApp::instance()->get_apps_data();
				if ( isset( $apps_data['app_id'] ) && ! empty( $apps_data['app_id'] ) ) {
					$dir_old = $upload_dir["basedir"] . "/ab-branding/" . $apps_data['app_id'] . "/" . get_current_blog_id();
					$dir_new = $upload_dir["basedir"] . "/bbapp/branding" . "/" . get_current_blog_id();
					if ( file_exists( $dir_old ) ) {
						BBAPP_File::CreateDir($dir_new);
						BBAPP_File::CopyDir( $dir_old, $dir_new );
					}

					bbapp_set_network_option( "bbapp_migrate_branding_path", "1" );
				}
			}
		}
	}
}