<?php

namespace ReceiptValidator;

class RunTimeException extends \Exception
{
}
