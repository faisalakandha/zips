<?php

use MingYuanYun\AppStore\Client;

class IConnectApps extends \MingYuanYun\AppStore\Api\AbstractApi {

	public function __construct( Client $client ) {
		parent::__construct( $client );
	}

	/**
	 * Query Testers
	 *
	 * @param array $params
	 *
	 * @return mixed
	 */
	public function query( array $params = [] ) {
		$query = $this->get( "/apps", $params );

		return $query;
	}

	/**
	 * Query Testers
	 *
	 * @param int   $app_id
	 * @param array $params
	 *
	 * @return mixed
	 */
	public function get_app( $app_id, array $params = [] ) {
		$query = $this->get( '/apps/' . $app_id, $params );

		return $query;
	}

	/**
	 * Query Testers
	 *
	 * @param string $url
	 * @param array  $params
	 *
	 * @return mixed
	 */
	public function get_request( $url, array $params = [] ) {
		$query = $this->get( $url, $params );

		return $query;
	}
}