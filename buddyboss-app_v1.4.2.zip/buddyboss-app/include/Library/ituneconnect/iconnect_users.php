<?php

use MingYuanYun\AppStore\Client;

class IConnectUsers extends \MingYuanYun\AppStore\Api\AbstractApi {
	public function query( array $params = [] ) {
		return $this->get( '/users', $params );
	}

	public function create( $fname, $lname, $email ) {
		$data = [
			'data' => [
				'type'          => 'userInvitations',
				'attributes' => [
					'allAppsVisible' => true,
					'email'          => $email,
					'firstName'      => $fname,
					'lastName'       => $lname,
					'roles'          => [ 'APP_MANAGER' ],
				]
			]
		];

		return $this->postJson( '/userInvitations', $data );
	}

}