<?php

use MingYuanYun\AppStore\Client;

class IConnectBuilds extends \MingYuanYun\AppStore\Api\AbstractApi {

	public function __construct( Client $client ) {
		parent::__construct( $client );
	}

	/**
	 * Query Builds
	 *
	 * @param array $params
	 *
	 * @return mixed
	 */
	public function get_builds( $app_id, array $params = [] ) {
		$query = $this->get( "/apps/{$app_id}/builds", $params );

		return $query;
	}

}