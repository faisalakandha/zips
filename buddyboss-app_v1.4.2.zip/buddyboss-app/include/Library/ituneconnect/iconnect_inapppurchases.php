<?php

use MingYuanYun\AppStore\Client;

class IConnectInAppPurchases extends \MingYuanYun\AppStore\Api\AbstractApi {

	protected $app_id;

	public function __construct( string $app_id, Client $client ) {
		$this->app_id = $app_id;
		parent::__construct( $client );
	}

	/**
	 * Query Testers
	 *
	 * @param array $params
	 *
	 * @return mixed
	 */
	public function query( array $params = [] ) {
		$query = $this->get( "/apps/{$this->app_id}/inAppPurchases", $params );

		return $query;
	}
}