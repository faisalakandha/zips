<?php


namespace BuddyBossApp;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


class Menu {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return Menu
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * AppMenu constructor.
	 */
	public function __construct() {
	}

	/**
	 * load all hooks and action.
	 */
	public function _load() {
	}

	/**
	 * Get current menu.
	 *
	 * @return mixed|string
	 */
	public function get_current_menu() {
		return isset( $_REQUEST['menu'] ) ? $_REQUEST['menu'] : 'tabbar';
	}


	/**
	 * Returns the app menu data.
	 *
	 * @param string $app_menu_type
	 *
	 * @return array|bool
	 */
	public function get_menu( $app_menu_type = 'tabbar' ) {

		$app_menu = array();

		$app_settings = get_option('bbapp_menus');

		if ( ! empty( $app_settings[ $app_menu_type ] ) ) {
			$app_menu = $app_settings[ $app_menu_type ];
		}
		$app_menu = apply_filters( "bbapp_app_menu_filter", $app_menu, $app_menu_type );

		$is_more_menu = end( $app_menu );

		if ( is_array( $is_more_menu ) && 'more' !== $is_more_menu['object'] ) {
			if ( 'tabbar' === $app_menu_type && $this->more_menu_bar_exists() ) {
				$app_menu = $this->get_default_appmenu( $app_menu, 'more' );
			}
		}

		// Remove the more menu icon if the more menu empty.
		if ( is_array( $is_more_menu ) && false === $this->more_menu_bar_exists() ) {
			if ( 'more' === $is_more_menu['object'] ) {
				array_pop( $app_menu );
			}
		}

		return $app_menu;
	}

	/**
	 * More menu available or not.
	 *
	 * @param $app_id
	 *
	 * @return bool
	 */
	public function more_menu_bar_exists() {
		$app_settings = get_option('bbapp_menus');

		return (bool) ! empty( $app_settings['more'] );
	}

	/**
	 * Setting menu exists or not.
	 *
	 * @return bool
	 */
	public function setting_menu_exists() {
		$app_settings           = get_option('bbapp_menus');
		$is_setting_menu_exists = false;
		if ( ! empty( $app_settings ) ) {
			foreach ( $app_settings as $menu_bar_type => $menu_items ) {
				foreach ( $menu_items as $menu_index => $menu_item ) {
					if ( 'settings' === $menu_item['object'] ) {
						$is_setting_menu_exists = true;
					}
					if ( ! empty( $menu_item['section'] ) && is_array( $menu_item['section'] ) ) {
						foreach ( $menu_item['section'] as $m_item ) {
							if ( 'settings' === $m_item['object'] ) {
								$is_setting_menu_exists = true;
							}
						}
					}
				}
			}
		}

		return (bool) $is_setting_menu_exists;
	}

	/**
	 * Returns the default menu data of specific app.
	 *
	 * @param        $app_menu
	 * @param string $app_menu_type
	 * @param null   $app_id
	 *
	 * @return mixed
	 */
	public function get_default_appmenu( $app_menu, $app_menu_type = 'tabbar', $app_id = null ) {

		if ( 'tabbar' != $app_menu_type ) {
			// get old more menu icon setting.
			$icon_settings = \BuddyBossApp\AppSettings::instance()->get_setting_value( "app_menu.tabbar_more_menu_icon" );
			if ( empty( $icon_settings ) ) {
				$icon_settings = array(
					'uri'                => 'bbapp/list',
					'icon_style'         => 'filled',
					'monochrome_setting' => wp_json_encode( array(
						'icon_monochrome_checkbox' => 'yes',
						'monochrome_option'        => 'default',
						'icon_monochrome_color'    => bbapp_get_default_color( 'bottomTabsColor' ),
					) ),
				);
			}
			$app_menu[] = array(
				"id"       => uniqid(),
				"object"   => "more",
				"label"    => __( "More", 'buddyboss-app' ),
				"original" => __( "More", 'buddyboss-app' ),
				"type"     => "core",
				'data'     => array(
					'id'     => 'more',
					'parent' => 0,
				),
				"icon"     => $icon_settings,
			);

		}

		return $app_menu;
	}

	/**
	 * Rest Endpoint Function for Returning App Menu
	 *
	 * @param $request
	 *
	 * @return mixed
	 */
	public function rest_response( $request ) {

		$allow_more = isset( $request['allow_more'] ) && ! empty( $request['allow_more'] ) ? (bool) $request['allow_more'] : false;

		$app_tabbar_menu = $this->get_menu( 'tabbar' );
		$app_more_menu   = $this->get_menu( 'more' );

		if ( ! $app_tabbar_menu && ! $app_more_menu ) {
			$app_menu = array(
				'tabbar' => array(),
				'more'   => array(),
			);
			return rest_ensure_response( $app_menu );
		}

		$app_tabbar_screen = array();
		$app_more_screen   = array();

		if ( isset( $app_tabbar_menu ) ) {
			// Tabbar menu.
			foreach ( $app_tabbar_menu as $k => $tabbar_menu ) {
				if ( false === $allow_more && 'more' === $tabbar_menu['object'] ) {
					continue;
				}
				if ( false === $this->filter_app_menu_by_dependency( $tabbar_menu ) ) {
					continue;
				}
				$app_tabbar_screen[ $k ] = $this->get_user_app_menu_filter_menu_data( $tabbar_menu, $request, $k, 'tabbar' );
			}
		}

		if ( isset( $app_more_menu ) ) {
			// More icon menu.
			foreach ( $app_more_menu as $k => $more_menu ) {
				if ( 'section' === $more_menu['type'] ) {
					unset( $more_menu['original'] );
					$app_more_screen[ $k ] = $more_menu;
					// make sure section is array format.
					if ( ! is_array( $app_more_menu[ $k ]['section'] ) ) {
						$app_more_screen[ $k ]['section'] = array();
					}

					if ( ! empty( $more_menu['section'] ) && is_array( $more_menu['section'] ) ) {
						$app_more_screen_section = array();
						foreach ( $more_menu['section'] as $j => $section_menu ) {
							if ( false === $this->filter_app_menu_by_dependency( $section_menu ) ) {
								continue;
							}
							$app_more_screen_section[ $j ] = $this->get_user_app_menu_filter_menu_data( $section_menu, $j, $request, 'more',  true );
						}
						// NOTE : Need to do this else =>  2: { }
						$app_more_screen[ $k ]['section'] = array_values( $app_more_screen_section );
					}

				} else {
					if ( false === $this->filter_app_menu_by_dependency( $more_menu ) ) {
						continue;
					}
					$app_more_screen[ $k ] = $this->get_user_app_menu_filter_menu_data( $more_menu, $request, $k, 'more' );
				}
			}
		}

		$app_menu = array(
			'tabbar' => array_values( $app_tabbar_screen ),
			'more'   => array_values( $app_more_screen ),
		);

		return rest_ensure_response( $app_menu );
	}

	/**
	 * If platform or buddypress or bbpress component not found then exclude the menu.
	 *
	 * @param $menu
	 *
	 * @return bool
	 *
	 */
	public function filter_app_menu_by_dependency( $menu ) {
		return apply_filters( 'bbapp_filter_app_menu_by_dependency', true, $menu );
	}

	/**
	 * Filter menu data.
	 *
	 * @param       $menu
	 * @param       $request
	 * @param       $index
	 * @param       $menu_screen
	 * @param int   $app_id
	 * @param false $is_section
	 * @param bool  $is_tabbar
	 *
	 * @return mixed
	 */
	public function get_user_app_menu_filter_menu_data( $menu, $request, $index, $menu_screen, $is_section = false ) {
		unset( $menu['original'] );

		/**
		 * get menu result.
		 *
		 */
		$menu = apply_filters( 'bbapp_get_menu_result', $menu, $request, $menu["object"] );

		$menu['data']['open_external'] = ( isset( $menu['data']['open_external'] ) && 'yes' == $menu['data']['open_external'] ) ? true : false;

		$icon_defaults = array( "uri" => 'bbapp/file' );

		/**
		 * Transform URL of Icon & default data.
		 */
		if ( isset( $menu['object'] ) && ! isset( $menu['icon'] ) ) {
			$icon_defaults = bbapp_get_menu_icon( $menu['object'], $menu['type'] );
		}

		if ( ! isset( $menu["icon"] ) ) {
			$menu['icon'] = array();
		}

		$menu["icon"] = array_merge( $icon_defaults, $menu["icon"] );

		// Monochrome Color.
		$monochrome_setting = isset( $menu["icon"]['monochrome_setting'] ) ? $menu["icon"]['monochrome_setting'] : "";
		$monochrome_setting = str_replace( '\\', '', $monochrome_setting );
		$monochrome_data    = json_decode( $monochrome_setting, ARRAY_A );

		if ( 'default' !== $monochrome_data['monochrome_option'] ) {
			$monochrome_color = isset( $monochrome_data['icon_monochrome_color'] ) ? $monochrome_data['icon_monochrome_color'] : '';
		} else {
			$styling_option_colors = bbapp_get_default_tab_color();
			$monochrome_color      = $styling_option_colors['default_color'];
		}

		// Set Monochrome Color.
		if ( isset( $menu["icon"]['monochrome_setting'] ) ) {
			unset( $menu["icon"]['monochrome_setting'] );
			$menu["icon"]['tint_color'] = $monochrome_color;
		}

		/**
		 * Paths & Dirs
		 */
		$icons_path = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_app_icon_url();
		$icons_dir  = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_app_icon_dir();
		$menu["icon"]['monochrome'] = true;
		if ( strpos( $menu["icon"]['uri'], "custom/" ) !== false ) {
			// if it's custom uploaded icon.
			$menu["icon"]['uri'] = str_replace( "custom/", "/", $menu["icon"]['uri'] ); // remove the identifier.
			$icons_path          = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_url();
			$icons_dir           = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_dir();
			$menu["icon"]['monochrome'] = ( isset( $monochrome_data['icon_monochrome_checkbox'] ) && 'yes' === $monochrome_data['icon_monochrome_checkbox'] );
		}

		$app_settings = \BuddyBossApp\AppSettings::instance();
		if ( 'tabbar' === $menu_screen ) {
			$menu["icon"]['icon_style'] = $app_settings->get_setting_value( 'app_menu.tab_bar_icon_style' );
			$menu_icon_style            = !empty( $menu["icon"]['icon_style'] ) ? $menu["icon"]['icon_style'] : 'outlined';
		} else {
			$menu_icon_style            = 'outlined';
			$menu["icon"]['icon_style'] = $app_settings->get_setting_value( 'app_menu.more_icon_style' );
			$menu["icon"]['icon_style'] = empty( $menu["icon"]['icon_style'] ) ? 'outlined' : $menu["icon"]['icon_style'];
		}

		if ( ! empty( $menu["icon"]['uri'] ) ) {

			if ( file_exists( $icons_dir . str_replace( 'appboss/', 'bbapp/', $menu["icon"]['uri'] ) . '-' . $menu_icon_style . '.png' ) ) {
				$menu["icon"]['uri'] = $icons_path . str_replace( 'appboss/', 'bbapp/', $menu["icon"]['uri'] ) . '-' . $menu_icon_style . '.png';
			} elseif ( file_exists( $icons_dir . str_replace( 'appboss/', 'bbapp/', $menu["icon"]['uri'] ) ) ) {
				$menu["icon"]['uri'] = $icons_path . str_replace( 'appboss/', 'bbapp/', $menu["icon"]['uri'] );
			} else {
				$menu["icon"]['uri'] = "";
			}
		}

		// Set the default when it's empty at this point.
		if ( empty( $menu["icon"]['uri'] ) && isset( $menu["icon"]['icon_style'] ) ) {
			$menu["icon"]['uri'] = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_app_icon_url() . "bbapp/file-" . $menu_icon_style . ".png";
		}

		// Menu custom link deeplink data show.
		if ( bbapp_is_rest() && 'custom' === $menu['object'] && isset( $menu['data']['link'] ) && bbapp_is_valid_url( $menu['data']['link'] ) ) {
			/**
			 * Redirect to topic endpoint.
			 */
			global $wp_rest_server;
			$menu_deeplink_request = new \WP_REST_Request( 'POST', '/buddyboss-app/core/v1/url-details' );
			$menu_deeplink_request->set_param( 'url', $menu['data']['link'] );
			$server   = rest_get_server();
			$response = $server->dispatch( $menu_deeplink_request );

			$status               = $response->get_status();
			$menu_deeplink_result = array();
			if ( 200 === $status ) {
				$menu_deeplink_result = $wp_rest_server->response_to_data( rest_ensure_response( $response ), isset( $request['_embed'] ) ? 1 : 0 );
			}
			$menu['deeplink_data'] = $menu_deeplink_result;
		}

		return apply_filters( 'bbapp_menu_filter_menu_data', $menu );

	}

}
