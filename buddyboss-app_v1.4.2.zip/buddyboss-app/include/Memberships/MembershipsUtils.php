<?php

namespace BuddyBossApp\Memberships;

use WP_Error;

trait MembershipsUtils
{


    /**
     * @param $id
     * @return bool
     */
    public static function memberpressHasAccess($id)
    {
        $hasAccess = false;

        if (class_exists('MeprUtils')) {
            $user = \MeprUtils::get_currentuserinfo();
            $activeProductSubscriptions = $user->active_product_subscriptions();
            if (in_array($id, $activeProductSubscriptions)) {
                $hasAccess = true;
            }

        } else {
            return new WP_Error('not_available', __('MemberPress is inactive or integration is not available'), array('status' => 400));
        }

        return $hasAccess;
    }

    /**
     * This will return ids of Memberpress(memberpressproduct) which current(logged-in) user have access to.
     * @return array Consists Ids
     */
    public static function memberpressAccessList()
    {
        $accessList = array();
        if (class_exists('MeprUtils')) {
            $user = \MeprUtils::get_currentuserinfo();
            $activeProductSubscriptions = $user->active_product_subscriptions();
            $accessList = $activeProductSubscriptions;
        } else {
            return new WP_Error('not_available', __('MemberPress is inactive or integration is not available'), array('status' => 400));
        }

        return $accessList;

    }

    /**
     * @param $planId
     * @return bool
     */
    public static function wooMembershipHasAccess($planId)
    {
        $hasAccess = false;

        // NOTE : Using wc_memberships_get_user_active_memberships() NOT wc_memberships_get_user_memberships()
        if (class_exists('WC_Memberships_User_Memberships') && function_exists('wc_memberships_get_user_active_memberships')) {
            $userMemberships = wc_memberships_get_user_active_memberships();
            $accessList = array();
            // Note : Can't use wp_list_pluck($userMemberships, 'plan_id') since string casting was NOT possible
            foreach ($userMemberships as $index => $membership) {
                if (isset($membership->plan_id)) {
                    $accessList[] = $membership->plan_id;
                }
            }

            if (in_array($planId, $accessList)) {
                $hasAccess = true;
            }

        } else {
            return new WP_Error('not_available', __('WooCommerce Memberships is inactive or integration is not available'), array('status' => 400));
        }

        return $hasAccess;

    }


	/**
	 * @param $levelId
	 *
	 * @return bool
	 */
	public static function pmProMembershipHasAccess( $levelId ) {
		$hasAccess = false;

		// Only if pmpro-memberships(constant: PMPRO_VERSION) plugin is active
		if ( defined( 'PMPRO_VERSION' ) ) {

			$userId          = get_current_user_id();
			$userMemberships = pmpro_getMembershipLevelsForUser( $userId );

			$accessList = array();
			// Note : Can't use wp_list_pluck($userMemberships, 'ID') since string casting was NOT possible
			foreach ( $userMemberships as $index => $membership ) {
				if ( isset( $membership->ID ) ) {
					$accessList[] = $membership->ID;
				}
			}

			if ( in_array( $levelId, $accessList ) ) {
				$hasAccess = true;
			}

		} else {
			return new WP_Error( 'not_available', __( 'Paid Memberships Pro is inactive or integration is not available' ), array( 'status' => 400 ) );
		}

		return $hasAccess;

	}

    /**
     * This will return ids of WooCommerce(woo-memberships) which current(logged-in) user have access to
     * @return array Consists Ids
     */
    public static function wooMembershipAccessList()
    {
        $accessList = array();

        // NOTE : Using wc_memberships_get_user_active_memberships() NOT wc_memberships_get_user_memberships()
        if (class_exists('WC_Memberships_User_Memberships') && function_exists('wc_memberships_get_user_active_memberships')) {
            $userMemberships = wc_memberships_get_user_active_memberships();
            $accessList = array();
            // Note : Can't use wp_list_pluck($userMemberships, 'plan_id') since string casting was NOT possible
            foreach ($userMemberships as $index => $membership) {
                if (isset($membership->plan_id)) {
                    $accessList[] = (string)$membership->plan_id;
                }
            }

        } else {
            return new WP_Error('not_available', __('WooCommerce Memberships is inactive or integration is not available'), array('status' => 400));
        }

        return $accessList;
    }


	/**
	 * This will return ids of PmProMembership(pm-pro-membership) which current(logged-in) user have access to
	 * @return array Consists Ids
	 */
	public static function pmProMembershipAccessList() {
		$accessList = array();

		// Only if pmpro-memberships(constant: PMPRO_VERSION) plugin is active
		if ( defined( 'PMPRO_VERSION' ) ) {

			$userId          = get_current_user_id();
			$userMemberships = pmpro_getMembershipLevelsForUser( $userId );

			$accessList = array();
			// Note : Can't use wp_list_pluck($userMemberships, 'ID') since string casting was NOT possible
			foreach ( $userMemberships as $index => $membership ) {
				if ( isset( $membership->ID ) ) {
					$accessList[] = (string) $membership->ID;
				}
			}

		} else {
			return new WP_Error( 'not_available', __( 'Paid Memberships Pro is inactive or integration is not available' ), array( 'status' => 400 ) );
		}

		return $accessList;
	}


	/**
     * @param $courseId
     * @return bool
     */
    public static function learndashCourseHasAccess($courseId)
    {
        $hasAccess = false;

        if (function_exists('sfwd_lms_has_access')) {

            if (sfwd_lms_has_access($courseId)) {
                $hasAccess = true;
            }

        } else {
            return new WP_Error('not_available', __('LearnDash is inactive or integration is not available'), array('status' => 400));
        }

        return $hasAccess;

    }


    /**
     * This will return ids of LearnDash(learndash-course) which current(logged-in) user have access to
     * @return array Consists Ids
     */
    public static function learndashCourseAccessList()
    {
        $accessList = array();

        if (function_exists('learndash_user_get_enrolled_courses')) {
            $currentUserId = get_current_user_id();
            $accessList = learndash_user_get_enrolled_courses($currentUserId, array(), true);
        } else {
            return new WP_Error('not_available', __('LearnDash is inactive or integration is not available'), array('status' => 400));
        }
        return $accessList;

    }

}