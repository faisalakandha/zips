<?php

namespace BuddyBossApp\Memberships;

use WP_Error;
use WP_REST_Controller;
use WP_REST_SERVER;
use WP_REST_Request;
use WP_REST_Response;

// API for memberpress
class Memberships extends WP_REST_Controller
{
    use MembershipsUtils;

    // NOTE : Must be protected
    protected $namespace = 'buddyboss-app/v2';

    private static $instance;
    private $routeSlug = 'memberships';


	/**
	 * Memberships constructor.
	 */
    public function __construct()
    {
        //Using Singleton, see instance()
    }

    /**
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $className = __CLASS__;
            self::$instance = new $className;
            self::$instance->load(); // run the hooks.
        }
        return self::$instance;
    }

	/**
	 *
	 */
    public function load()
    {
        add_action('rest_api_init', array($this, "registerRoutes"), 99);
    }

	/**
	 *
	 */
    public function registerRoutes()
    {
        register_rest_route($this->namespace, $this->routeSlug . '/(?P<integration_type>\S+)' . '/(?P<id>\d+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'itemDetails'),
                'permission_callback' => array($this, 'permissionCallback'),
                'args' => array(
                    'integration_type' => array(
                        'required' => true,
                        'type' => 'string',
                        'description' => __("Integration Type"),
                        'enum' => array('memberpress', 'woo-membership','pm-pro-membership'),
                    ),
                    'id' => array(
                        'required' => true,
                        'type' => 'number',
                        'description' => __("Unique Identifier")
                    )
                )
            )));


        register_rest_route($this->namespace, $this->routeSlug . '/(?P<integration_type>\S+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'accessDetails'),
                'permission_callback' => array($this, 'permissionCallback'),
                'args' => array(
                    'integration_type' => array(
                        'required' => true,
                        'type' => 'string',
                        'description' => __("Integration Type"),
                        'enum' => array('memberpress', 'woo-membership','pm-pro-membership'),
                    )
                )
            )));


    }

	/**
	 * @return mixed
	 */
    public function permissionCallback()
    {
        return is_user_logged_in();
    }


    /**
     * @param $request
     * @return WP_REST_Response\WP_Error
     * @api {GET} /wp-json/buddyboss-app/v2/memberships/:integration_type/:id Membership details
     * @apiName MembershipItemInfo
     * @apiGroup Memberships
     * @apiVersion 2.0.0
     * @apiPermission LoggedInUser
     * @apiDescription Get information for particular membership item
     * @apiUse apidocForMembershipItemInfo
     */
    public function itemDetails($request)
    {
        $integrationType = @$request->get_param('integration_type');
        $id = @$request->get_param('id');

        $response['has_access'] = false;

        switch ($integrationType) {
            case 'memberpress' :
                $response['has_access'] = $this->memberpressHasAccess($id);
                if (is_wp_error($response['has_access'])) {
                    return $response['has_access'];
                }

                break;
            case 'woo-membership' :
                $response['has_access'] = $this->wooMembershipHasAccess($id);
                if (is_wp_error($response['has_access'])) {
                    return $response['has_access'];
                }
                break;
	        case 'pm-pro-membership' :
		        $response['has_access'] = $this->pmProMembershipHasAccess($id);
		        if (is_wp_error($response['has_access'])) {
			        return $response['has_access'];
		        }
		        break;
            default:
                return new WP_Error('not_found', 'Integration is not found');
                break;

        }

        return rest_ensure_response($response);
    }


    /**
     * @param $request
     * @return WP_REST_Response\WP_Error
     * @api {GET} /wp-json/buddyboss-app/v2/memberships/:integration_type Membership access details
     * @apiName MembershipAccessDetails
     * @apiGroup Memberships
     * @apiVersion 2.0.0
     * @apiPermission LoggedInUser
     * @apiDescription Get access information for particular membership
     * @apiUse apidocForMembershipAccessDetails
     */
    public function accessDetails($request)
    {
        $integrationType = @$request->get_param('integration_type');

        $response['access_list'] = false;

        switch ($integrationType) {
            case 'memberpress' :
                $response['access_list'] = MembershipsUtils::memberpressAccessList();
                if (is_wp_error($response['access_list'])) {
                    return $response['access_list'];
                }
                break;
            case 'woo-membership' :
                $response['access_list'] = MembershipsUtils::wooMembershipAccessList();
                if (is_wp_error($response['access_list'])) {
                    return $response['access_list'];
                }
                break;
	        case 'pm-pro-membership' :
		        $response['access_list'] = MembershipsUtils::pmProMembershipAccessList();
		        if (is_wp_error($response['access_list'])) {
			        return $response['access_list'];
		        }
		        break;
            case 'learndash-course' :
                $response['access_list'] = MembershipsUtils::learndashCourseAccessList();
                if (is_wp_error($response['access_list'])) {
                    return $response['access_list'];
                }
                break;
            default:
                return new WP_Error('not_found', 'Integration is not found');
                break;

        }

        return rest_ensure_response($response);
    }
}