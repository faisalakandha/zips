<?php

namespace BuddyBossApp\Memberships;

// Note : The soul purpose of this class is apidoc(documentation generator). By Ketan
class MembershipsApidoc
{

    private function apidocForMembershipItemInfo()
    {
        /**
         * @apiDefine apidocForMembershipItemInfo
         *
         * @apiHeader {String} accessToken Auth token
         * @apiParam {String=memberpress,woo-membership,pm-pro-membership} integration_type Integration Type
         * @apiParam {Number} id Unique identifier
         */
    }


    private function apidocForMembershipAccessDetails()
    {
        /**
         * @apiDefine apidocForMembershipAccessDetails
         *
         * @apiHeader {String} accessToken Auth token
         * @apiParam {String=memberpress,woo-membership,pm-pro-membership} integration_type Integration Type
         */
    }


}
