<?php

namespace BuddyBossApp\Integrations\Learndash;

use BuddyBossApp\App\App;
use BuddyBossApp\Helpers\PostCover;

class Main {

	private static $instance;

	/**
	 * Main constructor.
	 */
	public function __construct() {
	}

	/**
	 * @return mixed
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {

		add_action("init", array($this, 'learndash_init'));
	}

	function learndash_init(){
		if ( ! defined( 'LEARNDASH_VERSION' ) ) {
			return;
		}

		add_filter( 'bbapp_quick_link_user_links_items', array( $this, 'learndash_bbapp_quick_link_user_links_items' ), 10, 1 );
		add_filter( 'bbapp_quick_link_deeplink_links', array( $this, 'learndash_bbapp_quick_link_deeplink_links' ), 10, 2 );
		add_filter( 'bbapp_user_segment_integrations', array( $this, 'load_segment' ), 11 );
		$this->local_features();

		// Add Course cover image if BuddyBoss theme is not activated
		if ( ! function_exists( 'buddyboss_theme' ) && class_exists( 'BuddyBossApp\Helpers\PostCover' ) ) {
			new PostCover(
				array(
					'label'     => __( 'Cover Photo', 'buddyboss-theme' ),
					'id'        => 'course-cover-image',
					'post_type' => 'sfwd-courses',
				)
			);
		}
		add_filter( 'bbapp_core_profile_tabs', array( $this, 'bbapp_core_profile_learndash_tabs' ), 10, 1 );
	}

	/**
	 * Add location features related to social features.
	 */
	public function local_features() {

		// Learndash Support.
		App::instance()->add_local_feature( "learndash", array(
			"is_enabled_android" => defined( 'LEARNDASH_VERSION' ),
			"is_enabled_ios"     => defined( 'LEARNDASH_VERSION' ),
		) );
	}

	/**
	 * Load Learndash related user segments
	 *
	 * @param $integrations
	 *
	 * @return mixed
	 */
	public function load_segment( $integrations ) {
		$integrations['learndash'] = new Segment();

		return $integrations;
	}

	/**
	 * Quick link widget user link.
	 *
	 * @param $quick_link_user_links_items
	 *
	 * @return mixed
	 */
	public function learndash_bbapp_quick_link_user_links_items( $quick_link_user_links_items ) {
		if ( function_exists( 'bp_ld_sync' ) && bp_ld_sync()->settings->get( 'course.courses_visibility' ) ) {
			$slug         = apply_filters( 'bp_learndash_profile_courses_slug', \LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Section_Permalinks', 'courses' ) );
			$name         = \LearnDash_Custom_Label::get_label( 'courses' );
			$item_courses = array(
				'ID'       => $slug,
				'title'    => $name,
				'icon'     => bbapp_tabbar_get_selected_icon( 'bbapp/book-open', 'outlined' ),
				'icon_val' => 'bbapp/book-open',
			);

			$quick_link_user_links_items[] = $item_courses;
		}

		/**
		 * Course certificate support added.
		 */
		if ( function_exists( 'bp_core_learndash_certificates_enables' ) && bp_core_learndash_certificates_enables() ) {

			$item_certificates = array(
				'ID'       => apply_filters( 'bp_learndash_profile_certificates_slug', 'certificates' ),
				'title'    => apply_filters( 'bp_learndash_profile_certificates_tab_name', __( 'Certificates', 'buddyboss-app' ) ),
				'icon'     => bbapp_tabbar_get_selected_icon( 'bbapp/certificates', 'outlined' ),
				'icon_val' => 'bbapp/certificates',
			);

			$quick_link_user_links_items[] = $item_certificates;

		}

		return $quick_link_user_links_items;
	}

	/**
	 * Quick link deeplink url.
	 *
	 * @param $link
	 * @param $link_slug
	 *
	 * @return string
	 */
	public function learndash_bbapp_quick_link_deeplink_links( $link, $link_slug ) {
		if ( function_exists( 'bp_ld_sync' ) && bp_ld_sync()->settings->get( 'course.courses_visibility' ) ) {
			$slug = apply_filters( 'bp_learndash_profile_courses_slug', \LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Section_Permalinks', 'courses' ) );
			if ( $slug === $link_slug ) {
				return trailingslashit( bp_loggedin_user_domain() . $slug );
			}
		}

		/**
		 * Course certificate support added.
		 */
		if ( function_exists( 'bp_core_learndash_certificates_enables' ) && bp_core_learndash_certificates_enables() ) {
			$course_slug = apply_filters( 'bp_learndash_profile_courses_slug', \LearnDash_Settings_Section::get_section_setting('LearnDash_Settings_Section_Permalinks', 'courses' ) );
			if ( apply_filters( 'bp_learndash_profile_certificates_slug', 'certificates' ) === $link_slug ) {
				if ( ! empty( $course_slug ) ) {
					return trailingslashit( bp_loggedin_user_domain() . $course_slug . '/' . $link_slug );
				} else {
					return trailingslashit( bp_loggedin_user_domain() . $link_slug );
				}
			}
		}

		return $link;
	}

	/**
	 * Get learndash slugs.
	 * @param $nav_items
	 *
	 * @return mixed
	 */
	public function bbapp_core_profile_learndash_tabs( $nav_items ) {
		$course_name          = \LearnDash_Custom_Label::get_label( 'courses' );
		$course_slug          = bb_learndash_profile_courses_slug();
		$my_course_name       = sprintf( __( 'My %s', 'buddyboss-app' ), $course_name );
		$my_course_slug       = apply_filters( 'bp_learndash_profile_courses_slug', 'my-courses' );
		$my_certificates_name = sprintf( __( 'My %s', 'buddyboss-app' ), $course_name );
		$my_certificates_slug = apply_filters( 'bp_learndash_profile_certificates_slug', 'certificates' );

		$nav_items[ $course_slug ]          = $course_name;
		$nav_items[ $my_course_slug ]       = $my_course_name;
		$nav_items[ $my_certificates_slug ] = $my_certificates_name;

		return $nav_items;
	}

	/**
	 * Function to get the course categories and tags.
	 *
	 * @since 1.4.0
	 *
	 * @param int $item_id
	 *
	 * @return mixed
	 */
	public function bbapp_get_course_cats_and_tags( $item_id = 0 ) {

		if ( empty( $item_id ) ) {
			return array();
		}

		$course_cats = array();
		$course_tags = array();

		if ( method_exists( 'LearnDash_Settings_Section', 'get_section_setting' ) && 'yes' === \LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Courses_Taxonomies', 'ld_course_category' ) ) {
			$course_cats = wp_get_post_terms( $item_id, 'ld_course_category', array( 'fields' => 'ids' ) );
		}

		if ( method_exists( 'LearnDash_Settings_Section', 'get_section_setting' ) && 'yes' === \LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Courses_Taxonomies', 'ld_course_tag' ) ) {
			$course_tags = wp_get_post_terms( $item_id, 'ld_course_tag', array( 'fields' => 'ids' ) );
		}

		$iap_ids = $this->bbapp_iap_get_courses_iap_products( array( $item_id ), $course_cats, $course_tags );

		return $iap_ids;
	}

	/**
	 * Function to get the LD course IAP.
	 *
	 * @since 1.4.0
	 *
	 * @param array $course_ids     specific course ids.
	 * @param array $course_cat_ids specific course category ids.
	 * @param array $course_tag_ids specific course tag ids.
	 *
	 * @return array|object
	 */
	public function bbapp_iap_get_courses_iap_products( $course_ids = array(), $course_cat_ids = array(), $course_tag_ids = array() ) {
		global $wpdb;

		$select = "SELECT DISTINCT {$wpdb->prefix}bbapp_iap_products.id FROM {$wpdb->prefix}bbapp_iap_products INNER JOIN {$wpdb->prefix}bbapp_iap_productmeta iapm1 ON ({$wpdb->prefix}bbapp_iap_products.id = iapm1.iap_id ) INNER JOIN {$wpdb->prefix}bbapp_iap_productmeta iapm2 ON ({$wpdb->prefix}bbapp_iap_products.id = iapm2.iap_id)";

		$where = array();

		$where['all_courses'] = "(iapm1.meta_key='course_access_type' AND iapm1.meta_value='all-courses')";

		if ( ! empty( $course_ids ) ) {
			$imploded_course_ids       = "'" . implode( "','", array_map( 'intval', $course_ids ) ) . "'";
			$where['specific_courses'] = "(iapm1.meta_key='course_access_type' AND iapm1.meta_value='specific-course' AND iapm2.meta_key='course_access_id' AND iapm2.meta_value IN ({$imploded_course_ids}))";
		}

		if ( ! empty( $course_cat_ids ) ) {
			$imploded_cat_ids       = "'" . implode( "','", array_map( 'intval', $course_cat_ids ) ) . "'";
			$where['specific_cats'] = "(iapm1.meta_key='course_access_type' AND iapm1.meta_value='specific-category-courses' AND iapm2.meta_key='course_access_cat_id' AND iapm2.meta_value IN ({$imploded_cat_ids}))";
		}

		if ( ! empty( $course_tag_ids ) ) {
			$imploded_tag_ids       = "'" . implode( "','", array_map( 'intval', $course_tag_ids ) ) . "'";
			$where['specific_tags'] = "(iapm1.meta_key='course_access_type' AND iapm1.meta_value='specific-tag-courses' AND iapm2.meta_key='course_access_tag_id' AND iapm2.meta_value IN ({$imploded_tag_ids}))";
		}

		$imploded_where = "(" . implode( ' OR ', $where ) . ")";
		$published_iap  = "{$wpdb->prefix}bbapp_iap_products.status='published'";

		$sql = $select . ' WHERE ' . $published_iap . ' AND ' . $imploded_where;

		$results = $wpdb->get_results( $sql );

		return ! empty( $results ) ? $results : array();
	}
}
