<?php

namespace BuddyBossApp\UserSegment\Fields;

class LDCourseSelect {

	public static function render( $field_name, $args = array() ) {
		$before_label = isset( $args["before_label"] ) ? $args["before_label"] : "";
		?>
		<span class="bbapp_usegment_field_ldcourseselect">
            <?php if ( ! empty( $before_label ) ): ?>
	            <label><?php echo esc_html( $before_label ); ?></label>
            <?php endif; ?>
            <select name="<?php echo esc_html( $field_name ); ?>[{{data._index}}]">
                <option value=""><?php esc_html_e( "Select Course", "buddyboss-app" ); ?></option>
            </select>
        </span>
		<?php

	}

	/**
	 * Render the part outside of template. idea for js & css for fields specific.
	 */
	public static function render_script() {
		static $output_once;

		// avoid function to exec twice.
		if ( isset( $output_once ) ) {
			return false;
		}
		?>

		<script>

			function bbapp_segment_ldcourse_select_init() {

				jQuery('.bbapp_usegment_field_ldcourseselect').each(function () {

					if (jQuery(this).data("processed")=="1") {
						return true;
					}

					jQuery(this).data("processed", "1");

					var select = jQuery(this).find("select");
					jQuery(select).select2({
						formatSelection: function (item) {
							return item.id;
						},
						dropdownAutoWidth: true,
						width: 'auto',
						tags: [],
						ajax: {
							headers: {
								'X-WP-Nonce': bbapp_ajax.rest_nonce
							},
							url: bbapp_ajax.resturl + "buddyboss-app/learndash/v1/courses",
							dataType: 'json',
							type: "GET",
							quietMillis: 50,
							data: function (term) {
								return {
									search: term.term
								};
							},
							processResults: function (data) {
								return {
									results: jQuery.map(data, function (item) {
										return {
											text: jQuery("<div/>").html(item.title.rendered).text(),
											id: item.id
										}
									})
								};
							},

						}
					});

				});

				/*jQuery('.bbapp_usegment_field_ldcourseselect select').change(function (){
					jQuery('#btn-notifications-submit').trigger("segment_refresh_user_list");
				});*/
			}

			jQuery(document).ready(function () {
				jQuery(document).on(".choose_filter, .choose_sub_filter").change(function(){
					bbapp_segment_ldcourse_select_init();
				});
			});

		</script>

		<?php


	}

}