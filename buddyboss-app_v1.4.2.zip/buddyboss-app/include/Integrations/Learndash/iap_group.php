<?php

namespace BuddyBossApp\Integrations\LearndashGroup;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\InAppPurchases\Controller;
use BuddyBossApp\InAppPurchases\IntegrationAbstract;
use BuddyBossApp\InAppPurchases\Orders;

// Learndash Group Integration for BuddyBossApp InAppPurchases.
final class IAP extends IntegrationAbstract {

	private static $instance = null;

	/**
	 * LearnDashGroupIntegration constructor.
	 */
	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 * @return Controller|null
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
		}

		return self::$instance;
	}

	/**
	 * Overriding the parent(from base-class) function
	 *
	 * @param $integration_type
	 * @param $integration_label
	 */
	public function set_up( $integration_type, $integration_label ) {

		$this->integration_slug = Controller::$learndash_group_slug;

		parent::set_up( $integration_type, $integration_label );

		$this->item_label = __( 'LearnDash Group', 'buddyboss-app' );

		// Register Instance
		bbapp_iap()->integration[ $integration_type ] = $this::instance();

	}

	/**
	 * Below function get triggers when(hook) order is completed.
	 *
	 * @param $item_ids
	 * @param $order
	 *
	 * @return mixed
	 */
	public function on_order_completed( $item_ids, $order ) {

		foreach ( $item_ids as $item_identifier ) {

			$split = explode( ':', $item_identifier );
			$group_id    = $split[0];

			$readable_item_ids[] = "<a href=\"post.php?post=$group_id&action=edit\" target='_blank'>$group_id</a>";

			// grant the group access
			ld_update_group_access( $order->user_id, $group_id, false);
			// update user group count.
			$this->user_update_count( $group_id, $order->user_id, "plus" );

		}
		$readable_item_ids = implode( ', ', $readable_item_ids );

		Orders::instance()->add_history( $order->id, 'info', sprintf( __( "User enrolled in Group(s), ID(s) are : %s", 'buddyboss-app' ), $readable_item_ids ) );

		Orders::instance()->update_meta( $order->id, "_learndash_group_ids", serialize( $item_ids ) );

	}

	/**
	 * Below function get triggers when(hook) order is activated.
	 *
	 * @param $item_ids
	 * @param $order
	 *
	 * @return mixed
	 */
	public function on_order_activate( $item_ids, $order ) {
		// NOTE : Similar to onOrderCompleted($order) until something needs to be changed?
		return $this->on_order_completed( $item_ids, $order );
	}

	/**
	 * Below function get triggers when(hook) order is expired.
	 *
	 * @param $item_ids
	 * @param $order
	 *
	 * @return mixed
	 */
	public function on_order_expired( $item_ids, $order ) {
		// NOTE : Similar to onOrderCancelled($order) until something needs to be changed?
		$this->on_order_cancelled( $item_ids, $order );
	}

	/**
	 * Below function get triggers when(hook) order is cancelled.
	 *
	 * @param $item_ids
	 * @param $order
	 *
	 * @return mixed
	 */
	public function on_order_cancelled( $item_ids, $order ) {

		//$item_ids = unserialize( Orders::instance()->get_meta( $order->id, "_learndash_course_ids" ) );

		foreach ( $item_ids as $item_identifier ) {
			$split = explode( ':', $item_identifier );
			$group_id    = $split[0];

			$readable_item_ids[] = "<a href=\"post.php?post=$group_id&action=edit\" target='_blank'>$group_id</a>";

			// revoke the group access
			ld_update_group_access( $order->user_id, $group_id, true );
			// update user group count.
			$this->user_update_count( $group_id, $order->user_id, "minus" );

		}
		$readable_item_ids = implode( ', ', $readable_item_ids );

		Orders::instance()->add_history( $order->id, 'info', sprintf( __( "User un-enrolled in group(s), ID(s) are : %s ", 'buddyboss-app' ), $readable_item_ids ) );
	}

	/**
	 * Helper function to update users group counts.
	 *
	 * @param        $group_id
	 * @param        $user_id
	 * @param string $action
	 */
	public function user_update_count( $group_id, $user_id, $action = "plus" ) {

		$groups = get_user_meta( $user_id, '_learndash_inapp_purchase_enrolled_group_access_counter', true );

		if ( ! empty( $groups ) ) {
			$groups = maybe_unserialize( $groups );
		} else {
			$groups = array();
		}

		if ( isset( $groups[ $group_id ] ) ) {
			if ( $action == "plus" ) {
				$groups[ $group_id ] += 1;
			} else {
				$groups[ $group_id ] -= 1;
			}
		} else {
			$groups[ $group_id ] = ( $action == "plus" ) ? 1 : 0;
		}

		update_user_meta( $user_id, '_learndash_inapp_purchase_enrolled_group_access_counter', $groups );

	}

	function iap_linking_options( $results ) {
		return \BuddyBossApp\Admin\InAppPurchases\Helpers::getIntegrationItems( 'groups' );
	}

	function iap_integration_ids( $results, $integration_ids ) {
		return $results;
	}

	function item_id_permalink( $link, $item_id ) {
		return "post.php?post=$item_id&action=edit";
	}

	function is_purchase_available( $is_available, $item_id, $integration_item_id ) {
		return learndash_group_has_course( $integration_item_id, $item_id );
	}

	/**
	 * Check given integration item has access.
	 *
	 * @param $item_ids
	 * @param $user_id
	 *
	 * @return false
	 */
	function has_access( $item_ids, $user_id ) {
		if ( is_admin() ) {
			return true;
		}
		$has_access = false;

		foreach ( $item_ids as $item_identifier ) {
			$split    = explode( ':', $item_identifier );
			$group_id = $split[0];
			if ( learndash_is_user_in_group( $user_id, $group_id ) ) {
				$has_access = true;
				break;
			}
		}
		return $has_access;
	}
}
