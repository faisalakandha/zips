<?php

namespace BuddyBossApp\Integrations\GravityForm;

use BuddyBossApp\App\App;
use BuddyBossApp\Notification\IntegrationAbstract;

/**
 * @todo: Remove this file we there is no code.
 * Class Notification
 * @package BuddyBossApp\Integrations\GravityForm
 */
class Notification extends IntegrationAbstract
{

    protected static $instance;

	/**
	 *
	 */
    public function load()
    {

        // Require action to do.
        $this->register_component('gravityform');

        /**
         * Not supported on the product.
         */
//        if (class_exists("RGFormsModel")) {
//
//            /**
//             * add the push notification type.
//             */
//            $this->add_push_notification_type(array( $this, "gravityFormIntegration" ));
//        }

    }

//    /**
//     * @param $push_types
//     * @param $app_id
//     *
//     * @return mixed
//     */
//    public function gravityFormIntegration($push_types, $app_id) {
//
//        $forms = \RGFormsModel::get_forms(null, 'title');
//
//        $options = array("" => __("None", 'buddyboss-app'));
//
//        $forms = \RGFormsModel::get_forms( null, 'title' );
//
//        $options = array( "" => __("None", bbapp()->domain) );
//
//        foreach ($forms as $form) {
//            $options[$form->id] = "#$form->id $form->title";
//        }
//
//        $options = apply_filters("bbapp_push_notification_type_gravity_options", $options, $app_id);
//
//        $push_types["gravityform"] = array(
//            "label" => __("Gravity Form"),
//            "settings" => array(
//                "id" => array(
//                    "label" => __("Form ID", 'buddyboss-app'),
//                    "type" => "select",
//                    "options" => $options,
//                ),
//            ),
//            'data_callback' => array($this, 'gravity_form_integration_callback'),
//        );
//
//        return $push_types;
//    }

//    /**
//     * Callback to merge settings into data.
//     *
//     * @param $data
//     * @param $settings
//     *
//     * @return mixed
//     */
//    public function gravity_form_integration_callback($data, $settings) {
//
//        $data["action"] = "gravityform";
//        $data["item_id"] = "0";
//        $data["namespace"] = "gravityform";
//
//        if (isset($settings["gravityform"]) && isset($settings["gravityform"]["id"])) {
//            $data["item_id"] = $settings["gravityform"]["id"];
//        }
//
//        return $data;
//    }

    /**
     * Format the notifications for API and Web.
     * @param $component_name
     * @param $component_action
     * @param $item_id
     * @param $secondary_item_id
     * @param $notification_id
     * @return array {
     *  "link" => "" // Must be URL eg. http://example.com/example/example
     *  "text" => "" // Link Text eg. Someone replied to your topic.
     * }
     */
    function format_notification($component_name, $component_action, $item_id, $secondary_item_id, $notification_id)
    {
        // TODO: Implement format_notification() method.
    }
}