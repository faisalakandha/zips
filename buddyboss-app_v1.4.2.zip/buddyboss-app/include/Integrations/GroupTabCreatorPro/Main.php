<?php

namespace BuddyBossApp\Integrations\GroupTabCreatorPro;

/**
 * Contains all Group Creator Pro related features/hooks/filters
 *
 * Class Main
 *
 * @package BuddyBossApp\Integrations\GroupTabCreatorPro
 */
class Main {

	private static $instance;

	/**
	 * Main constructor.
	 */
	public function __construct() {
	}

	/**
	 * @return mixed
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 * Load all hooks.
	 */
	public function load() {
		add_action( 'bp_rest_api_init', array( $this, 'bbapp_rest_compatibility_loader' ), 5 );
		add_filter( 'bp_rest_group_tabs', array( $this, 'bbapp_rest_group_tabs_creator_pro' ), 10, 1 );
	}

	/**
	 * Remove platform hooks.
	 * Todo : Platform plugin we don't need this group tab creator code.
	 * We will remove this code on platform and keep on buddyboss app.
	 */
	public function bbapp_rest_compatibility_loader() {
		// Apply WordPress defined filters.
		remove_filter( 'bp_rest_group_tabs', 'bp_rest_group_tabs_creator_pro', 10 );
	}

	/**
	 * Get BuddyPress Groups Tabs Creator Pro tasb getting.
	 *
	 * @param array $navigation Array of navigation items.
	 *
	 * @return array|mixed
	 *
	 * @since BuddyBossApp x.x.x
	 */
	public function bbapp_rest_group_tabs_creator_pro( $navigation ) {
		if ( function_exists( 'bpgtc_get_active_group_tab_entries' ) ) {
			$active_tabs = bpgtc_get_active_group_tab_entries();
			$tabs        = array();

			if ( ! empty( $active_tabs ) ) {
				foreach ( $active_tabs as $active_tab ) {

					// if not active or no unique key, do not register.
					if ( ! $active_tab->is_active || ! $active_tab->slug ) {
						continue;
					}

					$current_group = bp_is_group() ? groups_get_current_group() : null;

					// do not add tab if does not apply to this group.
					if ( ! bpgtc_is_tab_available( $active_tab, $current_group ) ) {
						continue;
					}

					if ( ! empty( $active_tab->link ) ) {
						$link = trailingslashit( bpgtc_parse_group_tab_url( $active_tab->link ) );
					} else {
						$group_link = bp_get_group_permalink( $current_group );
						$link       = trailingslashit( $group_link . $active_tab->slug );
					}

					$tab = array(
						'id'              => $active_tab->slug,
						'title'           => $active_tab->label,
						'count'           => false,
						'position'        => $active_tab->position,
						'default'         => false,
						'user_has_access' => ! empty( $current_group ) ? $current_group->user_has_access : false,
						'link'            => $link,
						'children'        => array(),
					);

					$tabs[] = $tab;
				}

				$navigation = array_merge( $navigation, $tabs );
				usort( $navigation, function ( $a, $b ) {
					return $a['position'] - $b['position'];
				} );
			}
		}

		return $navigation;
	}

}