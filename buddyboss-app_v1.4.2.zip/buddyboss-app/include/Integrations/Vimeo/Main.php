<?php
namespace BuddyBossApp\Integrations\Vimeo;

// Contains all Vimeo related feature
class Main {

	private static $instance;

	/**
	 * Main constructor.
	 */
	public function __construct() {}

	/**
	 * @return mixed
	 */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->load(); // run the hooks.
		}
		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {
		VimeoEmbed::instance();
		RestAPI::instance();
	}

}