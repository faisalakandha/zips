<?php

namespace BuddyBossApp\Integrations\BuddyBossPlatform\Push;

use BuddyBossApp\Notification\IntegrationAbstract;

/**
 * Messages component push notification support.
 * Class MessagesNotification
 *
 * @package BuddyBossApp\Integrations\BuddyBossPlatform\Push
 */
class MessagesNotification extends IntegrationAbstract {

	/**
	 * @var $instance
	 */
	protected static $instance;

	/**
	 * Load methods.
	 */
	public function load() {
		$this->push_types();
		$this->link_notifications();

	}

	/**
	 * Register Subscriptions Types
	 */
	public function push_types() {

		// Messages
		$this->register_push_group( 'messages', __( "Messages", "buddyboss-app" ));
		$this->register_push_type( 'bp_messages_new_message', __( "A member receives a new message", "buddyboss-app" ), __( "A member sends you a new message", "buddyboss-app" ), array( 'push_group' => 'messages' ) );
	}

	/**
	 * Link Normal Notification to Push.
	 */
	public function link_notifications() {
		// Messages
		$this->register_push_to_normal( 'messages', 'new_message', 'bp_messages_new_message' );
	}

	/**
	 * Format the notifications for API and Web.
	 *
	 * @param $component_name
	 * @param $component_action
	 * @param $item_id
	 * @param $secondary_item_id
	 * @param $notification_id
	 *
	 * @return array {
	 *  "link" => "" // Must be URL eg. http://example.com/example/example
	 *  "text" => "" // Link Text eg. Someone replied to your topic.
	 * }
	 */
	public function format_notification( $component_name, $component_action, $item_id, $secondary_item_id, $notification_id ) {
		// TODO: Implement format_notification() method.
	}
}