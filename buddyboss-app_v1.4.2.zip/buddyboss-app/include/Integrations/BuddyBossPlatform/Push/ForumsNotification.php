<?php

namespace BuddyBossApp\Integrations\BuddyBossPlatform\Push;

use BuddyBossApp\Notification\IntegrationAbstract;

/**
 * Forums component push notification support.
 * Class ForumsNotification
 *
 * @package BuddyBossApp\Integrations\BuddyBossPlatform\Push
 */
class ForumsNotification extends IntegrationAbstract {

	/**
	 * @var $instance
	 */
	protected static $instance;

	/**
	 * Load methods.
	 */
	public function load() {
		$this->push_types();
		$this->link_notifications();

	}

	/**
	 * Register Subscriptions Types
	 */
	public function push_types() {

		// Forum
		$this->register_push_group( 'forum', __( "Forums", "buddyboss-app" ));
		$this->register_push_type( 'bbp_new_reply', __( "A member receives a new reply to a discussion they’ve created", "buddyboss-app" ), __( "New reply on discussion you created", "buddyboss-app" ), array( 'push_group' => 'forum' ) );
		$this->register_push_type( 'bbp_new_at_mention', __( "A discussion is created in a forum a member is subscribed to", "buddyboss-app" ), sprintf( __( 'A member mentions you in a discussion using "@%s"', 'buddyboss-app' ), bp_core_get_user_displayname( get_current_user_id() ) ), array( 'push_group' => 'forum' ) );
	}

	/**
	 * Link Normal Notification to Push.
	 */
	public function link_notifications() {
		// Forum
		$this->register_push_to_normal( 'forums', 'bbp_new_reply', 'bbp_new_reply' );
		$this->register_push_to_normal( 'forums', 'bbp_new_at_mention', 'bbp_new_at_mention' );
	}

	/**
	 * Format the notifications for API and Web.
	 *
	 * @param $component_name
	 * @param $component_action
	 * @param $item_id
	 * @param $secondary_item_id
	 * @param $notification_id
	 *
	 * @return array {
	 *  "link" => "" // Must be URL eg. http://example.com/example/example
	 *  "text" => "" // Link Text eg. Someone replied to your topic.
	 * }
	 */
	public function format_notification( $component_name, $component_action, $item_id, $secondary_item_id, $notification_id ) {
		// TODO: Implement format_notification() method.
	}
}