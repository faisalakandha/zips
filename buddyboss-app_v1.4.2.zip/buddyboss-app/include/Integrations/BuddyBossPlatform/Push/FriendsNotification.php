<?php

namespace BuddyBossApp\Integrations\BuddyBossPlatform\Push;

use BuddyBossApp\Notification\IntegrationAbstract;

/**
 * Friends component push notification support.
 * Class FriendsNotification
 *
 * @package BuddyBossApp\Integrations\BuddyBossPlatform\Push
 */
class FriendsNotification extends IntegrationAbstract {

	/**
	 * @var $instance
	 */
	protected static $instance;

	/**
	 * Load methods.
	 */
	public function load() {
		$this->push_types();
		$this->link_notifications();

	}

	/**
	 * Register Subscriptions Types
	 */
	public function push_types() {

		// Friends / Connections.
		$this->register_push_group( 'connections', __( "Connections", "buddyboss-app" ));
		$this->register_push_type( 'bp_friends_friendship_request', __( "A member receives a new connection request", "buddyboss-app" ), __( "A member invites you to connect", "buddyboss-app" ), array( 'push_group' => 'connections' ) );
		$this->register_push_type( 'bp_friends_friendship_accepted', __( "A member’s connection request is accepted", "buddyboss-app" ), __( "A member accepts your connection request", "buddyboss-app" ), array( 'push_group' => 'connections' ) );

	}

	/**
	 * Link Normal Notification to Push.
	 */
	public function link_notifications() {

		// Friends
		$this->register_push_to_normal( 'friends', 'friendship_request', 'bp_friends_friendship_request' );
		$this->register_push_to_normal( 'friends', 'friendship_accepted', 'bp_friends_friendship_accepted' );

	}

	/**
	 * Format the notifications for API and Web.
	 *
	 * @param $component_name
	 * @param $component_action
	 * @param $item_id
	 * @param $secondary_item_id
	 * @param $notification_id
	 *
	 * @return array {
	 *  "link" => "" // Must be URL eg. http://example.com/example/example
	 *  "text" => "" // Link Text eg. Someone replied to your topic.
	 * }
	 */
	public function format_notification( $component_name, $component_action, $item_id, $secondary_item_id, $notification_id ) {
		// TODO: Implement format_notification() method.
	}
}