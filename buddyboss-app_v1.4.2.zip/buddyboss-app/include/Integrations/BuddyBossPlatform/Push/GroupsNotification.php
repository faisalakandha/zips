<?php

namespace BuddyBossApp\Integrations\BuddyBossPlatform\Push;

use BuddyBossApp\Notification\IntegrationAbstract;

/**
 * Groups component push notification support.
 * Class GroupsNotification
 *
 * @package BuddyBossApp\Integrations\BuddyBossPlatform\Push
 */
class GroupsNotification extends IntegrationAbstract {

	/**
	 * @var $instance
	 */
	protected static $instance;

	/**
	 * Load methods.
	 */
	public function load() {
		$this->push_types();
		$this->link_notifications();

	}

	/**
	 * Register Subscriptions Types
	 */
	public function push_types() {

		// Groups
		$this->register_push_group( 'groups', __( "Social Groups", "buddyboss-app" ) );
		$this->register_push_type( 'bp_groups_new_invite', __( "A member is invited to join a group", "buddyboss-app" ), __( "A member invites you to join a group", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		$this->register_push_type( 'bp_groups_admin_promotion', __( "A member is promoted to a group organizer", "buddyboss-app" ), __( "You are promoted to a group organizer or moderator", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		$this->register_push_type( 'bp_groups_admin_promotion_mod', __( "A member is promoted to a moderator", "buddyboss-app" ), __( "You are promoted to a group organizer or moderator", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		$this->register_push_type( 'bp_groups_new_membership_request', __( "A member receives a request to join a private group they organize", "buddyboss-app" ), __( "A member requests to join a private group you organize", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		$this->register_push_type( 'bp_groups_request_completed', __( "A member’s request to join a group has been approved", "buddyboss-app" ), __( "Your request to join a group has been approved or denied", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		$this->register_push_type( 'bp_groups_request_denied', __( "A member’s request to join a group has been denied", "buddyboss-app" ), __( "Your request to join a group has been approved or denied", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		if ( function_exists( 'bp_disable_group_messages' ) && true === bp_disable_group_messages() ) {
			$this->register_push_type( 'bp_groups_send_new_message', __( "A member receives a new group message", "buddyboss-app" ), __( "A group sends you a new message", "buddyboss-app" ), array( 'push_group' => 'groups' ) );
		}

	}

	/**
	 * Link Normal Notification to Push.
	 */
	public function link_notifications() {
		// Groups
		$this->register_push_to_normal( 'groups', 'group_invite', 'bp_groups_new_invite' );
		$this->register_push_to_normal( 'groups', 'new_membership_request', 'bp_groups_new_membership_request' );
		$this->register_push_to_normal( 'groups', 'membership_request_accepted', 'bp_groups_request_completed' );
		$this->register_push_to_normal( 'groups', 'membership_request_rejected', 'bp_groups_request_denied' );
		$this->register_push_to_normal( 'groups', 'member_promoted_to_admin', 'bp_groups_admin_promotion' );
		$this->register_push_to_normal( 'groups', 'member_promoted_to_mod', 'bp_groups_admin_promotion_mod' );
		if ( function_exists( 'bp_disable_group_messages' ) && true === bp_disable_group_messages() ) {
			$this->register_push_to_normal( 'groups', 'new_message', 'bp_groups_send_new_message' );
		}
	}

	/**
	 * Format the notifications for API and Web.
	 *
	 * @param $component_name
	 * @param $component_action
	 * @param $item_id
	 * @param $secondary_item_id
	 * @param $notification_id
	 *
	 * @return array {
	 *  "link" => "" // Must be URL eg. http://example.com/example/example
	 *  "text" => "" // Link Text eg. Someone replied to your topic.
	 * }
	 */
	public function format_notification( $component_name, $component_action, $item_id, $secondary_item_id, $notification_id ) {
		// TODO: Implement format_notification() method.
	}
}