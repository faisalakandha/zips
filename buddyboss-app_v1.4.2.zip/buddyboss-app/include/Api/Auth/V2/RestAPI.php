<?php

namespace BuddyBossApp\Api\Auth\V2;

use BuddyBossApp\Auth\Jwt;
use WP_Error as WP_Error;
use WP_REST_Controller as WP_REST_Controller;

// Contain functionality for required additional rest api endpoints for Authentication.

/**
 * Class RestAPI
 *
 * @package BuddyBossApp\Api\Auth\V2
 */
class RestAPI extends WP_REST_Controller
{

    protected $namespace = "buddyboss-app/auth/v2";
    private static $instance;

    public function __construct()
    {
    }

    /**
     * Get class instance
     *
	 * @return RestAPI
	 */
    public static function instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new self();
            self::$instance->hooks();
        }

        return self::$instance;
    }

	/**
	 *
	 */
    public function hooks()
    {
        add_action('rest_api_init', array($this, "registerRoutes"), 99);
    }

    /**
     * Register API Routes.
     */
    public function registerRoutes()
    {

        register_rest_route($this->namespace, '/jwt/login', array(
            'methods' => 'POST',
            'callback' => array($this, "rest_login"),
            'permission_callback' => '__return_true',
            'args' => array(
                'username' => array(
                    'type' => 'string',
                    'required' => true,
                    'description' => __('Username of user wants to authenticate, Email is also valid.'),
                    'validate_callback' => function ($param, $request, $key) {
                        return sanitize_user($param);
                    },
                ),
                'password' => array(
                    'type' => 'string',
                    'required' => true,
                    'description' => __('Password of user wants to authenticate.'),
                ),
                'device_token' => array(
                    'type' => 'string',
                    'required' => false,
                    'description' => __('Firebase app device token.'),
                ),
            ),
        ));

        register_rest_route($this->namespace, '/jwt/access-token', array(
            'methods' => 'POST',
            'callback' => array($this, "rest_access_token"),
            'permission_callback' => '__return_true',
            'args' => array(
                'refresh_token' => array(
                    'type' => 'string',
                    'required' => true,
                    'description' => __('User Refresh Token.'),
                ),
            ),
        ));

        register_rest_route($this->namespace, '/jwt/logout', array(
            'methods' => 'POST',
            'callback' => array($this, "rest_logout"),
            'permission_callback' => '__return_true',
            'args' => array(
                'refresh_token' => array(
                    'type' => 'string',
                    'required' => true,
                    'description' => __('User Refresh Token.'),
                ),
            ),
        ));

        register_rest_route($this->namespace, '/jwt/validate', array(
            'methods' => 'POST',
            'callback' => array($this, "validate_token"),
            'permission_callback' => '__return_true',
            'args' => array(
                'token' => array(
                    'type' => 'string',
                    'required' => true,
                    'description' => __('Require access token or refresh token.'),
                ),
            ),
        ));

    }

    /**
     * @param $request
     * @return WP_Error
     * @api {POST} /wp-json/buddyboss-app/auth/v2/jwt/login Request token
     * @apiPrivate true
     * @apiName RequestToken
     * @apiGroup Authentication
     * @apiVersion 2.0.0
     * @apiPermission Public
     * @apiDescription Get token on authentication
     * @apiUse apidocForRequestTokenV2
     */
    public function rest_login($request)
    {

        global $bbapp_var;

        $username = $request->get_param('username');
        $password = $request->get_param('password');
        $device_token = $request->get_param('device_token');

        if (empty($username)) {
            return new WP_Error('rest_bbapp_jwt_username_req', __('A valid username param is required.', 'buddyboss-app'), array('status' => 400));
        }

        if (empty($password)) {
            return new WP_Error('rest_bbapp_jwt_password_req', __('A valid password param is required.', 'buddyboss-app'), array('status' => 400));
        }

	    /**
         * Hook can be used to trigger a custom message before user login.
         */

        $flag = apply_filters('bbapp_validate_before_generate_token', true, $request);

        if ($flag !== true) {
            return new WP_Error('rest_bbapp_jwt_error', $flag, array('status' => 404));
        }

	    $accounts = \BuddyBossApp\Auth\Account::instance();

	    // Get user details based on username.
	    $user = $accounts->get_user( $username );
	    /**
	     * User detail check exits or not.
	     */
	    if ( ! $user ) {
		    return new WP_Error( 'rest_bbapp_jwt_invalid_username', __( 'Unknown username. Check again or try your email address.', 'buddyboss-app' ), array( 'status' => 500 ) );
	    }
	    if ( ! wp_check_password( $password, $user->user_pass, $user->ID ) ) {
		    return new WP_Error( 'rest_bbapp_jwt_incorrect_password',
			    sprintf(
			    /* translators: %s: User name. */
				    __( 'The password you entered for the username %s is incorrect.', 'buddyboss-app' ),
				    $username
			    ), array( 'status' => 400 ) );
	    }
	    /**
	     * Check existing user is active or not.
	     */
	    $signup = ( isset( $user->data ) ) ? $accounts->get_signup_user( $user->data->user_email ) : false;
	    if ( $user && ( ! empty( $signup ) && ! $signup->active ) ) {
		    return new Wp_Error( 'bbapp_auth_require_activation', __( 'User account activation is pending.', 'buddyboss-app' ), array( 'status' => 500 ) );
	    }

        /**
         * Generate the token for user.
         */
        $jwt = Jwt::instance();

        $token_args = array(
            'expire_at_days' => 1, // allow only 1 day expire for access token. we have refresh token on service for renew.
        );

        $generate_token = $jwt->generate_user_token($username, $password, true, false, $token_args);

        return $this->generate_user_token_response($generate_token, $device_token);

    }



    /**
     * @param $request
     * @return WP_Error
     * @apiPrivate true
     * @api {POST} /wp-json/buddyboss-app/auth/v2/jwt/access-token Regenerate token
     * @apiName RegenerateAccessToken
     * @apiGroup Authentication
     * @apiVersion 2.0.0
     * @apiPermission Public
     * @apiDescription Regenerate user access token
     * @apiParam device_token Firebase app device token.
     * @apiParam refresh_token User Refresh Token.
     */
    public function rest_access_token($request)
    {

        global $bbapp_var;

        $device_token = $request->get_param('device_token');
        $refresh_token = $request->get_param('refresh_token');

        $jwt = Jwt::instance();

        $validate = $jwt->verify_token($refresh_token);

        if (is_wp_error($validate)) {
            return new WP_Error('jwt_invalid_token', __('Your token is invalid or is expired.', 'buddyboss-app'), array('status' => 401));
        }

        $user = $validate["user"];

        if ($validate["refresh_token"] !== true) {
            return new WP_Error('jwt_invalid_token', __('Given token is not a valid refresh token.', 'buddyboss-app'), array('status' => 401));
        }

        // Everything is validated. lets generate a access token.
        $jwt = Jwt::instance();
        $generate_token = $jwt->generate_jwt_base($user, false, $refresh_token);

        return $this->generate_user_token_response($generate_token, $device_token);

    }

	/**
	 * Handle & Reponse for Successfully Login Situations.
	 *
	 * @param $generate_token
	 *
	 * @param $device_token
	 * @param $uapp_id
	 *
	 * @return WP_Error
	 */
    public function generate_user_token_response($generate_token, $device_token)
    {

	    if ( is_wp_error( $generate_token ) ) {
		    return $generate_token;
	    }

        if (!$generate_token) {
            return new WP_Error('jwt_token_error', __('Error while generating jwt token.', 'buddyboss-app'), array('status' => 401));
        }

        if (!empty($device_token) && isset($generate_token['user_id']) && !empty($generate_token['user_id'])) {
            if (function_exists('bbapp_notifications')) {
                bbapp_notifications()->register_device_for_user($generate_token['user_id'], $device_token, $generate_token['access_token']);
            }
        }

        $response = array(
            "access_token" => $generate_token["token"], # access token
            "refresh_token" => $generate_token["refresh_token"], # refresh token
            "user_display_name" => $generate_token["user_display_name"], # user display name
            "user_nicename" => $generate_token["user_nicename"], # user nicename
            "user_email" => $generate_token["user_email"], # user email
            "user_id" => $generate_token["user_id"], # user id
        );

        return rest_ensure_response($response);
    }

    /**
     * @param $request
     * @return array|bool|WP_Error
     * @apiPrivate true
     * @api {POST} /wp-json/buddyboss-app/auth/v2/jwt/logout Revoke refresh token
     * @apiName RevokeRefreshToken
     * @apiGroup Authentication
     * @apiVersion 2.0.0
     * @apiPermission Public
     * @apiDescription Revoke refresh token
     * @apiParam {String} refresh_token User Refresh Token.
     */
    public function rest_logout($request)
    {

        $refresh_token = @$request->get_param('refresh_token');

        $jwt = Jwt::instance();

        $revoke = $jwt->revoke_jwt_token($refresh_token);

        if (is_wp_error($revoke)) {
            return $revoke;
        }

        do_action("bbapp_auth_delete_jwt_token_request", $request);

        return rest_ensure_response(array(
            'revoked' => true,
        ));
    }

    /**
     * @param $request
     * @return WP_Error
     * @apiPrivate true
     * @api {POST} /wp-json/buddyboss-app/auth/v2/jwt/validate Validate token
     * @apiName ValidateToken
     * @apiGroup Authentication
     * @apiVersion 2.0.0
     * @apiPermission Public
     * @apiDescription Validate if token is valid or not
     * @apiParam {String} token Access token
     */
    public function validate_token($request)
    {

        $token = @$request->get_param('token');

        if (empty($token)) {
            return new WP_Error('rest_bbapp_jwt_token_req', __('A valid token param is required.', 'buddyboss-app'), array('status' => 400));
        }

        $jwt = Jwt::instance();

        $validate = $jwt->verify_token($token);

        if (is_wp_error($validate)) {
            return new WP_Error('jwt_invalid_token', __('Your token is invalid or is expired.', 'buddyboss-app'), array('status' => 401));
        }

        $data = array(
            "user_id" => $validate["user_id"],
        );

        return rest_ensure_response($data);

    }

}