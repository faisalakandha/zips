<?php

namespace BuddyBossApp\Api\WpCore\V2;

class BuddyBossApp_REST_Post_Controller {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return BuddyBossApp_REST_Post_Controller class object.
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;

			self::$instance->extend_post_object();
		}

		return self::$instance;
	}

	public function extend_post_object() {
		register_rest_field(
			'post',
			'comments_count',
			array(
				'get_callback'    => array( $this, 'bbapp_post_comment_counts' ),
				'schema'          => array(
					'description' => 'Post comments count.',
					'type'        => 'integer',
					'context'     => array( 'embed', 'view', 'edit' ),
				),
			)
		);
	}

	/**
	 * Added new object into the post rest api.
	 *
	 * @param WP_Post $post      Post object.
	 * @param string  $attribute The REST Field key used into the REST response.
	 *
	 * @return int|string
	 */
	public function bbapp_post_comment_counts( $post, $attribute ) {
		$post_id = $post['id'];
		return get_comments_number( $post_id );
	}
}