<?php

namespace BuddyBossApp\Api\Notification;


use BuddyBossApp\Api\Notification\V1\RestAPI as RestAPIv1;
use BuddyBossApp\Api\Notification\V2\RestAPI as RestAPIv2;

/**
 * Class Main
 *
 * @package BuddyBossApp\Api\Notification
 */
class Main {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return Main
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * Register all hooks
	 * @since 1.0.0
	 * @return void
	 */
	public function hooks() {
		add_action( 'plugins_loaded', array( $this, '_load' ) );
	}

	/**
	 * Load Notification API versions.
	 */
	public function _load() {
		RestAPIv1::instance();
		RestAPIv2::instance();
	}
}
