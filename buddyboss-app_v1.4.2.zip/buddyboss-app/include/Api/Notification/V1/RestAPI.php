<?php

namespace BuddyBossApp\Api\Notification\V1;

// use BuddyBossApp\ClientCommon;
use BuddyBossApp\Notification\Notification;
use BuddyBossApp\RestErrors;


/**
 * @deprecated
 * @todo :- Remove the rest API and convert it into dummy once all old codes are migrated.
 */

/**
 * Contain functionality for required additional rest api endpoints.
 * v1 Standard
 * Class RestAPI
 *
 * @package BuddyBossApp\Api\Notification\V1
 */
class RestAPI extends \WP_REST_Controller {

	protected $namespace_slug = '';
	protected $namespace = "buddyboss-app/core/v1";
	public static $instance;

	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class();
			self::$instance->hooks();
		}

		return self::$instance;
	}

	public function hooks() {
		add_action( 'rest_api_init', array( $this, "register_routes" ), 99 );
		add_filter( "init", array( $this, "register_header" ), 20 );
		add_filter( 'bbapp_notification_api_response_entry', array( $this, "bbapp_notification_api_response_entry" ), 99, 2 );
	}

	/**
	 * Register routes.
	 */
	public function register_routes() {

		register_rest_route( $this->namespace, '/notification/settings', array(
			array(
				'methods'  => \WP_REST_Server::READABLE,
				'callback' => array( $this, 'get_notification_settings' ),
				'permission_callback' => '__return_true',
				'args'     => array(),
			),
			array(
				'methods'  => \WP_REST_Server::CREATABLE,
				'callback' => array( $this, 'update_notification_settings' ),
				'permission_callback' => '__return_true',
				'args'     => array(),
			)
		) );

	}

	/**
	 * Notification settings.
	 *
	 * @param $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|\WP_REST_Response
     * @apiPrivate
	 * @api {GET} /wp-json/buddyboss-app/core/v1/notification/settings Core notification settings
     * @apiName GetCoreNotificationSettings
     * @apiGroup CoreNotifications
     * @apiVersion 1.0.0
     * @apiPermission Public
     * @apiDescription Get core notification settings
	 */
	public function get_notification_settings( $request ) {
		global $bbapp_var;

		/**
		 * Check user logged in permissions.
		 */
		if ( ! is_user_logged_in() ) {
			return RestErrors::instance()->user_not_logged_in();
		}

		$settings_list = Notification::instance()->get_push_notification_subs_for_user( get_current_user_id() );

		$response = array();

		foreach ( $settings_list as $sub_name => $sub ) {
			$response[] = array_merge( array(
				"name" => $sub_name,
			), $sub );
		}

		return rest_ensure_response( $response );

	}

	/**
	 * Update notification settings.
	 *
	 * @param $request
	 *
	 * @return \WP_Error|\WP_HTTP_Response|\WP_REST_Response
     * @apiPrivate
	 * @api {POST} /wp-json/buddyboss-app/core/v1/notification/settings Update core notification settings
     * @apiName UpdateCoreNotificationSettings
     * @apiGroup CoreNotifications
     * @apiVersion 1.0.0
     * @apiPermission Public
     * @apiDescription Update core notification settings
	 */
	public function update_notification_settings( $request ) {
		global $bbapp_var;

		/**
		 * Check user logged in permissions.
		 */
		if ( ! is_user_logged_in() ) {
			return RestErrors::instance()->user_not_logged_in();
		}

		$notification_settings_list = Notification::instance()->get_push_notification_subs_for_user( get_current_user_id() );

		$sub_data = Notification::instance()->get_push_notification_subs( get_current_user_id() );

		foreach ( $notification_settings_list as $notification_setting ) {
			if ( isset( $notification_setting['settings'] ) ) {
				foreach ( $notification_setting['settings'] as $sub_name => $sub ) {
					if ( isset( $request[ $sub_name ] ) && $sub["available"] ) {
						if ( $request[ $sub_name ] == "1" ) {
							$sub_data[ $sub_name ] = true;
						} else {
							$sub_data[ $sub_name ] = false;
						}
					}
				}
			}
		}

		Notification::instance()->update_push_notification_subs( get_current_user_id(), $sub_data );

		return $this->get_notification_settings( $request );

	}

	/**
	 * Add the headers for notification rest API.
	 *
	 * @param $result
	 * @param $server
	 * @param $request
	 *
	 * @return mixed
	 */
	public function register_header() {

		if ( is_user_logged_in() && function_exists( 'bbapp_notifications' ) ) {

			$count = bbapp_notifications()->get_notification_count( get_current_user_id() );

			header( "bbapp-unread-notifications:" . $count );
			// Deprecated Support.
			header( "bbp-unread-notifications:" . $count );

		}
	}

	public function prepare_notifications_response( $val ) {

		$response = rest_ensure_response( $val );

		$uris = array();

		$uris[] = array( "author", rest_url( '/wp/v2/users/' . $val["author_id"] ) );

		if ( ! empty( $val["user_id"] ) && $val["user_id"] != $val["author_id"] ) {
			$uris[] = array( "author", rest_url( '/wp/v2/users/' . $val["user_id"] ) );
		}

		foreach ( $uris as $uri ) {
			$response->add_link( $uri[0], $uri[1], array( 'embeddable' => true ) );
		}

		return $response;

	}

	/**
	 * Generate the SQL Query for Notification
	 *
	 * @param array $args
	 *
	 * @return string the sql query
	 */
	protected function _get_notifications_sql_query( $args ) {

		global $wpdb;

		$where_clause = array();

		$settings_actions = array();

		if ( is_user_logged_in() ) {
			// get user push notification settings
			$actions = get_user_meta( get_current_user_id(), 'push_notification_settings', true );
			if ( ! is_array( $actions ) ) {
				$actions = json_decode( $actions, true );
			}
			if ( ! empty( $actions ) ) {
				foreach ( $actions as $key => $value ) {
					if ( ! $value ) {
						$settings_actions[] = $key;

						//Deprecated support for manual support
						if ( $key == 'manual_push_notification' ) {
							$settings_actions[] = 'manual_push';
						}
					}
				}
			}
		}

		if ( $args["action"] ) {
			$settings_actions = $args["action"];
		}

		/**
		 * Allow plugins to filter the notification output based on actions.
		 */
		$settings_actions = apply_filters( 'bbapp_push_notification_actions', $settings_actions );

		if ( ! empty( $settings_actions ) ) {
			$actions        = array_map( function ( $v ) {
				return "'" . esc_sql( $v ) . "'";
			}, $settings_actions );
			$actions        = implode( ',', $actions );
			$where_clause[] = "action NOT IN ( " . $actions . " )";
		}

		// filter by after
		if ( isset( $args["after"] ) ) {
			$args["after"]  = date( "Y-m-d H:i:s", strtotime( $args["after"] ) );
			$where_clause[] = $wpdb->prepare( " date_notified >= %s ", $args["after"] );
		}

		if ( isset( $args["user_id"] ) ) {
			$where_clause[] = $wpdb->prepare( " ( user_id = %d )", $args["user_id"] );
		}

		$where_clause[] = $wpdb->prepare( " blog_id = %d ", get_current_blog_id() );
		$where_clause[] = $wpdb->prepare( " version = %d ", 1 );

		$where_clause = implode( " AND ", $where_clause );

		if ( ! empty( $where_clause ) ) {
			$where_clause = "WHERE {$where_clause}";
		}

		$table = bbapp_get_network_table( 'bbapp_notifications' );

		$sql_queries = ( "SELECT
			`{$table}`.id as 'id',
			`{$table}`.date_notified as 'date_notified',
			`{$table}`.action as 'action',
			`{$table}`.user_id as 'user_id',
			`{$table}`.item_id as 'item_id',
			`{$table}`.author_id as 'author_id',
			`{$table}`.secondary_item_id as 'secondary_item_id',
			`{$table}`.primary_text as 'primary_text',
			`{$table}`.secondary_text as 'secondary_text',
		    `{$table}`.namespace AS 'namespace'
			FROM {$table} {$where_clause}" );

		$limit_clause = "";
		if ( ! empty( $args["per_page"] ) ) {

			$per_page   = intval( $args["per_page"] );
			$page       = max( $args["page"], 1 );
			$start_from = ( $page - 1 ) * $per_page;

			if ( ( ! is_numeric( $args["only_recent"] ) ) || ( is_numeric( $args["only_recent"] ) && $per_page < $args["only_recent"] ) ) {
				$limit_clause = "LIMIT {$start_from}, {$per_page}";
			} else {
				$args["only_recent"] = min( $args["only_recent"], 100 ); //keep 100 max so we don't crash db
				$limit_clause        = "LIMIT 0, {$args["only_recent"]}";
			}
		}

		return sprintf( "%s ORDER BY `date_notified` DESC, `id` DESC %s", $sql_queries, $limit_clause );
	}

	/**
	 * Adds the common embeddable on Notification Rest API.
	 *
	 * @param $response
	 * @param $args
	 *
	 * @return mixed
	 */
	public function bbapp_notification_api_response_entry( $response, $args ) {

		$data = $response->get_data();

		if ( ! is_array( $data ) || $data['namespace'] != "push_notification" ) {
			return $response;
		}

		// Due to Old API Release We have to Modify Some Properties for Manual Push Notification Type.

		$uris = array();

		if ( $data["action"] == "manual_push" ) {

			$data["item_id"]           = $data["primary_text"];
			$data["secondary_item_id"] = $data["secondary_text"];
			$data["action"]            = "manual_push_notification";

			if ( ! empty( $data["user_id"] ) ) {
				$uris[] = array( "author", rest_url( '/wp/v2/users/' . $data["user_id"] ) );
			}
			if ( ! empty( $data["author_id"] ) ) {
				$uris[] = array( "author", rest_url( '/wp/v2/users/' . $data["author_id"] ) );
			}

			$response->set_data( $data ); // update the modified properties.

		}

		foreach ( $uris as $uri ) {
			$response->add_link( $uri[0], $uri[1], array( 'embeddable' => true ) );
		}

		return $response;
	}
}