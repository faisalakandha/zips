<?php

namespace BuddyBossApp\Api\LearnDash\V1\Assignments;

use BuddyBossApp\Api\LearnDash\V1\Lesson\LessonsError;
use BuddyBossApp\Api\LearnDash\V1\Topic\TopicsError;
use BuddyBossApp\Helpers\BBAPP_File;
use WP_Error;
use WP_REST_Request;
use WP_REST_Server;

class AssignmentsActionRest extends AssignmentsRest {

	/**
	 * @var $instance
	 */
	protected static $instance;

	/**
	 * singleton instance.
	 *
	 * @since 0.1.0
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 */
	public function __construct() {
		parent::__construct();
	}

	/**
	 * Register the component routes.
	 *
	 * @since 0.1.0
	 */
	public function register_routes() {

		register_rest_route( $this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)/upload', array(
				array(
					'methods'             => WP_REST_Server::EDITABLE,
					'callback'            => array( $this, 'upload' ),
					'permission_callback' => array( $this, 'get_upload_permissions_check' ),
					'args'                => array(
						'context' => $this->get_context_param( array( 'default' => 'view' ) ),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			) );
	}

	/**
	 * Check if a given request has access to upload assignment item.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool|WP_Error
	 * @since 0.1.0
	 */
	public function get_upload_permissions_check( $request ) {

		$retval = true;
		if ( ! is_user_logged_in() ) {
			$retval = AssignmentsError::instance()->userNotLoggedIn();
		}

		/**
		 * Assignments setting.
		 */
		if ( true === $retval ) {
			$is_enable = $this->enable_assignment_comment();
			$retval    = ( true === $is_enable ) ? true : AssignmentsError::instance()->enableCommentOnAssignmentSetting();
		}

		/**
		 * Filter the Assignment `upload` permissions check.
		 *
		 * @param bool|WP_Error   $retval  Returned value.
		 * @param WP_REST_Request $request The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		return apply_filters( 'bbapp_ld_assignment_upload_permissions_check', $retval, $request );
	}

	/**
	 * Upload Assignment file.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return \WP_REST_Response|WP_Error|boolean
	 * @since          0.1.0
	 *
	 * @api            {POST} /wp-json/buddyboss-app/learndash/v1/assignments/:id/upload Upload LearnDash Assignment file.
	 * @apiName        LDAssignmentUpload
	 * @apiGroup       LD Assignments
	 * @apiDescription Upload Assignments file. This endpoint requires request to be sent in "multipart/form-data" format.
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiParam {Number} id A unique numeric ID for the Assignment.
	 * @apiParam {File} [ attachment ] A file to upload for Assignment file.
	 */
	public function upload( $request ) {
		$user_id   = get_current_user_id();
		$lesson_id = 0;
		$topic_id  = 0;
		$post      = null;

		$id = $request->get_param( 'id' );

		if ( learndash_get_post_type_slug( 'lesson' ) !== get_post_type( $id ) && learndash_get_post_type_slug( 'topic' ) !== get_post_type( $id ) ) {
			return AssignmentsError::instance()->invalidProvidedID();
		}

		if ( learndash_get_post_type_slug( 'lesson' ) === get_post_type( $id ) ) {
			$lesson_id = $id;
			$post      = get_post( $lesson_id );
		}

		if ( learndash_get_post_type_slug( 'topic' ) === get_post_type( $id ) ) {
			$topic_id  = $id;
			$lesson_id = get_post_meta( $topic_id, 'lesson_id', true );
			$post      = get_post( $topic_id );
		}

		if ( empty( $post ) ) {
			return AssignmentsError::instance()->invalidId();
		}

		if ( ! $this->get_lesson_topic_assignment_upload( $post ) ) {
			return AssignmentsError::instance()->invalidPermission();
		}

		if ( empty( $_FILES ) ) {
			return AssignmentsError::instance()->AssignmentEmptyFile();
		}

		if ( ! sfwd_lms_has_access( $lesson_id, $user_id ) ) {
			return AssignmentsError::instance()->invalidAccess();
		}

		$created_assignment_id = $this->upload_attachment_file( $lesson_id, $topic_id );

		if ( is_wp_error( $created_assignment_id ) ) {
			return $created_assignment_id;
		} else if ( is_numeric( $created_assignment_id ) ) {
			$request['assignment_id'] = $created_assignment_id;

			return $this->get_item( $request );
		}

		return false;
	}

	/**
	 * Upload assignment attachment file.
	 *
	 * @param     $lesson_id
	 * @param int $topic_id
	 *
	 * @return bool|int|void|WP_Error
	 */
	public function upload_attachment_file( $lesson_id, $topic_id = 0 ) {
		$assignment_id = 0;
		if ( ! empty( $_FILES['attachment'] ) ) {

			$post_id = ! empty( $topic_id ) ? $topic_id : $lesson_id;

			/**
			 * Assignment Upload process
			 */

			if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
				require_once ABSPATH . "wp-admin" . '/includes/image.php';
				require_once ABSPATH . "wp-admin" . '/includes/file.php';
				require_once ABSPATH . "wp-admin" . '/includes/media.php';
			}

			if ( ! function_exists( 'media_handle_upload' ) ) {
				require_once ABSPATH . 'wp-admin/includes/admin.php';
			}

			$_FILES['attachment']['name'] = learndash_clean_filename( $_FILES['attachment']['name'] );

			// Before this function we have already validated the file extention/type via the function learndash_check_upload
			// @2.5.4
			$file_title = pathinfo( basename( $_FILES['attachment']['name'] ), PATHINFO_FILENAME );
			$file_ext   = pathinfo( basename( $_FILES['attachment']['name'] ), PATHINFO_EXTENSION );

			if ( ! function_exists( 'wp_get_current_user' ) ) {
				include ABSPATH . 'wp-includes/pluggable.php';
			}

			$filetype  = wp_check_filetype( basename( $_FILES['attachment']['name'] ), null );
			$filetitle = preg_replace( '/\.[^.]+$/', '', basename( $_FILES['attachment']['name'] ) );

			$upload_dir      = wp_upload_dir();
			$upload_dir_base = $upload_dir['basedir'];
			$upload_dir_path = $upload_dir_base . '/assignments';

			if ( ! file_exists( $upload_dir_path ) ) {
				BBAPP_File::CreateDir( $upload_dir_path );
			}

			// Add an index.php file to prevent directory browesing
			$_index = trailingslashit( $upload_dir_path ) . 'index.php';
			if ( ! file_exists( $_index ) ) {
				learndash_put_directory_index_file( $_index );
			}

			$file_time = microtime( true ) * 100;
			$filename  = sprintf( 'assignment_%d_%d_%s.%s', $post_id, $file_time, $file_title, $file_ext );

			/**
			 * Filters the assignment upload filename.
			 *
			 * @param string $filename   File name.
			 * @param int    $post_id    Post ID.
			 * @param string $file_time  Unix timestamp.
			 * @param string $file_title Title of the file.
			 * @param string $file_ext   File extention.
			 *
			 * @since 3.2.0
			 *
			 */
			$filename = apply_filters( 'learndash_assignment_upload_filename', $filename, $post_id, $file_time, $file_title, $file_ext );

			/**
			 * Check if the filename already exist in the directory and rename the
			 * file if necessary
			 */
			$i = 0;

			while ( file_exists( $upload_dir_path . '/' . $filename ) ) {
				$i ++;
				$filename = $filetitle . '_' . $i . '.' . $filetype['ext'];
			}

			$_FILES['attachment']['name'] = $filename;
			$filedest                     = $upload_dir_path . '/' . $filename;

			/**
			 * Check write permissions
			 */
			if ( ! is_writeable( $upload_dir_path ) ) {
				return LessonsError::instance()->AssignmentDirNotWriteable();
			}

			add_filter( 'upload_dir', 'bbapp_lms_media_upload_dir' );
			$attachment_id = media_handle_upload( 'attachment', $lesson_id );
			remove_filter( 'upload_dir', 'bbapp_lms_media_upload_dir' );

			// if has wp error then throw it.
			if ( is_wp_error( $attachment_id ) ) {
				return $attachment_id;
			}

			$attachment = get_post( $attachment_id );

			if ( ! empty( $attachment ) ) {
				$assignment_id = bbapp_lms_upload_assignment_init( $post_id, $filename, $filedest );
			}
		} else {
			if ( ! empty( $topic_id ) ) {
				return TopicsError::instance()->topicAssignmentNotCompleted();
			} else {
				return LessonsError::instance()->lessonAssignmentNotCompleted();
			}
		}

		return $assignment_id;
	}

	/**
	 * @param $post
	 *
	 * @return bool
	 */
	protected function get_lesson_topic_assignment_upload( $post ) {
		return lesson_hasassignments( $post );
	}
}