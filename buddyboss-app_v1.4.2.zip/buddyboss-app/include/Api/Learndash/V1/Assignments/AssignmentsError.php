<?php

namespace BuddyBossApp\Api\LearnDash\V1\Assignments;

use BuddyBossApp\RestErrors;
use WP_Error;


class AssignmentsError {
	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return RestErrors
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
		}

		return self::$instance;
	}

	/**
	 * When user is not logged in this error message should be used.
	 * @return WP_Error
	 */
	public function userNotLoggedIn() {
		return RestErrors::instance()->user_not_logged_in();
	}

	/**
	 * When Assignment id not correct.
	 * @return WP_Error
	 */
	public function awaitingForApprovalAssignment() {
		return new WP_Error( 'learndash_json_assignment_awaiting_for_approval', __( 'You have an assignment awaiting approval.', 'buddyboss-app' ), array( 'status' => 202 ) );
	}

	/**
	 * When Assignment id not correct.
	 * @return WP_Error
	 */
	public function invalidAssignmentId() {
		return new WP_Error( 'learndash_json_assignment_invalid_id', __( 'Assignment not found.', 'buddyboss-app' ), array( 'status' => 404 ) );
	}

	/**
	 * When Assignment file is empty.
	 * @return WP_Error
	 */
	public function AssignmentEmptyFile() {
		return new WP_Error( 'learndash_json_assignment_file_empty', __( "Assignment file shouldn’t be empty.", 'buddyboss-app' ), array( 'status' => 400 ) );
	}

	/**
	 * When Assignment id not correct.
	 * @return WP_Error
	 */
	public function invalidId() {
		return new WP_Error( 'learndash_json_invalid_id', __( 'Lesson/Topic not found.', 'buddyboss-app' ), array( 'status' => 404 ) );
	}

	/**
	 * Assignment file upload permission.
	 * @return WP_Error
	 */
	public function invalidPermission() {
		return new WP_Error( 'learndash_json_assignment_upload permission', __( "Lesson/Topic does not allow uploading an assignment.", 'buddyboss-app' ), array( 'status' => 400 ) );
	}

	/**
	 * When user don't have lesson/topic access.
	 * @return WP_Error
	 */
	public function invalidAccess() {
		return new WP_Error( 'learndash_json_invalid_access', __( 'You do not have access to this lesson/topic.', 'buddyboss-app' ), array( 'status' => 400 ) );
	}

	/**
	 * When user don't have lesson/topic access.
	 * @return WP_Error
	 */
	public function AssignmentAuthorizationRequired() {
		return new WP_Error( 'bbapp_rest_authorization_required', __( 'Sorry, you are not allowed to delete this assignment.', 'buddyboss-app' ), array( 'status' => is_user_logged_in() ? 403 : 401 ) );
	}

	/**
	 * When user don't have lesson/topic access.
	 * @return WP_Error
	 */
	public function invalidUserAccess() {
		return new WP_Error( 'learndash_json_invalid_user_access', __( 'You do not have access to delete this assignment.', 'buddyboss-app' ), array( 'status' => 400 ) );
	}

	/**
	 * Can not delete assignment.
	 * @return WP_Error
	 */
	public function cannotDeleteAssignment() {
		return new WP_Error( 'learndash_json_can_not_delete_assignment', __( 'Cannot delete the assignment.', 'buddyboss-app' ), array( 'status' => 400 ) );
	}

	/**
	 * Can not delete assignment.
	 * @return WP_Error
	 */
	public function enableCommentOnAssignmentSetting() {
		return new WP_Error( 'learndash_json_enable_comment_on_assignment_setting', __( 'Enable comment on assignment setting.', 'buddyboss-app' ), array( 'status' => 400 ) );
	}

	/**
	 * Lesson or Topic is is invalid.
	 * @return WP_Error
	 */
	public function invalidProvidedID() {
		return new WP_Error( 'learndash_json_invalid_provided_id', __( 'Invalid provided lesson or topic ID.', 'buddyboss-app' ), array( 'status' => 400 ) );
	}

}