<?php

namespace BuddyBossApp\Api\LearnDash\V1\Topic;

use BuddyBossApp\Api\LearnDash\V1\Core\LDRestController;
use BuddyBossApp\Api\LearnDash\V1\Course\CoursesError;
use LDLMS_Factory_Post;
use LearnDash_Settings_Section;
use WP_Error;
use WP_Query;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

class TopicsRest extends LDRestController {

	protected static $instance;

	protected $post_type = 'sfwd-topic';

	/**
	 * singleton instance.
	 *
	 * @since 0.1.0
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 */
	public function __construct() {
		$this->rest_base = 'topics';
		parent::__construct();
	}

	/**
	 * Check if a given request has access to topic items.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool|WP_Error
	 * @since 0.1.0
	 */
	public function get_items_permissions_check( $request ) {

		$retval = true;

		/**
		 * Filter the topic `get_items` permissions check.
		 *
		 * @param bool|WP_Error   $retval  Returned value.
		 * @param WP_REST_Request $request The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		return apply_filters( 'bbapp_ld_topics_permissions_check', $retval, $request );
	}

	/**
	 * Check if a given request has access to topic item.
	 *
	 * @param WP_REST_Request $request Full data about the request.
	 *
	 * @return bool|WP_Error
	 * @since 0.1.0
	 */
	public function get_item_permissions_check( $request ) {

		$retval = true;

		/**
		 * Filter the topic `get_item` permissions check.
		 *
		 * @param bool|WP_Error   $retval  Returned value.
		 * @param WP_REST_Request $request The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		return apply_filters( 'bbapp_ld_topic_permissions_check', $retval, $request );
	}

	/**
	 * Register the component routes.
	 *
	 * @since 0.1.0
	 */
	public function register_routes() {

		register_rest_route( $this->namespace,
			'/' . $this->rest_base, array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_items' ),
					'permission_callback' => array( $this, 'get_items_permissions_check' ),
					'args'                => $this->get_collection_params(),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			) );

		register_rest_route( $this->namespace,
			'/' . $this->rest_base . '/(?P<id>[\d]+)', array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'get_item' ),
					'permission_callback' => array( $this, 'get_item_permissions_check' ),
					'args'                => array(
						'context' => $this->get_context_param( array( 'default' => 'view' ) ),
					),
				),
				'schema' => array( $this, 'get_public_item_schema' ),
			) );
	}


	/**
	 * Retrieve Topics.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 * @since          0.1.0
	 *
	 * @api            {GET} /wp-json/buddyboss-app/learndash/v1/topics Get LearnDash Topics
	 * @apiName        GetLDTopics
	 * @apiGroup       LD Topics
	 * @apiDescription Retrieve Topics
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiParam {Number} [page] Current page of the collection.
	 * @apiParam {Number} [per_page=10] Maximum number of items to be returned in result set.
	 * @apiParam {String} [search] Limit results to those matching a string.
	 * @apiParam {Array} [exclude] Ensure result set excludes specific IDs.
	 * @apiParam {Array} [include] Ensure result set includes specific IDs.
	 * @apiParam {String} [after]  Limit results to those published after a given ISO8601 compliant date.
	 * @apiParam {String} [before] Limit results to those published before a given ISO8601 compliant date.
	 * @apiParam {Array} [author] Limit results to those assigned to specific authors.
	 * @apiParam {Array} [author_exclude] Ensure results to excludes those assigned to specific authors.
	 * @apiParam {String=asc,desc} [order=desc] Sort result set by given order.
	 * @apiParam {String=date,id,title,menu_order} [orderby=date] Sort result set by given field.
	 * @apiParam {Array} [parent] Limit results to those assigned to specific parent.
	 */
	public function get_items( $request ) {
		$user_id = get_current_user_id();

		$registered = $this->get_collection_params();

		/**
		 * Filter the the request.
		 *
		 * @param WP_REST_Request $request The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		$request = apply_filters( 'bbapp_ld_get_topics_request', $request );

		/**
		 * This array defines mappings between public API query parameters whose
		 * values are accepted as-passed, and their internal WP_Query parameter
		 * name equivalents (some are the same). Only values which are also
		 * present in $registered will be set.
		 */
		$parameter_mappings = array(
			'author'         => 'author__in',
			'author_exclude' => 'author__not_in',
			'exclude'        => 'post__not_in',
			'include'        => 'post__in',
			'offset'         => 'offset',
			'order'          => 'order',
			'orderby'        => 'orderby',
			'page'           => 'paged',
			'parent'         => 'post_parent__in',
			'parent_exclude' => 'post_parent__not_in',
			'search'         => 's',
			'slug'           => 'post_name__in',
			'status'         => 'post_status',
			'per_page'       => 'posts_per_page',
		);

		/**
		 * For each known parameter which is both registered and present in the request,
		 * set the parameter's value on the query $args.
		 */
		foreach ( $parameter_mappings as $api_param => $wp_param ) {
			if ( isset( $registered[ $api_param ], $request[ $api_param ] ) ) {
				$args[ $wp_param ] = $request[ $api_param ];
			} else if ( isset( $registered[ $api_param ]['default'] ) ) {
				$args[ $wp_param ] = $registered[ $api_param ]['default'];
			}
		}

		// Check for & assign any parameters which require special handling or setting.
		$args['date_query'] = array();

		// Set before into date query. Date query must be specified as an array of an array.
		if ( isset( $registered['before'], $request['before'] ) ) {
			$args['date_query'][0]['before'] = $request['before'];
		}

		// Set after into date query. Date query must be specified as an array of an array.
		if ( isset( $registered['after'], $request['after'] ) ) {
			$args['date_query'][0]['after'] = $request['after'];
		}

		$args = $this->prepare_items_query( $args, $request );

		/**
		 * Filter the query arguments for the request.
		 *
		 * @param array           $args    Key value array of query var to query value.
		 * @param WP_REST_Request $request The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		$args = apply_filters( 'bbapp_ld_get_topics_args', $args, $request );

		$args['post_type'] = $this->post_type;

		/**
		 * if User pass course id & lesson id then return topic list
		 *  - We want list to list out topic on lesson page
		 * else return topic if user has access of the topic course
		 **/
		if ( isset( $request['course_id'] ) && isset( $request['lesson_id'] ) ) {
			$course_id = isset( $request['course_id'] ) ? (int) $request['course_id'] : false;
			$lesson_id = isset( $request['lesson_id'] ) ? (int) $request['lesson_id'] : false;

			/**
			 * Support lesson/topics order setting of course
			 */
			$default_args = sfwd_lms_get_post_options( $this->post_type );
			//We are not supporting custom pagination option
			/*if ( isset( $default_args['course_pagination_enabled'] ) && 'yes' == $default_args['course_pagination_enabled'] ) {
				$args['posts_per_page'] = ! empty( $default_args['course_pagination_topics'] ) ? $default_args['course_pagination_topics'] : $args['posts_per_page'];
			}*/

			if ( isset( $default_args['lesson_topic_order_enabled'] ) && 'yes' == $default_args['lesson_topic_order_enabled'] ) {
				$args['order']   = ! empty( $default_args['lesson_topic_order'] ) ? $default_args['lesson_topic_order'] : $args['order'];
				$args['orderby'] = ! empty( $default_args['lesson_topic_orderby'] ) ? $default_args['lesson_topic_orderby'] : $args['orderby'];
			}

			$is_custom_order = bbapp_learndash_get_course_meta_setting( $course_id, 'course_lesson_order_enabled' );
			if ( 'on' == $is_custom_order ) {
				$order           = bbapp_learndash_get_course_meta_setting( $course_id, 'course_lesson_order' );
				$orderby         = bbapp_learndash_get_course_meta_setting( $course_id, 'course_lesson_orderby' );
				$args['order']   = ! empty( $order ) ? $order : $args['order'];
				$args['orderby'] = ! empty( $orderby ) ? $orderby : $args['orderby'];
			}

			//We are not supporting custom pagination option
			/*$is_custom_per_page = bbapp_learndash_get_course_meta_setting( $course_id, 'course_lesson_per_page' );
			if ( 'CUSTOM' == $is_custom_per_page ) {
				$per_page               = bbapp_learndash_get_course_meta_setting( $course_id, 'course_topic_per_page_custom' );
				$args['posts_per_page'] = ! empty( $per_page ) ? $per_page : $args['posts_per_page'];
			}*/

			$_course_ids = array( $course_id );

			//Get Topics ids by lesson id
			$topic_ids = array( - 1 );
			$ld_course_steps_object = LDLMS_Factory_Post::course_steps( $course_id );
			if ( $ld_course_steps_object ){
				$ld_course_steps_object->load_steps();
				$steps = $ld_course_steps_object->get_steps();
				if ( ( isset( $steps['sfwd-lessons'][ $lesson_id ]['sfwd-topic'] ) ) && ( ! empty( $steps['sfwd-lessons'][ $lesson_id ]['sfwd-topic'] ) ) ) {
					$topic_ids = array_keys( $steps['sfwd-lessons'][ $lesson_id ]['sfwd-topic'] );
				}
			}
		} else {
			$_course_ids = ld_get_mycourses( $user_id, array() );
			$topic_ids   = array();
		}

		global $wpdb;
		if ( ! empty( $_course_ids ) ) {
			//if Course builder enabled then fetch lesson by that otherwise fetch by meta
			if ( LearnDash_Settings_Section::get_section_setting( 'LearnDash_Settings_Courses_Builder', 'enabled' ) == 'yes' ) {

				if ( empty( $topic_ids ) ) {
					/**
					 * Filter Topics ids by course which users has access
					 * Instead of using core function to fetch topics of course/lesson one by one we use custom query to improve performance.
					 */
					$_course_str = implode( ',', $_course_ids );
					$topic_ids   = $wpdb->get_col( "SELECT `post_id` FROM $wpdb->postmeta WHERE meta_value IN ($_course_str) AND (`meta_key` LIKE '%ld_course_%' OR  `meta_key`LIKE 'course_id' ) ORDER BY `meta_id` ASC" );
				}

				if ( ! empty( $topic_ids ) ) {
					if ( ! empty( $args['post__in'] ) ) {
						if ( ! is_array( $args['post__in'] ) ) {
							$args['post__in'] = array( $args['post__in'] );
						}
						$topic_ids = array_intersect( $args['post__in'], $topic_ids );
						if ( empty( $topic_ids ) ) {
							$topic_ids = array( - 1 );
						}
					}
					$args['post__in'] = $topic_ids;

					/**
					 * If argument $args['post__in'] available at that time orderby should work based on post__in.
					 */
					if ( isset( $args['post__in'] ) ) {
						$args['orderby'] = 'post__in';
						unset( $args['order'] );
					}
					/**
					 * Set order if we requesting more then one course topics
					 * For single course lesson's topic request we use Course setting order
					 */
					if ( ! isset( $request['course_id'] ) || ! isset( $request['lesson_id'] ) ) {
						$args['orderby'] = ( isset( $args['s'] ) ) ? 'relevance' : 'post__in';
						unset( $args['order'] );
					}
				} else {
					$args['post__in'] = array( - 1 );
				}
			} else {
				/**
				 * Fetch lesson with old structure
				 */
				if ( isset( $request['course_id'] ) && isset( $request['lesson_id'] ) ) {
					//Filter topic if course and lesson id pass
					$lesson_id = isset( $request['lesson_id'] ) ? (int) $request['lesson_id'] : false;

					$args['meta_query'][] = array(
						'key'     => 'lesson_id',
						'value'   => $lesson_id,
						'compare' => 'IN',
					);
				} else {
					//Filter topic by course which users has access
					$args['meta_query'][] = array(
						'key'     => 'course_id',
						'value'   => $_course_ids,
						'compare' => 'IN',
					);
				}
			}
		}

		/**
		 * Taxonomy Filter query
		 */
		$taxonomies = wp_list_filter( get_object_taxonomies( $this->post_type, 'objects' ), array( 'show_in_rest' => true ) );
		foreach ( $taxonomies as $taxonomy ) {
			$base = ! empty( $taxonomy->rest_base ) ? $taxonomy->rest_base : $taxonomy->name;

			if ( ! empty( $request[ $base ] ) ) {
				$args['tax_query'][] = array(
					'taxonomy'         => $taxonomy->name,
					'field'            => 'term_id',
					'terms'            => $request[ $base ],
					'include_children' => false,
				);
			}
		}

		$posts_query           = new WP_Query();
		$topics['posts']       = $posts_query->query( $args );
		$topics['total_posts'] = $posts_query->found_posts;

		/**
		 * Fires list of Topics is fetched via Query.
		 *
		 * @param array            $topics Fetched topics.
		 * @param WP_REST_Response $args    Query arguments.
		 * @param WP_REST_Request  $request The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		$topics = apply_filters( 'bbapp_ld_get_topics', $topics, $args, $request );

		$retval = array();
		foreach ( $topics['posts'] as $topic ) {
			if ( ! $this->check_read_permission( $topic ) ) {
				continue;
			}
			$retval[] = $this->prepare_response_for_collection(
				$this->prepare_item_for_response( $topic, $request )
			);
		}

		$response = rest_ensure_response( $retval );
		$response = bbapp_learners_response_add_total_headers( $response, $topics['total_posts'], $args['posts_per_page'] );


		/**
		 * Fires after a list of topics respose is prepared via the REST API.
		 *
		 * @param WP_REST_Response $response The response data.
		 * @param WP_REST_Request  $request  The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		do_action( 'bbapp_ld_topic_items_response', $response, $request );

		return $response;
	}


	/**
	 * Retrieve Topic.
	 *
	 * @param WP_REST_Request $request Full details about the request.
	 *
	 * @return WP_REST_Response
	 * @since          0.1.0
	 *
	 * @api            {GET} /wp-json/buddyboss-app/learndash/v1/topics/:id Get LearnDash Topic
	 * @apiName        GetLDTopic
	 * @apiGroup       LD Topic
	 * @apiDescription Retrieve single Topic
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiParam {Number} id A unique numeric ID for the Topic.
	 */
	public function get_item( $request ) {
		$topic_id = is_numeric( $request ) ? $request : (int) $request['id'];

		$topic = get_post( $topic_id );

		if ( empty( $topic ) || $this->post_type !== $topic->post_type ) {
			return TopicsError::instance()->invalidTopicId();
		}

		/**
		 * Fire after Topic is fetched via Query.
		 *
		 * @param array           $topic   Fetched Topic.
		 * @param WP_REST_Request $topic_id Topic id.
		 *
		 * @since 0.1.0
		 */
		$topic = apply_filters( 'bbapp_ld_get_topic', $topic, $topic_id );

		$retval = $retval = $this->prepare_response_for_collection(
			$this->prepare_item_for_response( $topic, $request )
		);

		$response = rest_ensure_response( $retval );

		/**
		 * Fires after an topic response is prepared via the REST API.
		 *
		 * @param WP_REST_Response $response The response data.
		 * @param WP_REST_Request  $request  The request sent to the API.
		 *
		 * @since 0.1.0
		 */
		do_action( 'bbapp_ld_topic_item_response', $response, $request );

		return $response;
	}

	/**
	 * Prepare a single post output for response.
	 *
	 * @param WP_Post         $post    Post object.
	 * @param WP_REST_Request $request Request object.
	 *
	 * @return WP_REST_Response $data
	 */
	public function prepare_item_for_response( $post, $request ) {
		$GLOBALS['post'] = $post;
		setup_postdata( $post );

		$context = ! empty( $request['context'] ) ? $request['context'] : 'view';
		$schema  = $this->get_public_item_schema();

		$post->has_content_access   = $this->get_has_content_access( $post );

		// Base fields for every post.
		$data = array(
			'id'           => $post->ID,
			'title'        => array(
				'raw'      => $post->post_title,
				'rendered' => get_the_title( $post->ID ),
			),
			'content'      => array(
				'raw'      => ( $post->has_content_access ) ? bbapp_learners_fix_relative_urls_protocol( $post->post_content ) : '',
				'rendered' => ( $post->has_content_access ) ? bbapp_learners_fix_relative_urls_protocol( apply_filters( 'the_content', $post->post_content ) ) : '',
			),
			'date'         => mysql_to_rfc3339( $post->post_date ),
			'date_gmt'     => mysql_to_rfc3339( $post->post_date_gmt ),
			'modified'     => mysql_to_rfc3339( $post->post_modified ),
			'modified_gmt' => mysql_to_rfc3339( $post->post_modified_gmt ),
			'link'         => get_permalink( $post->ID ),
			'slug'         => $post->post_name,
			'author'       => (int) $post->post_author,
			'excerpt'      => array(
				'raw'      => bbapp_learners_fix_relative_urls_protocol( $post->post_excerpt ),
				'rendered' => bbapp_learners_fix_relative_urls_protocol( apply_filters( 'the_excerpt', $post->post_excerpt ) ),
			),
			'menu_order'   => (int) $post->menu_order,
		);

		if ( ! empty( $schema['properties']['has_course_access'] ) && in_array( $context, $schema['properties']['has_course_access']['context'], true ) ) {
			$post->has_course_access = $this->get_has_course_access( $post );
			$data['has_course_access'] = (boolean) $post->has_course_access;
		}

		if ( ! empty( $schema['properties']['has_content_access'] ) && in_array( $context, $schema['properties']['has_content_access']['context'], true ) ) {
			$data['has_content_access'] = (boolean) $post->has_content_access;
		}

		/**
		 * Feature Media
		 */
		$post->featured_media            = $this->get_feature_media( $post );
		$data['featured_media']          = array();
		$data['featured_media']['small'] = ( is_array( $post->featured_media ) && isset( $post->featured_media['small'] ) ) ? $post->featured_media['small'] : null;
		$data['featured_media']['large'] = ( is_array( $post->featured_media ) && isset( $post->featured_media['large'] ) ) ? $post->featured_media['large'] : null;

		if ( ! empty( $schema['properties']['course'] ) && in_array( $context, $schema['properties']['course']['context'], true ) ) {
			$post->course   = $this->get_course_id( $post );
			$data['course'] = (int) $post->course;
		}

		if ( ! empty( $schema['properties']['lesson'] ) && in_array( $context, $schema['properties']['lesson']['context'], true ) ) {
			$post->lesson   = $this->get_lesson_id( $post );
			$data['lesson'] = (int) $post->lesson;
		}

		if ( ! empty( $schema['properties']['next_topic'] ) && in_array( $context, $schema['properties']['next_topic']['context'], true ) ) {
			$post->next_topic   = $this->get_next_topic_id( $post );
			$data['next_topic'] = (int) $post->next_topic;
		}

		if ( ! empty( $schema['properties']['materials'] ) && in_array( $context, $schema['properties']['materials']['context'], true ) ) {
			$post->materials   = $this->get_materials( $post );
			$data['materials'] = ( $post->has_content_access ) ? $post->materials : '';
		}

		if ( ! empty( $schema['properties']['duration'] ) && in_array( $context, $schema['properties']['duration']['context'], true ) ) {
			$post->duration          = $this->get_duration( $post );
			$data['duration']        = array();
			$data['duration']['min'] = (int) ( is_array( $post->duration ) && isset( $post->duration['min'] ) ) ? $post->duration['min'] : 0;
		}

		if ( ! empty( $schema['properties']['video'] ) && in_array( $context, $schema['properties']['video']['context'], true ) ) {
			$post->video   = $this->get_video( $post );
			$data['video'] = ( $post->has_content_access ) ? $post->video : '';
		}

		if ( ! empty( $schema['properties']['assignment_upload'] ) && in_array( $context, $schema['properties']['assignment_upload']['context'], true ) ) {
			$post->assignment_upload   = $this->get_lesson_assignment_upload( $post );
			$data['assignment_upload'] = $post->assignment_upload;
		}

		if ( ! empty( $schema['properties']['category'] ) && in_array( $context, $schema['properties']['category']['context'], true ) ) {
			$post->category   = $this->get_category( $post );
			$data['category'] = $post->category;
		}

		if ( ! empty( $schema['properties']['tag'] ) && in_array( $context, $schema['properties']['tag']['context'], true ) ) {
			$post->tag   = $this->get_tag( $post );
			$data['tag'] = $post->tag;
		}

		if ( ! empty( $schema['properties']['module'] ) && in_array( $context, $schema['properties']['module']['context'], true ) ) {
			//$data['module'] = $post->module;
		}

		if ( ! empty( $schema['properties']['quizzes'] ) && in_array( $context, $schema['properties']['quizzes']['context'], true ) ) {
			$post->quizzes   = $this->get_quizzes( $post );
			$data['quizzes'] = $post->quizzes;
		}

		if ( ! empty( $schema['properties']['completed'] ) && in_array( $context, $schema['properties']['completed']['context'], true ) ) {
			$post->completed   = $this->is_completed( $post );
			$data['completed'] = (boolean) $post->completed;
		}

		if ( ! empty( $schema['properties']['quiz_completed'] ) && in_array( $context, $schema['properties']['quiz_completed']['context'], true ) ) {
			$post->quiz_completed   = $this->is_quiz_completed( $post );
			$data['quiz_completed'] = (boolean) $post->quiz_completed;
		}

		if ( ! empty( $schema['properties']['settings'] ) && in_array( $context, $schema['properties']['settings']['context'], true ) ) {
			$post->settings   = $this->get_settings( $post );
			$data['settings'] = $post->settings;
		}

		if ( ! empty( $schema['properties']['can_complete'] ) && in_array( $context, $schema['properties']['can_complete']['context'], true ) ) {
			$post->can_complete   = $this->get_can_complete( $post );
			$data['can_complete'] = $post->can_complete;
		}

		if ( ! empty( $schema['properties']['error_message'] ) && in_array( $context, $schema['properties']['error_message']['context'], true ) ) {
			$post->error_message = $this->get_error_message( $post );
			if ( ! empty( $post->error_message ) ) {
				$error_code            = $post->error_message->get_error_code();
				$data['error_message'] = array(
					'code'    => $error_code,
					'message' => $post->error_message->get_error_message(),
					'data'    => $post->error_message->get_error_data( $error_code ),

				);
			} else {
				$data['error_message'] = array();
			}
		}

		$data = $this->add_additional_fields_to_object( $data, $request );
		$data = $this->filter_response_by_context( $data, $context );

		// Wrap the data in a response object.
		$response = rest_ensure_response( $data );

		$response->add_links( $this->prepare_links( $data ) );

		return apply_filters( 'bbapp_ld_rest_prepare_topic', $response, $post, $request );
	}

	/**
	 * @param array $prepared_args
	 * @param null  $request
	 *
	 * @return array
	 */
	protected function prepare_items_query( $prepared_args = array(), $request = null ) {
		$query_args = array();

		foreach ( $prepared_args as $key => $value ) {
			/**
			 * Filters the query_vars used in get_items() for the constructed query.
			 *
			 * The dynamic portion of the hook name, `$key`, refers to the query_var key.
			 *
			 * @param string $value The query_var value.
			 *
			 * @since 4.7.0
			 *
			 */
			$query_args[ $key ] = apply_filters( "rest_query_var-{$key}", $value ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores
		}

		$query_args['ignore_sticky_posts'] = true;

		// Map to proper WP_Query orderby param.
		if ( isset( $query_args['orderby'] ) && isset( $request['orderby'] ) ) {
			$orderby_mappings = array(
				'id'            => 'ID',
				'include'       => 'post__in',
				'slug'          => 'post_name',
				'include_slugs' => 'post_name__in',
			);

			if ( isset( $orderby_mappings[ $request['orderby'] ] ) ) {
				$query_args['orderby'] = $orderby_mappings[ $request['orderby'] ];
			}
		}

		return $query_args;
	}

	/**
	 * Prepare links for the request.
	 *
	 * @param array item object.
	 *
	 * @return array Links for the given data.
	 */
	public function prepare_links( $data ) {

		$links = parent::prepare_links( $data );

		/**
		 * Quiz links
		 */
		if ( isset( $data['quizzes'] ) ) {
			$links['quizzes'] = array();
			foreach ( $data['quizzes'] as $quiz ) {
				$links['quizzes'][] = array(
					'href'       => rest_url( $this->namespace . '/quiz/' . $quiz ),
					'embeddable' => true
				);
			}
		}

		/**
		 * Course
		 */
		if ( isset( $data["course"] ) ) {
			$links['course'] = array(
				'href'       => rest_url( $this->namespace . '/courses/' . $data["course"] ),
				'embeddable' => false
			);
		}

		/**
		 * Lesson
		 */
		if ( isset( $data["lesson"] ) ) {
			$links['lesson'] = array(
				'href'       => rest_url( $this->namespace . '/lessons/' . $data["lesson"] . '?course_id=' . $data["course"] ),
				'embeddable' => false
			);
		}

		/**
		 * Next Topic
		 */
		if ( isset( $data["next_topic"] ) ) {
			$links['next_lesson'] = array(
				'href' => rest_url( $this->namespace . '/topics/' . $data["next_topic"] ),
				'embeddable' => false
			);
		}

		//Todo::dips add filter here for course/lesson/topic

		return $links;
	}

	/**
	 * Get the query params for collections of attachments.
	 *
	 * @return array
	 */
	public function get_collection_params() {

		$params = parent::get_collection_params();

		$params['after'] = array(
			'description'       => __( 'Limit response to resources published after a given ISO8601 compliant date.', 'buddyboss-app' ),
			'type'              => 'string',
			'format'            => 'date-time',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['before'] = array(
			'description'       => __( 'Limit response to resources published before a given ISO8601 compliant date.', 'buddyboss-app' ),
			'type'              => 'string',
			'format'            => 'date-time',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['author'] = array(
			'description'       => __( 'Limit result set to posts assigned to specific authors.', 'buddyboss-app' ),
			'type'              => 'array',
			'items'             => array( 'type' => 'integer' ),
			'sanitize_callback' => 'wp_parse_id_list',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['author_exclude'] = array(
			'description'       => __( 'Ensure result set excludes posts assigned to specific authors.', 'buddyboss-app' ),
			'type'              => 'array',
			'items'             => array( 'type' => 'integer' ),
			'sanitize_callback' => 'wp_parse_id_list',
			'validate_callback' => 'rest_validate_request_arg',
		);

		$params['exclude'] = array(
			'description'       => __( 'Ensure result set excludes specific ids.', 'buddyboss-app' ),
			'type'              => 'array',
			'items'             => array( 'type' => 'integer' ),
			'sanitize_callback' => 'wp_parse_id_list',
		);
		$params['include'] = array(
			'description'       => __( 'Limit result set to specific ids.', 'buddyboss-app' ),
			'type'              => 'array',
			'items'             => array( 'type' => 'integer' ),
			'sanitize_callback' => 'wp_parse_id_list',
		);

		$params['offset']            = array(
			'description'       => __( 'Offset the result set by a specific number of items.', 'buddyboss-app' ),
			'type'              => 'integer',
			'sanitize_callback' => 'absint',
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['order']             = array(
			'description'       => __( 'Order sort attribute ascending or descending.', 'buddyboss-app' ),
			'type'              => 'string',
			'default'           => 'desc',
			'enum'              => array( 'asc', 'desc' ),
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['orderby']           = array(
			'description'       => __( 'Sort collection by object attribute.', 'buddyboss-app' ),
			'type'              => 'string',
			'default'           => 'date',
			'enum'              => array(
				'date',
				'id',
				'include',
				'title',
				'slug',
				'relevance',
			),
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['orderby']['enum'][] = 'menu_order';

		$params['parent']         = array(
			'description'       => __( 'Limit result set to those of particular parent IDs.', 'buddyboss-app' ),
			'type'              => 'array',
			'sanitize_callback' => 'wp_parse_id_list',
			'items'             => array( 'type' => 'integer' ),
		);
		$params['parent_exclude'] = array(
			'description'       => __( 'Limit result set to all items except those of a particular parent ID.', 'buddyboss-app' ),
			'type'              => 'array',
			'sanitize_callback' => 'wp_parse_id_list',
			'items'             => array( 'type' => 'integer' ),
		);

		$params['slug']   = array(
			'description'       => __( 'Limit result set to posts with a specific slug.', 'buddyboss-app' ),
			'type'              => 'string',
			'validate_callback' => 'rest_validate_request_arg',
		);
		$params['filter'] = array(
			'description' => __( 'Use WP Query arguments to modify the response; private query vars require appropriate authorization.', 'buddyboss-app' ),
		);

		return $params;
	}

	/**
	 * Get the plugin schema, conforming to JSON Schema.
	 *
	 * @return array
	 * @since 0.1.0
	 */
	public function get_item_schema() {
		$schema = array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'ld_topic',
			'type'       => 'object',
			/*
				 * Base properties for every Post.
			*/
			'properties' => array(
				'id'             => array(
					'description' => __( 'Unique identifier for the object.', 'buddyboss-app' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit', 'embed' ),
					'readonly'    => true,
				),
				'title'          => array(
					'description' => __( 'The title for the object.', 'buddyboss-app' ),
					'type'        => 'object',
					'context'     => array( 'view', 'edit', 'embed' ),
					'properties'  => array(
						'raw'      => array(
							'description' => __( 'Title for the object, as it exists in the database.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'edit' ),
						),
						'rendered' => array(
							'description' => __( 'HTML title for the object, transformed for display.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit', 'embed' ),
						),
					),
				),
				'content'        => array(
					'description' => __( 'The content for the object.' ),
					'type'        => 'object',
					'context'     => array( 'view', 'edit' ),
					'properties'  => array(
						'raw'      => array(
							'description' => __( 'Content for the object, as it exists in the database.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'edit' ),
						),
						'rendered' => array(
							'description' => __( 'HTML content for the object, transformed for display.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit' ),
						),
					),
				),
				'date'           => array(
					'description' => __( 'The date the object was published, in the site\'s timezone.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'date_gmt'       => array(
					'description' => __( 'The date the object was published, as GMT.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'modified'       => array(
					'description' => __( 'The date the object was last modified, in the site\'s timezone.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit', 'embed' ),
					'readonly'    => true,
				),
				'modified_gmt'   => array(
					'description' => __( 'The date the object was last modified, as GMT.' , 'buddyboss-app'),
					'type'        => 'string',
					'format'      => 'date-time',
					'context'     => array( 'view', 'edit', 'embed' ),
					'readonly'    => true,
				),
				'link'           => array(
					'description' => __( 'URL to the object.', 'buddyboss-app' ),
					'type'        => 'string',
					'format'      => 'uri',
					'context'     => array( 'view', 'edit', 'embed' ),
					'readonly'    => true,
				),
				'slug'           => array(
					'description' => __( 'An alphanumeric identifier for the object unique to its type.', 'buddyboss-app' ),
					'type'        => 'string',
					'context'     => array( 'view', 'edit', 'embed' ),
					'arg_options' => array(
						'sanitize_callback' => 'sanitize_title',
					),
				),
				'author'         => array(
					'description' => __( 'The ID for the author of the object.', 'buddyboss-app' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'excerpt'        => array(
					'description' => __( 'The excerpt for the object.', 'buddyboss-app' ),
					'type'        => 'object',
					'context'     => array( 'view', 'edit', 'embed' ),
					'properties'  => array(
						'raw'      => array(
							'description' => __( 'Excerpt for the object, as it exists in the database.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'edit' ),
						),
						'rendered' => array(
							'description' => __( 'HTML excerpt for the object, transformed for display.', 'buddyboss-app' ),
							'type'        => 'string',
							'context'     => array( 'view', 'edit', 'embed' ),
						),
					),
				),
				'featured_media' => array(
					'description' => __( 'Feature media object containing thumb and full URL of image.', 'buddyboss-app' ),
					'type'        => 'array',
					'context'     => array( 'view', 'edit', 'embed' ),
				),
				'menu_order'     => array(
					'description' => __( 'The order of the object in relation to other object of its type.', 'buddyboss-app' ),
					'type'        => 'integer',
					'context'     => array( 'view', 'edit' ),
				),
			),
		);

		$schema['properties']['category'] = array(
			'description' => sprintf( __( 'The terms assigned to the object in the %s taxonomy.', 'buddyboss-app' ), 'category' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['tag'] = array(
			'description' => sprintf( __( 'The terms assigned to the object in the %s taxonomy.', 'buddyboss-app' ), 'tag' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['module'] = array(
			'description' => sprintf( __( 'The terms assigned to the object in the %s taxonomy.', 'buddyboss-app' ), 'module' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['course'] = array(
			'description' => __( 'The Course id for the object', 'buddyboss-app'),
			'type'        => 'integer',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		$schema['properties']['lesson'] = array(
			'description' => __( 'The Lesson id for the object', 'buddyboss-app' ),
			'type'        => 'integer',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		$schema['properties']['next_topic'] = array(
			'description' => __( 'The next topic id for the object', 'buddyboss-app' ),
			'type'        => 'integer',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		$schema['properties']['materials'] = array(
			'description' => __( 'Materials for the object.', 'buddyboss-app' ),
			'type'        => 'string',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['video'] = array(
			'description' => __( 'video for the object.', 'buddyboss-app' ),
			'type'        => 'string',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['duration'] = array(
			'description' => __( 'The time duration for the object', 'buddyboss-app' ),
			'type'        => 'object',
			'context'     => array( 'view', 'edit' ),
			'properties'  => array(
				'properties' => array(
					'min' => array(
						'description' => __( 'Minimum required time for this object.', 'buddyboss-app' ),
						'type'        => 'integer',
						'context'     => array( 'view', 'edit' ),
					),
				),
			),
		);

		$schema['properties']['assignment_upload'] = array(
			'description' => __( 'Assignment upload enable for the object', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['has_course_access'] = array(
			'description' => __( 'Whether or not user have the object access.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['has_content_access'] = array(
			'description' => __( 'Whether or not user have the object content access.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['quizzes'] = array(
			'description' => __( 'The quizzes list which has access of the object', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['completed'] = array(
			'description' => __( 'The object is completed by current user or not.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		$schema['properties']['quiz_completed'] = array(
			'description' => __( 'The object Quizzes is completed by current user or not.', 'buddyboss-app' ),
			'type'        => 'boolean',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		$schema['properties']['settings'] = array(
			'description' => __( 'The object settings.', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['can_complete'] = array(
			'description' => __( 'The object can complete by user or not.', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit' ),
		);

		$schema['properties']['error_message'] = array(
			'description' => __( 'Error message for this object.', 'buddyboss-app' ),
			'type'        => 'array',
			'context'     => array( 'view', 'edit', 'embed' ),
		);

		return $this->add_additional_fields_schema( $schema );
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_feature_media( $post ) {
		$return = array(
			"large" => null,
			"small" => null,
		);
		$large  = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large' );
		$small  = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'medium' );

		if ( isset( $large[0] ) ) {
			$return["large"] = $large[0];
		}
		if ( isset( $small[0] ) ) {
			$return["small"] = $small[0];
		}

		return $return;

	}

	/**
	 * @param $post
	 *
	 * @return int
	 */
	protected function get_course_id( $post ) {
		$course_id = bbapp_learndash_get_course_id( $post->ID );
		if ( ! isset( $course_id ) ) {
			$course_id = 0;
		}

		return $course_id;
	}

	/**
	 * @param $post
	 *
	 * @return int
	 */
	protected function get_lesson_id( $post ) {
		$lesson_id = bbapp_learndash_get_lesson_id( $post->ID );
		if ( ! isset( $lesson_id ) ) {
			$lesson_id = 0;
		}

		return $lesson_id;
	}

	/**
	 * @param $post
	 *
	 * @return int|string
	 */
	protected function get_next_topic_id( $post ) {
		$next = bbapp_lms_next_post_id( $post );
		if ( ! empty( $next ) ) {
			return $next;
		} else {
			return 0;
		}
	}

	/**
	 * @param $post
	 *
	 * @return string
	 */
	protected function get_materials( $post ) {
		$topic_materials_enabled = learndash_get_setting( $post->ID, 'topic_materials_enabled' );
		if ( ( isset( $topic_materials_enabled ) ) && ( $topic_materials_enabled == 'on' ) ) {
			$topic_materials = learndash_get_setting( $post->ID, 'topic_materials' );
			$topic_materials = wp_kses_post( wp_specialchars_decode( $topic_materials, ENT_QUOTES ) );
			if ( ! empty( $topic_materials ) ) {
				$topic_materials = do_shortcode( $topic_materials );
			};

			return $topic_materials;
		}

		return '';
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_duration( $post ) {
		$timeval = learndash_get_setting( $post->ID, 'forced_lesson_time' );
		if ( ! empty( $timeval ) ) {
			$time_sections = explode( ' ', $timeval );
			$h             = $m = $s = 0;

			foreach ( $time_sections as $k => $v ) {
				$value = trim( $v );

				if ( strpos( $value, 'h' ) ) {
					$h = intVal( $value );
				} else if ( strpos( $value, 'm' ) ) {
					$m = intVal( $value );
				} else if ( strpos( $value, 's' ) ) {
					$s = intVal( $value );
				}
			}

			$time = $h * 60 * 60 + $m * 60 + $s;

			if ( $time == 0 ) {
				$time = (int) $timeval;
			}
		} else {
			$time = 0;
		}

		return array(
			"min" => $time,
		);
	}

	/**
	 * @param $post
	 *
	 * @return bool
	 */
	protected function get_lesson_assignment_upload( $post ) {
		return lesson_hasassignments( $post );
	}
	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_lesson_assignment_upload_settings( $post ) {
		$settings        = learndash_get_setting( $post->ID );
		$file_extensions = ! empty( $settings['assignment_upload_limit_extensions'] ) ? $settings['assignment_upload_limit_extensions'] : array(
			'pdf',
			'xls',
			'zip'
		);

		$php_max_upload = ini_get( 'upload_max_filesize' );
		if ( ( isset( $settings['assignment_upload_limit_size'] ) ) && ( ! empty( $settings['assignment_upload_limit_size'] ) ) ) {
			if ( ( learndash_return_bytes_from_shorthand( $settings['assignment_upload_limit_size'] ) < learndash_return_bytes_from_shorthand( $php_max_upload ) ) ) {
				$php_max_upload = $settings['assignment_upload_limit_size'];
			}
		}

		$file_size_limit              = $php_max_upload;
		$enable_points                = ! empty( $settings['lesson_assignment_points_enabled'] ) && 'on' === $settings['lesson_assignment_points_enabled'];
		$points_amount                = ! empty( $settings['lesson_assignment_points_amount'] ) ? $settings['lesson_assignment_points_amount'] : 1;
		$grading_type['auto_approve'] = ! empty( $settings['auto_approve_assignment'] ) && 'on' === $settings['auto_approve_assignment'];
		if ( false === $grading_type['auto_approve'] ) {
			$grading_type['upload_limit_count'] = ! empty( $settings['assignment_upload_limit_count'] ) ? $settings['assignment_upload_limit_count'] : 1;
			$grading_type['can_delete']         = ! empty( $settings['lesson_assignment_deletion_enabled'] ) && 'on' === $settings['lesson_assignment_deletion_enabled'];
		}

		return array(
			'file_extensions' => $file_extensions,
			'file_size_limit' => $file_size_limit,
			'enable_points'   => $enable_points,
			'points_amount'   => $points_amount,
			'grading_type'    => $grading_type,
		);
	}

	/**
	 * @param $post
	 *
	 * @return mixed
	 */
	protected function get_video( $post ) {

		$topic_video_enabled = learndash_get_setting( $post->ID, 'lesson_video_enabled' );
		if ( ( isset( $topic_video_enabled ) ) && ( $topic_video_enabled == 'on' ) ) {
			return learndash_get_setting( $post->ID, 'lesson_video_url' );
		}

		return '';
	}

	/**
	 * @param $post
	 *
	 * @return mixed
	 */
	public function get_has_course_access( $post ) {
		$course_id = bbapp_learndash_get_course_id( $post->ID );

		return sfwd_lms_has_access( $course_id );
	}

	/**
	 * @param $post
	 *
	 * @return bool
	 */
	public function get_has_content_access( $post ) {
		return bbapp_lms_is_content_access( $post, 'prerequities_completed' )
		       && bbapp_lms_is_content_access( $post, 'points_access' )
		       && bbapp_lms_is_content_access( $post, 'previous_lesson_completed' )
		       && bbapp_lms_is_content_access( $post, 'previous_topic_completed' )
		       && sfwd_lms_has_access( $post->ID );
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_category( $post ) {
		$terms = get_the_terms( $post, 'ld_topic_category' );

		return $terms && ! is_wp_error( $terms ) ? wp_list_pluck( $terms, 'term_id' ) : array();
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_tag( $post ) {
		$terms = get_the_terms( $post, 'ld_topic_tag' );

		return $terms && ! is_wp_error( $terms ) ? wp_list_pluck( $terms, 'term_id' ) : array();
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_quizzes( $post ) {
		$quizes = learndash_get_lesson_quiz_list( $post );
		$posts  = array();
		foreach ( $quizes as $quiz ) {
			$posts[] = $quiz['post']->ID;
		}

		return $posts;
	}

	/**
	 * This function we use in Lesson endpoint so it should be public
	 *
	 * @param $post
	 *
	 * @return bool
	 */
	public function is_completed( $post ) {
		if ( ! is_user_logged_in() ){
			return false;
		}
		$user_id = get_current_user_id();

		$course_id       = bbapp_learndash_get_course_id( $post );
		$lesson_id       = bbapp_learndash_get_lesson_id( $post->ID );
		$usermeta        = get_user_meta( $user_id, '_sfwd-course_progress', true );
		$course_progress = empty( $usermeta ) ? array() : $usermeta;

		return ( ! empty( $course_progress[ $course_id ]['topics'][ $lesson_id ][ $post->ID ] ) && 1 === $course_progress[ $course_id ]['topics'][ $lesson_id ][ $post->ID ] );
	}

	/**
	 * @param $post
	 *
	 * @return bool
	 */
	protected function is_quiz_completed( $post ) {
		return bbapp_lms_quiz_completed( $post );
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	protected function get_settings( $post ) {
		$settings                          = array();
		$topic_settings                    = learndash_get_setting( $post->ID );
		$topic_video_enabled               = learndash_get_setting( $post->ID, 'lesson_video_enabled' );
		$topic_assignments_uploads_enabled = learndash_get_setting( $post->ID, 'lesson_assignment_upload' );

		/**
		 * Video settings.
		 */
		$settings['video'] = array(
			'shown'         => '',
			'auto_start'    => false,
			'show_controls' => true,
			'cookie_key'    => null,
		);
		if ( isset( $topic_video_enabled ) && 'on' == $topic_video_enabled ) {
			$settings['video'] = array(
				'shown'         => isset( $topic_settings['lesson_video_shown'] ) ? $topic_settings['lesson_video_shown'] : false,
				'auto_start'    => isset( $topic_settings['lesson_video_auto_start'] ) ? 'on' == $topic_settings['lesson_video_auto_start'] : false,
				'show_controls' => isset( $topic_settings['lesson_video_show_controls'] ) ? 'on' == $topic_settings['lesson_video_show_controls'] : false,
				'cookie_key'    => build_video_cookie_key( $post ),
			);

			if ( 'AFTER' === $settings['video']['shown'] ) {
				$settings['video']['shown_after_lesson_video_auto_complete']        = isset( $topic_settings['lesson_video_auto_complete'] ) ? 'on' == $topic_settings['lesson_video_auto_complete'] : false;
				$settings['video']['shown_after_lesson_video_auto_complete_delay']  = $topic_settings['lesson_video_auto_complete_delay'];
				$settings['video']['shown_after_lesson_video_show_complete_button'] = isset( $topic_settings['lesson_video_show_complete_button'] ) ? 'on' == $topic_settings['lesson_video_show_complete_button'] : false;
			}
		} 

		/**
		 * Assignment upload settings.
		 */
		$settings['assignment_upload'] = array(
			'limit_extensions' => '',
			'limit_size'       => '',
			'points'           => '',
			'limit_count'      => '',
			'deletion_enabled' => false,
		);
		if ( isset( $topic_assignments_uploads_enabled ) && 'on' == $topic_assignments_uploads_enabled ) {
			$settings['assignment_upload'] = array(
				'limit_extensions'        => isset( $topic_settings['assignment_upload_limit_extensions'] ) && ! empty( $topic_settings['assignment_upload_limit_extensions'] ) ? $topic_settings['assignment_upload_limit_extensions'] : 'any',
				'limit_size'              => isset( $topic_settings['assignment_upload_limit_size'] ) && ! empty( $topic_settings['assignment_upload_limit_size'] ) ? $topic_settings['assignment_upload_limit_size'] : ini_get( 'upload_max_filesize' ),
				'points'                  => isset( $topic_settings['lesson_assignment_points_enabled'] ) && 'on' === $topic_settings['lesson_assignment_points_enabled'] ? $topic_settings['lesson_assignment_points_amount'] : '',
				'auto_approve_assignment' => isset( $topic_settings['auto_approve_assignment'] ) ? 'on' === $topic_settings['auto_approve_assignment'] : false,
			);
			$settings['assignment_upload']['limit_count'] = 1;
			if ( ! $settings['assignment_upload']['auto_approve_assignment'] ) {
				$settings['assignment_upload']['limit_count']      = isset( $topic_settings['assignment_upload_limit_count'] ) && ! empty( $topic_settings['assignment_upload_limit_count'] ) ? $topic_settings['assignment_upload_limit_count'] : 1;
				$settings['assignment_upload']['deletion_enabled'] = isset( $topic_settings['lesson_assignment_deletion_enabled'] ) ? 'on' === $topic_settings['lesson_assignment_deletion_enabled'] : false;
			}
		}

		if ( isset( $post->assignment_upload ) && ! empty( $post->assignment_upload ) ) {
			$settings['assignment_upload'] = $this->get_lesson_assignment_upload_settings( $post );
		}

		return $settings;
	}

	/**
	 * Current user complete course or not.
	 *
	 * @param $post
	 *
	 * @return bool
	 */
	private function get_can_complete( $post ){
		$can_complete = false;
		if ( is_user_logged_in() ) {
			$can_complete = true;
		}
		return $can_complete;
	}

	/**
	 * @param $post
	 *
	 * @return array
	 */
	public function get_error_message( $post ) {
		$course_id = bbapp_learndash_get_course_id( $post->ID );
		$user_id   = get_current_user_id();

		if ( ! bbapp_lms_is_content_access( $post, 'prerequities_completed' ) ) {
			$prerequisite_posts_all = learndash_get_course_prerequisites( $course_id );
			$course_str             = '';
			if ( ! empty( $prerequisite_posts_all ) ) {
				foreach ( $prerequisite_posts_all as $pre_post_id => $pre_status ) {
					if ( $pre_status === false ) {
						if ( ! empty( $course_str ) ) {
							$course_str .= ', ';
						}

						$course_str .= get_the_title( $pre_post_id );
					}
				}
			}

			return CoursesError::instance()->invalidCoursePrerequities( $course_str );
		}

		if ( ! bbapp_lms_is_content_access( $post, 'points_access' ) ) {
			$course_access_points = learndash_get_course_points_access( $course_id );
			$user_course_points   = learndash_get_user_course_points( $user_id );

			return CoursesError::instance()->invalidCourseAccessPoint( $course_access_points, $user_course_points );
		}

		if ( ! sfwd_lms_has_access( $post->ID, $user_id ) ) {
			return TopicsError::instance()->invalidTopicAccess();
		}

		if ( ! bbapp_lms_is_content_access( $post, 'previous_lesson_completed' ) || ! bbapp_lms_is_content_access( $post, 'previous_topic_completed' ) ) {
			return TopicsError::instance()->topicPreviousNotCompleted();
		}
	}
}