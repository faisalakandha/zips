<?php

namespace BuddyBossApp\Api\InAppPurchases\V2\Orders;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Admin\InAppPurchases\Helpers;
use BuddyBossApp\InAppPurchases\Orders;
use BuddyBossApp\InAppPurchases\StoreAbstract;
use WP_Error as WP_Error;
use WP_REST_Server;

/**
 * Class RestOrders
 *
 * @package BuddyBossApp\Api\InAppPurchases\V2\Orders
 */
final class OrdersRest {

	private static $instance = null;

	public $namespace = "buddyboss-app/iap/v2";

	private function __construct() {
		// ... leave empty, see Singleton below
	}

	/**
	 * Get the instance of this class.
	 *
	 * @return OrdersRest
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->hooks();
		}

		return self::$instance;
	}

	/**
	 * All hooks here
	 *
	 * @return void
	 */
	public function hooks() {
		add_action( 'rest_api_init', array( $this, "register_routes" ), 99 );
	}

	/**
	 * Register all api endpoints for this class here
	 *
	 * @return void
	 */
	public function register_routes() {

		// Create Order Endpoint.
		register_rest_route( $this->namespace, '/order', array(
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'rest_get_orders' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'device_platform' => array(
						'required'    => true,
						'type'        => 'string',
						'description' => __( "InAppPurchase Platform(also known as IAP Type)", 'buddyboss-app' ),
						'enum'        => array( 'ios', 'android' ),

					),
					'status'          => array(
						'required'    => true,
						'type'        => 'string',
						'default'     => 'all',
						'description' => __( "Order status", 'buddyboss-app' ),
						'enum'        => array( 'all', 'active' ),
					),
				),
			),
			array(
				'methods'             => WP_REST_Server::EDITABLE,
				'callback'            => array( $this, 'rest_create_order' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'iap_receipt_token' => array(
						'required'    => true,
						'type'        => 'string',
						'description' => __( "InAppPurchase Token (receipt token)" ),
					),
					'device_platform'   => array(
						'required'    => true,
						'type'        => 'string',
						'description' => __( "InAppPurchase Platform(also known as IAP Type)", 'buddyboss-app' ),
						'enum'        => array( 'ios', 'android' ),
					),
					'bbapp_product_id'  => array(
						'required'    => true,
						'type'        => 'string',
						'description' => __( "Integration Id(also known as iap_product_id) or Store product id.", 'buddyboss-app' ),
					),
					'test_mode'         => array(
						'type'        => "integer",
						'description' => __( "Order is for testing or real order.", 'buddyboss-app' ),
					),
					'email'             => array(
						'validate_callback' => function ( $param, $request, $key ) {
							return is_email( $param );
						},
					),
				),
			),
		) );

	}

	/**
	 * @param $request
	 *
	 * @return WP_Error
	 * @api            {GET} /wp-json/buddyboss-app/iap/v2/orders Orders
	 * @apiName        GetIAPOrders
	 * @apiGroup       In-App Purchases
	 * @apiVersion     1.0.0
	 * @apiPermission  LoggedInUser
	 * @apiDescription Get In-App Purchase orders
	 * @apiUse         apidocForGetOrders
	 */
	public function rest_get_orders( $request ) {

		// Prevent unauthorised access
		if ( ! is_user_logged_in() ) {
			return new WP_Error( 'not_logged_in', __( 'Please login to view products', 'buddyboss-app' ), array( 'status' => 401 ) );
		}

		$device_platform = $request->get_param( 'device_platform' );
		$status          = $request->get_param( 'status' );

		$order_args = array(
			'user_id'         => get_current_user_id(),
			'device_platform' => $device_platform,
		);

		if ( 'active' === $status ) {
			$order_args['order_status'] = array(
				'subscribed',
				'completed'
			);
		} elseif ( 'expired' === $status ) {
			$order_args['order_status'] = array(
				'expired',
				'retrying',
			);
		}

		$orders     = array();
		$orders_obj = Orders::instance()->get_orders( $order_args );

		if ( ! empty( $orders_obj ) ) {
			$orders = $orders_obj;
			foreach ( $orders as $key => $order ) {

				if ( isset( $order->integration_types ) ) {
					if ( is_serialized( $order->integration_types ) ) {
						$integration_types = unserialize( $order->integration_types );

						if ( is_array( $integration_types ) ) {

							//NOTE : Overridden values
							$order->integration_types = array_values( $integration_types );

							if ( isset( $order->item_ids ) ) {
								if ( is_serialized( $order->item_ids ) ) {
									$itemIds = unserialize( $order->item_ids );
									foreach ( $integration_types as $integration_type ) {
										if ( bbapp()->is_network_activated() ) {
											$order->item_ids = array( $integration_type => unserialize( $itemIds[ get_current_blog_id() ][ $integration_type ] ) );
										} else {
											$order->item_ids = array( $integration_type => unserialize( $itemIds[ $integration_type ] ) );
										}

									}

								}
							}

						}

					}

				}

				$order->transaction_id          = Orders::instance()->get_meta( $order->id, '_transaction_id', true );
				$order->original_transaction_id = Orders::instance()->get_meta( $order->id, '_parent_transaction_id', true );
				$order->transaction_date_ms     = Orders::instance()->get_meta( $order->id, '_transaction_date_ms', true );

			}
		}

		return rest_ensure_response( $orders );
	}

	/**
	 * @param $request
	 *
	 * @return array|WP_Error
	 * @api            {POST} /wp-json/buddyboss-app/iap/v2/order Create order
	 * @apiName        CreateIAPOrder
	 * @apiGroup       In-App Purchases
	 * @apiVersion     2.0.0
	 * @apiPermission  LoggedInUser
	 * @apiDescription Create order for In-App Purchases
	 * @apiParam {String} iap_receipt_token InAppPurchase Token (receipt token)
	 * @apiParam {String=ios,android} device_platform InAppPurchase Platform (also known as InAppPurchase type)
	 * @apiParam {Number} bbapp_product_id BuddyBossApp InAppPurchase Product Id (also known as Integration Id, nothing related to store_product_id)
	 * <a href="#api-InAppPurchases-GetIAPProducts">Gettable at endpoint</a>
	 */
	public function rest_create_order( $request ) {

		$iap_receipt_token = $request->get_param( 'iap_receipt_token' );
		$device_platform   = $request->get_param( 'device_platform' );
		$bbapp_product_id  = $request->get_param( 'bbapp_product_id' );
		$email             = $request->get_param( "email" );
		$test_mode         = (int) $request->get_param( 'test_mode' );
		$test_mode         = ( ! empty( $test_mode ) && 1 === $test_mode );

		if ( is_numeric( $bbapp_product_id ) ) {
			$bbapp_product_id = (int) $bbapp_product_id;
		} else {
			$bbapp_product_id = Helpers::get_product_id_by_store_product_id( $bbapp_product_id, $device_platform );
		}

		$user_id = 0;
		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
		}

		$blog_id = 1;
		if ( is_multisite() ) {
			$blog_id = get_current_blog_id();
		}

		// some validations.
		if ( ! isset( bbapp_iap()->iap[ $device_platform ] ) ) {
			return new WP_Error( 'invalid_device_platform', sprintf( __( "InAppPurchase for Platform(%s) you requested is not available currently.", 'buddyboss-app' ), $device_platform ), array( 'status' => 404 ) );
		}
		if ( empty( $bbapp_product_id ) ) {
			return new WP_Error( 'iap_product_id_missing', __( "InAppPurchase bbapp_product_id shouldn't be empty.", 'buddyboss-app' ), array( 'status' => 400 ) );
		}
		if ( empty( $iap_receipt_token ) ) {
			return new WP_Error( 'iap_receipt_token_missing', __( "InAppPurchase Receipt token shouldn't be empty.", 'buddyboss-app' ), array( 'status' => 400 ) );
		}
		if ( ! is_user_logged_in() ) {
			if ( empty( $email ) ) {
				return new Wp_Error( 'iap_user_email_missing', __( 'A valid email param is required.' ), array( 'status' => 500 ) );
			}
		} else {
			$user  = wp_get_current_user();
			$email = $user->user_email;
		}

		/**
		 * @var $iap StoreAbstract
		 */
		$iap = bbapp_iap()->iap[ $device_platform ];

		$order_args = array(
			'bbapp_product_id'  => $bbapp_product_id,
			'device_platform'   => $device_platform,
			'blog_id'           => $blog_id,
			'iap_receipt_token' => $iap_receipt_token,
			'user_id'           => $user_id,
			'user_email'        => $email,
			'test_mode'         => $test_mode,
		);

		$_order = Orders::instance()->creating_order( $order_args, $iap );
		if ( is_wp_error( $_order ) ) {
			return $_order;
		}

		/**
		 * Only when use is only we need to complete the order in same time.
		 */
		if ( is_user_logged_in() ) {
			$order_args = array(
				'order_id'          => $_order->id,
				'test_mode'         => $test_mode,
				'iap_receipt_token' => $iap_receipt_token,
				'user_id'           => $user_id,
			);

			$_order = Orders::instance()->completing_order( $order_args );

		}
		if ( is_wp_error( $_order ) ) {
			return $_order;
		}

		return $this->rest_order_status_response( $_order );
	}

	/**
	 * Provides status of order
	 *
	 * @param $order
	 *
	 * @return array
	 */
	public function rest_order_status_response( $order ) {

		$response = array(
			"order_id"         => $order->id,
			"status"           => $order->order_status,
			"date_created_gmt" => mysql_to_rfc3339( $order->date_created ),
			"date_updated_gmt" => mysql_to_rfc3339( $order->date_updated ),
		);

		return $response;
	}



}
