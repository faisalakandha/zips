<?php

namespace BuddyBossApp\V2;

// Note : The soul purpose of this class is apidoc(documentation generator). By Ketan
class ApidocV2
{

    private function apidocForRequestTokenV2()
    {
        /**
         * @apiDefine apidocForRequestTokenV2
         *
         * @apiHeader {String} appid Unique App Id(Note : it is `appid` with no underscore)
         * @apiParam {String} username Username of user wants to authenticate, Email is also valid.
         * @apiParam {String} password Password of user wants to authenticate.
         * @apiParam {String} device_token Firebase app device token.
         * @apiSuccessExample {json} Success-Response:
         *    {
         *    "access_token": "secret",
         *    "refresh_token": "secret",
         *    "user_display_name": "firstname",
         *    "user_nicename": "nickname",
         *    "user_email": "someone@example.com",
         *    "user_id": "#"
         *    }
         */
    }
}