<?php

namespace BuddyBossApp\ItemMeta;

trait itemMetaUtils
{
    /**
     * @param $item_id
     * @param $item_type
     * @param $meta_data
     *
     * @return boolean
     */
    public static function update_or_insert_item( $item_id, $item_type, $meta_data)
    {

        global $wpdb;
        $table_name = $wpdb->prefix . 'bbapp_itemmeta';
        $serialize_data = serialize($meta_data);

        $select_query = "SELECT count(*) as total FROM {$table_name} WHERE item_id = {$item_id}";
        $exists = $wpdb->get_results($select_query);
        if (isset($exists[0]->total) && $exists[0]->total == 0) {
            $insert_query = "INSERT INTO {$table_name} (`item_id`,`item_type`, `meta_data`)
        VALUES ('{$item_id}', '{$item_type}','{$serialize_data}')";

            $status = $wpdb->query($insert_query);
        } else {


            $status = $wpdb->update(
                $table_name,
                array(
                    'item_type' => $item_type,
                    'meta_data' => $serialize_data,
                ),
                array('item_id' => $item_id)
            );

        }

        return $status;
    }

    /**
     * Set Transient for item under BuddyBossApp prefix
     *
     * @param $item_id
     *
     * @return array
     */
    public static function set_transient_for_item($item_id)
    {
        $transient_name = itemMetaUtils::prepare_transient_name($item_id);

        $meta_data = self::prepare_meta($item_id);

        // TODO : Verify/Decide right time for caching this information?
        set_transient($transient_name, $meta_data, 1 * 60);
        $data = get_transient($transient_name);

        return $data;
    }


    /**
     * Prepare Meta
     *
     * @param $item_id
     *
     * @return array
     */
    public static function prepare_meta($item_id)
    {
        $data = array();

        $modified_time = get_post_modified_time( "G", true, $item_id);
        $last_changed = $modified_time;

        $child_ids = array();
        $child_updates = array();

        // @todo : Implement below.
        $parent_ids = array();
        $parent_updates = array();

        $post_type = get_post_type($item_id);
        switch ($post_type) {
            case 'sfwd-courses':
                if (function_exists('learndash_get_course_lessons_list')) {
                    $lessons = learndash_get_course_lessons_list($item_id, null, array());
                    foreach ($lessons as $key => $lesson) {
                        $child_ids['lessons'][] = $lesson['post']->ID;
                        $modified_time = get_post_modified_time("G", true, $lesson['post']->ID);
                        if ($child_updates['lessons'][$lesson['post']->ID] < $modified_time) {
                            $child_updates['lessons'][$lesson['post']->ID] = $modified_time;
                        }


                    }
                }

                if (function_exists('learndash_course_get_steps_by_type')) {
                    $topics = learndash_course_get_steps_by_type($item_id, 'sfwd-topic');

                    foreach ($topics as $key => $topic_id) {
                        $child_ids['topics'][] = $topic_id;
                        if ($child_updates['topics'][$topic_id] < $modified_time) {
                            $child_updates['topics'][$topic_id] = $modified_time;
                        }
                    }
                }
                break;
        }

        $data['updates'] = array(
            'last_changed' => $last_changed,
            'child_updated' => $child_updates,
            'parent_updated' => $parent_updates,
        );
        $data['child_ids'] = $child_ids;
        $data['parent_ids'] = $parent_ids;
        return $data;
    }


    /**
     * Prepare Last Changed
     *
     * @param $item_id
     * @param $since_timestamp
     *
     * @return array
     */
    public static function prepare_last_changed($item_id, $since_timestamp)
    {
        $modified_time = get_post_modified_time( "G", true, $item_id);

        $data = array();
        $child_updates = array();
        $parent_updates = array();


        $data['self_changed'] = $modified_time;
        $post_type = get_post_type($item_id);

        switch ($post_type) {
            case 'sfwd-courses':
                if (function_exists('learndash_get_course_lessons_list')) {
                    $lessons = learndash_get_course_lessons_list($item_id, null, array());
                    foreach ($lessons as $key => $lesson) {
                        $lesson_modified_time = get_post_modified_time("G", true, $lesson['post']->ID);
                        if ( $lesson_modified_time > $since_timestamp) {
                            $child_updates[] = array('id' => $lesson['post']->ID, 'type' => 'lesson');
                        }

                    }
                }

                if (function_exists('learndash_course_get_steps_by_type')) {
                    $topics = learndash_course_get_steps_by_type($item_id, 'sfwd-topic');

                    foreach ($topics as $key => $topic_id) {
                        $topicModifiedTime = get_post_modified_time("G", true, $topic_id);
                        if ( $topicModifiedTime > $since_timestamp) {
                            $child_updates[] = array('id' => $topic_id, 'type' => 'topic');
                        }
                    }
                }
                break;
        }
        $data['child_updated'] = array_values($child_updates);
        $data['parent_updated'] = array_values($parent_updates);

        return $data;
    }


    /**
     * Get Items by Type
     *
     * @param $item_type
     *
     * @return array
     */
    public static function get_items_by_type($item_type)
    {

        global $wpdb;
        $table_name = $wpdb->prefix . "bbapp_itemmeta";

        $select_query = "SELECT * FROM {$table_name} WHERE item_type='{$item_type}'";

	    return $wpdb->get_results($select_query, OBJECT);
    }


    /**
     * Prepare Transient Name
     *
     * @param $item_id
     *
     * @return string
     */
    public static function prepare_transient_name($item_id)
    {
	    //Eg : "bbapp-$itemId-meta";
        return bbapp()->transient_key . $item_id . '-meta';
    }
}