<?php

namespace BuddyBossApp\ItemMeta;

if (!defined('ABSPATH')) {
    exit();
}

class LessonMeta extends ItemMeta
{
    private static $instance = null;

    private function __construct()
    {
        // ... leave empty, see Singleton below
    }

    /**
     * Get the instance of this class.
     * @return object
     */
    public static function instance()
    {
        if (null === self::$instance) {
            $class_name = __CLASS__;
            self::$instance = new $class_name;
            self::$instance->post_type = "sfwd-lessons";
            self::$instance->init();
        }

        return self::$instance;
    }


    /**
     * Fires when Item(Lesson) is saved/updated
     * @param $response
     * @param $post
     * @param $update
     * @return void
     */
    public function on_save_or_update($response, $post, $update)
    {
        $item_type = $post->post_type;
        $meta_data = itemMetaUtils::prepare_meta($post->ID);
        $status = itemMetaUtils::update_or_insert_item($post->ID, $item_type, $meta_data);
        if ($status) {
            // NOTE : Regenerating transient for this item
            itemMetaUtils::set_transient_for_item($post->ID);
        }

    }

    /**
     * Retrieve/Get meta-information of item(Lesson) since specified timestamp
     *
     * @param $item_type
     * @param $item_ids
     * @param $since_timestamp
     *
     * @return array
     */
    public static function get_meta_by_item_ids($item_type, $item_ids = null, $since_timestamp = null)
    {
        $transient_key = bbapp()->transient_key;
        $metas = array();

        foreach ($item_ids as $item_id) {
            $transient_name = $transient_key . $item_id . '-meta'; //Eg : "bbapp-$itemId-meta";
            if (false === get_transient($transient_name)) {
                $meta_data = itemMetaUtils::set_transient_for_item($item_id);
            } else {
                $meta_data = get_transient($transient_name);
            }

            if ( $since_timestamp == null) {
                $metas[$item_id] = $meta_data;
            } else {

                if ( $meta_data['updates']['last_changed'] > $since_timestamp) {
                    $metas[$item_id] = $meta_data;
                }
            }


        }
        return $metas;
    }

	/**
	 *
	 */
    public function on_plugin_activate()
    {
        self::$instance->store_meta_once();
    }

	/**
	 *
	 */
    public function on_plugin_deactivate()
    {
    }

	/**
	 * @return bool|void
	 */
    public function has_child()
    {
        // TODO: Implement has_child() method.
    }

	/**
	 * @return bool|void
	 */
    public function has_parent()
    {
        // TODO: Implement has_parent() method.
    }

}
