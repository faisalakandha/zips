<?php

namespace BuddyBossApp\ItemMeta;

if (!defined('ABSPATH')) {
    exit();
}


use WP_Error;
use WP_REST_Server;

class MetaApi
{

    public $table_name = "bbapp_itemmeta";
    public $namespace = "buddyboss-app/v1";
    private $route_slug = "/meta";
	private static $instance;

    private function __construct()
    {
        // ... leave empty, see Singleton below
    }

    /**
     * Get the instance of this class.
     * @return MetaApi
     */
	public static function instance()
	{

		if (is_null(self::$instance)) {
			self::$instance = new self();
			self::$instance->init();
		}

		return self::$instance;
	}

    /**
     *
     */
    public function init()
    {
        add_action('rest_api_init', array($this, "register_routes"));

    }

	/**
	 *
	 */
    public function register_routes()
    {

        // Item Meta Last changed
        register_rest_route($this->namespace, $this->route_slug . '/last-changed/' . '(?P<item_type>\S+)/', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'rest_item_last_changed'),
                'permission_callback' => '__return_true',
                'args' => array(
                    'item_type' => array(
                        'required' => true,
                        'type' => 'string',
                        'description' => __("Content Type.", 'buddyboss-app'),
                        'enum' => array('course', 'lesson', 'topic'),
                    ),
                    'item_id' => array(
                        'required' => true,
                        'type' => 'string',
                        'description' => __("Item ID", 'buddyboss-app'),
                    ),
                    'timestamp' => array(
                        'required' => true,
                        'type' => 'string',
                        'description' => __("Timestamp", 'buddyboss-app')
                    ),

                ),
            ),
        ));


        // Item Meta Since
        register_rest_route($this->namespace, $this->route_slug . '/(?P<item_type>\S+)', array(
            array(
                'methods' => WP_REST_Server::READABLE,
                'callback' => array($this, 'rest_items_meta_since'),
                'permission_callback' => '__return_true',
                'args' => array(
                    'item_type' => array(
                        'required' => true,
                        'type' => 'string',
                        'description' => __("Content Type.", 'buddyboss-app'),
                        'enum' => array('course', 'lesson', 'topic'),
                    ),
                    'item_filter' => array(
                        'required' => true,
                        'type' => 'array',
                        'description' => __("Item ID, timestamp", 'buddyboss-app'),
                    )
                ),
            ),
        ));


    }

    /**
     * @param $request
     * @return WP_Error
     * @api {GET} /wp-json/buddyboss-app/v1/meta/:item_type LearnDash item(s) meta since
     * @apiName GetItemMetaSince
     * @apiGroup LD Meta
     * @apiVersion 1.0.0
     * @apiPermission LoggedInUser
     * @apiDescription Information such as Last changed, changed by and further
     * @apiUse apidocForItemsMetaSinceV1
     */
    public function rest_items_meta_since($request)
    {
        $item_type = @$request->get_param('item_type');
        $item_ids = @$request->get_param('item_ids');
        $since_timestamp = @$request->get_param('timestamp');

        // NOTE : We need to do this here since can't use rest input validation
        if (!isset($since_timestamp) && !isset($item_ids)) {
            return new WP_Error('rest_missing_callback_param', __("Missing parameter: item_ids(array) or timestamp is required.", 'buddyboss-app'), array('status' => 400));
        }

        $meta_data = array();
        $last_change = null;

        switch ($item_type) {
            case 'course':
                $meta_data = CourseMeta::get_meta_by_item_ids('sfwd-courses', $item_ids, $since_timestamp);
                break;
            case 'lesson':
                $meta_data = LessonMeta::get_meta_by_item_ids('sfwd-lessons', $item_ids, $since_timestamp);
                break;
            case 'topic':
                $meta_data = TopicMeta::get_meta_by_item_ids('sfwd-topic', $item_ids, $since_timestamp);
                break;
        }

        if (is_wp_error($meta_data)) {
            return new WP_Error('error_while_retrieving', __("Error encountered while retrieving item by ID.", 'buddyboss-app'), array('status' => 500));
        }

        return rest_ensure_response($meta_data);

    }


    /**
     * @param $request
     * @return WP_Error
     * @api {GET} /wp-json/buddyboss-app/v1/meta/last-changed/:item_type LearnDash item last changed
     * @apiName GetItemMetaLastChanged
     * @apiGroup LD Meta
     * @apiVersion 1.0.0
     * @apiPermission LoggedInUser
     * @apiDescription Last change information for self and children's
     * @apiUse apidocForItemMetaLastChangedV1
     */
    public function rest_item_last_changed($request)
    {
        $item_type = @$request->get_param('item_type');
        $item_id = @$request->get_param('item_id');
        $since_timestamp = @$request->get_param('timestamp');

        $meta_data = array();
        $last_change = null;

        switch ($item_type) {
            case 'course':
                $meta_data = CourseMeta::get_item_last_changed('sfwd-courses', $item_id, $since_timestamp);
                break;
//            case 'lesson':
//                $metaData = LessonMeta::get_meta_by_item_ids('sfwd-lessons', $itemIds, $sinceTimestamp);
//                break;
//            case 'topic':
//                $metaData = TopicMeta::get_meta_by_item_ids('sfwd-topic', $itemIds, $sinceTimestamp);
//                break;
        }
//
        if (is_wp_error($meta_data)) {
            return new WP_Error('error_while_retrieving', __("Error encountered while retrieving item by ID.", 'buddyboss-app'), array('status' => 500));
        }

        return rest_ensure_response($meta_data);

    }

    /**
     * @param $response
     * @param $post
     * @param $request
     * @return response
     */
    public function rest_integrate_course($response, $post, $request)
    {

        // Only if our learner-component is currently working with learndash.
        if (class_exists('bbapp_learner_learndash')) {
            $data = $response->data;
            $data['new-property-1'] = 'property-value-1';
            $response->data = $data;
        }

        return $response;
    }

    /**
     * @param $response
     * @param $post
     * @param $request
     * @return response
     */
    public function rest_integrate_lesson($response, $post, $request)
    {

        $data = $response->data;
        $data['new-property-1'] = 'property-value-1';

        $response->data = $data;
        return $response;
    }

    /**
     * @return void
     */
    public function on_activation()
    {

        global $wpdb;

        $global_prefix = bbapp_get_global_db_prefix();

        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $table_name = "{$global_prefix}bbapp_itemmeta";

        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) NOT NULL AUTO_INCREMENT PRIMARY KEY,
            item_id bigint(20) NOT NULL,
            item_type varchar(100) NOT NULL,
            meta_data longtext NOT NULL,
            date_created datetime DEFAULT '0000-00-00 00:00:00' NULL,
            date_updated datetime DEFAULT '0000-00-00 00:00:00' NULL
		    ) {$charset_collate}";

        dbDelta($sql);

    }

    /**
     * @return void
     */
    public function on_plugin_deactivate()
    {
    }

}
