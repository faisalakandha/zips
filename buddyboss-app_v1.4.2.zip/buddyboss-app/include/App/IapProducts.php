<?php

namespace BuddyBossApp\App;

use BuddyBossApp\Admin\Configure;

class IapProducts {

	private static $instance;

	/**
	 * IapProducts constructor.
	 */
	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * @return mixed
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {

		App::instance()->add_local_feature( "in_app_purchases", array(
			"is_enabled_android" => true,
			"is_enabled_ios"     => true,
		) );

		/**
		 * Register menus & widgets.
		 */
		add_filter( 'bbapp_feature_availability_in_app_purchases', array( $this, 'featureAvailability' ), 1, 1 );

	}

	/**
	 * Feature availability check for InAppPurchase
	 * NOTE : The feature can still be disabled by BuddyBossApp(control center, old-name: customer center) doesn't matter what's the status here
	 *
	 * @param $feature
	 *
	 * @return mixed
	 */
	public function featureAvailability( $feature ) {

		$feature["is_enabled_ios"]     = false;
		$feature["is_enabled_android"] = false;

		if ( bbapp_is_active( 'iap' ) ) {

			// On Admin UI: iOs(icon) App Shared Secret
			$iOsSecret = Configure::instance()->option( 'publish.ios.shared_secret' );
			// On Admin UI: Android(icon) Service Account Key
			$androidKey = Configure::instance()->option( 'publish.android.account_key' );

			$feature["is_enabled_ios"]     = ! empty( $iOsSecret );
			$feature["is_enabled_android"] = ! empty( $androidKey );
		}

		return $feature;
	}

}
