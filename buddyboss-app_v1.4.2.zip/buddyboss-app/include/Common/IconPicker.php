<?php

namespace BuddyBossApp\Common;

// Exit if accessed directly
use BuddyBossApp\Helpers\BBAPP_File;
use BuddyBossApp\Helpers\File;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class IconPicker {

	public static $instance;

	public function __construct() {
	}

	/**
	 * Get the instance of the class.
	 *
	 * @return IconPicker
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function _load() {
		$this->hooks();
	}

	/**
	 * Define all Hooks.
	 */
	public function hooks() {
		add_action( 'wp_ajax_bbapp_icon_picker_upload', array( $this, 'icon_picker_upload' ) );
		add_action( 'wp_ajax_bbapp_delete_custom_icon', array( $this, 'delete_custom_icon' ) );
		add_action( "admin_enqueue_scripts", array( $this, "admin_head" ), 9 );
	}

	function admin_head() {
		global $pagenow, $post_type;

		$_get_var = function ( $getkey ) {
			return ( isset( $_GET[ $getkey ] ) ) ? $_GET[ $getkey ] : "";
		};

		if (
			( in_array( $pagenow, array(
					'post-new.php',
					'edit.php',
					'post.php',
					'edit.php'
				) ) && $post_type == "app_page" ) ||
			( $pagenow == "admin.php" && in_array( $_get_var( "page" ), array( "bbapp-appearance" ) ) && in_array( $_get_var( "setting" ), array(
					"app_menu",
					"branding",
					""
				) ) )
		) {
			add_action( 'admin_footer', array( $this, 'load_icon_picker_code' ) );
		}
	}

	/**
	 * Icon Picker Related Code
	 */
	public function load_icon_picker_code() {

		/**
		 * Do not removed these variables.
		 * Variables used under footer.php.
		 */
		$icons_url         = $this->icon_picker_app_icon_url();
		$icons_path        = $this->icon_picker_app_icon_dir();
		$custom_icons_path = $this->icon_picker_custom_icon_url();

		// Include AppPage Footer Code.
		include bbapp()->plugin_dir . 'views/icon-picker/footer.php';


	}

	/**
	 * Ajax handler to upload custom icons into wordpress.
	 *
	 * @return void
	 */
	public function icon_picker_upload() {

		$icons_size = 200;

		if ( ! current_user_can( "manage_options" ) ) {
			wp_send_json_error( __( "You don't have permission to upload a custom icon", 'buddyboss-app' ) );
		}

		$task = @$_POST["task"];

		if ( $task == "upload" ) {

			$dir = $this->icon_picker_custom_icon_dir();
			$url = $this->icon_picker_custom_icon_url();

			$file_data = $_FILES["icon"];
			$file_data = BBAPP_File::readFile( $file_data["tmp_name"] );

			if ( empty( $file_data ) ) {
				wp_send_json_error( __( "Icon you provided is invalid.", 'buddyboss-app' ) );
			}

			$file_hash = uniqid() . ".png";

			$im = imagecreatefromstring( $file_data );

			if ( ! $im ) {
				wp_send_json_error( __( "Icon you provided is invalid.", 'buddyboss-app' ) );
			}

			$width = imagesx( $im );

			$height = imagesy( $im );

			if ( $width != $icons_size || $height != $icons_size ) {
				wp_send_json_error( __( "Please provide an icon with correct size.", 'buddyboss-app' ) );
			}

			$out_location = $dir . "/" . $file_hash;

			// Save the image
			$new = imagecreatetruecolor( $width, $height );
			imagecolortransparent( $new, imagecolorallocatealpha( $new, 0, 0, 0, 127 ) );
			imagealphablending( $new, false );
			imagesavealpha( $new, true );
			imagecopyresampled( $new, $im, 0, 0, 0, 0, $icons_size, $icons_size, $width, $height );
			imagepng( $new, $out_location );

			imagedestroy( $im );

			$name = "custom/" . $file_hash;

			wp_send_json_success( array( "url" => $url . "/" . $file_hash, "name" => $name ) );

			exit;

		}

	}

	/**
	 * Delete Custom Icon selected.
	 */
	public function delete_custom_icon() {
		if ( ! current_user_can( "manage_options" ) ) {
			wp_send_json_error( __( "You don't have permission to delete a custom icon", 'buddyboss-app' ) );
		}

		$task      = @$_POST["task"];
		$icon_data = ! empty( $_POST["elm1_data_val"] ) ? $_POST["elm1_data_val"] : '';

		if ( empty( $icon_data ) ) {
			wp_send_json_error( __( "Please choose custom Icon to Delete.", 'buddyboss-app' ) );
		}

		$icon_data = explode( '/', $icon_data );
		$icon      = isset( $icon_data[1] ) ? $icon_data[1] : '';

		if ( empty( $icon ) ) {
			wp_send_json_error( __( "Please choose custom Icon to Delete.", 'buddyboss-app' ) );
		}

		if ( 'delete_custom_icon' === $task ) {
			$dir = $this->icon_picker_custom_icon_dir();

			$icon_path = $dir . '/' . $icon;

			if ( file_exists( $icon_path ) ) {
				wp_delete_file( $icon_path );
				wp_send_json_success( __( "Icon deleted.", 'buddyboss-app' ) );
			}

			exit;
		}
	}

	/**
	 * Return the Icon URI.
	 *
	 * @param $icon
	 * @param bool $default
	 * @param $icon_style
	 *
	 * @return bool|string
	 */
	public function get_icon_uri( $icon, $default = false, $icon_style = 'filled' ) {

		$icons_path = $this->icon_picker_app_icon_url();
		$icons_dir  = $this->icon_picker_app_icon_dir();

		if ( empty( $icon ) ) {
			return $default;
		}

		if ( strpos( $icon, "custom/" ) !== false ) {

			// if it's custom uploaded icon.
			$icon       = str_replace( "custom/", "/", $icon ); // remove the identifier.
			$icons_path = $this->icon_picker_custom_icon_url();
			$icons_dir  = $this->icon_picker_custom_icon_dir();

		}

		if ( file_exists( $icons_dir . $icon . '-' . $icon_style . '.png' ) ) {
			return $icons_path . $icon . '-' . $icon_style . '.png';
		} elseif ( file_exists( $icons_dir . $icon ) ) {
			return $icons_path . $icon;
		} else {
			return $default;
		}

	}

	/**
	 * App Icon picker dir path.
	 * @return string
	 */
	public function icon_picker_app_icon_dir() {
		return trailingslashit( bbapp()->plugin_dir . "assets/app-icons/" );

	}

	/**
	 * App Icon picker url path.
	 * @return string
	 */
	public function icon_picker_app_icon_url() {
		return trailingslashit( bbapp()->plugin_url . "assets/app-icons/" );
	}

	/**
	 * App icon list.
	 */
	public function ap_icon_picker_app_icon_list() {
		$bpapp_icon_list = array(
			'activity'              => __( "Activity", "Tab Bar Icon", "buddyboss-app" ),
			'blog'                  => __( "Blog", "Tab Bar Icon", "buddyboss-app" ),
			'book-open'             => __( "Courses", "Tab Bar Icon", "buddyboss-app" ),
			'achievement'           => __( "Achievement", "Tab Bar Icon", "buddyboss-app" ),
			'certificates'          => __( "Certificates", "Tab Bar Icon", "buddyboss-app" ),
			'category'              => __( "Category", "Tab Bar Icon", "buddyboss-app" ),
			'file'                  => __( "Page", "Tab Bar Icon", "buddyboss-app" ),
			'forums'                => __( "Forums", "Tab Bar Icon", "buddyboss-app" ),
			'groups'                => __( "Groups", "Tab Bar Icon", "buddyboss-app" ),
			'home'                  => __( "Home", "Tab Bar Icon", "buddyboss-app" ),
			'library'               => __( "Library", "Tab Bar Icon", "buddyboss-app" ),
			'messages'              => __( "Messages", "Tab Bar Icon", "buddyboss-app" ),
			'notification'          => __( "Notifications", "Tab Bar Icon", "buddyboss-app" ),
			'people'                => __( "Members", "Tab Bar Icon", "buddyboss-app" ),
			'photos'                => __( "Photos", "Tab Bar Icon", "buddyboss-app" ),
			'products'              => __( "Products", "Tab Bar Icon", "buddyboss-app" ),
			'profile'               => __( "Profile", "Tab Bar Icon", "buddyboss-app" ),
			'settings'              => __( "Settings", "Tab Bar Icon", "buddyboss-app" ),
			'topics'                => __( "Discussion", "Tab Bar Icon", "buddyboss-app" ),
			'web-link'              => __( "Web Link", "Tab Bar Icon", "buddyboss-app" ),
			'documents'             => __( "Documents", "Tab Bar Icon", "buddyboss-app" ),
			'email'                 => __( "Email", "Tab Bar Icon", "buddyboss-app" ),
			'folder'                => __( "Folder", "Tab Bar Icon", "buddyboss-app" ),
			'folders'               => __( "Folders", "Tab Bar Icon", "buddyboss-app" ),
			'graduation-cap'        => __( "Graduation Cap", "Tab Bar Icon", "buddyboss-app" ),
			'bar-chart'             => __( "Bar Chart", "Tab Bar Icon", "buddyboss-app" ),
			'hashtag'               => __( "Hashtag", "Tab Bar Icon", "buddyboss-app" ),
			'health'                => __( "Health", "Tab Bar Icon", "buddyboss-app" ),
			'list-square'           => __( "List Square", "Tab Bar Icon", "buddyboss-app" ),
			'map'                   => __( "Map", "Tab Bar Icon", "buddyboss-app" ),
			'map-marker'            => __( "Map Marker", "Tab Bar Icon", "buddyboss-app" ),
			'chat'                  => __( "Chat", "Tab Bar Icon", "buddyboss-app" ),
			'audio'                 => __( "Audio", "Tab Bar Icon", "buddyboss-app" ),
			'photo-edit'            => __( "Photo Edit", "Tab Bar Icon", "buddyboss-app" ),
			'pinterest'             => __( "Pinterest", "Tab Bar Icon", "buddyboss-app" ),
			'playlist'              => __( "Playlist", "Tab Bar Icon", "buddyboss-app" ),
			'lock'                  => __( "Lock", "Tab Bar Icon", "buddyboss-app" ),
			'heart'                 => __( "Heart", "Tab Bar Icon", "buddyboss-app" ),
			'reward'                => __( "Reward", "Tab Bar Icon", "buddyboss-app" ),
			'videos'                => __( "Videos", "Tab Bar Icon", "buddyboss-app" ),
			'airbnb'                => __( "Airbnb", "Tab Bar Icon", "buddyboss-app" ),
			'bookmark'              => __( "Bookmark", "Tab Bar Icon", "buddyboss-app" ),
			'browser'               => __( "Browser", "Tab Bar Icon", "buddyboss-app" ),
			'build'                 => __( "Build", "Tab Bar Icon", "buddyboss-app" ),
			'business'              => __( "Business", "Tab Bar Icon", "buddyboss-app" ),
			'calendar'              => __( "Calendar", "Tab Bar Icon", "buddyboss-app" ),
			'camera'                => __( "Camera", "Tab Bar Icon", "buddyboss-app" ),
			'pie-chart'             => __( "Pie Chart", "Tab Bar Icon", "buddyboss-app" ),
			'call'                  => __( "Call", "Tab Bar Icon", "buddyboss-app" ),
			'clock'                 => __( "Clock", "Tab Bar Icon", "buddyboss-app" ),
			'content'               => __( "Content", "Tab Bar Icon", "buddyboss-app" ),
			'credit-card'           => __( "Credit Card", "Tab Bar Icon", "buddyboss-app" ),
			'dashboard'             => __( "Dashboard", "Tab Bar Icon", "buddyboss-app" ),
			'dribbble'              => __( "Dribbble", "Tab Bar Icon", "buddyboss-app" ),
			'dropbox'               => __( "Dropbox", "Tab Bar Icon", "buddyboss-app" ),
			'facebook'              => __( "Facebook", "Tab Bar Icon", "buddyboss-app" ),
			'google-drive'          => __( "Google Drive", "Tab Bar Icon", "buddyboss-app" ),
			'instagram'             => __( "Instagram", "Tab Bar Icon", "buddyboss-app" ),
			'briefcase'             => __( "Briefcase", "Tab Bar Icon", "buddyboss-app" ),
			'list'                  => __( "List", "Tab Bar Icon", "buddyboss-app" ),
			'medium'                => __( "Medium", "Tab Bar Icon", "buddyboss-app" ),
			'menu'                  => __( "Menu", "Tab Bar Icon", "buddyboss-app" ),
			'paypal'                => __( "PayPal", "Tab Bar Icon", "buddyboss-app" ),
			'slack'                 => __( "Slack", "Tab Bar Icon", "buddyboss-app" ),
			'soundcloud'            => __( "SoundCloud", "Tab Bar Icon", "buddyboss-app" ),
			'spotify'               => __( "Spotify", "Tab Bar Icon", "buddyboss-app" ),
			'telegram'              => __( "Telegram", "Tab Bar Icon", "buddyboss-app" ),
			'tumblr'                => __( "Tumblr", "Tab Bar Icon", "buddyboss-app" ),
			'twitter'               => __( "Twitter", "Tab Bar Icon", "buddyboss-app" ),
			'vk'                    => __( "VK", "Tab Bar Icon", "buddyboss-app" ),
			'web-page'              => __( "Web Page", "Tab Bar Icon", "buddyboss-app" ),
			'whatsapp'              => __( "WhatsApp", "Tab Bar Icon", "buddyboss-app" ),
			'youtube'               => __( "YouTube", "Tab Bar Icon", "buddyboss-app" ),
			'android'               => __( "Android", "Tab Bar Icon", "buddyboss-app" ),
			'apple'                 => __( "Apple", "Tab Bar Icon", "buddyboss-app" ),
			'apple-watch'           => __( "Apple Watch", "Tab Bar Icon", "buddyboss-app" ),
			'award-rating'          => __( "Award Rating", "Tab Bar Icon", "buddyboss-app" ),
			'shopping-bag'          => __( "Shopping Bag", "Tab Bar Icon", "buddyboss-app" ),
			'bar-graph'             => __( "Bar Graph", "Tab Bar Icon", "buddyboss-app" ),
			'download'              => __( "Download", "Tab Bar Icon", "buddyboss-app" ),
			'fingerprint'           => __( "Fingerprint", "Tab Bar Icon", "buddyboss-app" ),
			'github'                => __( "Github", "Tab Bar Icon", "buddyboss-app" ),
			'google-chrome'         => __( "Google Chrome", "Tab Bar Icon", "buddyboss-app" ),
			'google'                => __( "Google", "Tab Bar Icon", "buddyboss-app" ),
			'linkedin'              => __( "Linkedin", "Tab Bar Icon", "buddyboss-app" ),
			'skype'                 => __( "Skype", "Tab Bar Icon", "buddyboss-app" ),
			'snapchat'              => __( "SnapChat", "Tab Bar Icon", "buddyboss-app" ),
			'about'                 => __( "About", "Tab Bar Icon", "buddyboss-app" ),
			'email-preferences'     => __( "Email Preferences", "Tab Bar Icon", "buddyboss-app" ),
			'export-data'           => __( "Export Data", "Tab Bar Icon", "buddyboss-app" ),
			'feedback'              => __( "Feedback", "Tab Bar Icon", "buddyboss-app" ),
			'privacy-settings'      => __( "Privacy Settings", "Tab Bar Icon", "buddyboss-app" ),
			'profile-connections'   => __( "Profile Connections", "Tab Bar Icon", "buddyboss-app" ),
			'profile-email-invites' => __( "Invites", "Tab Bar Icon", "buddyboss-app" ),
			'profile-groups'        => __( "Profile Groups", "Tab Bar Icon", "buddyboss-app" ),
			'profile-timeline'      => __( "Profile Activity", "Tab Bar Icon", "buddyboss-app" ),
			'push-notifications'    => __( "Push notifications", "Tab Bar Icon", "buddyboss-app" ),
		);
		asort( $bpapp_icon_list );

		return array(
			'bbapp' => $bpapp_icon_list
		);
	}

	/**
	 * Returns the directory of custom icons.
	 *
	 * @return string
	 */
	public function icon_picker_custom_icon_dir() {
		$upload_dir = wp_upload_dir();
		$dir        = $upload_dir["basedir"] . "/bbapp/custom-icons";
		if ( ! file_exists( $dir ) ) {
			BBAPP_File::CreateDir(dirname( $dir ));
			BBAPP_File::CreateDir($dir);
		}

		return $dir;
	}

	/**
	 * Returns the url of custom icons directory.
	 *
	 * @return string
	 */
	public function icon_picker_custom_icon_url() {
		$upload_dir = wp_upload_dir();
		$dir        = $upload_dir["baseurl"] . "/bbapp/custom-icons";

		return $dir;
	}

	/**
	 * Return the list of custom icons uploaded.
	 *
	 * @return array
	 */
	public function icon_picker_custom_icon_list() {
		$dir   = \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_dir();
		$icons = glob( $dir . "/*.png" );
		$list  = array();
		foreach ( $icons as $icon ) {
			$icon   = basename( $icon );
			$list[] = "custom/{$icon}"; // /custom is a identifier.
		}

		return $list;
	}

	/**
	 * Make common svg crater.
	 *
	 * @param $menu_id
	 * @param $color
	 */
	public function icon_picker_svg_render( $menu_id, $color ) {
		?>
        <svg id="<?php echo esc_attr( $menu_id ); ?>"
             style="position: absolute; height: 0; visibility: hidden; width: 0;">
            <defs>
                <filter id="bbapp-<?php echo esc_attr( $menu_id ); ?>">
                    <feFlood flood-color="<?php echo esc_attr( $color ); ?>"></feFlood>
                    <feComposite in2="SourceAlpha" operator="atop"></feComposite>
                </filter>
            </defs>
        </svg>
		<?php
	}

}