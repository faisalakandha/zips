<?php
namespace BuddyBossApp\Auth;

// Contains all common function
class Common {

    private static $instance;

    public function __construct()
    {
    }

    /**
     * Get class instance
     *
     * @return Common
     */
    public static function instance()
    {

        if (is_null(self::$instance)) {
            self::$instance = new self();
            self::$instance->hooks();
        }

        return self::$instance;
    }

	/**
	 *
	 */
	public function hooks() {}

	/**
	 * @param $user_login
	 *
	 * @return bool|\WP_Error
	 */
	public static function api_retrieve_password($user_login) {

		global $wpdb, $wp_hasher;

		$errors = new \WP_Error();

        $user_data = false;

		if (empty($user_login)) {
			$errors->add( 'empty_username', __( 'ERROR: Enter a username or email address.', 'buddyboss-app' ), array( 'status' => 400 ) );
		} elseif (strpos($user_login, '@')) {
			$user_data = get_user_by('email', trim($user_login));
			if (empty($user_data)) {
				$errors->add( 'invalid_email', __( 'ERROR: There is no user registered with that email address.', 'buddyboss-app' ), array( 'status' => 400 ) );
			}

		} else {
			$login = trim($user_login);
			$user_data = get_user_by('login', $login);
		}

		/**
		 * Fires before errors are returned from a password reset request.
		 *
		 * @since 2.1.0
		 * @since 4.4.0 Added the `$errors` parameter.
		 *
		 * @param \WP_Error $errors A \WP_Error object containing any errors generated
		 *                         by using invalid credentials.
		 */
		do_action('lostpassword_post', $errors);

		if ($errors->get_error_code()) {
			return $errors;
		}

		if (!$user_data) {
			$errors->add( 'invalidcombo', __( 'ERROR: Invalid username or email.', 'buddyboss-app' ), array( 'status' => 400 ) );
			return $errors;
		}

		// Redefining user_login ensures we return the right case in the email.
		$user_login = $user_data->user_login;
		$user_email = $user_data->user_email;
		$key = get_password_reset_key($user_data);

		if (is_wp_error($key)) {
			return $key;
		}

		$message = __('Someone has requested a password reset for the following account:') . "\r\n\r\n";
		$message .= network_home_url('/') . "\r\n\r\n";
		$message .= sprintf(__('Username: %s'), $user_login) . "\r\n\r\n";
		$message .= __('If this was a mistake, kindly ignore this email, and no further action is required.') . "\r\n\r\n";
		$message .= __('To reset your password, visit the following address:') . "\r\n\r\n";
		$message .= '<' . network_site_url("wp-login.php?action=rp&key=$key&login=" . rawurlencode($user_login), 'login') . ">\r\n";

		if (is_multisite()) {
			$blogname = $GLOBALS['current_site']->site_name;
		} else
		/*
			             * The blogname option is escaped with esc_html on the way into the database
			             * in sanitize_option we want to reverse this for the plain text arena of emails.
		*/
		{
			$blogname = wp_specialchars_decode(get_option('blogname'), ENT_QUOTES);
		}

		$title = sprintf( __( '[%s] Password Reset', 'buddyboss-app' ), $blogname );

		$title = apply_filters('retrieve_password_title', $title, $user_login, $user_data);

		$message = apply_filters('retrieve_password_message', $message, $key, $user_login, $user_data);

		if ( $message && ! wp_mail( $user_email, wp_specialchars_decode( $title ), $message ) ) {
			return new \WP_Error( 'couldnt_send_mail', __( 'The email could not be sent. Possible reason: your host may have disabled the mail() function.', 'buddyboss-app' ), array(
				'status' =>
					500,
			) );
		}

		return true;
	}

	/**
	 * @return bool|mixed
	 */
	public function get_access_token() {
		$header = $this->getallheaders();
		$jwt_token = false;
		foreach ($header as $k => $v) {
			if (strtolower($k) == "accesstoken") {
				$jwt_token = $v;
				break;
			}
		}

		return $jwt_token;
	}

	/**
	 * Add Custom Cookie for extra cookie adding.
	 *
	 * @return bool|mixed
	 */
	public function get_custom_cookie() {
		$header        = $this->getallheaders();
		$custom_cookie = false;
		foreach ( $header as $k => $v ) {
			if ( strtolower( $k ) == "bbapp-cookie" ) {
				$custom_cookie = $v;
				break;
			}
		}

		return $custom_cookie;
	}

	/**
	 * @return array|false|string
	 */
	public function getallheaders() {

		if (function_exists("getallheaders")) {
			return getallheaders();
		}

		if (!is_array($_SERVER)) {
			return array();
		}

		$headers = array();
		foreach ($_SERVER as $name => $value) {
			if (substr($name, 0, 5) == 'HTTP_') {
				$headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
			}
		}

		return $headers;
	}

}