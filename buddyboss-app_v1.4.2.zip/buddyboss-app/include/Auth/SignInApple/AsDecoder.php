<?php

namespace BuddyBossApp\Auth\SignInApple;

use BuddyBossApp\Auth\SignInApple\AsJwk;
use BuddyBossApp\Auth\SignInApple\AsJwt;

use Exception;

/**
 * Decode Sign In with Apple identity token, and produce an AsPayload for
 * utilizing in backend auth flows to verify validity of provided user creds.
 */
class AsDecoder
{

    /**
     * Parse a provided Sign In with Apple identity token.
     *
     * @param string $identityToken
     * @return object|null
     * @throws Exception
     */
    public static function getAppleSignInPayload($identityToken)
    {
        $identityPayload = self::decodeIdentityToken($identityToken);
        return new AsPayload($identityPayload);
    }

    /**
     * Decode the Apple encoded JWT using Apple's public key for the signing.
     *
     * @param string $identityToken
     * @return object
     * @throws Exception
     */
    public static function decodeIdentityToken($identityToken)
    {
        $publicKeyData = self::fetchPublicKey();

        $publicKey = $publicKeyData['publicKey'];
        $alg = $publicKeyData['alg'];

        return AsJwt::decode($identityToken, $publicKey, [$alg]);
    }

    /**
     * Fetch Apple's public key from the auth/keys REST API to use to decode
     * the Sign In JWT.
     *
     * @return array
     * @throws Exception
     */
    public static function fetchPublicKey()
    {
        $publicKeys = file_get_contents('https://appleid.apple.com/auth/keys');
        $decodedPublicKeys = json_decode($publicKeys, true);

        if (!isset($decodedPublicKeys['keys']) || count($decodedPublicKeys['keys']) < 1) {
            throw new Exception('Invalid key format.');
        }

        $parsedKeyData = $decodedPublicKeys['keys'][0];
        $parsedPublicKey = AsJwk::parseKey($parsedKeyData);
        $publicKeyDetails = openssl_pkey_get_details($parsedPublicKey);

        if (!isset($publicKeyDetails['key'])) {
            throw new Exception('Invalid public key details.');
        }

        return [
            'publicKey' => $publicKeyDetails['key'],
            'alg' => $parsedKeyData['alg']
        ];
    }
}

/**
 * A class decorator for the Sign In with Apple payload produced by
 * decoding the signed JWT from a client.
 */
class AsPayload
{
    protected $_instance;

    public function __construct($instance)
    {
        if (is_null($instance)) {
            throw new Exception('AsPayload received null instance.');
        }
        $this->_instance = $instance;
    }

    public function __call($method, $args)
    {
        return call_user_func_array(array($this->_instance, $method), $args);
    }

    public function __get($key)
    {
        return $this->_instance->$key;
    }

    public function __set($key, $val)
    {
        return $this->_instance->$key = $val;
    }

    public function getEmail()
    {
        return (isset($this->_instance->email)) ? $this->_instance->email : null;
    }

    public function getUser()
    {
        return (isset($this->_instance->sub)) ? $this->_instance->sub : null;
    }

    public function verifyUser($user)
    {
        return $user === $this->getUser();
    }
}
