<?php

namespace BuddyBossApp\Admin\InAppPurchases;

class UpgradeHelper {

	private static $instance;
	private $messages = array();

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 * @return Helpers
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * Load additional hooks such as : admin_init
	 * NOTE : Method is similar to concept of init
	 * @return void {void}
	 */
	public function _load() {
		// All actions/filters below
	}


	/**
	 * Get old IAP-products data, to be refactored
	 * @return void
	 */
	public static function upgradeProductsToNewSchema() {

		global $wpdb;

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		$query        = "SELECT * FROM {$globalPrefix}bbapp_iap_products_OLD";
		$rows         = $wpdb->get_results( $query, OBJECT );

		if ( IAP_LOG ) {
			$totalRows = count( $rows );
			echo "Total rows need to be imported : " . $totalRows;

			foreach ( $rows as $row ) {
				echo "<br/>Attempt for ID:" . $row->id . '    Status:' . self::insertOrUpdateProduct( $row );
			}
		}
	}


	/**
	 * Insert/Update old IAP-products data into new IAP-products-table
	 *
	 * @param $row
	 *
	 * @return  integer $status
	 */
	public static function insertOrUpdateProduct( $row ) {

		global $wpdb;

		$tableName = \bbapp_iap()->get_global_dbprefix() . 'bbapp_iap_products';
		$itemIds   = null;
		if ( isset( $row->item_id ) ) {
			$itemIds = serialize( $row->item_id );
		}

		$devicePlatform = null;
		if ( isset( $row->iap_type ) ) {
			// NOTE : Old DB column has single value(and NOT serialized). Eg : apple or google
			$iapType = $row->iap_type;

			if ( $iapType == 'apple' ) {
				$devicePlatform = 'ios';
			} elseif ( $iapType == 'google' ) {
				$devicePlatform = 'android';
			}
		}

		$integrationTypes = null;
		if ( isset( $row->item_type ) ) {
			$integrationTypes = serialize( $row->item_type );
		}


		$dateCreated = null;
		$dateUpdated = null;
		if ( isset( $row->date_created ) ) {
			$dateCreated = $row->date_created;
			// NOTE : Keeping date_updated same as date_created since old IAP didn't had date_updated column
			$dateUpdated = $dateCreated;
		}

		// NOTE : we don't use this column at-all currently
		$secondaryId = 0;

		// TODO : Below need to be calculated since old IAP didn't had this fields
		$BuddyBossAppProductId = - 11;
		$storeProductId   = - 11;

		$selectQuery = "SELECT count(*) as total FROM {$tableName} WHERE id = {$row->id}";
		$exists      = $wpdb->get_results( $selectQuery );
		if ( isset( $exists[0]->total ) && $exists[0]->total == 0 ) {
			$insertQuery = "INSERT INTO {$tableName} (`id`,
 `blog_id`, `user_id`, `bbapp_product_id`, `device_platform`, `order_status`,
  `store_product_id`, `integration_types`, `item_ids`, `is_recurring`, `secondary_id`, `date_created`, `date_updated`, `expire_at`, `user_email`) 
VALUES ('{$row->id}', '{$row->blog_id}', '{$row->user_id}','{$BuddyBossAppProductId}','{$devicePlatform}','{$row->order_status}', '{$row->storeProductId}', 
'{$integrationTypes}','{$itemIds}','{$row->is_recurring}','{$secondaryId}', '{$dateCreated}','{$dateUpdated}','{$row->expire_at}','{$row->user_email}')";

			$status = $wpdb->query( $insertQuery );
		} else {

			$settings = Settings::instance()->get_settings();

			if ( isset( $settings['logger.iap_log.enabled'] ) && $settings['logger.iap_log.enabled'] ) {

			}
			$status = $wpdb->update(
				$tableName,
				array(
					'blog_id'            => $row->blog_id,
					'user_id'            => $row->user_id,
					'bbapp_product_id' => $row->order_status,
					'device_platform'    => $devicePlatform,
					'order_status'       => $row->order_status,
					'store_product_id'   => $row->order_status,
					'integration_types'  => $integrationTypes,
					'item_ids'           => $itemIds,
					'is_recurring'       => $row->is_recurring,
					'secondary_id'       => $secondaryId,
					'date_created'       => $dateCreated,
					'date_updated'       => $dateUpdated,
					'expire_at'          => $row->expire_at,
					'user_email'         => $row->user_email,
				),
				array( 'id' => $row->id )
			);

		}

		return $status;
	}

	/**
	 * Get old data, to be refactored
	 * @return void
	 */
	public static function upgradeOrdersToNewSchema() {

		global $wpdb;

		$query    = "SELECT * FROM {$wpdb->prefix}appb_iap_orders_OLD";
		$rows     = $wpdb->get_results( $query, OBJECT );
		$settings = Settings::instance()->get_settings();

		if ( isset( $settings['logger.iap_log.enabled'] ) && $settings['logger.iap_log.enabled'] ) {

		}
		$totalRows = count( $rows );
		echo "Total rows need to be imported : " . $totalRows;

		foreach ( $rows as $row ) {
			echo "<br/>Attempt for ID:" . $row->id . '    Status:' . self::insertOrUpdateOrder( $row );
		}
	}

	/**
	 * Insert/Update into NEW
	 *
	 * @param $row
	 *
	 * @return array {object}
	 */
	public static function insertOrUpdateOrder( $row ) {

		global $wpdb;

		$tableName = $wpdb->prefix . 'bbapp_iap_orders';
		$itemIds   = null;
		if ( isset( $row->item_id ) ) {
			$itemIds = serialize( $row->item_id );
		}

		$devicePlatform = null;
		if ( isset( $row->iap_type ) ) {
			// NOTE : Old DB column has single value(and unserialized). Eg : apple or google
			$iapType = $row->iap_type;

			if ( $iapType == 'apple' ) {
				$devicePlatform = 'ios';
			} elseif ( $iapType == 'google' ) {
				$devicePlatform = 'android';
			}
		}

		$integrationTypes = null;
		if ( isset( $row->item_type ) ) {
			$integrationTypes = serialize( $row->item_type );
		}


		$dateCreated = null;
		$dateUpdated = null;
		if ( isset( $row->date_created ) ) {
			$dateCreated = $row->date_created;
			// NOTE : Keeping date_updated same as date_created since old IAP didn't had date_updated column
			$dateUpdated = $dateCreated;
		}

		// NOTE : we don't use this column at-all currently
		$secondaryId = 0;

		// TODO : Below need to be calculated since old IAP didn't had this fields
		$BuddyBossAppProductId = - 11;
		$storeProductId   = - 11;

		$selectQuery = "SELECT count(*) as total FROM {$tableName} WHERE id = {$row->id}";
		$exists      = $wpdb->get_results( $selectQuery );
		if ( isset( $exists[0]->total ) && $exists[0]->total == 0 ) {
			$insertQuery = "INSERT INTO {$tableName} (`id`,
 `blog_id`, `user_id`, `bbapp_product_id`, `device_platform`, `order_status`,
  `store_product_id`, `integration_types`, `item_ids`, `is_recurring`, `secondary_id`, `date_created`, `date_updated`, `expire_at`, `user_email`) 
VALUES ('{$row->id}', '{$row->blog_id}', '{$row->user_id}','{$BuddyBossAppProductId}','{$devicePlatform}','{$row->order_status}', '{$row->storeProductId}', 
'{$integrationTypes}','{$itemIds}','{$row->is_recurring}','{$secondaryId}', '{$dateCreated}','{$dateUpdated}','{$row->expire_at}','{$row->user_email}')";

			$status = $wpdb->query( $insertQuery );
		} else {

			$status = $wpdb->update(
				$tableName,
				array(
					'blog_id'            => $row->blog_id,
					'user_id'            => $row->user_id,
					'bbapp_product_id' => $row->order_status,
					'device_platform'    => $devicePlatform,
					'order_status'       => $row->order_status,
					'store_product_id'   => $row->order_status,
					'integration_types'  => $integrationTypes,
					'item_ids'           => $itemIds,
					'is_recurring'       => $row->is_recurring,
					'secondary_id'       => $secondaryId,
					'date_created'       => $dateCreated,
					'date_updated'       => $dateUpdated,
					'expire_at'          => $row->expire_at,
					'user_email'         => $row->user_email,
				),
				array( 'id' => $row->id )
			);

		}

		return $status;
	}
}