<?php

namespace BuddyBossApp\Admin\InAppPurchases;
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Helpers\WP_List_Table;
use BuddyBossApp\InAppPurchases\SubscriptionGroupTaxonomy;

class ProductList extends WP_List_Table {
	/**
	 * The type of view currently being displayed.
	 *
	 * E.g. "All", "Pending", "Approved", "Spam"...
	 *
	 * @since BuddyPress 1.7.0
	 * @var string
	 */
	public $view = 'all';
	/**
	 * Group counts for each group type.
	 *
	 * @since BuddyPress 1.7.0
	 * @var int
	 */
	public $iap_product_counts = 0;

	/** Class constructor */
	public function __construct() {
		parent::__construct( array(
			'singular' => __( 'IAP Product', 'buddyboss-app' ), //singular name of the listed records
			'plural'   => __( 'IAP Products', 'buddyboss-app' ), //plural name of the listed records
			'ajax'     => false, //should this table support ajax?

		) );
	}

	/**
	 * Get products from database.
	 *
	 * @param int    $per_page
	 * @param int    $page_number
	 * @param string $view
	 *
	 * @return mixed
	 */
	public static function get_products( $per_page = 5, $page_number = 1,$view = '' ) {

		$args    = array();
		$request = $_REQUEST;
		if ( isset( $request['orderby'] ) && ! empty( $request['orderby'] ) ) {
			$args["orderby"] = $request['orderby'];
		}
		if ( isset( $request['order'] ) && ! empty( $request['order'] ) ) {
			$args["order"] = $request['order'];
		}

		if ( ! empty( $view ) && 'all' !== $view ) {
			$args['status'] = $view;
		}

		$args["per_page"] = $per_page;

		$args["current_page"] = $page_number;

		$results = bbapp_iap_get_products( $args );

		// convert to array;
		foreach ( $results as $k => $v ) {
			$results[ $k ] = (array) $v;
		}

		return $results;

	}

	/**
	 * Sync all products from apple and google.
	 *
	 * @since BuddyBoss App 1.1.6
	 *
	 * @param string $which 'top' or 'bottom'.
	 */
	function extra_tablenav( $which ) {

		// Bail on bottom table nav.
		if ( 'bottom' === $which ) {
			return;
		}
		?>

        <button class="sync_product_button button" data-platform="all">
            <div class="bbapp_loading" style="display:none;"></div>
            <span class="sync_product_button_lable"><?php echo esc_html__( 'Sync Products', 'buddyboss-app' ); ?></span>
        </button>

		<?php
	}

	/**
	 * Returns the count of records in the database.
	 *
	 * @param string $status eg.trash
	 *
	 * @return null|string
	 */
	public static function record_count( $status = '' ) {
		return bbapp_iap_get_products_count( $status );
	}

	/**
	 * return the column available to this table list.
	 * @return array
	 */
	public function get_columns() {

		$columns        = array();
		$product_status = filter_input( INPUT_GET, 'product_status', FILTER_SANITIZE_STRING  );
		if ( 'trash' !== $product_status ) {
			$columns['reorder'] = "";
		}
		$columns['cb']                 = '<input type="checkbox" />';
		$columns['name']               = __( 'Product Name', 'buddyboss-app' );
		$columns['ios_product']        = __( 'iOS Product', 'buddyboss-app' );
		$columns['android_product']    = __( 'Android Product', 'buddyboss-app' );
		$columns['products_screen']    = __( 'Products Screen', 'buddyboss-app' );
		$columns['subscription-group'] = __( 'Subscription Group', 'buddyboss-app' );
		$columns['date_created']       = __( 'Date Created', 'buddyboss-app' );
		$columns['purchases']          = __( 'Purchases', 'buddyboss-app' );

		return $columns;
	}

	/**
	 * Gets the name of the primary column.
	 * @return string The name of the primary column.
	 */
	public function get_primary_column_name(){
		return 'name';
	}

	/**
	 *
	 */
	public function no_items() {
		_e( 'No products found.', 'buddyboss-app' );
	}

	/**
	 * @param object $item
	 * @param string $column_name
	 *
	 * @return string|void
	 */
	public function column_default( $item, $column_name ) {

		$storeData    = unserialize( $item["store_data"] );
		$miscSettings = unserialize( $item["misc_settings"] );

		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings
		if ( bbapp()->is_network_activated() ) {
			$miscSettings = $miscSettings[ get_current_blog_id() ];
		}

		switch ( $column_name ) {
			case 'name':
				return "<a class='row-title' href=admin.php?page=bbapp-iap&setting=products&action=edit&id=" . $item["id"] . ">" . $item["name"] . "</a>";
				break;
			case 'ios_product':
				$store_product_detail = $this->iap_store_product_detail( $storeData, 'ios' );

				return ! empty( $store_product_detail ) ? $store_product_detail : __( 'N/A' );
				break;
			case 'android_product':
				$store_product_detail = $this->iap_store_product_detail( $storeData, 'android' );

				return ! empty( $store_product_detail ) ? $store_product_detail : __( 'N/A' );
				break;
			case 'date_created':
				$date_format = get_option( 'date_format' );
				$date_format = ! empty( $date_format ) ? $date_format : __('F j, Y');
				$time_format = get_option( 'time_format' );
				$time_format = ! empty( $time_format ) ? $time_format : __('g:i a');
				return sprintf(
					__( '%1$s at %2$s' ),
					get_gmt_from_date( $item["date_created"], $date_format ),
					get_gmt_from_date( $item["date_created"], $time_format )
				);
				break;
			case 'products_screen':

				if ( isset( $miscSettings['global_subscription'] ) ) {
					return $miscSettings['global_subscription'] ? 'Yes' : 'No';
				}

				return 'No';
				break;
			case 'subscription-group':

				if ( ! empty( $item['iap_group'] ) ) {
					return SubscriptionGroupTaxonomy::get_group_name( $item['iap_group'] );
				}

				return 'N/A';
				break;
			case 'id':
				return $item["id"];
				break;
			case 'purchases':
				return $this->bbapp_purchases_order_data( $item['id'] );
				break;
			default:
				return "N/A";
				break;
		}
	}

	/**
     * IAP Store product detail
	 * @param $storeData
	 * @param $device_platform
	 *
	 * @return string
	 */
	public function iap_store_product_detail( $storeData, $device_platform ) {
		$store_product = '';
		if ( empty( $storeData ) ) {
			return $store_product;
		}
		$product_type = isset( $storeData["bbapp_product_type"] ) ? $storeData["bbapp_product_type"] : '';

		if ( 'free' === $product_type ) {
			$store_product .= __( 'Free', 'buddyboss-app' );
		} else {
			$enabled_iap_device_platform = $storeData['device_platforms'];
			$store_product_id            = ! empty( $storeData["store_product_ids"][ $device_platform ] ) ? $storeData["store_product_ids"][ $device_platform ] : '';
			$store_product_type          = ! empty( $storeData["store_product_types"][ $device_platform ] ) ? $storeData["store_product_types"][ $device_platform ] : '';

			if ( ! is_array( $enabled_iap_device_platform ) || ! in_array( $device_platform, $enabled_iap_device_platform ) ) {
				return __( 'Not set', 'buddyboss-app' );
			}

			// Check Product exists in store product.
			$store_products = bbapp_iap_get_store_products( $device_platform );
			if ( false === array_search( $store_product_id, array_column( $store_products, 'id' ) ) ) {
				$store_product_id = '';
			}

			if ( ! empty( $store_product_id ) ) {
				$store_product .= $store_product_id . '<br />';

				$store_product_type_label = Helpers::getStoreProductInfo( $store_product_type, $device_platform );
				if ( ! empty( $store_product_type_label ) ) {
					$store_product .= ' (' . $store_product_type_label . ') ';
				}
				$store_product_status = bbapp_iap_get_store_product( $store_product_id, $device_platform, 'status' );
				$product_status       = Helpers::get_store_product_status_info( $store_product_status, $device_platform );
				$store_product        .= sprintf( __( '<br /><span class="iap_product_status"><b>Status:</b> %s</div>', 'buddyboss-app' ), ucwords( $product_status ) );
			} else {
				$store_product .= __( 'Not set', 'buddyboss-app' );
			}
		}

		return $store_product;
	}

	/**
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array(
			'name'         => array( 'name', true ),
			'date_created' => array( 'date_created', true ),
		);
	}

	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items() {
		/**
		 * Init column headers.
		 */
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		/** Process bulk action */
		$this->process_bulk_action();

		$product_status = filter_input( INPUT_GET, 'product_status', FILTER_SANITIZE_STRING );
		// Set the current view.
		if ( in_array( $product_status, array( 'trash' ) ) ) {
			$this->view = $product_status;
		}

		$per_page     = $this->get_items_per_page( 'iap_product_per_page', 10 );
		$current_page = $this->get_pagenum();

		// Get group type counts for display in the filter tabs.
		$total_items  = self::get_product_status_count();
		// Get order type counts for display in the filter tabs.
		$this->iap_product_counts = array();
		foreach ( $total_items as $view => $total_item ) {
			$this->iap_product_counts[ $view ] = $total_item;
		}

		$this->set_pagination_args( [
			'total_items' => $this->iap_product_counts[ $this->view ], //WE have to calculate the total number of items
			'per_page'    => $per_page, //WE have to determine how many items to show on a page
		] );

		$this->items = self::get_products( $per_page, $current_page, $this->view );
	}

	/**
	 * Get an array containing ids for each product status count.
	 *
	 * A bit of a kludge workaround for some issues
	 *
	 * @return array
	 * @since BuddyPress 1.7.0
	 *
	 */
	public static function get_product_status_count() {

		$ids = array();
		$ids['all']   = self::record_count();
		$ids['trash'] = self::record_count( 'trash' );

		return $ids;
	}

	/**
	 * Checkbox for bulk items.
	 *
	 * @param object $item
	 *
	 * @return string|void
	 */
	function column_reorder( $item ) {
		return sprintf(
			'<span class="iap-reorder-product"><img src="'.\bbapp::instance()->plugin_url.'/assets/img/icons/fontawesome/solid/bars.svg" alt="'.esc_attr__('Drag','buddyboss-app').'"</span>'
		);
	}

	/**
	 * Checkbox for bulk items.
	 *
	 * @param object $item
	 *
	 * @return string|void
	 */
	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" id="cb-select-%s" name="iap_product_ids[]" value="%s" />', $item['id'],$item['id']
		);
	}

	/**
	 * Bulk action.
	 *
	 * @return array
	 */
	public function get_bulk_actions() {
		$actions = array();
		$product_status = filter_input( INPUT_GET, 'product_status', FILTER_SANITIZE_STRING );
		if ( 'trash' === $product_status ) {
			$actions['bulk-untrash'] = __( 'Restore' );
			$actions['bulk-delete']  = __( 'Delete permanently' );
		} else {
			$actions['bulk-trash'] = __( 'Move to Trash' );
		}

		return $actions;
	}

	/**
	 * Bulk action process.
	 * @return bool
	 */
	public function process_bulk_action() {

		if ( ! current_user_can( "manage_options" ) ) {
			wp_die( "You don't have permission to access this page.", "buddyboss-app" );
		}

		// Build redirection URL.
		$redirect_to = remove_query_arg( array(
			'action',
			'action2',
			'iap_product',
			'iap_product_ids',
			'deleted',
			'error',
			'updated',
			'success_new',
			'error_new',
			'success_modified',
			'error_modified',
			'_wpnonce'
		), $_SERVER['REQUEST_URI'] );

		$action = $this->current_action();

		switch ( $action ) {
			case 'delete':
			case 'bulk-delete':
				if ( ! empty( $_REQUEST['iap_product_ids'] ) ) {
					$nonce_key = ( 'bulk-delete' === $action ) ? 'bulk-' . sanitize_key( $this->_args['plural'] ) : 'cc_delete_iap_product';
					check_admin_referer( $nonce_key );
					$iap_product_ids = wp_parse_id_list( $_REQUEST['iap_product_ids'] );

					$count = 0;
					foreach ( $iap_product_ids as $iap_product_id ) {
						if ( $this->delete_iap_product( $iap_product_id ) ) {
							$count ++;
						}
					}
					$redirect_to = add_query_arg( array(
						'deleted' => $count,
						'ids'       => $iap_product_ids,
					), $redirect_to );
					wp_safe_redirect( $redirect_to );
					exit();
				}
				break;
			case 'trash':
			case 'bulk-trash':
				if ( ! empty( $_REQUEST['iap_product_ids'] ) ) {
					$nonce_key = ( 'bulk-trash' === $action ) ? 'bulk-' . sanitize_key( $this->_args['plural'] ) : 'cc_trash_iap_product';
					check_admin_referer( $nonce_key );
					$iap_product_ids = wp_parse_id_list( $_REQUEST['iap_product_ids'] );

					$count = 0;
					foreach ( $iap_product_ids as $iap_product_id ) {
						if ( $this->trash_iap_product( $iap_product_id ) ) {
							$count ++;
						}
					}
					$redirect_to = add_query_arg( array(
						'trashed' => $count,
						'ids'       => $iap_product_ids,
					), $redirect_to );
					wp_safe_redirect( $redirect_to );
					exit();
				}
				break;
			case 'untrash':
			case 'bulk-untrash':
				if ( ! empty( $_REQUEST['iap_product_ids'] ) ) {
					$nonce_key = ( 'bulk-untrash' === $action ) ? 'bulk-' . sanitize_key( $this->_args['plural'] ) : 'cc_untrash_iap_product';
					check_admin_referer( $nonce_key );
					if ( ! is_array( $_REQUEST['iap_product_ids'] ) ) {
						$_REQUEST['iap_product_ids'] = explode( ',', $_REQUEST['iap_product_ids'] );
					}
					$iap_product_ids = wp_parse_id_list( $_REQUEST['iap_product_ids'] );

					$count = 0;
					foreach ( $iap_product_ids as $iap_product_id ) {
						if ( $this->untrash_iap_product( $iap_product_id ) ) {
							$count ++;
						}
					}
					$redirect_to = add_query_arg( array(
						'untrashed' => $count,
						'ids'       => $iap_product_ids,
					), $redirect_to );

					wp_safe_redirect( $redirect_to );
					exit();
				}
				break;
		}
		return true;
	}

	/**
	 * Delete IAP product.
	 *
	 * @param $id
	 *
	 * @return false
	 */
	public function delete_iap_product( $id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return ProductHelper::instance()->delete_iap_product( $id );
	}


	/**
	 * Trash IAP product.
	 *
	 * @param $id
	 *
	 * @return false
	 */
	public function trash_iap_product( $id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return ProductHelper::instance()->update_iap_product_status( $id,'trash' );
	}
	/**
	 * Trash IAP product.
	 *
	 * @param $id
	 *
	 * @return false
	 */
	public function untrash_iap_product( $id ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		return ProductHelper::instance()->update_iap_product_status( $id );
	}


	/**
	 * Get the list of views available on this table (e.g. "all", "public").
	 *

	 */
	public function get_views() {
		$url_base = bbapp_get_admin_url( 'admin.php?page=bbapp-iap&setting=products' );
		?>

        <h2 class="screen-reader-text">
			<?php
			/* translators: accessibility text */
			_e( 'Filter IAP Products list', 'buddyboss-app' );
			?>
        </h2>

        <ul class="subsubsub">
	        <li class="all"><a href="<?php echo esc_url( $url_base ); ?>" class=" <?php if ( 'all' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( __( 'All <span class="count">(%s)</span>', '' ), $this->iap_product_counts['all'] ); ?></a> |
	        </li>
	        <li class="completed">
	            <a href="<?php echo esc_url( add_query_arg( 'product_status', 'trash', $url_base ) ); ?>" class="<?php if ( 'trash' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( _n( 'Trash <span class="count">(%s)</span>', 'Trash <span class="count">(%s)</span>', $this->iap_product_counts['trash'], 'buddyboss-app' ), number_format_i18n( $this->iap_product_counts['trash'] ) ); ?>
	            </a>
	        </li>
		</ul>
		<?php
	}

	/**
	 * @param $item
	 *
	 * @return string
	 */
	public function column_name( $item ) {
		$actions = array();
		// Build actions URLs.
		$base_url       = bbapp_get_admin_url( 'admin.php?page=' . esc_attr( $_REQUEST['page'] ) . '&amp;setting=products&amp;iap_product_ids=' . $item['id'] );
		$product_status = filter_input( INPUT_GET, 'product_status', FILTER_SANITIZE_STRING );
		$base_url       = add_query_arg( 'product_status', $product_status, $base_url );
		if ( 'trash' === $product_status ) {
			$restore_url        = wp_nonce_url( $base_url . '&amp;action=untrash', 'cc_untrash_iap_product' );
			$delete_url         = wp_nonce_url( $base_url . '&amp;action=delete', 'cc_delete_iap_product' );
			$actions['untrash'] = sprintf(
				'<a href="%s" aria-label="%s">%s</a>',
				$restore_url,
				/* translators: %s: Post title. */
				esc_attr( sprintf( __( 'Restore &#8220;%s&#8221; from the Trash', 'buddyboss-app' ), $item['name'] ) ),
				__( 'Restore', 'buddyboss-app' )
			);
			$actions['delete']  = sprintf(
				'<a href="%s" class="submitdelete" onclick="return showNotice.warn();" aria-label="%s">%s</a>',
				$delete_url,
				/* translators: %s: Post title. */
				esc_attr( sprintf( __( 'Delete &#8220;%s&#8221; permanently', 'buddyboss-app' ), $item['name'] ) ),
				__( 'Delete Permanently', 'buddyboss-app' )
			);

			return sprintf( '%1$s %2$s', $item["name"], $this->row_actions( $actions ) );
		}

		$trash_url        = wp_nonce_url( $base_url . '&amp;action=trash', 'cc_trash_iap_product' );
		$actions['edit']  = sprintf(
			'<a href="%s" aria-label="%s">%s</a>',
			sprintf( "admin.php?page=%s&setting=products&action=%s&id=%s", $_REQUEST['page'], 'edit', $item['id'] ),
			/* translators: %s: Post title. */
			esc_attr( sprintf( __( 'Edit &#8220;%s&#8221;', 'buddyboss-app' ), $item['name'] ) ),
			__( 'Edit', 'buddyboss-app' )
		);
		$actions['trash'] = sprintf(
			'<a href="%s" aria-label="%s">%s</a>',
			$trash_url,
			/* translators: %s: Post title. */
			esc_attr( sprintf( __( 'Move &#8220;%s&#8221; to the Trash', 'buddyboss-app' ), $item['name'] ) ),
			__( 'Trash', 'buddyboss-app' )
		);

		// NOTE : Delete operation is only permitted at main(default) site,
		// network level don't have product creation screen)
		if ( ! is_main_site() ) {
			unset( $actions['trash'] );
			unset( $actions['delete'] );
		}

		return sprintf( '%1$s %2$s', "<a class='row-title' href=admin.php?page=bbapp-iap&setting=products&action=edit&id=" . $item["id"] . ">" . $item["name"] . "</a>", $this->row_actions( $actions ) );
	}


	/**
	 * @global array $item iap product array.
	 *
	 * @param int|array $item
	 * @param int         $level
	 */
	public function single_row( $item, $level = 0 ) {

	    $classes = '';
	    if( $item['status'] ){
		    $classes = 'iap-product status-' . $item['status'];
	    }
		?>
		<tr id="iap-product-<?php echo esc_attr($item['id']); ?>" class="<?php esc_attr($classes); ?>">
			<?php $this->single_row_columns( $item ); ?>
		</tr>
		<?php
	}
	
	/**
	 * Return count of all orders status based on particular product id.
	 *
	 * @param $purchase_product_id
	 */
	public function bbapp_purchases_order_data( $purchase_product_id ) {
		$order_list_obj   = new OrderList();
		$all_order_status            = $order_list_obj::get_orders_type_ids( $purchase_product_id );
		// Added expired order status with count in above array.
		// We have not added in above function because this is displaying count in table row in IAP screen for filtering purpose.
		$all_order_status['expired'] = $order_list_obj::record_count( 'expired', $purchase_product_id );
		if ( ! empty( $all_order_status ) ) {
			$order_link       = admin_url( 'admin.php?page=bbapp-iap&setting=orders' );
			$order_link       = $order_list_obj->bbapp_add_query_args_as_product_filter( $order_link, $purchase_product_id );
			unset( $all_order_status['all'] );
			?>
			<ul>
				<?php
				foreach ( $all_order_status as $order_status => $order_count ) {
					if ( ! empty( $order_count ) ) {
						?>
						<li>
							<strong><?php echo esc_html( ucfirst( $order_status ) ); ?></strong>: <?php echo esc_html( $order_count ); ?>
						</li>
						<?php
					}
				}
				?>
				<a href="<?php echo esc_url( $order_link ); ?>"><?php echo __( 'View Purchases', 'buddyboss-app' ); ?></a>
			</ul>
			<?php
		}
	}
}
