<?php

namespace BuddyBossApp\Admin\InAppPurchases;

use BuddyBossApp\InAppPurchases\Controller;

class Helpers {

	private static $instance;
	private $messages = array();

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 * @return Helpers
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * Load additional hooks such as : admin_init
	 * NOTE : Method is similar to concept of init
	 * @return void
	 */
	public function _load() {
		// All actions/filters below
	}

	/**
	 * Parse(split) custom format(id:title) to get id and attach it to associated integration(learndash-course, memberpress or woo-membership)
	 *
	 * @param $itemIds
	 *
	 * @return array {array} items items
	 */
	public static function parseItemIds( $itemIds ) {
		$items = array();
		foreach ( $itemIds as $integrationType => $identifiers ) {
			$readableItemIds = array();

			foreach ( unserialize( $identifiers ) as $identifier ) {

				$split = explode( ':', $identifier );
				$id    = $split[0];

				/**
				 * Filter to get Edit permalink for item id as it different for every 3rd party plugin.
				 */
				$link              = apply_filters( 'bbapp_iap_integration_item_id_permalink', '#', $id, $integrationType );
				$readableItemIds[] = "<a href='$link' target='_blank'>$id</a>";
			}
			$integrationItemLabel = Helpers::getIntegrationItemLabel( $integrationType );
			$items[]              = "$integrationItemLabel: " . implode( ', ', $readableItemIds );
		}

		return $items;

	}

	/**
	 * Helper function to get integration-instance via integration-slug
	 *
	 * @param $slug
	 *
	 * @return  string integration-slug
	 */
	public static function getIntegrationInstance( $slug ) {

		$integrations = Controller::instance()->get_integrations();
		if ( isset( $integrations[ $slug ] ) && isset( $integrations[ $slug ]['class'] ) ) {
			return $integrations[ $slug ]['class']::instance();
		}

		return false;
	}

	/**
	 * Helper function to get integration-label via integration-type
	 *
	 * @param $type
	 *
	 * @return  string integration-label
	 */
	public static function getIntegrationLabel( $type ) {

		$label        = $type;
		$integrations = Controller::instance()->get_integrations();
		foreach ( $integrations as $slug => $details ) {
			if ( $type === $details['type'] ) {
				$label = $details['label'];
				break;
			}
		}

		return $label;
	}

	/**
	 * Helper function to get integration-slug via integration-type
	 *
	 * @param $type
	 *
	 * @return  string integration-label
	 */
	public static function getIntegrationSlug( $type ) {

		$slug         = $type;
		$integrations = Controller::instance()->get_integrations();
		foreach ( $integrations as $i_slug => $details ) {
			if ( $type === $details['type'] ) {
				$slug = $i_slug;
				break;
			}
		}

		return $slug;
	}

	/**
	 * Helper function to get integration items via integration-slug
	 *
	 * @param $slug
	 *
	 * @return  array integration-slug
	 */
	public static function getIntegrationItems( $slug ) {
		global $wpdb;
		/**
		 * Allow to update list of integration items for linking by 3rd party integration for admin screen.
		 */
		$results = apply_filters( 'bbapp_ajax_iap_linking_options', [], $slug );
		if ( empty( $results ) ) {
			$query   = "SELECT CONCAT(posts.ID, \":\" , posts.post_title, \"\") as 'id', CONCAT(posts.post_title, \" (#\" , posts.ID, \")\")  as 'text' FROM $wpdb->posts posts WHERE posts.post_type = \"$slug\"  AND posts.post_status = 'publish' ";
			$results = $wpdb->get_results( $query, ARRAY_A );
		}

		return $results;
	}

	/**
	 * Helper function to get integration-item-label via integration-type
	 *
	 * @param $type
	 *
	 * @return  string integration-label
	 */
	public static function getIntegrationItemLabel( $type ) {

		$label        = $type;
		$integrations = Controller::instance()->get_integrations();
		foreach ( $integrations as $slug => $details ) {
			if ( $type === $details['type'] && ! empty( $details['class'] ) ) {
				$class = $details['class'];
				$label = $class::instance()->get_item_label();
				break;
			}
		}

		return $label;
	}

	/**
	 * BuddyBossApp Product(for InAppPurchase) by id
	 *
	 * @param $id
	 *
	 * @return array {object}
	 */
	public static function getProductById( $id ) {

		global $wpdb;

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		$query        = "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE id = {$id} AND status = 'published'";
		$result       = $wpdb->get_row( $query, OBJECT );

		$product = array();

		if ( ! empty( $result ) ) {

			$storeData         = maybe_unserialize( $result->store_data );
			$miscSettings      = self::bbapp_iap_product_mics_setting( $result );
			$integrationData   = self::bbapp_iap_product_integration_data( $result );
			$integrationType   = ( isset( $miscSettings['integration_type'] ) ? $miscSettings['integration_type'] : '' );
			$integratedItemIds = self::bbapp_iap_product_integration_ids( $integrationType, $integrationData );

			$iOS                = self::bbapp_iap_ios_product_info( $storeData );
			$android            = self::bbapp_iap_android_product_info( $storeData );
			$bbapp_product_type = isset( $storeData['bbapp_product_type'] ) ? $storeData['bbapp_product_type'] : 'free';

			// Check Product is configure properly or not. If not it should not return in api response.
			if (
				( isset( $storeData['device_platforms'] ) && in_array( 'ios', $storeData['device_platforms'] ) && ( empty( $iOS['status'] ) || ( 'free' !== $bbapp_product_type && empty( $iOS['store_product_id'] ) ) ) ) ||
				( isset( $storeData['device_platforms'] ) && in_array( 'android', $storeData['device_platforms'] ) && ( empty( $android['status'] ) || ( 'free' !== $bbapp_product_type && empty( $android['store_product_id'] ) ) ) ) ||
				empty( $integratedItemIds )
			) {
				return $product;
			}

			if ( is_user_logged_in() ) {
				// NOTE : Get user_id and check into bbapp_orders if this bbapp;
				$hasAccess = ProductHelper::hasActiveOrder( $result, get_current_user_id() );

				// Check Any order exist for same group product
				$group_active_product = 0;
				if ( ! empty( $result->iap_group ) ) {
					$group_active_product = ProductHelper::get_group_active_order_product_id( $result->iap_group, get_current_user_id() );
				}
			} else {
				$hasAccess            = false;
				$group_active_product = 0;
			}

			$product = array(
				'product_id'           => (int) $result->id,
				'product_name'         => $result->name,
				'product_tagline'      => $result->tagline,
				'product_desc'         => $result->description,
				'benefits'             => $miscSettings['benefits'],
				'global_subscription'  => $miscSettings['global_subscription'] ? true : false,
				'bbapp_product_type'   => $bbapp_product_type,
				'ios'                  => $iOS,
				'android'              => $android,
				'integration_type'     => $miscSettings['integration_type'],
				'integrated_item_ids'  => $integratedItemIds,
				'has_access'           => $hasAccess,
				'group_active_product' => $group_active_product,
				'sort_order'           => (int) $result->menu_order,
			);
		}

		return $product;

	}

	/**
	 * BuddyBossApp Product ID by Store product ID.
	 *
	 * @param string $store_product_id Store Product ID.
	 * @param string $device_platform  Device Platform.
	 *
	 * @return int BuddyBossApp Product ID
	 */
	public static function get_product_id_by_store_product_id( $store_product_id, $device_platform ) {
		global $wpdb;

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		$string       = '%s:' . strlen( $device_platform ) . ':"' . $device_platform . '";s:' . strlen( $store_product_id ) . ':"' . $store_product_id . '";%';
		$query        = "SELECT id FROM {$globalPrefix}bbapp_iap_products WHERE store_data like '{$string}'";

		return $wpdb->get_var( $query );
	}

	/**
	 * BuddyBossApp Products(for InAppPurchase) for selectbox ui
	 * @return array {Object} with id and text attribute
	 */
	public static function getProductsForSelectbox() {
		global $wpdb;

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		$query        = "SELECT CONCAT(id, \":\" , name, \"\") as 'id', CONCAT(id, \" (#\" , name, \")\")  as 'text' FROM {$globalPrefix}bbapp_iap_products";
		$options      = array();
		$results      = $wpdb->get_results( $query, OBJECT );

		foreach ( $results as $key => $result ) {
			$options[ $result->id ] = $result->text;
		}

		return $options;
	}

	/**
	 * BuddyBossApp Products(for InAppPurchase)
	 *
	 * @param array $args
	 *
	 * @return array {array}
	 */
	public static function getProducts( $args = array() ) {

		global $wpdb;
		$globalPrefix = \bbapp_iap()->get_global_dbprefix();

		$query = "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE status = 'published'";
		if ( isset( $args['include'] ) && ! empty( $args['include'] ) ) {
			$query .= $wpdb->prepare( ' AND id IN (' . implode( ",", $args['include'] ) . ')' );
		}

		if ( ! empty( $args['orderby'] ) ) {
			$query .= ' ORDER BY menu_order,' . esc_sql( $args['orderby'] );
			$query .= ! empty( $args['order'] ) ? ' ' . esc_sql( $args['order'] ) : ' ASC';
		} else {
			$query .= ' ORDER BY menu_order ASC';
		}

		$products = array();
		$results  = $wpdb->get_results( $query, OBJECT );
		foreach ( $results as $result ) {

			$storeData       = maybe_unserialize( $result->store_data );
			$miscSettings    = self::bbapp_iap_product_mics_setting( $result );
			$integrationData = self::bbapp_iap_product_integration_data( $result );

			/**
			 * If global_subscription filter active and product isn't global_subscription then filter it.
			 */
			if ( isset( $args['global_subscription'] ) && ! empty( $args['global_subscription'] ) && ! $miscSettings['global_subscription'] ) {
				continue;
			}

			$integrationType   = ( isset( $miscSettings['integration_type'] ) ? $miscSettings['integration_type'] : '' );
			$integratedItemIds = self::bbapp_iap_product_integration_ids( $integrationType, $integrationData );

			$iOS                = self::bbapp_iap_ios_product_info( $storeData );
			$android            = self::bbapp_iap_android_product_info( $storeData );
			$bbapp_product_type = isset( $storeData['bbapp_product_type'] ) ? $storeData['bbapp_product_type'] : 'free';

			// Check Product is configure properly or not. If not it should not return in api response.
			if (
				( isset( $storeData['device_platforms'] ) && in_array( 'ios', $storeData['device_platforms'] ) && ( empty( $iOS['status'] ) || ( 'free' !== $bbapp_product_type && empty( $iOS['store_product_id'] ) ) ) ) ||
				( isset( $storeData['device_platforms'] ) && in_array( 'android', $storeData['device_platforms'] ) && ( empty( $android['status'] ) || ( 'free' !== $bbapp_product_type && empty( $android['store_product_id'] ) ) ) ) ||
				empty( $integratedItemIds )
			) {
				continue;
			}

			if ( is_user_logged_in() ) {
				// NOTE : Get user_id and check into bbapp_orders if this bbapp;
				$hasAccess = ProductHelper::hasActiveOrder( $result, get_current_user_id() );

				// Check Any order exist for same group product
				$group_active_product = 0;
				if ( ! empty( $result->iap_group ) ) {
					$group_active_product = ProductHelper::get_group_active_order_product_id( $result->iap_group, get_current_user_id() );
				}
			} else {
				$hasAccess            = false;
				$group_active_product = 0;
			}

			$products[] = array(
				'product_id'           => (int) $result->id,
				'product_name'         => $result->name,
				'product_tagline'      => $result->tagline,
				'product_desc'         => $result->description,
				'benefits'             => $miscSettings['benefits'],
				'global_subscription'  => $miscSettings['global_subscription'] ? true : false,
				'bbapp_product_type'   => $bbapp_product_type,
				'ios'                  => $iOS,
				'android'              => $android,
				'integration_type'     => $miscSettings['integration_type'],
				'integrated_item_ids'  => $integratedItemIds,
				'has_access'           => $hasAccess,
				'group_active_product' => $group_active_product,
				'sort_order'           => (int) $result->menu_order
			);
		}

		return $products;

	}

	/**
	 * Search IntegrationAbstract for itemId[ Example: Course ID ]
	 *
	 * @param null   $forItemId       : item id. it can be course_id or membership id or anything which connected with membership plugin
	 * @param string $integrationType integration type
	 * @param array  $args
	 *
	 * @return array {array}
	 */
	public static function searchIntegration( $forItemId = null, $integrationType = '', $args = array() ) {
		global $wpdb;

		$integratedProducts = array();

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		$query        = "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE status = 'published'";

		if ( ! empty( $integrationType ) ) {
			$integration_slug     = self::getIntegrationSlug( $integrationType );
			$integration_type_str = sprintf( "s:%d:\"%s\";s:%d:\"%s\";", strlen( "integration_type" ), "integration_type", strlen( $integration_slug ), $integration_slug );
			$query                .= " AND misc_settings like ";
			$query                .= "'%$integration_type_str%'";
		}

		if ( ! empty( $args['orderby'] ) ) {
			$query .= ' ORDER BY menu_order,' . esc_sql( $args['orderby'] );
			$query .= ! empty( $args['order'] ) ? ' ' . esc_sql( $args['order'] ) : ' ASC';
		} else {
			$query .= ' ORDER BY menu_order ASC';
		}

		$BuddyBossAppProducts = $wpdb->get_results( $query, OBJECT );

		/**
		 * We need to check through all all bbapp product of $integrationType to find items which is direct/indirect connected and give access for given $itemID
		 * For 3rd party integration, to identify connection might be different so it's will be custom code.
		 * We can do that code in while extending support using hooks
		 */
		foreach ( $BuddyBossAppProducts as $BuddyBossAppProduct ) {

			$miscSettings    = unserialize( $BuddyBossAppProduct->misc_settings );
			$integrationData = unserialize( $BuddyBossAppProduct->integration_data );

			if ( bbapp()->is_network_activated() ) {
				$miscSettings    = $miscSettings[ get_current_blog_id() ];
				$integrationData = $integrationData[ get_current_blog_id() ];
			}

			$integration_slug = $miscSettings['integration_type'];

			$integrationData = isset( $integrationData[ $integration_slug ] ) ? $integrationData[ $integration_slug ] : array();

			foreach ( $integrationData as $value ) {

				//NOTE : Sample storage is like => "id:label"
				$split               = explode( ':', $value );
				$integration_item_id = $split[0];

				/**
				 * Filter to check given $forItemId is connect directly/indirectly with given $integration_item_id
				 */
				$found_configured = apply_filters( 'bbapp_iap_is_purchase_available', false, $forItemId, $integration_item_id, $integration_slug );

				if ( $forItemId == null || $found_configured ) {
					$storeData         = maybe_unserialize( $BuddyBossAppProduct->store_data );
					$miscSettings      = self::bbapp_iap_product_mics_setting( $BuddyBossAppProduct );
					$integrationData   = self::bbapp_iap_product_integration_data( $BuddyBossAppProduct );
					$integrationType   = ( isset( $miscSettings['integration_type'] ) ? $miscSettings['integration_type'] : '' );
					$integratedItemIds = self::bbapp_iap_product_integration_ids( $integrationType, $integrationData );

					$iOS                = self::bbapp_iap_ios_product_info( $storeData );
					$android            = self::bbapp_iap_android_product_info( $storeData );
					$bbapp_product_type = isset( $storeData['bbapp_product_type'] ) ? $storeData['bbapp_product_type'] : 'free';

					// Check Product is configure properly or not. If not it should not return in api response.
					if (
						( isset( $storeData['device_platforms'] ) && in_array( 'ios', $storeData['device_platforms'] ) && ( empty( $iOS['status'] ) || ( 'free' !== $bbapp_product_type && empty( $iOS['store_product_id'] ) ) ) ) ||
						( isset( $storeData['device_platforms'] ) && in_array( 'android', $storeData['device_platforms'] ) && ( empty( $android['status'] ) || ( 'free' !== $bbapp_product_type && empty( $android['store_product_id'] ) ) ) ) ||
						empty( $integratedItemIds )
					) {
						continue;
					}

					if ( is_user_logged_in() ) {
						// NOTE : Get user_id and check into bbapp_orders if this bbapp;
						$hasAccess = ProductHelper::hasActiveOrder( $BuddyBossAppProduct, get_current_user_id() );

						// Check Any order exist for same group product
						$group_active_product = 0;
						if ( ! empty( $BuddyBossAppProduct->iap_group ) ) {
							$group_active_product = ProductHelper::get_group_active_order_product_id( $BuddyBossAppProduct->iap_group, get_current_user_id() );
						}
					} else {
						$hasAccess            = false;
						$group_active_product = 0;
					}

					$integratedProducts[] = array(
						'product_id'           => (int) $BuddyBossAppProduct->id,
						'product_name'         => $BuddyBossAppProduct->name,
						'product_tagline'      => $BuddyBossAppProduct->tagline,
						'product_desc'         => $BuddyBossAppProduct->description,
						'benefits'             => $miscSettings['benefits'],
						'global_subscription'  => $miscSettings['global_subscription'] ? true : false,
						'bbapp_product_type'   => $bbapp_product_type,
						'ios'                  => $iOS,
						'android'              => $android,
						'has_access'           => $hasAccess,
						'group_active_product' => $group_active_product,
						'sort_order'           => (int) $BuddyBossAppProduct->menu_order
					);

				}

			}

		}

		/**
		 * Filter to add courses to the integrated products.
		 *
		 * @since 1.4.0
		 *
		 * @param array  $integratedProducts Array of integrated products.
		 * @param int    $forItemId          Membership id.
		 * @param string $integrationType    Integration type.
		 *
		 */
		return apply_filters( 'bbapp_iap_integrated_products', $integratedProducts, $forItemId, $integrationType );
	}

	/**
	 * NOTE : Below should match based on what's define while initializing integration
	 *
	 * @param $storeProductType
	 *
	 * @return bool
	 */
	public static function isRecurringType( $storeProductType ) {

		$isRecurring = false;

		// Recurring ones: ios => auto_renewable, non_auto_renewable; android =>  auto_renewable
		$recurringTypes = array( 'auto_renewable', 'non_auto_renewable' );

		if ( in_array( $storeProductType, $recurringTypes ) ) {
			$isRecurring = true;
		}

		return $isRecurring;
	}

	/**
	 * Output the error or update messages to render.
	 */
	public function showMessages() {

		if ( ! empty( $this->messages ) ) {
			foreach ( $this->messages as $message ) {
				echo "<div id='message' class='{$message['type']}'><p>{$message['message']}</p></div>";
			}
		}

	}

	/**
	 * Return info(Store Product) via Type (Store Product Type) Default it'll return lable
	 *
	 * @param string $storeProductType : Store Product Type for ios or android. Eg : auto_renewable, non_auto_renewable
	 * @param string $devicePlatform   : Platform
	 * @param string $column
	 *
	 * @return string | null
	 */
	public static function getStoreProductInfo( $storeProductType, $devicePlatform = 'ios', $column = 'label' ) {

		$StoreProductTypes = self::platformStoreProductTypes( $devicePlatform );

		// needle, haystack
		if ( in_array( $storeProductType, array_keys( $StoreProductTypes ) ) ) {

			return $StoreProductTypes[ $storeProductType ][ $column ];
		}

		return null;
	}

	/**
	 * Convert store product type into local slug
	 *
	 * @return string
	 */
	public static function platformStoreProductTypeslug( $storePlatformType ) {
		$slug = '';

		switch ( $storePlatformType ) {
			case 'managedUser':
			case 'CONSUMABLE':
				$slug = 'consumable';
				break;
			case 'NON_CONSUMABLE':
				$slug = 'non_consumable';
				break;
			case 'subscription':
			case 'AUTOMATICALLY_RENEWABLE_SUBSCRIPTION':
				$slug = 'auto_renewable';
				break;
			case 'NON_RENEWING_SUBSCRIPTION':
				$slug = 'non_auto_renewable';
				break;
		}

		return $slug;
	}

	/**
	 * Return Store Product Types via platformType
	 *
	 * @param $platformType : device OS. Eg : ios, android
	 *
	 * @return array $types : Array with label, recurring and available values
	 */
	public static function platformStoreProductTypes( $platformType ) {

		switch ( $platformType ) {
			case 'ios':
				$types = array(
					"consumable"         => array(
						"label"       => __( "Consumable", "buddyboss-app" ),
						"description" => __( "This product type is used once, after which it becomes depleted and must be purchased again. There isn't a use case for this in BuddyBoss App, so you shouldn’t use this product type.", "buddyboss-app" ),
						"recurring"   => false,
						"available"   => false,
					),
					"non_consumable"     => array(
						"label"       => __( "Non-Consumable", "buddyboss-app" ),
						"description" => __( "This product type is purchased once and does not expire. Example: Membership or course that is purchased once and never expires.", "buddyboss-app" ),
						"recurring"   => false,
						"available"   => true,
					),
					"auto_renewable"     => array(
						"label"       => __( "Auto-Renewable Subscription", "buddyboss-app" ),
						"description" => __( "This product type allows users to purchase content for a set period, renewing automatically unless cancelled by the user. Example: Monthly subscription for a membership or course.", "buddyboss-app" ),
						"recurring"   => true,
						"available"   => true,
					),
					"non_auto_renewable" => array(
						"label"       => __( "Non-Renewing Subscription", "buddyboss-app" ),
						"description" => __( "This product type allows users to purchase content for a limited duration, which will not renew automatically. Example: Membership or course that will expire and not renew automatically.", "buddyboss-app" ),
						"recurring"   => false,
						"available"   => true,
					),
				);

				break;
			case 'android':

				$types = array(
					// NOTE : It is same product type as non-consumable (managed product) we have to do consume call on app.
					"consumable"     => array(
						"label"       => __( "In-App Product", "buddyboss-app" ),
						"description" => __( "This product type is purchased once and does not expire. Example: Membership or course that is purchased once and never expires.", "buddyboss-app" ),
						"recurring"   => false,
						"available"   => false,
					),
					// NOTE: Subscriptions are in-app content or services that are billed to users on a recurring basis.
					"auto_renewable" => array(
						"label"       => __( "Subscription", "buddyboss-app" ),
						"description" => __( "This product type allows users to purchase content for a set period, renewing automatically unless cancelled by the user. Example: Monthly subscription for a membership or course.", "buddyboss-app" ),
						"recurring"   => true,
						"available"   => true,
					),
				);

				break;

			default:
				$types = array();
				break;
		}

		return $types;

	}

	/**
	 * Return Store product status information
	 *
	 * @param string $status          : Store Product status for ios or android. Eg : active,inactive,approve etc.
	 * @param string $device_platform : Platform
	 * @param string $column
	 *
	 * @return string | null
	 */
	public static function get_store_product_status_info( $status, $device_platform = 'ios', $column = 'label' ) {

		$store_product_status = self::platform_store_product_status( $device_platform, $status );

		// needle, haystack
		if ( in_array( $column, array_keys( $store_product_status ) ) ) {
			return $store_product_status[ $column ];
		}

		return null;
	}

	/**
	 * Return Store Product Status via Platform
	 *
	 * @param string $platform : device OS. Eg : ios, android
	 * @param string $status Store product status.
	 *
	 * @return array $status : Array with label, recurring and available values
	 */
	public static function platform_store_product_status( $platform, $status ) {
		switch ( $platform ) {
			case 'ios':
				switch ( strtoupper( $status ) ) {
					case 'APPROVED':
						$store_product_status = array(
							"label"       => __( "Approved", "buddyboss-app" ),
							"description" => __( "This product has been approved by Apple and can be purchased in your release app. You can test the product from your test app, but you can only see real pricing, terms and purchase options in your release app.", "buddyboss-app" ),
						);
						break;
					default:
						$store_product_status = array(
							"label"       => __( "Not Approved", "buddyboss-app" ),
							"description" => __( "This product has not yet been approved by Apple. Until it has been submitted and approved, it will only be visible to admins in your release app, and cannot yet be purchased through Apple. You can still test the product from your test app, but you can only see real pricing and terms in your release app.", "buddyboss-app" ),
						);
						break;
				}
				break;
			case 'android':
				switch ( strtoupper( $status ) ) {
					case 'ACTIVE':
						$store_product_status = array(
							"label"       => __( "Active", "buddyboss-app" ),
							"description" => __( "This product is marked as active in the Google Play Console.", "buddyboss-app" ),
						);
						break;
					default:
						$store_product_status = array(
							"label"       => __( "Inactive", "buddyboss-app" ),
							"description" => __( "This product is marked as inactive in the Google Play Console. Until it is active, it will not be visible in your app.", "buddyboss-app" ),
						);
						break;
				}
				break;
			default:
				$store_product_status = array();
				break;
		}

		return $store_product_status;

	}

	/**
	 * Get store product id by valid status.
	 *
	 * @param        $store_product_id
	 * @param string $device_platform
	 *
	 * @return string
	 */
	public function bbapp_iap_get_store_product_id_by_valid_status( $store_product_id, $product_type, $device_platform = 'ios' ) {

		if ( 'free' === $product_type ){
			return 'ios' === $device_platform ? 'approved' : 'active';
		} else {
			$store_product_status = bbapp_iap_get_store_product( $store_product_id, $device_platform, 'status' );
			if ( 'ios' === $device_platform ) {
				if ( 'APPROVED' === strtoupper( $store_product_status ) ) {
					return 'approved';
				} else {
					return 'not-approved';
				}
			} else {
				if ( 'ACTIVE' === strtoupper( $store_product_status ) ) {
					return 'active';
				} else {
					return 'inactive';
				}
			}
		}
	}

	/**
	 * Return IAP product mics setting from product.
	 *
	 * @param object $ipa_app_product IAP product object.
	 *
	 * @return array|mixed|string
	 */
	public static function bbapp_iap_product_mics_setting( $ipa_app_product ) {

		$misc_settings = ( isset( $ipa_app_product->misc_settings ) ? maybe_unserialize( $ipa_app_product->misc_settings ) : array() );

		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings.
		if ( bbapp()->is_network_activated() ) {
			$misc_settings = ( array_key_exists( get_current_blog_id(), $misc_settings ) ? $misc_settings[ get_current_blog_id() ] : array() );
		}

		return $misc_settings;
	}

	/**
	 * Return IAP product Integration from product.
	 *
	 * @param object $ipa_app_product IAP product object.
	 *
	 * @return array|mixed|string
	 */
	public static function bbapp_iap_product_integration_data( $ipa_app_product ) {

		$integration_data = ( isset( $ipa_app_product->integration_data ) ? maybe_unserialize( $ipa_app_product->integration_data ) : array() );

		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings.
		if ( bbapp()->is_network_activated() ) {
			$integration_data = ( array_key_exists( get_current_blog_id(), $integration_data ) ? $integration_data[ get_current_blog_id() ] : array() );
		}

		return $integration_data;
	}

	/**
	 * Return IAP product Integration product ids.
	 *
	 * @param string $integration_type IAP product object.
	 * @param object $integration_data IAP product object.
	 *
	 * @return array|mixed|string
	 */
	public static function bbapp_iap_product_integration_ids( $integration_type, $integration_data ) {

		$integrated_item_ids = array();
		if ( ! empty( $integration_type ) && ! empty( $integration_data ) && is_array( $integration_data ) && array_key_exists( $integration_type, $integration_data ) ) {
			$item_ids = $integration_data[ $integration_type ];
			if ( is_array( $item_ids ) && ! empty( $item_ids ) ) {
				foreach ( $item_ids as $item_identifier ) {
					$split = explode( ':', $item_identifier );
					if ( isset( $split[0] ) ) {
						$integrated_item_ids[] = $split[0];
					}
				}
			}
		}

		return $integrated_item_ids;
	}

	/**
	 * Return the IOS information.
	 *
	 * @param array $store_data IAP product store data.
	 *
	 * @return array
	 */
	public static function bbapp_iap_ios_product_info( $store_data ) {
		$ios_data = array(
			'store_product_id'      => '',
			'store_product_type'    => '',
			'store_product_status'  => '',
			'subscription_duration' => '',
			'recurring'             => '',
			'status'                => false,
		);

		if ( empty( $store_data ) ) {
			return $ios_data;
		}

		$bbapp_product_type                = isset( $store_data['bbapp_product_type'] ) ? $store_data['bbapp_product_type'] : 'free';
		$ios_data['store_product_id']      = isset( $store_data['store_product_ids']['ios'] ) ? $store_data['store_product_ids']['ios'] : null;
		$ios_data['store_product_type']    = isset( $store_data['store_product_types']['ios'] ) ? $store_data['store_product_types']['ios'] : null;
		$ios_data['store_product_status']  = isset( $ios_data['store_product_id'] ) ? self::instance()->bbapp_iap_get_store_product_id_by_valid_status( $ios_data['store_product_id'], $bbapp_product_type, 'ios' ) : null;
		$ios_data['subscription_duration'] = isset( $store_data['subscription_duration']['subscription_duration']['ios'] ) ? $store_data['store_product_types']['ios'] : null;
		$ios_data['recurring']             = self::isRecurringType( $ios_data['store_product_type'] );

		// Check Product exists in store product.
		$store_products = bbapp_iap_get_store_products( 'ios' );
		if ( false === array_search( $ios_data['store_product_id'], array_column( $store_products, 'id' ) ) ) {
			$ios_data['store_product_id']   = '';
			$ios_data['store_product_type'] = '';
		}

		if ( is_array( $store_data['device_platforms'] ) && in_array( 'ios', $store_data['device_platforms'], true ) && ( 'free' === $bbapp_product_type || ! empty( $ios_data['store_product_id'] ) ) ) {
			$ios_data['status'] = true;
		}

		return $ios_data;
	}

	/**
	 * Return the Android information.
	 *
	 * @param array $store_data IAP product store data.
	 *
	 * @return array
	 */
	public static function bbapp_iap_android_product_info( $store_data ) {
		$android_data = array(
			'store_product_id'      => '',
			'store_product_type'    => '',
			'store_product_status'  => '',
			'subscription_duration' => '',
			'recurring'             => '',
			'status'                => false,
		);

		if ( empty( $store_data ) ) {
			return $android_data;
		}

		$bbapp_product_type = isset( $store_data['bbapp_product_type'] ) ? $store_data['bbapp_product_type'] : 'free';

		// Attach - Additional android Information.
		$android_data['store_product_id']     = isset( $store_data['store_product_ids']['android'] ) ? $store_data['store_product_ids']['android'] : null;
		$android_data['store_product_type']   = isset( $store_data['store_product_types']['android'] ) ? $store_data['store_product_types']['android'] : null;
		$android_data['store_product_status'] = isset( $android_data['store_product_id'] ) ? self::instance()->bbapp_iap_get_store_product_id_by_valid_status( $android_data['store_product_id'], $bbapp_product_type, 'android' ) : null;
		$android_data['recurring']            = self::isRecurringType( $android_data['store_product_type'] );

		// Check Product exists in store product.
		$store_products = bbapp_iap_get_store_products( 'android' );
		if ( false === array_search( $android_data['store_product_id'], array_column( $store_products, 'id' ) ) ) {
			$ios_data['store_product_id']   = '';
			$ios_data['store_product_type'] = '';
		}

		if ( is_array( $store_data['device_platforms'] ) && in_array( 'android', $store_data['device_platforms'], true ) && ( 'free' === $bbapp_product_type || ! empty( $android_data['store_product_id'] ) ) ) {
			$android_data['status'] = true;
		}

		return $android_data;
	}

}
