<?php

namespace BuddyBossApp\Admin\InAppPurchases;

use BuddyBossApp\InAppPurchases\SubscriptionGroupTaxonomy;

class SubscriptionGroupsHelpers {

	private static $instance = null;
	private $taxonomy;
	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 * @return object
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Show the errors & updates
	 */
	public function show_messages() {
		/** Also used by the Edit Tag  form */
		require_once ABSPATH . 'wp-admin/includes/edit-tag-messages.php';
		$class = ( isset( $_REQUEST['error'] ) ) ? 'error' : 'updated';
		if ( $message ) : ?>
            <div id="message" class="<?php echo $class; ?> notice is-dismissible"><p><?php echo $message; ?></p></div>
			<?php
			$_SERVER['REQUEST_URI'] = remove_query_arg( array( 'message', 'error' ), $_SERVER['REQUEST_URI'] );
		endif;
	}

	/**
	 * Initialize actions/filters
	 * @return void
	 */
	public function init() {
		$this->taxonomy = SubscriptionGroupTaxonomy::$taxonomy;
		// NOTE : can't use admin_post hook since it don't exists on multi-site
		add_action( 'admin_init', array( $this, 'action_subscription_group' ) );
		add_action( 'wp_ajax_create-term', array( $this, 'create_subscription_group' ) );
	}

	/**
	 * Ajax create subscription group.
	 */
	public function create_subscription_group(){
		check_ajax_referer( 'create-term', '_wpnonce_create-term' );
		$taxonomy = ! empty( $_POST['taxonomy'] ) ? $_POST['taxonomy'] : '';
		$tax      = get_taxonomy( $taxonomy );

		if ( ! current_user_can( $tax->cap->edit_terms ) ) {
			wp_die( -1 );
		}

		$x = new \WP_Ajax_Response();

		$tag = wp_insert_term( $_POST['tag-name'], $taxonomy, $_POST );

		if ( $tag && ! is_wp_error( $tag ) ) {
			$tag = get_term( $tag['term_id'], $taxonomy );
		}

		if ( ! $tag || is_wp_error( $tag ) ) {
			$message = __( 'An error has occurred. Please reload the page and try again.' );

			if ( is_wp_error( $tag ) && $tag->get_error_message() ) {
				$message = $tag->get_error_message();
			}

			$x->add(
				array(
					'what' => 'taxonomy',
					'data' => new \WP_Error( 'error', $message ),
				)
			);
			$x->send();
		}

		$this->subscription_groups_list = new SubscriptionGroupsList();

		$level     = 0;
		$noparents = '';

		if ( is_taxonomy_hierarchical( $taxonomy ) ) {
			$level = count( get_ancestors( $tag->term_id, $taxonomy, 'taxonomy' ) );
			ob_start();
			$this->subscription_groups_list->single_row( $tag, $level );
			$noparents = ob_get_clean();
		}

		ob_start();
		$this->subscription_groups_list->single_row( $tag );
		$parents = ob_get_clean();

		$x->add(
			array(
				'what'         => 'taxonomy',
				'supplemental' => compact( 'parents', 'noparents' ),
			)
		);

		$x->add(
			array(
				'what'         => 'term',
				'position'     => $level,
				'supplemental' => (array) $tag,
			)
		);

		$x->send();
	}

	/**
	 * Trigger all actions.
	 */
	public function action_subscription_group() {
		if ( ( isset( $_GET['page'] ) && 'bbapp-iap' === $_GET['page'] ) && isset( $_GET['setting'] ) && $this->taxonomy === $_GET['setting'] ) {
			$taxonomy                       = $this->taxonomy;
			$tax                            = get_taxonomy( $taxonomy );
			$this->subscription_groups_list = new SubscriptionGroupsList();
			$pagenum                        = $this->subscription_groups_list->get_pagenum();
			$location                       = false;
			$referer                        = wp_get_referer();
			if ( ! $referer ) { // For POST requests.
				$referer = wp_unslash( $_SERVER['REQUEST_URI'] );
			}
			$referer = remove_query_arg( array(
				'_wp_http_referer',
				'_wpnonce',
				'error',
				'message',
				'paged'
			), $referer );
			switch ( $this->subscription_groups_list->current_action() ) {

				case 'create-term':
					check_admin_referer( 'create-term', '_wpnonce_create-term' );

					if ( ! current_user_can( $tax->cap->edit_terms ) ) {
						wp_die(
							'<h1>' . __( 'You need a higher level of permission.' ) . '</h1>' .
							'<p>' . __( 'Sorry, you are not allowed to create terms in this taxonomy.' ) . '</p>',
							403
						);
					}

					$ret = wp_insert_term( $_POST['tag-name'], $taxonomy, $_POST );

					if ( $ret && ! is_wp_error( $ret ) ) {
						$location = add_query_arg( 'message', 1, $referer );
					} else {
						$location = add_query_arg(
							array(
								'error'   => true,
								'message' => 4,
							),
							$referer
						);
					}

					break;

				case 'delete':
					if ( ! isset( $_REQUEST['tag_ID'] ) ) {
						break;
					}

					$tag_ID = (int) $_REQUEST['tag_ID'];
					check_admin_referer( 'delete-tag_' . $tag_ID );

					if ( ! current_user_can( 'delete_term', $tag_ID ) ) {
						wp_die(
							'<h1>' . __( 'You need a higher level of permission.' ) . '</h1>' .
							'<p>' . __( 'Sorry, you are not allowed to delete this item.' ) . '</p>',
							403
						);
					}

					wp_delete_term( $tag_ID, $taxonomy );

					$location = add_query_arg( 'message', 2, $referer );

					// When deleting a term, prevent the action from redirecting back to a term that no longer exists.
					$location = remove_query_arg( array( 'tag_ID', 'action' ), $location );

					break;

				case 'bulk-delete':
					check_admin_referer( 'bulk-tags' );

					if ( ! current_user_can( $tax->cap->delete_terms ) ) {
						wp_die(
							'<h1>' . __( 'You need a higher level of permission.' ) . '</h1>' .
							'<p>' . __( 'Sorry, you are not allowed to delete these items.' ) . '</p>',
							403
						);
					}

					$tags = (array) $_REQUEST['delete_tags'];
					foreach ( $tags as $tag_ID ) {
						wp_delete_term( $tag_ID, $taxonomy );
					}
					$location = add_query_arg( 'message', 6, $referer );
					break;


				case 'editedtag':
					$tag_ID = (int) $_POST['tag_ID'];
					check_admin_referer( 'update-tag_' . $tag_ID );

					if ( ! current_user_can( 'edit_term', $tag_ID ) ) {
						wp_die(
							'<h1>' . __( 'You need a higher level of permission.' ) . '</h1>' .
							'<p>' . __( 'Sorry, you are not allowed to edit this item.' ) . '</p>',
							403
						);
					}

					$tag = get_term( $tag_ID, $taxonomy );
					if ( ! $tag ) {
						wp_die( __( 'You attempted to edit an item that doesn&#8217;t exist. Perhaps it was deleted?' ) );
					}

					$ret = wp_update_term( $tag_ID, $taxonomy, $_POST );

					if ( $ret && ! is_wp_error( $ret ) ) {
						$original_referer = wp_get_original_referer();
						if ( false !== $original_referer ) {
							$referer = $original_referer;
						}
						$referer  = remove_query_arg( array( 'tag_ID', 'action' ), $referer );
						$location = add_query_arg( 'message', 3, $referer );
					} else {
						$location = add_query_arg(
							array(
								'error'   => true,
								'message' => 5,
							),
							$referer
						);
					}

					break;
				default:
					if ( ! $this->subscription_groups_list->current_action() || ! isset( $_REQUEST['delete_tags'] ) ) {
						break;
					}
					check_admin_referer( 'bulk-tags' );

					$screen = get_current_screen()->id;
					$tags   = (array) $_REQUEST['delete_tags'];

					/** This action is documented in wp-admin/edit.php */
					$location = apply_filters( "handle_bulk_actions-{$screen}", $location, $this->subscription_groups_list->current_action(), $tags ); // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores
					break;
			}

			if ( ! $location && ! empty( $_REQUEST['_wp_http_referer'] ) ) {
				$location = remove_query_arg( array(
					'_wp_http_referer',
					'_wpnonce'
				), wp_unslash( $_SERVER['REQUEST_URI'] ) );
			}

			if ( $location ) {

				if ( $pagenum > 1 ) {
					$location = add_query_arg( 'paged', $pagenum, $location ); // $pagenum takes care of $total_pages.
				}
				/**
				 * Filters the taxonomy redirect destination URL.
				 *
				 * @param string      $location The destination URL.
				 *
				 * @since 4.6.0
				 *
				 */
				wp_safe_redirect( $location );
				exit;
			}
		}
	}


	/**
	 * Renders the branding screen
	 * @return bool|mixed
	 */
	public function render() {
		$this->show_messages();
		$request         = $_REQUEST;
		$action          = isset( $request['action'] ) ? $request['action'] : 'lists';
		wp_enqueue_script( 'admin-tags' );
		switch ( $action ) {
			case 'edit':
			    include bbapp()->plugin_dir . '/views/iap/admin/subscription-groups/edit.php';
				break;
			default:
				$this->subscription_groups_list = new SubscriptionGroupsList();
				$this->subscription_groups_list->prepare_items();
				include bbapp()->plugin_dir . '/views/iap/admin/subscription-groups/lists.php';
				break;
		}
	}


}
