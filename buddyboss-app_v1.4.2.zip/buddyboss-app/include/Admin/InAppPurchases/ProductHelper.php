<?php

namespace BuddyBossApp\Admin\InAppPurchases;

use BuddyBossApp\InAppPurchases\Controller;
use BuddyBossApp\InAppPurchases\Orders;
use BuddyBossApp\InAppPurchases\SubscriptionGroupTaxonomy;

class ProductHelper {

	private static $instance = null;
	private $isCurrentPage;
	private $messages = array();


	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 * @return object
	 */
	public static function instance() {

		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Functions to check/verify if there is order for this product
	 *
	 * @param object $iap_product
	 * @param int    $user_id
	 *
	 * @return bool
	 */
	public static function hasActiveOrder( $iap_product, $user_id = 0 ) {
		global $wpdb;

		if ( empty( $user_id ) ) {
			$user_id = get_current_user_id();
		}

		$table = Orders::instance()->table_name;

		/**
		 * We are checking below things :
		 * order_status is one of 'subscribed', 'completed'
		 * matching bbapp_product_id
		 * matching user_id
		 */
		$query = $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE bbapp_product_id = %s AND user_id = %d AND order_status IN ('subscribed', 'completed')", $iap_product->id, $user_id );
		$count = (int) $wpdb->get_var( $query );

		if ( $count > 0 ) {
			return true;
		}

		$misc_settings       = Helpers::bbapp_iap_product_mics_setting( $iap_product );
		$integration_data    = Helpers::bbapp_iap_product_integration_data( $iap_product );
		$integration_type    = ( isset( $misc_settings['integration_type'] ) ? $misc_settings['integration_type'] : '' );
		$integrated_item_ids = Helpers::bbapp_iap_product_integration_ids( $integration_type, $integration_data );

		/**
		 * Filter to check given $integrated_item_ids has access by user or not.
		 */
		return apply_filters( 'bbapp_iap_is_has_access', false, $integrated_item_ids, $integration_type, $user_id );
	}

	/**
	 * Function to get product id of active order in given group
	 *
	 * @param int $group_id Group Id.
	 * @param int $user_id  User Id.
	 *
	 * @return bool
	 */
	public static function get_group_active_order_product_id( $group_id, $user_id = 0 ) {
		if ( empty( $user_id ) ) {
			$user_id = get_current_user_id();
		}

		if ( empty( $group_id ) || ! term_exists( (int) $group_id, SubscriptionGroupTaxonomy::$taxonomy ) ) {
			return 0;
		}

		$products = self::getGroupProductsIds( (int) $group_id, 'all' );
		if ( empty( $products ) ) {
			return 0;
		}

		$retval = 0;

		foreach ( $products as $product ) {
			$status = self::hasActiveOrder( $product, $user_id );
			if ( true === $status ) {
				$retval = $product->id;
				break;
			}
		}

		return (int) $retval;
	}

	/**
	 * Function to get active order in given group
	 *
	 * @param int $group_id Group Id
	 * @param int $userId   User Id
	 *
	 * @return bool
	 */
	public static function getGroupActiveOrderId( $group_id, $userId ) {
		global $wpdb;

		$product_ids = self::getGroupProductsIds( $group_id );
		if ( empty( $product_ids ) ) {
			return false;
		}
		$product_ids = implode( ",", $product_ids );


		$table = Orders::instance()->table_name;

		/**
		 * We are checking below things :
		 * order_status is one of 'subscribed', 'completed'
		 * matching bbapp_product_ids
		 * matching user_id
		 */
		$query = $wpdb->prepare( "SELECT id FROM {$table} WHERE bbapp_product_id IN ({$product_ids}) AND user_id = %s AND order_status IN ('subscribed', 'completed') limit 1", $userId );

		return (int) $wpdb->get_var( $query );
	}

	/**
	 * Initialize actions/filters
	 * @return void
	 */
	public function init() {

		add_action( 'admin_init', array( $this, 'adminInit' ) );

		/* Add scripts for admin section for product create/edit */
		add_action( 'admin_enqueue_scripts', array( $this, 'addAdminScripts' ) );

		// NOTE : can't use admin_post hook since it don't exists on multi-site
		add_action( 'admin_init', array( $this, 'store' ) );
		add_action( 'admin_init', array( $this, 'update' ) );

		// IAP Product sorting.
		add_action( 'wp_ajax_update-iap-products-order', array( $this, 'bbapp_update_ipa_products_order' ) );
		add_action( 'wp_ajax_bbapp_get_ld_dropdown', array( $this, 'bbapp_get_ld_dropdown' ) );

		// IAP screen options.
		add_action( "load-buddyboss-app_page_bbapp-iap", array( $this, 'get_screen_options' ) );
		add_filter( 'set-screen-option', array( $this, 'bbapp_admin_screen_options' ), 10, 3 );
	}

	/**
	 * Include/enqueue admin side javascripts
	 *
	 * @param $hookSuffix
	 *
	 * @return void
	 */
	public function addAdminScripts( $hookSuffix ) {
		global $pagenow;

		if ( $pagenow == "admin.php" && isset( $_GET["page"] ) && $_GET["page"] == "bbapp-iap" ) {
			// Enqueue required scripts
			wp_enqueue_script( 'bbapp-addclear' );
			wp_enqueue_script( 'bbapp-clipboard' );
		}
	}

	/**
	 * Store a newly created BuddyBossApp-Product in DB
	 * @return void
	 */
	public function store() {
		$request = $_REQUEST;
		if ( isset( $request['_wpnonce'] ) ) {
			// Verify the nonce here.
			$nonce      = $request['_wpnonce'];
			$validNonce = wp_verify_nonce( $nonce, 'save_iap_product' );
			if ( $validNonce ) {
				$name = isset( $request["name"] ) ? $request["name"] : null;
				if ( empty( $name ) ) {
					wp_die( __( "Missing Product Name Param.", "buddyboss-app" ), 'IAP Product' );
				}

				$tagline = isset( $request["tagline"] ) ? stripslashes( $request["tagline"] ) : null;
				$description = isset( $request["description"] ) ? stripslashes( $request["description"] ) : null;

				$bbapp_product_type = isset( $request["bbapp_product_type"] ) ? stripslashes( $request["bbapp_product_type"] ) : 'free';

				$miscSettings                        = array();
				$currentBlogId                       = get_current_blog_id();
				$miscSettings['integration_type']    = isset( $request["integration_type"] ) ? $request["integration_type"] : null;
				$miscSettings['integration_type']    = 'membership' === $miscSettings['integration_type'] ? ( isset( $request["integration_sub_type"] ) ? $request["integration_sub_type"] : null ) : $miscSettings['integration_type'];
				$benefits                            = isset( $request["benefits"] ) ? array_filter( $request["benefits"] ) : array();
				$miscSettings['benefits']            = array_map( 'stripslashes', $benefits );
				$miscSettings['global_subscription'] = isset( $request["global_subscription"] ) ? $request["global_subscription"] : 0;
				$group_id                            = isset( $request[ SubscriptionGroupTaxonomy::$taxonomy ] ) ? $request[ SubscriptionGroupTaxonomy::$taxonomy ] : '';

				// Course access data.
				$miscSettings['course_access'] = ( ! empty( $request['course_access'] ) && ! empty( $request['integration_type'] ) && 'membership' === $request['integration_type'] && 'learndash' !== $miscSettings['integration_type'] && defined( 'LEARNDASH_VERSION' ) ) ? 1 : 0;

				$devicePlatforms   = isset( $request["bbapp_store_enabled"] ) ? $request["bbapp_store_enabled"] : null;
				$storeProductIds   = array();
				$storeProductTypes = array();
				$storeData         = array();
				$integrationData   = array();

				if ( ! empty( $devicePlatforms ) ) {
					// Going through device
					foreach ( (array) $devicePlatforms as $devicePlatform ) {
						$storeProductIds[ $devicePlatform ] = isset( $request["iap-$devicePlatform-id"] ) ? trim( $request["iap-$devicePlatform-id"] ) : null;

						$storeProductTypes[ $devicePlatform ] = isset( $request["bbapp-iap-integration-$devicePlatform-product_types"] ) ? trim( $request["bbapp-iap-integration-$devicePlatform-product_types"] ) : null;

						//$storeProductTypes[ $devicePlatform ]['subscription-duration'] = isset( $request["subscription-duration-$devicePlatform"] ) ? $request["subscription-duration-$devicePlatform"] : null;

					}
				}

				/**
				 * Check selected integration enabled & integration data [ unlock item ] selected then store it.
				 */
				$iap_integrations = Controller::instance()->get_integrations();
				if ( isset( $iap_integrations[ $miscSettings['integration_type'] ] ) ) {
					if ( $iap_integrations[ $miscSettings['integration_type'] ]['enabled'] && isset( $request[ $miscSettings['integration_type'] ] ) ) {
						$integrationData[ $miscSettings['integration_type'] ] = $request[ $miscSettings['integration_type'] ];
					}
				}

				$storeData['bbapp_product_type'] = $bbapp_product_type;
				$storeData['device_platforms']    = $devicePlatforms;
				$storeData['store_product_types'] = $storeProductTypes;
				$storeData['store_product_ids']   = $storeProductIds;

				// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings
				if ( bbapp()->is_network_activated() ) {
					$integrationData[ get_current_blog_id() ] = $integrationData;
					$miscSettings[ get_current_blog_id() ]    = $miscSettings;
				}

				// NOTE : Insert into DB
				$createProduct = bbapp_iap_create_product( array(
					'name'             => trim( $name ),
					'tagline'          => trim( $tagline ),
					'description'      => trim( $description ),
					'misc_settings'    => serialize( $miscSettings ),
					'store_data'       => serialize( $storeData ),
					'integration_data' => serialize( $integrationData ),
					'iap_group'        => $group_id,
				) );

				if ( is_wp_error( $createProduct ) ) {
					wp_die( sprintf( __( "An error occurred while creating the product: %s", "buddyboss-app" ), $createProduct->get_error_message() ) );
				}

				if ( ! empty( $request['ld_show_on'] ) && 1 === $miscSettings['course_access'] ) {
					bbapp_iap_update_meta( $createProduct['id'], 'course_access_type', $request['ld_show_on'] );
				}

				if ( ! empty( $request['ld_courses_selection'] ) && 1 === $miscSettings['course_access'] ) {

					$new_key_type = $this->bbapp_get_ld_meta_key_type( $request['ld_show_on'] );
					$ld_selection = array_unique( $request['ld_courses_selection'] );
					// Add new meta based on the selection.
					foreach ( $ld_selection as $item ) {
						bbapp_iap_add_meta( $createProduct['id'], $new_key_type, $item );
					}
				}

				$redirect_to = add_query_arg( array(
					'page'    => 'bbapp-iap',
					'setting' => 'products',
					'action'  => 'edit',
					'id'      => $createProduct['id'],
					'created' => 1,
				), 'admin.php' );
				wp_redirect( $redirect_to );
				exit;
			}
		}
	}

	/**
	 * Update a BuddyBossApp-Product in DB.
	 * @return void
	 */
	public function update() {
		$request = $_REQUEST;
		if ( isset( $request['_wpnonce'] ) ) {
			// Verify the nonce here.
			$nonce      = $request['_wpnonce'];
			$validNonce = wp_verify_nonce( $nonce, 'update_iap_product' );
			if ( $validNonce ) {
				$id          = $request['id'];
				$name        = isset( $request["name"] ) ? $request["name"] : null;

				if ( empty( $name ) ) {
					wp_die( __( "Required fields:  product name, and description.", "buddyboss-app" ) );
				}

				$tagline = isset( $request["tagline"] ) ? stripslashes( $request["tagline"] ) : null;
				$description = isset( $request["description"] ) ? stripslashes( $request["description"] ) : null;
				$bbapp_product_type = isset( $request["bbapp_product_type"] ) ? stripslashes( $request["bbapp_product_type"] ) : 'free';

				$miscSettings                     = array();
				$currentBlogId                    = get_current_blog_id();
				$miscSettings['integration_type'] = isset( $request["integration_type"] ) ? $request["integration_type"] : null;
				$miscSettings['integration_type'] = 'membership' === $miscSettings['integration_type'] ? ( isset( $request["integration_sub_type"] ) ? $request["integration_sub_type"] : null ) : $miscSettings['integration_type'];
				$benefits                         = isset( $request["benefits"] ) ? array_filter( $request["benefits"] ) : array();
				$miscSettings['benefits']         = array_map( 'stripslashes', $benefits );

				$miscSettings['global_subscription'] = isset( $request["global_subscription"] ) ? $request["global_subscription"] : 0;
				$group_id                            = isset( $request[ SubscriptionGroupTaxonomy::$taxonomy ] ) ? $request[ SubscriptionGroupTaxonomy::$taxonomy ] : '';

				// Course access data.
				$miscSettings['course_access'] = ( ! empty( $request['course_access'] ) && ! empty( $request['integration_type'] ) && 'membership' === $request['integration_type'] && 'learndash' !== $miscSettings['integration_type'] && defined( 'LEARNDASH_VERSION' ) ) ? 1 : 0;

				if ( ! empty( $request['ld_show_on'] ) && 1 === $miscSettings['course_access'] ) {

					$old_course_type = bbapp_iap_get_meta( $id, 'course_access_type', true );

					if ( ! empty( $old_course_type ) ) {
						$old_key_type = $this->bbapp_get_ld_meta_key_type( $old_course_type );

						if ( ! empty( $old_key_type ) ) {
							$old_meta = bbapp_iap_get_meta( $id, $old_key_type, false );
							if ( ! empty( $old_meta ) ) {
								foreach ( $old_meta as $old_item ) {
									bbapp_iap_delete_meta( $id, $old_key_type, $old_item );
								}
							}
						}
					}

					bbapp_iap_update_meta( $id, 'course_access_type', $request['ld_show_on'] );

					$new_key_type = $this->bbapp_get_ld_meta_key_type( $request['ld_show_on'] );

					if ( ! empty( $request['ld_courses_selection'] ) ) {
						$ld_selection = array_unique( $request['ld_courses_selection'] );
						// Add new meta based on the selection.
						foreach ( $ld_selection as $item ) {
							bbapp_iap_add_meta( $id, $new_key_type, $item );
						}
					}
				} else {
					bbapp_iap_delete_meta( $id, '', '', true );
				}

				$devicePlatforms   = isset( $request["bbapp_store_enabled"] ) ? $request["bbapp_store_enabled"] : null;
				$storeProductIds   = array();
				$storeProductTypes = array();
				$storeData         = array();
				$integrationData   = array();

				if ( ! empty( $devicePlatforms ) ) {
					//Going through device
					foreach ( (array) $devicePlatforms as $devicePlatform ) {
						$storeProductIds[ $devicePlatform ] = isset( $request["iap-$devicePlatform-id"] ) ? trim( $request["iap-$devicePlatform-id"] ) : null;

						$storeProductTypes[ $devicePlatform ] = isset( $request["bbapp-iap-integration-$devicePlatform-product_types"] ) ? trim( $request["bbapp-iap-integration-$devicePlatform-product_types"] ) : null;

						//$storeProductTypes[ $devicePlatform ]['subscription-duration'] = isset( $request["subscription-duration-$devicePlatform"] ) ? $request["subscription-duration-$devicePlatform"] : null;

					}
				}

				/**
				 * Check selected integration enabled & integration data [ unlock item ] selected then store it.
				 */
				$iap_integrations = Controller::instance()->get_integrations();
				if ( isset( $iap_integrations[ $miscSettings['integration_type'] ] ) ) {
					if ( $iap_integrations[ $miscSettings['integration_type'] ]['enabled'] && isset( $request[ $miscSettings['integration_type'] ] ) ) {
						$integrationData[ $miscSettings['integration_type'] ] = $request[ $miscSettings['integration_type'] ];
					}
				}

				$storeData['bbapp_product_type'] = $bbapp_product_type;
				$storeData['device_platforms']    = $devicePlatforms;
				$storeData['store_product_types'] = $storeProductTypes;
				$storeData['store_product_ids']   = $storeProductIds;

				// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings
				if ( bbapp()->is_network_activated() ) {
					$BuddyBossAppProduct = bbapp_iap_get_product( $id );

					//NOTE : For misc_settings we need to append data NOT override
					$currentMiscSettings                          = unserialize( $BuddyBossAppProduct['misc_settings'] );
					$currentMiscSettings[ get_current_blog_id() ] = $miscSettings;
					$miscSettings                                 = $currentMiscSettings;

					//NOTE : For integration_data we need to append data NOT override
					$currentIntegrationData                          = unserialize( $BuddyBossAppProduct['integration_data'] );
					$currentIntegrationData[ get_current_blog_id() ] = $integrationData;
					$integrationData                                 = $currentIntegrationData;
				}


				// NOTE : Update it into DB
				$updatedData['name']             = trim( $name );
				$updatedData['tagline']          = trim( $tagline );
				$updatedData['description']      = trim( $description );
				$updatedData['misc_settings']    = serialize( $miscSettings );
				$updatedData['store_data']       = serialize( $storeData );
				$updatedData['integration_data'] = serialize( $integrationData );
				$updatedData['date_updated']     = current_time( 'mysql', 1 );
				$updatedData['iap_group']        = $group_id;

				// NOTE : We only allow edits at NetworkLevel NOT at subSite(s) for MultiSite wordpress
				if ( bbapp()->is_network_activated() && ! is_network_admin() ) {
					unset( $updatedData['name'] );
					unset( $updatedData['tagline'] );
					unset( $updatedData['description'] );
					unset( $updatedData['store_data'] );
					unset( $updatedData['name'] );
				}

				//NOTE : Update
				$updateProduct = bbapp_iap_update_product( $id, $updatedData );
				if ( is_wp_error( $updateProduct ) ) {
					wp_die( sprintf( __( "An error occurred while updating the product: %s", "buddyboss-app" ), $updateProduct->get_error_message() ) );
				}

				$redirect_to = add_query_arg( array(
					'page'    => 'bbapp-iap',
					'setting' => 'products',
					'action'  => 'edit',
					'id'      => $id,
					'updated' => 1,
				), 'admin.php' );
				wp_redirect( $redirect_to );
				exit;
			}
		}
	}

	/**
	 * Function to get the meta key type.
	 *
	 * @since 1.4.0
	 *
	 * @param string $selection LD show on selection.
	 *
	 * @return string
	 */
	public function bbapp_get_ld_meta_key_type( $selection ) {

		$key_type = '';

		if ( 'specific-category-courses' === $selection ) {
			$key_type = 'course_access_cat_id';
		} elseif ( 'specific-tag-courses' === $selection ) {
			$key_type = 'course_access_tag_id';
		} elseif ( 'specific-course' === $selection ) {
			$key_type = 'course_access_id';
		}

		return $key_type;

	}

	/**
	 * Load Product List.
	 * @return void
	 */
	public function adminInit() {
		if ( $this->willRender() ) {
			$this->products_list = new ProductList();
			$this->products_list->prepare_items();
		}

	}

	/**
	 * Functions tells & sets if current page is one where it will render.
	 *
	 * @param bool $set
	 *
	 * @return bool
	 */
	public function willRender( $set = false ) {
		if ( $set ) {
			$this->isCurrentPage = true;
		}

		return $this->isCurrentPage;
	}

	/**
	 * Renders the branding screen
	 * @return bool|mixed
	 */
	public function render() {

		$request         = $_REQUEST;
		$action          = isset( $request['action'] ) ? $request['action'] : 'lists';
		$devicePlatforms = bbapp_iap_get_types();
		$this->iap_screen_notice();
		switch ( $action ) {
			case 'create':

				//Used in template file
				$iap_integrations = Controller::instance()->get_integrations();

				$is_edit = false;
				include bbapp()->plugin_dir . '/views/iap/admin/product/edit.php';
				break;

			case 'edit':
				$id = isset( $request['id'] ) ? $request['id'] : false;
				if ( $id ) {

					//Used in template file
					$iap_integrations = Controller::instance()->get_integrations();

					$product        = $this->getIapProduct( $id );
					$miscSettings   = unserialize( $product->misc_settings );
					$bbappIapLinkTo = unserialize( $product->integration_data );

					// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_type or misc_settings
					if ( bbapp()->is_network_activated() ) {
						$miscSettings   = $miscSettings[ get_current_blog_id() ];
						$bbappIapLinkTo = $bbappIapLinkTo[ get_current_blog_id() ];
					}

					$integrationType      = $miscSettings['integration_type'];
					$benefits             = $miscSettings['benefits'];
					$isGlobalSubscription = $miscSettings['global_subscription'];
					$course_access        = ( ! empty( $miscSettings['course_access'] ) ) ? $miscSettings['course_access'] : 0;
					$course_show_on_type  = bbapp_iap_get_meta( $id, 'course_access_type', true );
					$course_show_on       = ( ! empty( $course_show_on_type ) ) ? $course_show_on_type : '';
					$key_type             = $this->bbapp_get_ld_meta_key_type( $course_show_on );
					$ld_selection_type    = bbapp_iap_get_meta( $id, $key_type, false );
					$ld_selection         = ( ! empty( $ld_selection_type ) ) ? $ld_selection_type : '';
					$storeData            = unserialize( $product->store_data );

					$enabledIapTypes   = $storeData['device_platforms'];
					$bbappProductType  = $storeData['bbapp_product_type'];
					$storeProductTypes = $storeData['store_product_types'];
					$storeProductIds   = $storeData['store_product_ids'];

					$is_edit = true;
					include bbapp()->plugin_dir . '/views/iap/admin/product/edit.php';
				}

				break;

			case 'upgrade':
				$upgradeHelper = UpgradeHelper::instance();

				return $upgradeHelper::upgradeProductsToNewSchema();
				break;
			default:
				$this->products_list = new ProductList();
				$this->products_list->prepare_items();
				include bbapp()->plugin_dir . '/views/iap/admin/product/lists.php';
				break;
		}

	}

	/**
	 * IAP Screen notice.
	 */
	public function iap_screen_notice(){
		$bulk_counts = array(
			'deleted'   => isset( $_REQUEST['deleted'] ) ? absint( $_REQUEST['deleted'] ) : 0,
			'trashed'   => isset( $_REQUEST['trashed'] ) ? absint( $_REQUEST['trashed'] ) : 0,
			'untrashed' => isset( $_REQUEST['untrashed'] ) ? absint( $_REQUEST['untrashed'] ) : 0,
		);
		$bulk_messages     = array(
			/* translators: %s: Number of IAP Products. */
			'deleted'   => _n( '%s product permanently deleted.', '%s products permanently deleted.', $bulk_counts['deleted'] ),
			/* translators: %s: Number of pages. */
			'trashed'   => _n( '%s product moved to the Trash.', '%s products moved to the Trash.', $bulk_counts['trashed'] ),
			/* translators: %s: Number of pages. */
			'untrashed' => _n( '%s product restored from the Trash.', '%s products restored from the Trash.', $bulk_counts['untrashed'] ),
		);
		$bulk_counts   = array_filter( $bulk_counts );
		$messages = array();
		foreach ( $bulk_counts as $message => $count ) {
			if ( isset( $bulk_messages[ $message ] ) ) {
				$messages[] = sprintf( $bulk_messages[ $message ], number_format_i18n( $count ) );
			}
			if ( 'trashed' === $message && isset( $_REQUEST['ids'] ) ) {
				$ids        = $_REQUEST['ids'];
				$base_url   = bbapp_get_admin_url( 'admin.php?page=' . esc_attr( $_REQUEST['page'] ) . '&amp;setting=products&amp;iap_product_ids=' . implode(',',$ids) );
				$messages[] = '<a href="' . esc_url( wp_nonce_url( $base_url . '&amp;action=untrash', 'cc_untrash_iap_product' ) ) . '">' . __( 'Undo' ) . '</a>';
			}

			if ( 'untrashed' === $message && isset( $_REQUEST['ids'] ) ) {
				$ids = $_REQUEST['ids'];
				if ( 1 === count( $ids ) ) {
					$messages[] = sprintf(
						'<a href="%1$s">%2$s</a>',
						esc_url( bbapp_get_admin_url(sprintf("admin.php?page=%s&setting=products&action=%s&id=%s",$_REQUEST['page'], 'edit', $ids[0] )) ),
						esc_html( 'Edit' )
					);
				}
			}
		}

		if ( empty( $messages ) ) {
			if ( isset( $_REQUEST['created'] ) ) {
				$messages[] = sprintf( __( 'The product has been created successfully.', 'buddyboss-app' ) );
			}
			if ( isset( $_REQUEST['updated'] ) ) {
				$messages[] = sprintf( __( 'The product has been updated successfully.', 'buddyboss-app' ) );
			}
		}
		if ( $messages ) {
			echo '<div id="message" class="updated notice is-dismissible"><p>' . implode( ' ', $messages ) . '</p></div>';
		}
	}

	/**
	 * Get IAP product from DB
	 *
	 * @param $id
	 *
	 * @return object Single product
	 */
	public function getIapProduct( $id ) {

		global $wpdb;
		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		$query        = "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE id = {$id}";

		return $wpdb->get_row( $query, OBJECT );
	}

	/**
	 * Delete iap product.
	 *
	 * @param $iap_product_id
	 *
	 * @return bool|int
	 */
	public function delete_iap_product( $iap_product_id ) {
		global $wpdb;

		$iap_product = $this->getIapProduct( $iap_product_id );

		if ( empty( $iap_product ) ) {
			return false;
		}
		$tableName = \bbapp_iap()->get_global_dbprefix() . "bbapp_iap_products";

		$iap_delete = $wpdb->delete( $tableName, array( 'id' => $iap_product_id ) );

		if ( $iap_delete ) {
			bbapp_iap_delete_meta( $iap_product_id );
		}

		return $iap_delete;
	}

	/**
	 * iap product Update status.
	 *
	 * @param        $iap_product_id
	 * @param string $status
	 *
	 * @return bool|int
	 */
	public function update_iap_product_status( $iap_product_id, $status = 'published' ) {
		global $wpdb;

		$iap_product = $this->getIapProduct( $iap_product_id );

		if ( empty( $iap_product ) ) {
			return false;
		}
		$tableName = \bbapp_iap()->get_global_dbprefix() . "bbapp_iap_products";

		return $update = $wpdb->update(
			$tableName,
			array(
				'status' => $status
			),
			array( "id" => $iap_product_id )
		);
	}

	/**
	 * Get IAP Products Ids by group from DB.
	 *
	 * @param int    $group_id Group ID.
	 * @param string $column   Column name to fetch.
	 *
	 * @return array
	 */
	public static function getGroupProductsIds( $group_id, $column = 'id' ) {
		global $wpdb;

		$globalPrefix = \bbapp_iap()->get_global_dbprefix();
		if ( $column === 'all' ) {
			$query = $wpdb->prepare( "SELECT * FROM {$globalPrefix}bbapp_iap_products WHERE iap_group=%d", $group_id );

			return $wpdb->get_results( $query, OBJECT );
		} else {
			$query = $wpdb->prepare( "SELECT {$column} FROM {$globalPrefix}bbapp_iap_products WHERE iap_group=%d", $group_id );

			return $wpdb->get_col( $query );
		}

		return array();

	}

	/**
	 * Update IAP Product order.
	 */
	public function bbapp_update_ipa_products_order() {
		set_time_limit( 600 );

		global $wpdb, $userdata;

		$screen = filter_var( $_POST['screen'], FILTER_SANITIZE_STRING );
		$paged  = filter_var( $_POST['paged'], FILTER_SANITIZE_NUMBER_INT );
		$nonce  = $_POST['sort_nonce'];

		//verify the nonce
		if ( ! wp_verify_nonce( $nonce, 'bbapp_sort_nonce_' . $userdata->ID ) ) {
			die();
		}

		parse_str( $_POST['order'], $data );

		if ( ! is_array( $data ) || count( $data ) < 1 ) {
			die();
		}

		//retrieve a list of all objects
		$tableName = \bbapp_iap()->get_global_dbprefix() . "bbapp_iap_products";
		$results   = $wpdb->get_results( "SELECT ID FROM {$tableName} WHERE status IN ('published') ORDER BY menu_order, date_created DESC" );

		if ( ! is_array( $results ) || count( $results ) < 1 ) {
			die();
		}

		// Create the list of ID's
		$objects_ids = array();
		foreach ( $results as $result ) {
			$objects_ids[] = (int) $result->ID;
		}

		$objects_per_page = get_user_meta( $userdata->ID, $screen . '_per_page', true );
		if ( empty( $objects_per_page ) ) {
			$objects_per_page = 20; // default pagination as screen option.
		}

		$edit_start_at = $paged * $objects_per_page - $objects_per_page;
		$index         = 0;
		for ( $i = $edit_start_at; $i < ( $edit_start_at + $objects_per_page ); $i ++ ) {
			if ( ! isset( $objects_ids[ $i ] ) ) {
				break;
			}

			$objects_ids[ $i ] = (int) $data['iap-product'][ $index ];
			$index ++;
		}

		// Update the menu_order within database.
		foreach ( $objects_ids as $menu_order => $id ) {
			$data = array(
				'menu_order' => $menu_order
			);

			$wpdb->update( $tableName, $data, array( "id" => $id ) );
		}

		//trigger action completed
		do_action( 'bbapp/order_update_complete' );
		wp_die();
	}

	/**
	 * Function to get the LearnDash dropdown based on the show on selection.
	 *
	 * @since 1.4.0
	 */
	function bbapp_get_ld_dropdown() {
		$result            = array();
		$result['message'] = esc_html__( 'Something went wrong please try again later', 'buddyboss-app' );
		$result['html']    = '';

		$nonce = ( ! empty( $_POST['ld_nonce'] ) ) ? $_POST['ld_nonce'] : '';
		if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'ld-dropdown-nonce' ) || ! current_user_can( 'manage_options' ) ) {
			$result['message'] = '<p class="bbapp-notice-box bbapp-notice-box--error">' . esc_html__( 'Security check failed', 'buddyboss-app' ) . '</p>';
			wp_send_json_error( $result );
		}

		$show_on = ( ! empty( $_POST['show_on'] ) ) ? $_POST['show_on'] : '';
		if ( empty( $show_on ) ) {
			$result['message'] = '<p class="bbapp-notice-box bbapp-notice-box--error">' . esc_html__( 'Please select option to show the LearnDash courses', 'buddyboss-app' ) . '</p>';
			wp_send_json_error( $result );
		}

		$result['message'] = esc_html__( 'Results found', 'buddyboss-app' );
		$result['html']    = $this->bbapp_get_ld_dropdown_html( $show_on );

		wp_send_json_success( $result );
	}

	public function bbapp_get_unique() {
		static $unique = 0;
		$unique ++;

		return $unique;
	}

	/**
	 * Function to get the show on dropdown results.
     *
	 * @since 1.4.0
     *
	 * @param string $selection Show on section.
	 * @param array $pre_filled array for save items.
	 *
	 * @return string
	 */
	public function bbapp_get_ld_dropdown_html( $selection, $pre_filled = array() ) {

		$pre_filled = ! empty( $pre_filled ) ? array_map( 'intval', $pre_filled ) : array();

		if ( 'specific-category-courses' === $selection ) {
			$selection_lists = get_terms( 'ld_course_category', array(
				'hide_empty' => false,
				'fields'     => 'id=>name',
			) );
			$place_holder    = esc_html__( 'Please select Categories', 'buddyboss-app' );
		} elseif ( 'specific-tag-courses' === $selection ) {
			$selection_lists = get_terms( 'ld_course_tag', array(
				'hide_empty' => false,
				'fields'     => 'id=>name',
			) );
			$place_holder    = esc_html__( 'Please select Tags', 'buddyboss-app' );
		} else {
			$ld_courses   = new \WP_Query( array(
				'post_type'       => 'sfwd-courses',
				'posts_per_page ' => - 1,
				'nopaging'        => true,
			) );
			$place_holder = esc_html__( 'Please select Courses', 'buddyboss-app' );

			if ( ! empty( $ld_courses->posts ) ) {
				$selection_lists = array();
				foreach ( $ld_courses->posts as $ld_course ) {
					$selection_lists[ $ld_course->ID ] = $ld_course->post_title;
				}
			}
		}

		$dropdown_html = '';
		$unique        = 1;
		ob_start();
		?>
        <br>
        <div class="bbapp-selection-main-wrapper">
            <div class="bbapp-selection-inr-wrapper">
		        <?php
		        if ( ! empty( $pre_filled ) ) {
			        foreach ( $pre_filled as $single_item ) {
				        ?>
                        <div class="bbapp-selection-cmn">
                            <select id="bbapp-show-on-selection-<?php echo $unique; ?>" class="bbapp-show-on-selection"
                                    name="ld_courses_selection[]"
                                    data-placeholder="<?php echo esc_html( $place_holder ) ?>"
                                    data-select-key="<?php echo $unique; ?>" style="width:100%">
		                        <?php
		                        if ( ! empty( $selection_lists ) ) {
			                        foreach ( $selection_lists as $key => $selection_list ) {
				                        ?>
                                        <option value="<?php echo esc_attr( $key ); ?>" <?php echo ( $single_item === $key ) ? 'selected=selected' : ''; ?>><?php echo esc_html( $selection_list ) ?></option>
				                        <?php
			                        }
		                        }
		                        ?>
                            </select>
	                        <?php
	                        if ( 1 !== $unique ) {
		                        ?>
                                <a href="javascript:void(0);" class="bbapp-remove-clone"><i
                                            class="dashicons dashicons-dismiss"></i></a>
		                        <?php
	                        }
	                        ?>
                        </div>
				        <?php
				        $unique ++;
			        }
		        } else {
			        ?>
                    <div class="bbapp-selection-cmn">
                        <select id="bbapp-show-on-selection-<?php echo $unique; ?>" class="bbapp-show-on-selection"
                                name="ld_courses_selection[]" data-placeholder="<?php echo esc_html( $place_holder ) ?>"
                                data-select-key="<?php echo $unique; ?>" style="width:100%">
					        <?php
					        if ( ! empty( $selection_lists ) ) {
						        foreach ( $selection_lists as $key => $selection_list ) {
							        ?>
                                    <option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $selection_list ) ?></option>
							        <?php
						        }
					        }
					        ?>
                        </select>
                    </div>
			        <?php
		        }
		        ?>
            </div>
            <br/>
            <a href="javascript:void(0);" class="button bbapp-add-selection">
				<?php
				esc_html_e( '+ Add Course', 'buddyboss-app' );
				?>
            </a>
        </div>
		<?php
		$dropdown_html .= ob_get_clean();

		return $dropdown_html;
	}

	/**
	 * Register the screen options.
	 */
	public function get_screen_options() {
		$screen = get_current_screen();

		if ( ! is_object( $screen ) || 'buddyboss-app_page_bbapp-iap' !== $screen->id ) {
			return;
		}

		if ( isset( $_GET['setting'] ) && 'products' !== $_GET['setting'] ) {
			return;
		}

		// Loop through all the options and add a screen option for each.
		add_screen_option( 'per_page',
			array(
				'label'   => __('Number of items per page:', 'buddyboss-app'),
				'default' => 20,
				'option'  => 'iap_product_per_page'
			)
		);
	}

	/**
	 * Handle save/update of screen options for iap product.
	 *
	 * @param string $value     Will always be false unless another plugin filters it first.
	 * @param string $option    Screen option name.
	 * @param string $new_value Screen option form value.
	 *
	 * @return string|int Option value. False to abandon update.
	 */
	public function bbapp_admin_screen_options( $value, $option, $new_value ) {
		if ( 'iap_product_per_page' !== $option ) {
			return $value;
		}

		// Per page.
		$new_value = (int) $new_value;
		if ( $new_value < 1 || $new_value > 999 ) {
			return $value;
		}

		return $new_value;
	}
}
