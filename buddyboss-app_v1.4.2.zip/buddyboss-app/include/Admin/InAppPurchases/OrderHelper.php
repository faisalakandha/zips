<?php

namespace BuddyBossApp\Admin\InAppPurchases;

use BuddyBossApp\InAppPurchases\Orders;

class OrderHelper {

	private static $instance = null;
	private $is_current_page;
	private $messages = array();
	private $orders_list;

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 *
	 * @return OrderHelper
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$className      = __CLASS__;
			self::$instance = new $className;
			self::$instance->init();
		}

		return self::$instance;
	}

	/**
	 * Initialize actions/filters
	 * @return void
	 */
	public function init() {
		add_action( 'admin_init', array( $this, 'adminInit' ), 15 );
	}

	/**
	 * Functions tells & sets if current page is one where it's will render.
	 *
	 * @param bool $set
	 *
	 * @return bool
	 */
	public function willRender( $set = false ) {

		if ( $set ) {
			$this->is_current_page = true;
		}

		return $this->is_current_page;
	}

	/**
	 * Load Order List.
	 * @return void
	 */
	public function adminInit() {

		if ( $this->willRender() ) {

			$this->orders_list = new OrderList();
			$this->orders_list->prepare_items();
		}

	}

	/**
	 * Renders screen based on action variable in url
	 * @return bool|mixed
	 */
	public function render() {
		$request = $_REQUEST;
		$action  = isset( $request['action'] ) ? $request['action'] : 'lists';

		switch ( $action ) {
			case 'upgrade':
				$upgradeHelper = UpgradeHelper::instance();

				return $upgradeHelper::upgradeOrdersToNewSchema();
				break;

			case 'revoke_order':
			case 'bulk-revoke-order':
				if ( isset( $_REQUEST['iap_purchases_ids'] ) && ! empty( $_REQUEST['iap_purchases_ids'] ) ) {
					include bbapp()->plugin_dir . '/views/iap/admin/order/revoke-order.php';
				} else {
					include bbapp()->plugin_dir . '/views/iap/admin/order/lists.php';
				}
				break;

			default:
				include bbapp()->plugin_dir . '/views/iap/admin/order/lists.php';
				break;
		}
	}

	/**
	 * Renders the Single Screen of InAppPurchase Order.
	 * @return void
	 */
	public function orderSingleScreen() {
		$orderId = (int) $_REQUEST["order_id"];
		$order   = Orders::instance()->get_by_id( $orderId );

		if ( empty( $orderId ) || is_wp_error( $order ) ) {
			include bbapp()->plugin_dir . "/views/iap/admin/order/not-found.php";
		} else {

			$dateFormat  = get_option( "date_format" ) . " @ " . get_option( "time_format" );
			$iap         = bbapp_iap()->iap[ $order->device_platform ];
			$deviceLabel = $iap->get_label();

			$BuddyBossAppProduct   = bbapp_iap_get_product( $order->bbapp_product_id );
			$integrationTypes = unserialize( $order->integration_types );
			$itemIds          = unserialize( $order->item_ids );
			$items            = Helpers::parseItemIds( $itemIds );
			$itemsReadable    = implode( "<br/>", $items );

			// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_types or item_ids
			if ( bbapp()->is_network_activated() ) {
				$itemIds       = $itemIds[ get_current_blog_id() ];
				$items         = Helpers::parseItemIds( $itemIds );
				$itemsReadable = implode( "<br/>", $items );
			}

			$integrationLabels = array();
			foreach ( $integrationTypes as $integrationType ) {
				$integrationLabels[] = Helpers::getIntegrationLabel( $integrationType );
			}

			// if multisite we need to get integration types from current blog site.
			if ( bbapp()->is_network_activated() ) {
				$integrationTypes = $integrationTypes[ get_current_blog_id() ];
			}
			$integrationReadable = implode( "<br/>", $integrationLabels );
			$userData            = get_userdata( $order->user_id );
			$name                = __( "Deleted" );

			if ( function_exists( 'bp_core_get_user_displayname' ) ) {
				$name = bp_core_get_user_displayname( $order->user_id );
			} elseif ( ! empty( $userData ) ) {
				$name = $userData->display_name;
			}
			$userDetails['id']           = $order->user_id;
			$userDetails['display_name'] = $name;

			include bbapp()->plugin_dir . "/views/iap/admin/order/single.php";
		}

	}

	/**
	 * @param int $user_id
	 *
	 * @param bool $user_email
	 *
	 * @return bool|string|void
	 */
	public function bbapp_get_iap_user_url( $user_id = 0, $user_email = false ) {
		if ( empty( $user_id ) ) {
			if ( $user_email && is_email( $user_email ) ) {
				$url = admin_url( "users.php?s={$user_email}" );

				return "<a href='" . esc_url( $url ) . "' target='_blank'>{$user_email}</a>";
			}
			return __( 'No user found.', 'buddyboss-app' );
		}
		$user_data = get_userdata( $user_id );
		$name      = __( "Deleted" );
		$url       = '';
		if ( function_exists( 'bp_core_get_user_displayname' ) ) {
			$name = bp_core_get_user_displayname( $user_id );
			$url  = bp_core_get_userlink( $user_id, false, true );
		} elseif ( ! empty( $user_data ) ) {
			$name = $user_data->display_name;
			$url  = admin_url( "user-edit.php?user_id={$user_id}" );
		}

		return ! empty( $url ) ? "<a href='" . esc_url( $url ) . "' target='_blank'>{$name}</a>" : $name;
	}
}
