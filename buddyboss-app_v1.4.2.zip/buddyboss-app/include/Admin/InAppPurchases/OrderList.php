<?php

namespace BuddyBossApp\Admin\InAppPurchases;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Helpers\WP_List_Table;
use BuddyBossApp\InAppPurchases\Orders;
use BuddyBossApp\Logger;

class OrderList extends WP_List_Table {

	/**
	 * The type of view currently being displayed.
	 *
	 * E.g. "All", "Pending", "Approved", "Spam"...
	 *
	 * @since BuddyPress 1.7.0
	 * @var string
	 */
	public $view = 'all';
	/**
	 * Order counts for each order type.
	 *
	 * @since BuddyPress 1.7.0
	 * @var int
	 */
	public $iap_purchases_counts = 0;

	/** Class constructor */
	public function __construct() {

		parent::__construct( array(
			'singular' => __( 'IAP Order', 'buddyboss-app' ), //singular name of the listed records
			'plural'   => __( 'IAP Orders', 'buddyboss-app' ), //plural name of the listed records
			'ajax'     => false, //should this table support ajax?

		) );

	}

	/**
	 * Get orders from database.
	 *
	 * @param int    $perPage
	 * @param int    $pageNumber
	 * @param string $view
	 * @param int    $iap_product
	 *
	 * @return mixed
	 */
	public static function get_orders( $perPage = 5, $pageNumber = 1, $view = '', $iap_product ) {

		if ( IAP_LOG ) {
			Logger::instance()->add( "iap_log", 'BuddyBossApp\InAppPurchases\OrderList->get_orders()' );
		}

		$args    = array();
		$request = $_REQUEST;
		if ( isset( $request['orderby'] ) && ! empty( $request['orderby'] ) ) {
			$args["orderby"] = $request['orderby'];
		}
		if ( isset( $request['order'] ) && ! empty( $request['order'] ) ) {
			$args["order"] = $request['order'];
		}

		$args["per_page"] = $perPage;

		$args["current_page"] = $pageNumber;

		$where_args = array();

		// NOTE : For multi-site, we are displaying order of it's own site
		if ( bbapp()->is_network_activated() ) {
			$where_args['blog_id'] = get_current_blog_id();
		}

		if ( ! empty( $view ) && 'all' !== $view ) {
			$where_args['order_status'] = $view;
		}

		if ( ! empty( $iap_product ) ) {
			$where_args['bbapp_product_id'] = $iap_product;
		}

		$results = Orders::instance()->get_orders( $where_args, $args );

		if ( ! is_array( $results ) ) {
			$results = array();
		}

		// convert to array;
		foreach ( $results as $k => $v ) {
			$results[ $k ] = (array) $v;
		}

		return $results;

	}

	/**
	 * Returns the count of records in the database.
	 *
	 * @param string $order_status
	 * @param int    $iap_product
	 *
	 * @return null|string
	 */
	public static function record_count( $order_status = '', $iap_product ) {
		return Orders::instance()->get_total_orders_count( $order_status, $iap_product );
	}

	/**
	 * return the column available to this table list.
	 * @return array
	 */
	public function get_columns() {
		return array(
			'cb'              => '<input type="checkbox" />',
			'id'              => __( 'Purchase ID', 'buddyboss-app' ),
			'user'            => __( 'Customer', 'buddyboss-app' ),
			'status'          => __( 'Status', 'buddyboss-app' ),
			'device_platform' => __( 'Platform ', 'buddyboss-app' ),
			'iap_product'     => __( 'Product ', 'buddyboss-app' ),
			'integration'     => __( 'Integration', 'buddyboss-app' ),
			'date_created'    => __( 'Date', 'buddyboss-app' ),
		);
	}

	/**
	 *
	 */
	public function no_items() {
		_e( 'No purchases found.', 'buddyboss-app' );
	}

	/**
	 * @param object $item
	 * @param string $columnName
	 *
	 * @return string|void
	 */
	public function column_default( $item, $columnName ) {

		$itemIds          = unserialize( $item['item_ids'] ); // db keys.
		$items            = Helpers::parseItemIds( $itemIds );

		// NOTE : For multi-site, we are storing data as [:blog-id][some_key_index]. Eg : integration_types or item_ids
		if ( bbapp()->is_network_activated() ) {
			$itemIds          = $itemIds[ get_current_blog_id() ];
			$items            = Helpers::parseItemIds( $itemIds );

			$orderOfBlogId = $item['blog_id'];
			if ( $orderOfBlogId != get_current_blog_id() ) {

			}
		}

		$itemsReadable = implode( "<br/>", $items );

		if ( empty( $integrationLabels ) ) {
			$integrationLabels = "(Not Available)";
		}

		switch ( $columnName ) {
			case 'id':
				return $item["id"];
				break;
			case 'user':
				return OrderHelper::instance()->bbapp_get_iap_user_url( $item["user_id"], $item["user_email"] );
				break;
			case 'status':
				return "<div class='order-status " . strtolower( $item["order_status"] ) . "'><span>" . ucfirst( $item["order_status"] ) . "</span></div>";
				break;
			case 'device_platform':
				$iap         = bbapp_iap()->iap[ $item["device_platform"] ];
				$deviceLabel = $iap->get_label();

				return $deviceLabel;
				break;
			case 'iap_product':
				$iap_product = bbapp_iap_get_product( $item['bbapp_product_id'] );
				if ( ! empty( $iap_product ) ) {
					return "<a href='" . bbapp_get_admin_url( "admin.php?page=bbapp-iap&setting=products&action=edit&id={$item['bbapp_product_id']}" ) . "' target='_blank'>{$iap_product['name']}</a>";
				} else {
					return __( "Deleted" );
				}
				break;
			case 'integration':
				return $itemsReadable;
				break;
			case 'date_created':
				$date_format = get_option( 'date_format' );
				$date_format = ! empty( $date_format ) ? $date_format : __('F j, Y');
				$time_format = get_option( 'time_format' );
				$time_format = ! empty( $time_format ) ? $time_format : __('g:i a');

				return sprintf(
					__( '%1$s at %2$s' ),
					get_gmt_from_date( $item["date_created"], $date_format ),
					get_gmt_from_date( $item["date_created"], $time_format )
				);
				break;
			default:
				return "N/A";
				break;
		}

	}

	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items() {

		/**
		 * Init column headers.
		 */
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );

		/** Process bulk action */
		$this->process_bulk_action();

		// Set the current view.
		if ( isset( $_GET['order_status'] ) && in_array( $_GET['order_status'], array( 'subscribed', 'completed', 'pending', 'cancelled' ) ) ) {
			$this->view = $_GET['order_status'];
		}

		$iap_product = $this->bbapp_requested_purchased_product_id();

		$per_page     = 20;
		$current_page = $this->get_pagenum();
		$total_items  = self::get_orders_type_ids();
		// Get order type counts for display in the filter tabs.
		$this->iap_purchases_counts = array();
		foreach ( $total_items as $view => $total_item ) {
			$this->iap_purchases_counts[ $view ] = $total_item;
		}
		$this->items = self::get_orders( $per_page, $current_page, $this->view, $iap_product );
		if ( ! empty( $iap_product ) ) {
			$current_view = 'all' === $this->view ? '' : $this->view; // If status is all then pass blank for query.
			$total_count = self::record_count( $current_view, $iap_product );
		} else {
			$total_count = $this->iap_purchases_counts[ $this->view ];
		}
		$this->set_pagination_args( array(
			'total_items' => $total_count, //WE have to calculate the total number of items
			'per_page'    => $per_page, //WE have to determine how many items to show on a page
		) );
	}

	/**
	 * Get an array containing ids for each order type.
	 *
	 * A bit of a kludge workaround for some issues
	 *
	 * @param $iap_product
	 *
	 * @return array
	 * @since BuddyPress 1.7.0
	 *
	 */
	public static function get_orders_type_ids( $iap_product = '' ) {

		$ids = array();

		$ids['all']        = self::record_count( '', $iap_product );
		$ids['subscribed'] = self::record_count( 'subscribed', $iap_product );
		$ids['completed']  = self::record_count( 'completed', $iap_product );
		$ids['pending']    = self::record_count( 'pending', $iap_product );
		$ids['cancelled']  = self::record_count( 'cancelled', $iap_product );

		return $ids;
	}

	/**
	 * Checkbox for bulk items.
	 *
	 * @param object $item
	 *
	 * @return string|void
	 */
	function column_cb( $item ) {
		if ( in_array( $item['order_status'], array(
				'subscribed',
				'completed'
			) ) && current_user_can( "manage_options" ) ) {

			return sprintf(
				'<input type="checkbox" name="iap_purchases_ids[]" value="%s" />', $item['id']
			);
		}

		return '';
	}

	/**
	 * Bulk action process.
	 * @return bool
	 */
	public function process_bulk_action() {
		if ( ! current_user_can( "manage_options" ) ) {
			wp_die( "You don't have permission to access this page.", "buddyboss-app" );
		}
		// Build redirection URL.
		$redirect_to = remove_query_arg( array(
			'action',
			'action2',
			'cc_revoke_iap_purchases',
			'revoked',
			'revoke_order',
			'iap_purchases_ids',
			'error',
			'updated',
			'success_new',
			'error_new',
			'success_modified',
			'_wpnonce',
			'error_modified'
		), $_SERVER['REQUEST_URI'] );

		$action = $this->current_action();

		if ( 'do_revoke' === $action && ! empty( $_POST['revoke_iap_purchases'] ) ) {
			check_admin_referer( 'cc_revoke_iap_purchases' );
			$iap_purchases_ids = wp_parse_id_list( $_POST['revoke_iap_purchases'] );

			$count             = 0;
			foreach ( $iap_purchases_ids as $iap_purchases_id ) {

				$currentUserId = get_current_user_id();
				$success       = Orders::instance()->cancel_order( $iap_purchases_id, __( "Order has been cancelled manually by user #$currentUserId.", "buddyboss-app" ) );

				if ( is_wp_error( $success ) ) {
					wp_die( $success->get_error_message() );
				} else {
					// Store cancel detail on meta.
					Orders::instance()->update_meta( $iap_purchases_id, "order_cancelled_manually", 1 );
					Orders::instance()->update_meta( $iap_purchases_id, "order_cancelled_user_id", get_current_user_id() );
					$count ++;
				}

			}
			$redirect_to = add_query_arg( 'revoked', $count, $redirect_to );
			wp_safe_redirect( $redirect_to );
		}

		return true;
	}

	/**
	 * Bulk action.
	 * @return array
	 */
	public function get_bulk_actions() {
		return array(
			'bulk-revoke-order' => __( 'Revoke Purchase', 'buddyboss-app' ),
		);
	}

	/**
	 * Get the list of views available on this table (e.g. "all", "public").
	 *
	 */
	public function get_views() {
		$url_base = bbapp_get_admin_url( 'admin.php?page=bbapp-iap&setting=orders' );

		$iap_product = $this->bbapp_requested_purchased_product_id();
		if ( ! empty( $iap_product ) ) {
			$url_base = $this->bbapp_add_query_args_as_product_filter( $url_base, $iap_product );
		}
		?>

		<h2 class="screen-reader-text">
			<?php
			/* translators: accessibility text */
			_e( 'Filter IAP Orders list', 'buddyboss-app' );
			?>
		</h2>

		<ul class="subsubsub">
			<li class="all"><a href="<?php echo esc_url( $url_base ); ?>" class=" <?php if ( 'all' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( __( 'All <span class="count">(%s)</span>', '' ), $this->iap_purchases_counts['all'] ); ?></a> |
			</li>
			<li class="subscribed">
				<a href="<?php echo esc_url( add_query_arg( 'order_status', 'subscribed', $url_base ) ); ?>" class="<?php if ( 'subscribed' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( _n( 'Subscribed <span class="count">(%s)</span>', 'Subscribed <span class="count">(%s)</span>', $this->iap_purchases_counts['subscribed'], 'buddyboss-app' ), number_format_i18n( $this->iap_purchases_counts['subscribed'] ) ); ?>
				</a> |
			</li>
			<li class="completed">
				<a href="<?php echo esc_url( add_query_arg( 'order_status', 'completed', $url_base ) ); ?>" class="<?php if ( 'completed' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( _n( 'Completed <span class="count">(%s)</span>', 'Completed <span class="count">(%s)</span>', $this->iap_purchases_counts['completed'], 'buddyboss-app' ), number_format_i18n( $this->iap_purchases_counts['completed'] ) ); ?>
				</a> |
			</li>
			<li class="pending">
				<a href="<?php echo esc_url( add_query_arg( 'order_status', 'pending', $url_base ) ); ?>" class="<?php if ( 'pending' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( _n( 'Pending <span class="count">(%s)</span>', 'Pending <span class="count">(%s)</span>', $this->iap_purchases_counts['pending'], 'buddyboss-app' ), number_format_i18n( $this->iap_purchases_counts['pending'] ) ); ?>
				</a> |
			</li>
			<li class="cancelled">
				<a href="<?php echo esc_url( add_query_arg( 'order_status', 'cancelled', $url_base ) ); ?>" class="<?php if ( 'cancelled' == $this->view ) {
					echo 'current';
				} ?>">
					<?php printf( _n( 'Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>', $this->iap_purchases_counts['cancelled'], 'buddyboss-app' ), number_format_i18n( $this->iap_purchases_counts['cancelled'] ) ); ?>
				</a>
			</li>
		</ul>
		<?php
	}


	/**
	 * @param $item
	 *
	 * @return string
	 */
	public function column_id( $item ) {

		$actions = array(
			'view' => sprintf( '<span class="view"><a href="admin.php?page=%s&action=view_order&order_id=%s">View</a></span>', $_REQUEST['page'], $item['id'] ),
		);

		if ( in_array( $item['order_status'], array(
				'subscribed',
				'completed'
			) ) && current_user_can( "manage_options" ) ) {


			$base_url     = bbapp_get_admin_url( 'admin.php?page=' . esc_attr( $_REQUEST['page'] ) . '&amp;iap_purchases_ids=' . $item['id'] );
			$complete_url = wp_nonce_url( $base_url . '&amp;action=revoke_order', 'cc_revoke_iap_purchases' );


			//$completeUrl = wp_nonce_url( admin_url( 'admin.php?page=' . $_REQUEST['page'] . '&order_id=' . $item['id'] ), 'iap_cancel_order_' . $item['id'], 'iap-order-cancel' );
			$actions['cancel'] = sprintf( '<span class="trash"><a href="%s">Revoke</a></span>', $complete_url );
		}
		$test_mode_label = '';

		if ( true === (bool) Orders::instance()->get_meta( $item["id"], '_transaction_data_test_mode' ) ) {
			$test_mode_label = __( ' (Test App)' );
		}

		return sprintf( '%1$s %2$s', '<a class="row-title" href="admin.php?page=' . $_REQUEST['page'] . '&action=view_order&order_id=' . $item["id"] . '"> #' . $item["id"] . $test_mode_label, $this->row_actions( $actions ) );
	}

	/**
	 * Added filter here.
	 *
	 * @param string $which
	 */
	protected function extra_tablenav( $which ) {
		global $wpdb;
		$tableName = \bbapp_iap()->get_global_dbprefix() . "bbapp_iap_products";
		if ( 'top' === $which ) {
			$iap_product = $this->bbapp_requested_purchased_product_id();
			$results     = $wpdb->get_results( "SELECT id, name FROM {$tableName} WHERE status IN ('published') ORDER BY menu_order, date_created DESC", ARRAY_A );
			if ( $results ) {
				?>
				<div class="alignleft actions">
					<label class="screen-reader-text" for="filter-by-iap-products"><?php echo esc_html__( 'All Products', 'buddyboss-app' ); ?></label>
					<select name="iap_product_id" id="filter-by-iap-products" class="bbap-filter-product">
						<option value=""><?php echo esc_html__( 'All Products', 'buddyboss-app' ); ?></option>
						<?php
						foreach ( $results as $result ) {
							?>
							<option value="<?php echo esc_attr( $result['id'] ); ?>" <?php echo selected( (int) $iap_product, (int) $result['id'], false ); ?>><?php echo esc_html( $result['name'] ); ?></option>
							<?php
						}
						?>
					</select>
					<input type="button" name="iap_filter_action" id="iap_filter_action" class="button action" value="<?php esc_html_e( 'Filter', 'buddyboss-app' ); ?>"/>
				</div>
				<?php
			}
		}
	}

	/**
	 * Return product id from the request.
	 *
	 * @return mixed|string
	 */
	public function bbapp_requested_purchased_product_id() {
		$iap_product = isset( $_REQUEST['iap_product_id'] ) ? $_REQUEST['iap_product_id'] : '';
		return $iap_product;
	}

	/**
	 * Add filter parameter as query args in existing url after change filter dropdown
	 *
	 * @param string $url
	 *
	 * @param int    $iap_product
	 *
	 * @return string $url
	 */
	public function bbapp_add_query_args_as_product_filter( $url, $iap_product ) {
		$url = add_query_arg( 'iap_product_id', $iap_product, $url );
		return $url;
	}

}