<?php
namespace BuddyBossApp\Admin\ImportExport;

use BuddyBossApp\Admin\ImportExport;
use BuddyBossApp\Helpers\BBAPP_File;

class Images {

    private static $instance;
    private $module_name;

    /**
     * Get the instance of the class.
     *
     * @return Images
     */
    public static function instance() {
        if (!isset(self::$instance)) {
            $class = __CLASS__;
            self::$instance = new $class;
            self::$instance->_load();
        }

        return self::$instance;
    }

	/**
	 * Branding constructor.
	 */
    public function __construct() {
        //Using Singleton, see instance()
    }

	/**
	 *
	 */
    public function _load() {
        $this->module_name = "images";

        // Register The Module
        ImportExport::instance()->module_register($this->module_name, __("Images","buddyboss-app"));

        // Register the hooks for import and export data.
        ImportExport::instance()->hook_register($this->module_name,
            array($this, "import"),
            array($this, "export")
        );
    }

	/**
	 * Import data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
    public function import($data) {

        if(isset($data["data"]["branding"])) {

            if(!is_array($data["data"]["branding"])) {
                $data["data"]["branding"] = array();
            }

	        \BuddyBossApp\Branding::instance()->set_options( $data["data"]["branding"] );
        }

        $branding_dir = \BuddyBossApp\Branding::instance()->get_branding_upload_dir();

        // Copy the branding files.

        // Clear fonts directory first.
        BBAPP_File::DeleteDir($branding_dir);
        BBAPP_File::CreateDir($branding_dir);

        foreach($data["assets"] as $file_name => $file_path) {
            $copy_to_file_path = trailingslashit($branding_dir).$file_name;
            BBAPP_File::CopyFile($file_path,$copy_to_file_path);
        }

        return $data;
    }

	/**
	 * Export data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
    public function export($data) {

        $branding_settings = \BuddyBossApp\Branding::instance()->get_options();

        $data["data"]["branding"] = $branding_settings;

        $branding_dir = \BuddyBossApp\Branding::instance()->get_branding_upload_dir();

        /**
         * Export Files.
         */
        $objects = scandir($branding_dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                $data["assets"][$object] = trailingslashit($branding_dir)."/$object";
            }
        }

        return $data;
    }
}
