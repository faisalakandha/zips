<?php
namespace BuddyBossApp\Admin\ImportExport;

use BuddyBossApp\Admin\ImportExport;

class Colors {

	private static $instance;
    private $module_name;

	/**
	 * Get the instance of the class.
	 *
	 * @return Colors
	 */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 *
	 */
	public function _load() {
        $this->module_name = "colors";

        // Register The Module
        ImportExport::instance()->module_register($this->module_name, __("Colors","buddyboss-app"));

        // Register the hooks for import and export data.
	    ImportExport::instance()->hook_register($this->module_name,
            array($this, "import"),
            array($this, "export")
            );
	}

	/**
	 * Import data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
    public function import($data) {
        if (isset($data["data"]["styling"]) && is_array($data["data"]["styling"])) {
            \BuddyBossApp\Styling::instance()->set_options($data["data"]["styling"]);
        }
        return $data;
    }

	/**
	 * Export data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
    public function export($data) {
        $styling = \BuddyBossApp\Styling::instance()->get_options();
        $data["data"]["styling"] = $styling;
        return $data;
    }
}
