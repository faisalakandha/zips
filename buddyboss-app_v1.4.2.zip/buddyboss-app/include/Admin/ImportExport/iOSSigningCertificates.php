<?php

namespace BuddyBossApp\Admin\ImportExport;

use BuddyBossApp\Admin\ImportExport;
use BuddyBossApp\Helpers\BBAPP_File;

class iOSSigningCertificates {

	private static $instance;
	private $module_name;

	/**
	 * Get the instance of the class.
	 *
	 * @return iOSSigningCertificates
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 *
	 */
	public function _load() {
		$this->module_name = "ios_signing_certificates";

		// Register The Module
		ImportExport::instance()->module_register( $this->module_name, __( "iOS Signing Certificates", "buddyboss-app" ) );

		// Register the hooks for import and export data.
		ImportExport::instance()->hook_register( $this->module_name,
			array( $this, "import" ),
			array( $this, "export" )
		);
	}

	/**
	 * Import data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function import( $data ) {

		if ( isset( $data["data"][$this->module_name] ) ) {
			$uploaded_file_dir = ImportExport::instance()->get_bbapp_upload_dir();
			if ( ! is_array( $data["data"][$this->module_name] ) ) {
				$data["data"][$this->module_name] = array();
			}

			$global_settings = \BuddyBossApp\Admin\Settings::instance()->get_settings();
			foreach ( $data["data"][$this->module_name] as $key => $setting ) {
				$global_settings[ $key ] = ( 'publish.ios.signing_certificates_automatic' === $key ) ? '' : $setting;
			}
			\BuddyBossApp\Admin\Settings::instance()->save_global_settings( $global_settings );

			// Clear fonts directory first.
			BBAPP_File::CreateDir( $uploaded_file_dir );

			// Copy the files.
			foreach ( $data["assets"] as $file_name => $file_path ) {
				$copy_to_file_path = trailingslashit( $uploaded_file_dir ) . $file_name;
				BBAPP_File::CopyFile( $file_path, $copy_to_file_path );
			}
		}

		return apply_filters( 'bbapp_import_ios_signing_certificates', $data );

	}

	/**
	 * Export data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function export( $data ) {

		$data["assets"]      = array();
		$exportable_settings = ImportExport::instance()->get_exportable_settings( $this->module_name );
		$uploaded_file_dir   = ImportExport::instance()->get_bbapp_upload_dir();

		foreach ( $exportable_settings as $exportable_setting ) {
			if ( ! empty( $exportable_setting ) ) {
				$file_name = str_replace( "/bbapp/uploads/", "", $exportable_setting );
				$file_path = trailingslashit( $uploaded_file_dir ) . $file_name;
				if ( file_exists( $file_path ) ) {
					$data["assets"][ $file_name ] = $file_path;
				}
			}
		}
		$data["data"][$this->module_name] = $exportable_settings;

		return $data;
	}

}
