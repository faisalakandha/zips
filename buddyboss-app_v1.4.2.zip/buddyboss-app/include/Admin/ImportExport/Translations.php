<?php
namespace BuddyBossApp\Admin\ImportExport;

use BuddyBossApp\Admin\ImportExport;

class Translations {

	private static $instance;
    private $module_name;

	/**
	 * Get the instance of the class.
	 *
	 * @return Translations
	 */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 *
	 */
	public function _load() {
        $this->module_name = "translations";

        // Register The Module
        ImportExport::instance()->module_register($this->module_name, __("Translations","buddyboss-app"));

        // Register the hooks for import and export data.
	    ImportExport::instance()->hook_register($this->module_name,
            array($this, "import"),
            array($this, "export")
            );
	}

	/**
	 * Import data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function import($data) {
        if(isset($data["data"]["languages"])) {
           $languages = maybe_unserialize($data["data"]["languages"]);
           if(is_array($languages)) {
               \BuddyBossApp\AppLanguages::instance()->update_languages($languages);
           }
        }
	    return $data;
    }

	/**
	 * Export data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
    public function export($data) {
        $Languages = \BuddyBossApp\AppLanguages::instance()->get_languages();
        $data["data"]["languages"] = $Languages;
        return $data;
    }
}
