<?php
namespace BuddyBossApp\Admin\ImportExport;

use BuddyBossApp\Admin\ImportExport;

class TabBar {

	private static $instance;
    private $module_name;

	/**
	 * Get the instance of the class.
	 *
	 * @return TabBar
	 */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 *
	 */
	public function _load() {
        $this->module_name = "tabbar";

        // Register The Module
        ImportExport::instance()->module_register($this->module_name, __("Tab Bar","buddyboss-app"));

        // Register the hooks for import and export data.
	    ImportExport::instance()->hook_register($this->module_name,
            array($this, "import"),
            array($this, "export")
            );
	}

	/**
	 * Import data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function import($data) {
		if ( isset( $data["data"]["menus"] ) || isset( $data["data"]["app_menus"] ) ) {
			$app_settings = \BuddyBossApp\ManageApp::instance()->get_app_settings();
			if ( isset( $data["data"]["app_menus"] ) ) {
				$data["data"]["app_menus"]['tab_bar_icon_style'] = empty( $data["data"]["app_menus"]['tab_bar_icon_style'] ) ? 'outlined' : $data["data"]["app_menus"]['tab_bar_icon_style'];
				$data["data"]["app_menus"]['more_icon_style']    = empty( $data["data"]["app_menus"]['more_icon_style'] ) ? 'outlined' : $data["data"]["app_menus"]['more_icon_style'];
				$data["data"]["app_menus"]['tab_bar_visibility'] = empty( $data["data"]["app_menus"]['tab_bar_visibility'] ) ? 'show_on_tab_bar_menu' : $data["data"]["app_menus"]['tab_bar_visibility'];
				$app_settings['app_menu.tab_bar_icon_style'] = $data["data"]["app_menus"]['tab_bar_icon_style'];
				$app_settings['app_menu.more_icon_style']    = $data["data"]["app_menus"]['more_icon_style'];
				$app_settings['app_menu.tab_bar_visibility'] = $data["data"]["app_menus"]['tab_bar_visibility'];
				\BuddyBossApp\ManageApp::instance()->update_app_settings( $app_settings );
			}
			if ( isset( $data["data"]["menus"] ) ) {
				if ( empty( $data["data"]["menus"] ) ) {
					$data["data"]["menus"] = array(); // import empty.
				}
				$bbapp_menus = $data["data"]["menus"];
				update_option( 'bbapp_menus', $bbapp_menus );
			}

		}

        return $data;
    }

	/**
	 * Export data function.
	 *
	 * @param $data
	 *
	 * @return array
	 */
	public function export( $data ) {

		$app_settings = \BuddyBossApp\ManageApp::instance()->get_app_settings();

		$bbapp_settings = isset( $app_settings ) ? $app_settings : false;
		if ( false !== $bbapp_settings ) {
			$data["data"]['app_menus'] = array(
				'tab_bar_icon_style' => ! empty( $bbapp_settings['app_menu.tab_bar_icon_style'] ) ? $bbapp_settings['app_menu.tab_bar_icon_style'] : 'outlined',
				'more_icon_style'    => ! empty( $bbapp_settings['app_menu.more_icon_style'] ) ? $bbapp_settings['app_menu.more_icon_style'] : 'outlined',
				'tab_bar_visibility' => ! empty( $bbapp_settings['app_menu.tab_bar_visibility'] ) ? $bbapp_settings['app_menu.tab_bar_visibility'] : 'show_on_tab_bar_menu'
			);
		}
		$bbapp_menus   = get_option( 'bbapp_menus' );
		$menu_settings = isset( $bbapp_menus ) ? $bbapp_menus : false;

		$data["data"]["menus"] = $menu_settings;
		return $data;
	}



}
