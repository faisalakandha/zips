<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\Logger;
use BuddyBossApp\Permissions;

class Debug
{

    private static $instance;
    var $_messages;
    private $settings_form;

    /**
     * Get the instance of the class.
     *
     * @return Debug
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class = __CLASS__;
            self::$instance = new $class;
            self::$instance->_load();
        }

        return self::$instance;
    }

    public function __construct()
    {

    }

    public function _load()
    {
        // load the active plugin information as early as possible.
        if(is_admin() && isset($_GET["page"]) && $_GET["page"] == "bbapp-tools") {
            /**
             * Avoid option_active_plugins to get altered by 3rd party plugins.
             */
            add_filter("option_active_plugins", array($this,"option_active_plugins"),-1);
            add_filter("option_active_plugins", array($this,"option_active_plugins"),9999);
            add_filter("site_option_active_sitewide_plugins", array($this,"option_active_plugins"),9999);
            add_filter("site_option_active_sitewide_plugins", array($this,"option_active_plugins"),9999);

            $this->settings_form = new FormProvider('settings');

            // holds global settings storage handle.
            $app_settings_provider = new SettingProvider('app_settings');

            // register app settings storing & receiving
            $app_settings_provider->save_setting_hook(array(Settings::instance(), 'save_settings'));
            $app_settings_provider->get_setting_hook(array(Settings::instance(), 'get_settings'));
            $this->settings_form->link_setting_provider($app_settings_provider);

            // Logs Settings
            if (isset($_GET["setting"]) && $_GET["setting"] == "log") {

                $this->settings_form->add_field($app_settings_provider->field(false, array(
                    'type' => 'table-open',
                    'classes' => 'buddyboss-app-admin-card',
                )));

                $this->settings_form->add_field($app_settings_provider->field('logger_heading', array(
                    'type' => 'heading',
                    'value' => __('Log Settings', 'buddyboss-app'),
                    'desc' => "",
                )));

                $this->settings_form->add_field($app_settings_provider->field('logger.info_log.enabled', array(
                    'label' => __('General Logs', 'buddyboss-app'),
                    'label_checkbox' => __('Enable General Logs', 'buddyboss-app'),
                    'desc' => __('For development and de-bugging of general actions.', 'buddyboss-app'),
                    'type' => 'checkbox',
                    'value' => true,
                )));

                $this->settings_form->add_field($app_settings_provider->field('logger.api_log.enabled', array(
                    'label' => __('API Logs', 'buddyboss-app'),
                    'label_checkbox' => __('Enable API Logs', 'buddyboss-app'),
                    'desc' => __('For development and de-bugging of recent API requests.', 'buddyboss-app'),
                    'type' => 'checkbox',
                    'value' => true,
                )));

	            if ( bbapp_is_active( 'iap' ) ) {
		            $this->settings_form->add_field( $app_settings_provider->field( 'logger.iap_log.enabled', array(
			            'label'          => __( 'IAP Logs', 'buddyboss-app' ),
			            'label_checkbox' => __( 'Enable In-App Purchase Logs', 'buddyboss-app' ),
			            'desc'           => __( 'For development and de-bugging of recent IAP actions.', 'buddyboss-app' ),
			            'type'           => 'checkbox',
			            'value'          => true,
		            ) ) );
	            }

            }

            add_action("admin_init", array($this->settings_form, "save"));

        }
	    add_action( 'admin_init', array( $this, 'process_clear_log_button' ) );
	    add_action( 'admin_init', array( $this, 'process_debug_tool_submit' ) );
    }

	/**
     * Handles The Clear Log action button.
	 * @return false
	 */
	public function process_clear_log_button() {

    	if (!Permissions::instance()->can_manage_app(get_current_user_id())) {
			return false;
		}

		/**
		 * Only load on bbapp-tools page.
		 */
		if ( SetupAdmin::instance()->get_page_now() != "admin.php" || $_GET['page'] != 'bbapp-tools' ) {
			return false;
		}

		/**
		 * Permission check.
		 */
		if ( ! Permissions::instance()->can_manage_app() ) {
			wp_die( "You don't have permission to access this page.", "buddyboss-app" );
		}

		if ( ! isset( $_GET['do_action'] ) ) {
			return;
		}

		if ( ! check_admin_referer( 'bbapp-log-clear' ) ) {
			$this->_messages[] = array( 'type' => 'error', 'message' => __( 'Something unexpected happened. Please try again later.', 'buddyboss-app' ) );
		}

		/**
		 * Clear logs.
		 */
		if ( isset( $_GET["do_action"] ) && $_GET["do_action"] == "clear_log" && check_admin_referer( 'bbapp-log-clear' ) ) {
			// delete code.
			$supported_types   = Logger::get_logger_types();
			$supported_types   = array_keys( $supported_types );
			$supported_types   = array_filter( $supported_types );
			$log_type             = ( ! empty( $_GET['log_filter'] ) && in_array( $_GET['log_filter'], $supported_types ) ) ? $_GET['log_filter'] : '';
			Logger\Helpers::clear_logs( $log_type );
			$this->_messages[] = array( 'type' => 'updated', 'message' => __( 'Log cleared successfully!', "buddyboss-app" ) );
		}

	}

    /**
     * We are preserving the original db values on which are returned on most first time.
     * @param $plugins
     * @return mixed
     */
    public function option_active_plugins($plugins)
    {
        static $cache_plugins;

        // avoid infinite loop.
        if(isset($cache_plugins) && isset($cache_plugins[current_action()])) {
            return $cache_plugins[current_action()];
        }

        $cache_plugins[current_action()] = $plugins;

        return $plugins;
    }

    /**
     * Return the sub settings.
     *
     * @return array
     */
    public function sub_settings()
    {

	    $tabs = array(
		    'import'            => __( 'Import', 'buddyboss-app' ),
		    'export'            => __( 'Export', 'buddyboss-app' ),
		    'info'              => __( 'Site Health', 'buddyboss-app' ),
		    'debug'             => __( 'Transients', 'buddyboss-app' ),
		    'log'               => __( 'Logs', 'buddyboss-app' ),
		    'generate-keystore' => __( 'Generate KeyStore', 'buddyboss-app' ),
	    );

        return $tabs;
    }

    /**
     * Return the current setting page from active screen.
     *
     * @return string
     */
    public function get_current_sub_tab()
    {

        $default = 'import';
        $setting = (isset($_GET['setting'])) ? $_GET['setting'] : $default;
        $sub_settings = $this->sub_settings();

        if (isset($sub_settings[$setting])) {
            return $setting;
        }

        return $default;
    }

	/**
	 * @param string $default
	 *
	 * @return string
	 */
    public function get_current_view( $default = 'logs' )
    {
        return (isset($_GET["view"])) ? $_GET["view"] : $default;
    }

    /**
     * Return Current tabs for logs.
     */
    public function get_logs_tabs() {
        $tabs = array(
                "logs"=>__("Logs","buddyboss-app"),
                "settings" => __("Log Settings","buddyboss-app")
        );
        $current_view = $this->get_current_view();
        ?>
        <h2 class="nav-tab-wrapper">
            <?php foreach ($tabs as $k => $v): ?>
                <a href="<?php echo bbapp_get_super_admin_url("admin.php?page=bbapp-tools&setting=log&view=".$k); ?>" class="nav-tab <?php echo ($current_view==$k)?"nav-tab-active":""; ?>">
                    <?php echo esc_html($v); ?>
                </a>
            <?php endforeach; ?>
        </h2>
        <?php
    }

    /**
     * Renders the setting screen.
     */
    public function render_screen()
    {

        if (!Permissions::instance()->can_manage_app(get_current_user_id())) {
            echo '<p>' . __("You don't have permission to access this page.", "buddyboss-app") . '</p>';
            return false;
        }

        \BuddyBossApp\Admin\SetupAdmin::instance()->render_subtabs($this->sub_settings(),$this->get_current_sub_tab());

	    if ( $this->get_current_sub_tab() == "log" ) {
		    $this->get_logs_tabs();
		    if ( $this->get_current_view() == "settings" ) {
			    $this->settings_form->render_form();
		    } else {
			    include bbapp()->plugin_dir . 'views/settings/log.php';
		    }
	    } else if ( $this->get_current_sub_tab() == "info" ) {
		    include bbapp()->plugin_dir . 'views/settings/site-health-info.php';
	    } else if ( $this->get_current_sub_tab() == "import" ) {
		    include bbapp()->plugin_dir . 'views/settings/import-export.php';
	    } else if ( $this->get_current_sub_tab() == "export" ) {
		    include bbapp()->plugin_dir . 'views/settings/import-export.php';
	    } else if ( $this->get_current_sub_tab() == "generate-keystore" ) {
		    include bbapp()->plugin_dir . 'views/settings/generate-keystore.php';
	    } else {
		    include bbapp()->plugin_dir . 'views/settings/debug.php';
	    }
    }

    /**
     * Show the errors & updates
     */
    public function show_messages()
    {

        if (isset($_GET['success'])) {
            $this->_messages[] = array('type' => 'updated', 'message' => __('Settings saved.', 'buddyboss-app'));
        }

        if (!empty($this->_messages)) {
            foreach ($this->_messages as $message) {
                echo "<div id='message' class='{$message['type']}'><p>{$message['message']}</p></div>";
            }
        }
    }

    /**
     * Handles The Debug Process Submit
     */
    public function process_debug_tool_submit()
    {

        if (!Permissions::instance()->can_manage_app(get_current_user_id())) {
            return false;
        }

        if (!isset($_POST['bbapp_update_settings_debug_tools'])) {
            return;
        }

        if (!check_admin_referer('bbapp_update_settings_debug_tools', 'bbapp_update_settings_debug_tools')) {
            $this->_messages[] = array('type' => 'error', 'message' => __('Something unexpected happened. Please try again later.', 'buddyboss-app'));
        }

        /**
         * Clear Transients
         */
        if (isset($_POST["clear_transients"])) {

	        $delete_transients = array(
		        "_bbapp_app_signed_details",
		        "_bbapp_get_app_info",
		        "bbapp_preview_members",
		        "bbapp_preview_forums",
		        "bbapp_preview_single_lesson",
		        "bbapp_preview_topics",
		        "bbapp_preview_single_profile",
		        "bbapp_preview_registration",
		        "bbapp_preview_profile_tabs",
		        "_bbapp_fetch_last_versions",
		        "bbapp_last_build_status_interval_check",
		        "bbapp_is_under_maintenance",
		        "bbapp_apple_get_local_devices",
		        "bbapp_apple_client_apps_bundle_ids",
		        "bbapp_apple_client_apps",
		        "bbapp_apple_client_users",
		        "bbapp_apple_team_info",
		        "bbapp_get_app_core",
                "bbapp_apple_team_info",
		        "bbapp_google_app_details",
		        "bbapp_google_release_data",
		        "bbapp_google_all_production_release_data",
		        "bbapp_appcenter_settings",
		        "bbapp_publisher_email_address",
		        "_bbapp_deeplink_wp_url_data",
		        "_bbapp_deeplink_bp_url_data",
		        "bbapp_cron_job_health_flag",
		        "bbapp_healthcheck_user_token",
		        "_bbapp_google_typography_fonts",
	        );

            foreach ($delete_transients as $tr) {
                delete_transient($tr);
                delete_site_transient($tr);
            }

	        \BuddyBossApp\Build::instance()->clear_all_build_transients();
	        \BuddyBossApp\Admin\Publish\Publish::instance()->delete_all_publish_transients();

            $this->clear_all_transients();

            $this->_messages[] = array('type' => 'updated', 'message' => __('Transients are cleared!', "buddyboss-app"));
        }

        /**
         * Clear Duplicates Devices Tokens
         */
        if (isset($_POST["clear_duplicates_device_tokens"])) {

            bbapp_table_fix_remove_dublicates_device_tokens();

            $this->_messages[] = array('type' => 'updated', 'message' => __('Duplicate entries cleared.', 'buddyboss-app'));

        }

	    /**
	     * Clear all Devices Tokens
	     */
	    if (isset($_POST["clear_all_device_tokens"])) {

		    bbapp_table_remove_all_device_tokens();

		    $this->_messages[] = array('type' => 'updated', 'message' => __('All entries cleared!', 'buddyboss-app'));

	    }

    }

    public function let_to_num($size)
    {
        $l = substr($size, -1);
        $ret = substr($size, 0, -1);
        switch (strtoupper($l)) {
            case 'P':
                $ret *= 1024;
            case 'T':
                $ret *= 1024;
            case 'G':
                $ret *= 1024;
            case 'M':
                $ret *= 1024;
            case 'K':
                $ret *= 1024;
        }

        return $ret;
    }

    public function get_environment_info()
    {
        global $wpdb;

        // Figure out cURL version, if installed.
        $curl_version = '';
        if (function_exists('curl_version')) {
            $curl_version = curl_version();
            $curl_version = $curl_version['version'] . ', '
                . $curl_version['ssl_version'];
        }

        // WP memory limit
        $wp_memory_limit = $this->let_to_num(WP_MEMORY_LIMIT);
        if (function_exists('memory_get_usage')) {
            $wp_memory_limit = max($wp_memory_limit,
                $this->let_to_num(@ini_get('memory_limit')));
        }

        // Return all environment info. Described by JSON Schema.
        return array(
            'home_url' => get_option('home'),
            'site_url' => get_option('siteurl'),
            'wp_version' => get_bloginfo('version'),
            'wp_multisite' => is_multisite(),
            'wp_memory_limit' => $wp_memory_limit,
            'wp_debug_mode' => (defined('WP_DEBUG')
                && WP_DEBUG),
            'wp_cron' => !(defined('DISABLE_WP_CRON')
                && DISABLE_WP_CRON),
            'language' => get_locale(),
            'server_info' => $_SERVER['SERVER_SOFTWARE'],
            'php_version' => phpversion(),
            'php_post_max_size' => $this->let_to_num(ini_get('post_max_size')),
            'php_max_execution_time' => ini_get('max_execution_time'),
            'php_max_input_vars' => ini_get('max_input_vars'),
            'curl_version' => $curl_version,
            'max_upload_size' => wp_max_upload_size(),
            'mysql_version' => (!empty($wpdb->is_mysql)
                ? $wpdb->db_version() : ''),
            'default_timezone' => date_default_timezone_get(),
            'fsockopen_or_curl_enabled' => (function_exists('fsockopen')
                || function_exists('curl_init')),
            'domdocument_enabled' => class_exists('DOMDocument'),
            'gzip_enabled' => is_callable('gzopen'),
            'mbstring_enabled' => extension_loaded('mbstring')
        );
    }

    public function get_active_plugins()
    {
        static $cache_active_plugins;

        if(isset($cache_active_plugins)) {
            return $cache_active_plugins;
        }

        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/update.php';

        if (!function_exists('get_plugin_updates')) {
            return array();
        }

        $active_plugins = (array) get_option( 'active_plugins', array() );
        if ( is_multisite() ) {
            $network_activated_plugins = array_keys( get_site_option( 'active_sitewide_plugins', array() ) );
            $active_plugins            = array_merge( $active_plugins, $network_activated_plugins );
        }

        $active_plugins = array_unique($active_plugins);

        $active_plugins_data = array();

        foreach ($active_plugins as $plugin) {

            $data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);

            // convert plugin data to json response format.
            $active_plugins_data[] = array(
                'plugin' => $plugin,
                'name' => $data['Name'],
                'version' => $data['Version'],
                'url' => $data['PluginURI'],
                'author_name' => $data['AuthorName'],
                'author_url' => esc_url_raw($data['AuthorURI']),
                'network_activated' => $data['Network'],
            );
        }

        $cache_active_plugins = $active_plugins_data;

        return $active_plugins_data;
    }

    public function help_tip($tip)
    {
        return '<span class="dashicons dashicons-editor-help abtip" title="'
            . esc_attr($tip) . '"></span>';
    }

    public function return_bytes($val)
    {
        $val = trim($val);
        $last = strtolower($val[strlen($val) - 1]);
        switch ($last) {
            // The 'G' modifier is available since PHP 5.1.0
            case 'g':
                $val *= 1024;
            case 'm':
                $val *= 1024;
            case 'k':
                $val *= 1024;
        }

        return $val;
    }

    public function phpinfo_array($mode = -1)
    {
        ob_start();
        phpinfo($mode);
        $s = ob_get_contents();
        ob_end_clean();
        $a = $mtc = array();
        if (preg_match_all('/<tr><td class="e">(.*?)<\/td><td class="v">(.*?)<\/td>(:?<td class="v">(.*?)<\/td>)?<\/tr>/',
            $s, $mtc, PREG_SET_ORDER)
        ) {
            foreach ($mtc as $v) {
                if ($v[2] == '<i>no value</i>') {
                    continue;
                }

                $master = '';
                if (isset($v[3])) {
                    $master = strip_tags($v[3]);
                }
                $a[$v[1]] = array($v[2], $master);
            }
        }

        return $a;
    }

	/**
	 * Function will clear all transients from DB.
	 */
    public function clear_all_transients() {
	    $option_name_arr = array(
		    '_buddyboss_app_ld_course_enrolled_users_',
		    '_transient_bbapp-',
		    '_get_build_status_cache_',
		    '_bbapp_segment_data_',
		    'bbapp_vimeo_vid_cache',
		    'bbapp_apple_app_fetched_data_',
	    );
	    bbapp_delete_transients( $option_name_arr );
    }
}
