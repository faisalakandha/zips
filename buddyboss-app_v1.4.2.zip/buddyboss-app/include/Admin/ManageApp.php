<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\AppStores\Android;
use BuddyBossApp\Helpers\BBAPP_File;

class ManageApp {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return ManageApp
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	public function _load() {

		$this->hooks(); // wordpress hooks.

		if ( $this->get_current_sub_tab() == 'manage' ) {

		}
	}

	public function hooks() {
		$this->ajax_hooks( 'bbapp_app_connection', array( $this, 'ajax_manage_app' ) );
		$this->ajax_hooks( 'bbapp_site_disconnect', array( $this, 'ajax_site_disconnect' ) );
		$this->ajax_hooks( 'bbapp_secondary_site_cancel', array( $this, 'ajax_secondary_site_cancel' ) );
		$this->ajax_hooks( 'bpapp_download_keystore', array( $this, 'bpapp_download_keystore' ) );
		$this->ajax_hooks( 'bbapp_validate_namespace', array( $this, 'bbapp_validate_namespace' ) );
		$this->ajax_hooks( 'bbapp_validate_google_permissions', array( $this, 'bbapp_validate_google_permissions' ) );

		// Run once a day to clear expire device tokens.
		add_action( 'bbapp_every_10min', array( $this, 'verify_apps' ) );
		add_action("admin_init", array($this, "load_init"));
	}
	public function load_init() {

		if ( SetupAdmin::instance()->get_page_now() == "admin.php" && isset( $_GET['page'] ) && 'bbapp-tools' === $_GET['page'] ) {
			if ( isset( $_GET['setting'] ) && 'generate-keystore' === $_GET['setting'] ) {
				if ( isset( $_GET['success'] ) && true === (bool) $_GET['success'] ) {
					$this->keystore_file_delete();
				}
			}
		}
	}

	/**
	 * Function to check the permission;
	 */
	public function bbapp_validate_google_permissions() {
		$result            = array();
		$result['message'] = __( 'Something went wrong please try again later.', 'buddyboss-app' );

		$validate = \BuddyBossApp\AppStores\Services\Android\AndroidPublisher::instance()->operation_permission();

		if ( true === $validate ) {
			$result['message'] = __( 'All checks passed.', 'buddyboss-app' );
			wp_send_json_success( $result );
		} else {
			$result['message'] = __( 'The service account key provided does not have all the required permissions. Please resolve in your Google Developer account', 'buddyboss-app' );
			wp_send_json_error( $result );
		}
	}

	/**
	 *
	 */
	public function keystore_file_delete() {
		$upload          = wp_upload_dir();
		$keystore_dir    = $upload['basedir'] . '/bbapp/keystore/';
		$export_zip_path = trailingslashit( $keystore_dir ) . 'buddyboss-app-keystore.zip';
		if ( file_exists( $export_zip_path ) ) {
			wp_delete_file( $export_zip_path );
		}
	}

	/**
	 * Download key store record.
	 */
	public function bpapp_download_keystore() {
		$result              = [];
		$result['message']   = esc_html__( 'Something went wrong. Please try again later.', 'buddyboss-app' );
		$nonce               = filter_input( INPUT_POST, 'keystore_nonce', FILTER_SANITIZE_STRING );
		$password            = filter_input( INPUT_POST, 'password', FILTER_SANITIZE_STRING );
		$alias               = filter_input( INPUT_POST, 'alias', FILTER_SANITIZE_STRING );
		$fl_name             = filter_input( INPUT_POST, 'fl_name', FILTER_SANITIZE_STRING );
		$organization        = filter_input( INPUT_POST, 'organization', FILTER_SANITIZE_STRING );
		$organization_unit   = filter_input( INPUT_POST, 'organization_unit', FILTER_SANITIZE_STRING );
		$city                = filter_input( INPUT_POST, 'city', FILTER_SANITIZE_STRING );
		$state               = filter_input( INPUT_POST, 'state', FILTER_SANITIZE_STRING );
		$country_code        = filter_input( INPUT_POST, 'country_code', FILTER_SANITIZE_STRING );

		$error_message = __('There was an error generating your KeyStore certificate:','buddyboss-app') . '<br/>';
		$is_error      = false;
		if ( ! wp_verify_nonce( $nonce, 'bbapp_generate_keystore' ) ) {
			$error_message .= __( '- Security nonce verification failed. Please retry after refreshing your page.', 'buddyboss-app' ) . '<br/>';
			$is_error      = true;
		}
		if ( empty( $nonce ) ) {
			$error_message .= __( '- Nonce is not exists.', 'buddyboss-app' ) . '<br/>';
			$is_error      = true;
		}
		if ( empty( $password ) ) {
			$error_message .= __( '- KeyStore Password is required to generate KeyStore.', 'buddyboss-app' ) . '<br/>';
			$is_error      = true;
		}
		if ( empty( $alias ) ) {
			$error_message .= __( '- KeyStore Alias is required to generate KeyStore.', 'buddyboss-app' ) . '<br/>';
			$is_error      = true;
		}

		if ( empty( $fl_name ) ) {
			$error_message .= __( '- First and Last name is required to generate KeyStore.', 'buddyboss-app' ) . '<br/>';
			$is_error      = true;
		}

		if ( true === $is_error ) {
			$result['message'] = sprintf( '<div class="bbapp-notice-box bbapp-notice-box--error">%s</div>', $error_message );
			wp_send_json_error( $result );
		}

		$body_params = array(
			'password'           => $password,
			'storepass'          => $password,
			'alias_name'         => sanitize_title_with_dashes( $alias ),
			'firstname_lastname' => $fl_name,
		);

		if ( ! empty( $organization_unit ) ) {
			$body_params['organization_unit'] = $organization_unit;
		}

		if ( ! empty( $organization ) ) {
			$body_params['organization_name'] = $organization;
		}

		if ( ! empty( $city ) ) {
			$body_params['locality'] = $city;
		}

		if ( ! empty( $state ) ) {
			$body_params['local_state'] = $state;
		}

		if ( ! empty( $country ) ) {
			$body_params['country'] = $country;
		}

		if ( ! empty( $country_code ) ) {
			$body_params['country_code'] = $country_code;
		}

		$app = \BuddyBossApp\ManageApp::instance()->get_app();

		$do_request = bbapp_remote_post(
			'https://bbapp-cert-services.buddyboss.com/api/keystore',
			array(
				'method'  => 'POST',
				'timeout' => 45,
				'body'    => $body_params,
				'headers'  => array(
					'bbapp_id' => empty( $app ) ? false : $app['bbapp_app_id'],
					'bbapp_key' => \BuddyBossApp\ManageApp::instance()->get_auth_app_key()
				),
			)
		);

		if ( is_wp_error( $do_request ) || empty( $do_request ) ) {
			$error_message .= esc_html__( "- Something went wrong. Please try again later.", 'buddyboss-app' );
			$result['message'] = sprintf( '<div class="bbapp-notice-box bbapp-notice-box--error">%s</div>', $error_message );
			wp_send_json_error( $result );
		}

		$body     = wp_remote_retrieve_body( $do_request );
		$p12_file = $body;
		$body     = json_decode( $body, true );

		if ( isset( $body['status'] ) && 'error' === $body['status'] && isset( $body['message'] ) ) {
		    if( isset($body['message']) && !empty($body['message']) && is_array($body['message']) ) {
			    foreach ( $body['message'] as $key => $message ) {
				    $error_message .= '- '.$message[0] . '<br/>';
			    }
		    } else {
			    $error_message .= '- '.$body['message'] . '<br/>';
            }
			$result['message'] = sprintf( '<div class="bbapp-notice-box bbapp-notice-box--error">%s</div>', $error_message );
			wp_send_json_error( $result );
		}
		$keystore_jks_file_path = '';
		$body                   = $p12_file;
		if ( ! empty( $body ) && 200 === wp_remote_retrieve_response_code( $do_request ) ) {

			/**
			 * Get/Create JSK file
			 */
			$file_name = wp_remote_retrieve_header( $do_request, 'content-disposition' );
			if ( empty( $file_name ) ) {
				$error_message     .='- '. $body;
				$result['message'] = sprintf( '<div class="bbapp-notice-box bbapp-notice-box--error">%s</div>', $error_message );
				wp_send_json_error( $result );
			}

			$file_name     = str_replace( 'inline; filename=', '', $file_name );
			$file_ext      = pathinfo( $file_name, PATHINFO_EXTENSION );
			$file_name     = strtotime( gmdate( "Y-m-d H:i:s" ) ) . '.' . $file_ext;
			$upload        = wp_upload_dir();
			$file_path     = $upload['basedir'] . '/bbapp/keystore/';
			$file_uploaded = BBAPP_File::file_handler( $file_path . $file_name, $body );

			if ( ! empty( $file_uploaded ) || ! is_wp_error( $file_uploaded ) ) {
				$keystore_jks_file_path = $file_path . $file_name;
			}

			/**
			 * Create Zip for .jks and detials.
			 */
			$upload          = wp_upload_dir();
			$keystore_dir    = $upload['basedir'] . '/bbapp/keystore/';
			$keystore_url    = $upload['baseurl'] . '/bbapp/keystore/';
			$rootPath        = realpath( $keystore_dir );
			$export_zip_path = trailingslashit( $keystore_dir ) . 'buddyboss-app-keystore.zip';
			$export_zip_url  = trailingslashit( $keystore_url ) . 'buddyboss-app-keystore.zip';

			// Initialize archive object
			$zip = new \ZipArchive();
			if ( $zip->open( $export_zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
				if ( file_exists( $keystore_jks_file_path ) ) {
					// Put jks file into zip.
					$relativePath = substr( $keystore_jks_file_path, strlen( $rootPath ) + 1 );
					$zip->addFile( $keystore_jks_file_path, $relativePath ); // Add file into the Zip.

					// Creating keystore data file and put the key store data.
					BBAPP_File::WriteFile( "{$keystore_dir}keystore_data.json", json_encode( $body_params, JSON_PRETTY_PRINT ) );
					$keystore_json_file_path = "{$keystore_dir}keystore_data.json";
					$relativePath            = substr( $keystore_json_file_path, strlen( $rootPath ) + 1 );
					$zip->addFile( $keystore_json_file_path, $relativePath ); // Add file into the Zip.
					$zip->close(); // // Zip archive will be created only after closing object

					if ( file_exists( $keystore_jks_file_path ) ) {
						wp_delete_file( $keystore_jks_file_path );
					}
					if ( file_exists( $keystore_json_file_path ) ) {
						wp_delete_file( $keystore_json_file_path );
					}

					wp_send_json_success( array( 'name' => 'buddyboss-app-keystore.zip', 'url' => $export_zip_url ) );
				} else {
					$error_message     .= __( "- File not exists.", 'buddyboss-app' );
					$result['message'] = sprintf( '<div class="bbapp-notice-box bbapp-notice-box--error">%s</div>', $error_message );
					wp_send_json_error( $result );
				}
			} else {
				$error_message     .= __( "- Sorry the provided font is invalid or not supported to download.", 'buddyboss-app' );
				$result['message'] = sprintf( '<div class="bbapp-notice-box bbapp-notice-box--error">%s</div>', $error_message );
				wp_send_json_error( $result );
			}
		}
	}

	/**
	 * Function to validate namespace.
	 */
	public function bbapp_validate_namespace() {
		$result   = array();
		$name     = filter_input( INPUT_POST, 'name', FILTER_SANITIZE_STRING );
		$platform = filter_input( INPUT_POST, 'platform', FILTER_SANITIZE_STRING );

		$success_cls            = 'notice-success bbapp-notice-box bbapp-notice-box--success';
		$error_cls              = 'notice-error bbapp-notice-box bbapp-notice-box--error';
		$result['message']      = '';
		$alpha_numeric_cls      = ! preg_match( '/^[a-z0-9_.]+$/', $name ) ? $error_cls : $success_cls;
		$segment_cls            = ! strpos( $name, '.' ) ? $error_cls : $success_cls;
		$individual_segment_cls = ! preg_match( '/^[a-z][a-z0-9_]*(\.[a-z][a-z0-9_]*)+$/', $name ) ? $error_cls : $success_cls;
		$result['message']      .= sprintf( '<div class="%s">%s</div>', esc_attr( $segment_cls ), __( 'Application IDs must have at least two segments, separated by a dot', 'buddyboss-app' ) );
		$result['message']      .= sprintf( '<div class="%s">%s</div>', esc_attr( $individual_segment_cls ), __( 'Each segment in your Application ID must start with a letter', 'buddyboss-app' ) );
		$result['message']      .= sprintf( '<div class="%s">%s</div>', esc_attr( $alpha_numeric_cls ), __( 'Only lowercase letters, numbers or underscore can be used in application IDs', 'buddyboss-app' ) );

		if ( 'android' === $platform ) {
			if ( 200 === Android::instance()->validate_package_name( $name ) ) {
				$result['message'] .= sprintf( '<div class="notice-warning bbapp-notice-box bbapp-notice-box--warning">%s</div>', __( 'This Application ID is already used by a published app in the Google Play Store. You will only be able to publish a build using this Application ID if it is registered to you.', 'buddyboss-app' ) );
			} else {
				$result['message'] .= sprintf( '<div class="notice-success bbapp-notice-box bbapp-notice-box--success">%s</div>', __( 'This Application ID is not being used by a published app in the Google Play Store', 'buddyboss-app' ) );
			}
		}

		wp_send_json_success( $result );
	}

	/**
	 * Return the sub settings.
	 *
	 * @return array
	 */
	public function sub_settings() {
		return array(
			'Manage' => __( 'Manage', 'buddyboss-app' ),
		);
	}

	/**
	 * Return the current setting page from active screen.
	 *
	 * @return string
	 */
	public function get_current_sub_tab() {

		$default      = 'manage';
		$setting      = ( isset( $_GET['setting'] ) ) ? $_GET['setting']
			: $default;
		$sub_settings = $this->sub_settings();

		if ( isset( $sub_settings[ $setting ] ) ) {
			return $setting;
		}

		return $default;
	}

	/**
	 * Renders the setting screen.
	 */
	public function render_screen() {
		\BuddyBossApp\Admin\SetupAdmin::instance()->render_subtabs( $this->sub_settings(), $this->get_current_sub_tab() );

		if ( 'manage' === $this->get_current_sub_tab() ) {

			// Verify app.
			//\BuddyBossApp\ManageApp::instance()->verify_app();

			include bbapp()->plugin_dir . 'views/settings/manage_app.php';
		}
	}

	/**
	 * Ajax hooks helper.
	 *
	 * @param string $action action name of ajax hook
	 * @param mix    $method method to be call
	 */
	public function ajax_hooks( $action, $method ) {
		add_action( "wp_ajax_nopriv_$action", $method );
		add_action( "wp_ajax_$action", $method );
	}

	/**
	 * Admin hooks helper.
	 *
	 * @param string $action action name of admin post hook
	 * @param mix    $method method to be call
	 */
	public function admin_post_hooks( $action, $method ) {
		add_action( "admin_post_nopriv_$action", $method );
		add_action( "admin_post_$action", $method );
	}

	/**
	 * Handle Ajax Request Related to App Connect & Disconnect.
	 */
	public function ajax_manage_app() {
		if ( ! is_user_logged_in() ) {
			bbapp_ajax_error_response( 'no_allowed',
				__( "You don't have permission to do this action.",
					'buddyboss-app' ) );
		}

		// check if current user can do manage app.
		if ( ! \BuddyBossApp\Permissions::instance()
		                                ->can_manage_app( get_current_user_id() )
		) {
			bbapp_ajax_error_response( 'no_allowed',
				__( "You don't have permission to do this action. Action can be only performed from network.",
					'buddyboss-app' ) );
		}

		$do = ( isset( $_POST['do'] ) ) ? $_POST['do'] : '';

		$allowed_dos = array( 'connect', 'disconnect' );

		if ( ! in_array( $do, $allowed_dos ) ) {
			bbapp_ajax_error_response( 'no_allowed',
				__( "You don't have permission to do this action.",
					'buddyboss-app' ) );
		}

		// Verify Nonce.
		if ( ! isset( $_POST['_wpnonce'] )
		     || ! wp_verify_nonce( $_POST['_wpnonce'],
				'bbapp_manage_app_nonce' )
		) {
			bbapp_ajax_error_response( 'security_nonce',
				__( "Unable to verify security nonce. Please refresh the page and try again.",
					'buddyboss-app' ) );
		}

		if ( 'connect' == $do ) {

			if ( ! isset( $_POST['bbapp_app_id'] )
			     || ! isset( $_POST['bbapp_app_key'] )
			) {
				bbapp_ajax_error_response( 'data_missing',
					__( "Please provide BuddyBoss App ID & App Key.",
						'buddyboss-app' ) );
			}

			$bbapp_app_id    = trim( $_POST['bbapp_app_id'] );
			$bbapp_app_key   = trim( $_POST['bbapp_app_key'] );
			$bbapp_site_type = trim( $_POST['bbapp_site_type'] );

			$connect = \BuddyBossApp\ManageApp::instance()
			                                  ->connect_app( $bbapp_app_id,
				                                  $bbapp_app_key, $bbapp_site_type );

			if ( ! $connect || is_wp_error( $connect ) ) {
				if ( is_wp_error( $connect ) ) {

					if ( 'primary_not_possible' === $connect->get_error_code() ) {
						ob_start();
						include bbapp()->plugin_dir . 'views/settings/connect/secondary-site-confirm.php';
						$content = ob_get_clean();
						bbapp_ajax_error_response( $connect->get_error_code(), $content );
					}

					/**
					 * @var $connect \WP_Error
					 */
					bbapp_ajax_error_response( $connect->get_error_code(),
						$connect->get_error_message() );
				} else {
					bbapp_ajax_error_response( 'error_connecting',
						__( 'Unknown error while connecting app', 'buddyboss-app' ) );
				}
			} else {
				ob_start();
				?>
				<div class="bbapp-notice-box bbapp-notice-box--success">
					<?php if ( 'secondary' === $bbapp_site_type ) : ?>
						<?php esc_html_e( 'This site is now connected as a secondary site.', 'buddyboss-app' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'This site is now connected as your primary site.', 'buddyboss-app' ); ?>
					<?php endif; ?>
				</div>
				<?php
				include bbapp()->plugin_dir . 'views/settings/connect/main-connect.php';
				$content = ob_get_clean();
				bbapp_ajax_success_response( 'connected', $content );
			}
		}

		if ( 'disconnect' === $do ) {

			$app = \BuddyBossApp\ManageApp::instance()->get_app();

			$disconnect = \BuddyBossApp\ManageApp::instance()->disconnect_app( $app['bbapp_app_id'], $app['bbapp_app_key'], $app['bbapp_site_type'] );

			if ( $disconnect ) {
				ob_start();
				?>
				<div class="bbapp-notice-box bbapp-notice-box--success">
					<?php esc_html_e( 'You have successfully disconnected this site.', 'buddyboss-app' ); ?>
				</div>
				<?php
				include bbapp()->plugin_dir . 'views/settings/connect/main-connect.php';
				$content = ob_get_clean();
				bbapp_ajax_success_response( 'disconnected', $content );
			} else {
				bbapp_ajax_error_response( 'error_disconnecting', __( 'Unknown error while attempting to disconnect the app. Please refresh the page and try again.', 'buddyboss-app' ) );
			}
		}
	}

	/**
	 * Handle Ajax Request Related to Site Disconnect.
	 */
	public function ajax_site_disconnect() {

		if ( ! is_user_logged_in() ) {
			bbapp_ajax_error_response( 'no_allowed',
				__( 'You don\'t have permission to perform this action.',
					'buddyboss-app' ) );
		}

		// check if current user can do manage app.
		if ( ! \BuddyBossApp\Permissions::instance()
		                                ->can_manage_app( get_current_user_id() )
		) {
			bbapp_ajax_error_response( 'no_allowed',
				__( 'You don\'t have permission to perform this action. The action can only be performed from the network.',
					'buddyboss-app' ) );
		}

		// Verify Nonce.
		if ( ! isset( $_POST['_wpnonce'] )
		     || ! wp_verify_nonce( $_POST['_wpnonce'],
				'bbapp_manage_app_nonce' )
		) {
			bbapp_ajax_error_response( 'security_nonce',
				__( 'Unable to verify security nonce. Please refresh the page and try again.',
					'buddyboss-app' ) );
		}

		if ( empty( $_POST['site_url'] ) ) {
			bbapp_ajax_error_response( 'security_nonce',
				__( 'Please provide site URL to disconnect.',
					'buddyboss-app' ) );
		}

		$app = \BuddyBossApp\ManageApp::instance()->get_app();

		if ( ! $app ) {
			bbapp_ajax_error_response( 'no_allowed',
				__( 'The app you are trying to perform the action on was not found.',
					'buddyboss-app' ) );
		}

		$site_url = $_POST['site_url'];

		$disconnect = \BuddyBossApp\ManageApp::instance()->disconnect_app( $app['bbapp_app_id'], $app['bbapp_app_key'], 'secondary', $site_url );

		if ( $disconnect ) {
			bbapp_ajax_success_response( 'disconnected', __( 'Site successfully disconnected.', 'buddyboss-app' ) );
		} else {
			bbapp_ajax_error_response( 'error_disconnecting', __( 'Unknown error while attempting to disconnect the app. Please refresh the page and try again.', 'buddyboss-app' ) );
		}
	}

	/**
	 * Handle Ajax Request Related to Site secondary Cancel.
	 */
	public function ajax_secondary_site_cancel() {

		if ( ! is_user_logged_in() ) {
			bbapp_ajax_error_response( 'no_allowed',
				__( 'You don\'t have permission to perform this action.',
					'buddyboss-app' ) );
		}

		// check if current user can do manage app.
		if ( ! \BuddyBossApp\Permissions::instance()
		                                ->can_manage_app( get_current_user_id() )
		) {
			bbapp_ajax_error_response( 'no_allowed',
				__( 'You don\'t have permission to perform this action. The action can only be performed from the network.',
					'buddyboss-app' ) );
		}

		$app = \BuddyBossApp\ManageApp::instance()->get_app();

		if ( ! $app ) {
			bbapp_ajax_error_response( 'no_allowed',
				__( 'The app you are trying to perform the action on was not found.',
					'buddyboss-app' ) );
		}

		ob_start();
		include bbapp()->plugin_dir . 'views/settings/connect/main-connect.php';
		$content = ob_get_clean();
		bbapp_ajax_success_response( 'disconnected', $content );
	}

	/**
	 * Verify apps cron function.
	 */
	public function verify_apps() {
		\BuddyBossApp\ManageApp::instance()->verify_app();

		// Update Google/Apple connectivity to appcenter.
		\BuddyBossApp\ManageApp::instance()->account_connectivity();
	}
}
