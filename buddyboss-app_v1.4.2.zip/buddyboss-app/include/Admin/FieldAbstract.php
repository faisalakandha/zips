<?php
namespace BuddyBossApp\Admin;

abstract class FieldAbstract {

	private $value;
	private $settings;
	private $field_name;

	public function _render() {
		$this->render();
	}

	abstract function render();

	public function _save($post_value) {
		return $this->save($post_value);
	}

	abstract function save($post_value);

	public function set_value($value) {
		$this->value = $value;
	}

	public function get_value() {
		return $this->value;
	}

	public function set_field_name($name) {
		$this->field_name = $name;
	}

	public function get_field_name() {
		return $this->field_name;
	}

	public function set_settings($settings) {
		$this->settings = $settings;
	}

	public function get_settings() {
		return $this->settings;
	}

}
