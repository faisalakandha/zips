<?php

namespace BuddyBossApp\Admin\BuildUpload;
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use BuddyBossApp\Helpers\WP_List_Table;

class UploadList extends WP_List_Table {
	/**
	 * The type of view currently being displayed.
	 *
	 * E.g. "All", "Pending", "Approved", "Spam"...
	 *
	 * @since BuddyPress 1.7.0
	 * @var string
	 */
	public $view = 'all';

	/** Class constructor */
	public function __construct() {
		parent::__construct( array(
			'singular' => __( 'Build Upload', 'buddyboss-app' ), //singular name of the listed records
			'plural'   => __( 'Build Uploads', 'buddyboss-app' ), //plural name of the listed records
			'ajax'     => false, //should this table support ajax?
		) );
	}


	/**
	 * return the column available to this table list.
	 * @return array
	 */
	public function get_columns() {

		$columns                 = array();
		$columns['id']           = __( 'Upload ID', 'buddyboss-app' );
		$columns['build_id']     = __( 'Build ID', 'buddyboss-app' );
		$columns['app_ver']      = __( 'Build Version', 'buddyboss-app' );
		$columns['core_app_ver'] = __( 'Core App Version', 'buddyboss-app' );
		$columns['requester']    = __( 'Requester', 'buddyboss-app' );
		$columns['status']       = __( 'Status', 'buddyboss-app' );
		$columns['actions']      = __( 'Actions', 'buddyboss-app' );

		return $columns;
	}

	/**
	 * Gets the name of the primary column.
	 * @return string The name of the primary column.
	 */
	public function get_primary_column_name() {
		return 'id';
	}

	/**
	 *
	 */
	public function no_items() {
		_e( 'No uploads found.', 'buddyboss-app' );
	}

	/**
	 * @param object $item
	 * @param string $column_name
	 *
	 * @return string|void
	 * @throws \MingYuanYun\AppStore\Exceptions\ConfigException
	 */
	public function column_default( $item, $column_name ) {

		switch ( $column_name ) {
			case 'id':
				$upload_id = isset( $item["id"] ) ? $item["id"] : 0;

				return "#{$upload_id}";
				break;
			case 'build_id':
				$build_id = isset( $item["build_id"] ) ? $item["build_id"] : 0;

				return "#{$build_id}";
				break;
			case 'app_ver':
				$build_app_version = isset( $item["app_version"] ) ? $item["app_version"] : '';
				if ( empty( $build_app_version ) ) {
					$build_app_version = __( 'N/A', 'buddyboss-app' );
				}

				return "{$build_app_version}";
				break;
			case 'core_app_ver':
				$build_app_version = isset( $item["app_core_version"] ) ? $item["app_core_version"] : '';
				if ( empty( $build_app_version ) ) {
					$build_app_version = __( 'N/A', 'buddyboss-app' );
				}

				return "{$build_app_version}";
				break;
			case 'requester':
				$user = get_user_by( 'email', $item["requester_email"] );
				if ( ! $user ) {
					$user = $item["requester_email"];
					if ( is_email( $user ) ) {
						$val = "{$user}";
					} else {
						$val = "N/A";
					}
				} else {
					$user_link = admin_url( "user-edit.php?user_id={$user->ID}" );
					$val       = "<a href='{$user_link}'>{$user->display_name}</a>";
				}

				return $val;
				break;
			case 'status':
				$labels = Upload::instance()->get_statuses_labels();
				$status = ( isset( $labels[ $item["status"] ] ) ) ? $labels[ $item["status"] ] : ucfirst( $item["status"] );

				$date_modified = $item["date_modified"];
				$date_format   = get_option( 'date_format' );
				$date_format   = ! empty( $date_format ) ? $date_format : __( 'F j, Y' );
				$time_format   = get_option( 'time_format' );
				$time_format   = ! empty( $time_format ) ? $time_format : __( 'g:i a' );
				$date_modified = get_gmt_from_date( date( 'Y-m-d H:i:s', $date_modified ), $date_format . ' ' . $time_format );

				return "{$status} <span class='bbapp-date-modified'>{$date_modified}</span>";
				break;
			case 'actions':

				$actions = [];

				if ( isset( $item["status"] ) && ( $item["status"] == "running" || $item["status"] == "new" ) ) {
					ob_start();
					?>
                    <a href="#" class="bbapp-action-btn" data-upload-id="<?php echo esc_attr( $item["id"] ); ?>"
                       data-action="status_check">
                        <div class="bbapp_loading" style="display: none"></div>
						<?php esc_html_e( 'Recheck Status', 'buddyboss-app' ); ?>
                    </a>
					<?php
					$actions[] = ob_get_contents();
					ob_end_clean();
				}

				/**
				 * Failed & Cancelled Status Handle.
				 */
				if ( isset( $item["status"] ) && ( $item["status"] == "cancelled" || $item["status"] == "failed" ) ) {

					if ( ! isset( $item["error_message"] ) ) {
						$item["error_message"] = array();
					}

					$errors = array();

					if ( isset( $item["status"] ) && ( $item["status"] == "cancelled" && ! empty( $item["cancel_reason"] ) ) ) {
						$errors[] = $item["cancel_reason"];
					}

					if ( isset( $item["status"] ) && ( $item["status"] == "failed" && ! empty( $item["error_message"] ) ) ) {
						foreach ( $item["error_message"] as $err ) {
							$msg      = isset( $err['code'] ) ? sprintf( __( "Error #%s ", "buddyboss-app" ), $err['code'] ) : '';
							$msg      .= isset( $err['message'] ) ? $err['message'] : '';
							$errors[] = $msg;
						}
					}

					if ( empty( $errors ) ) {
						$errors[] = __( 'Unknown Error', 'buddyboss-app' );
					}

					ob_start();
					?>
                    <a href="#" class="bbapp-upload-cancel-reason-btn"
                       onclick="jQuery(this).next().toggle();"><?php esc_html_e( 'View Errors﻿', 'buddyboss-app' ); ?></a>
                    <div class="bbapp-lite-dialog" style="display: none">
                        <div class="overlay"></div>
                        <div class="bbapp-dialog  bbapp-dialog--error">
                            <h2><?php echo sprintf( __( 'Build Upload #%s', 'buddyboss-app' ), $item['id'] ); ?></h2>
                            <p><?php esc_html_e( 'We were unable to complete this build upload request for the following reason(s):', 'buddyboss-app' ); ?></p>

							<?php foreach ( $errors as $error ): ?>
                                <p class="bbapp-notice-box"><?php echo esc_html( $error ); ?></p>
							<?php endforeach; ?>

                            <a href="#" class="close" onclick="jQuery(this).next().toggle();">Close</a>
                        </div>
                    </div>
					<?php
					$actions[] = ob_get_contents();
					ob_end_clean();
				}

				/**
				 * New Status Handle.
				 */
				if ( isset( $item["status"] ) && $item["status"] == "new" ) {
					ob_start();
					?>
                    <a href="#" class="bbapp-action-btn" data-upload-id="<?php echo esc_attr( $item["id"] ); ?>"
                       data-action="cancel">
                        <div class="bbapp_loading" style="display: none"></div>
						<?php esc_html_e( 'Cancel', 'buddyboss-app' ); ?>
                    </a>
					<?php
					$actions[] = ob_get_contents();
					ob_end_clean();
				}

				if ( isset( $item["status"] ) && $item["status"] == "completed" ) {
					ob_start();
					$apple_app_id = $item['apple_app_id'];
					$apple_link   = "https://appstoreconnect.apple.com/apps/{$apple_app_id}/testflight/ios";

					if ( ! empty( $apple_app_id ) ): ?>

                        <a href="<?php echo esc_attr( $apple_link ); ?>" target="_blank">
							<?php esc_html_e( 'View in App Store Connect', 'buddyboss-app' ); ?>
                        </a>

					<?php endif;

					$actions[] = ob_get_contents();
					ob_end_clean();
				}

				return implode( '<span style="color:gray">|</span>', $actions );

				break;
			default:
				return "N/A";
				break;
		}
	}

	/**
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array(//			'date_created' => array( 'date_created', true ),
		);
	}

	/**
	 * Handles data query and filter, sorting, and pagination.
	 */
	public function prepare_items() {
		/**
		 * Init column headers.
		 */
		$this->_column_headers = array( $this->get_columns(), array(), array() );

		$per_page     = $this->get_items_per_page( 'bbapp_build_uploads_per_page', 10 );
		$current_page = $this->get_pagenum();
		$status       = "";
		$total_items  = 0;

		$results = Upload::instance()->get_uploads( $status, $current_page, $per_page );

		if ( ! is_wp_error( $results ) ) {
			$total_items = (int) $results["headers"]["total"];
			$this->items = $results["data"];
		}

		$this->set_pagination_args( [
			'total_items' => $total_items,
			'per_page'    => $per_page,
		] );

	}


	/**
	 * Checkbox for bulk items.
	 *
	 * @param object $item
	 *
	 * @return string|void
	 */
	function column_reorder( $item ) {
		return sprintf(
			'<span class="iap-reorder-product"><img src="' . \bbapp::instance()->plugin_url . '/assets/img/icons/fontawesome/solid/bars.svg" alt="' . esc_attr__( 'Drag', 'buddyboss-app' ) . '"</span>'
		);
	}

	/**
	 * Checkbox for bulk items.
	 *
	 * @param object $item
	 *
	 * @return string|void
	 */
	function column_cb( $item ) {
		return sprintf(
			'<input type="checkbox" id="cb-select-%s" name="iap_product_ids[]" value="%s" />', $item['id'], $item['id']
		);
	}

	function display() {
		parent::display();
		?>
        <script>
            jQuery(document).ready(function () {

                jQuery('.bbapp-action-btn').click(function () {

                    var _this = jQuery(this);

                    if (_this.data("loading") == '1') {
                        return false;
                    }

                    _this.data('loading', '1').find('.bbapp_loading').show();

                    var post = jQuery.post(ajaxurl, {
                        action: 'bbapp_build_upload_actions',
                        'sub_action': _this.data('action'),
                        'upload_id': _this.data('upload-id'),
                        'bbapp_upload_build_actions': "<?php echo esc_attr( wp_create_nonce( 'bbapp_upload_build_actions', 'bbapp_upload_build_actions' ) ); ?>"
                    });

                    post.done(function (data) {
                        if (typeof data.success != 'undefined') {
                            if (data.success && data.data.reload) {
                                window.location.reload();
                            } else {
                                alert(data.data);
                            }
                        }
                    });

                    post.fail(function (data) {
                        alert('<?php esc_attr_e( 'There is error while calling action', 'buddyboss-app' ); ?>');
                    });

                    post.always(function () {
                        _this.data('loading', '0').find('.bbapp_loading').hide();
                    });

                });

            });
        </script>
		<?php
	}
}
