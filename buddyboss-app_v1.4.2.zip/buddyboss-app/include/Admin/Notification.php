<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\Admin\Notification\Compose;
use BuddyBossApp\Admin\Notification\Notifications;
use BuddyBossApp\Notification\Notification as AppNotification;

class Notification {

	private static $instance;
	public $option_setting = "bbapp_push_notif_options";

	/**
	 * Get the instance of the class.
	 *
	 * @return Notification
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	public function _load() {

		Notifications::instance();
		Compose::instance();

		add_action( 'admin_init', array( $this, 'load_init' ), 9 );
		add_action( 'admin_init', array( $this, 'load_service_push_admin' ) );

	}

	public function load_init() {

		if ( SetupAdmin::instance()->get_page_now() == "admin.php" && $_GET['page'] == 'bbapp-notification' ) {

			if ( $this->get_current_sub_tab() == 'list' && bbapp_is_admin_page() ) {
				Notifications::instance()->will_render( true ); // tell the class that it will render.
			}

			if ( $this->get_current_sub_tab() == 'new' && bbapp_is_admin_page() ) {
				Compose::instance()->will_render( true ); // tell the class that it will render.
			}

		}

	}

	/**
	 * Load Settings.
	 */
	public function loadSettings() {

		$this->settings_form = new FormProvider( 'push_notif_settings' );

		// holds app settings storage handle.
		$settings_provider = new SettingProvider( 'push_notif_settings' );

		// register app settings storing & receiving
		$settings_provider->save_setting_hook( array( $this, 'save_settings' ) );
		$settings_provider->get_setting_hook( array( $this, 'get_settings' ) );

		// Link Provider In Form Provider
		$this->settings_form->link_setting_provider( $settings_provider );

		add_action( "admin_init", array( $this->settings_form, "save" ) );

		/**
		 * Push Notification Settings
		 */
		if ( ! bbapp_get_app_push_firebase_key() ) {
			$desc = sprintf( __( 'In order to use push notifications in the app, please add your <a href="%s">Firebase Server Key</a>.', 'buddyboss-app' ), bbapp_get_super_admin_url( "admin.php?page=bbapp-configure&setting=firebase" ) );
		} else {
			$desc = sprintf( __( 'Configure which notifications will be automatically sent as push notifications. You can send manual push notifications to your members on the <a href="%s">Push Notifications</a> page.', 'buddyboss-app' ), bbapp_get_admin_url( 'admin.php?page=bbapp-notification' ) );
		}

		$this->settings_form->add_field( $settings_provider->field( false, array(
			'type'    => 'table-open',
			'classes' => 'buddyboss-app-admin-card bbapp-admin-push_notification',
		) ) );

		$this->settings_form->add_field( $settings_provider->field( 'app_push_notification_heading', array(
			'type'         => 'heading',
			'value'        => __( 'Push Notifications', 'buddyboss-app' ),
			'desc'         => $desc,
			'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121838' ),
		) ) );

		if ( bbapp_get_app_push_firebase_key() ) {
			$subscriptions_settings_lists = AppNotification::instance()->get_push_notifications_subs_settings();
			if ( count( $subscriptions_settings_lists ) > 2 ) {

				foreach ( $subscriptions_settings_lists as $subscriptions_settings_list ) {

					if ( in_array( $subscriptions_settings_list['name'], array( '', 'announcements' ), true ) ) {
						continue;
					}

					if ( ! empty( $subscriptions_settings_list['settings'] ) ) {
						$label    = $subscriptions_settings_list['label'] . __( ' Notification' );
						$class    = 'section_element';
						$last_key = array_key_last( $subscriptions_settings_list['settings'] );
						foreach ( $subscriptions_settings_list['settings'] as $setting_key => $subscriptions_setting ) {
							if ( $setting_key === $last_key ) {
								$class = 'section_last_element';
							}
							$this->settings_form->add_field( $settings_provider->field( $setting_key, array(
								'label'          => $label,
								'label_checkbox' => $subscriptions_setting['admin_label'],
								'type'           => 'checkbox',
								'class'          => $class,
								'value'          => true,
							) ) );
							$label = '';
						}
					}
				}
			}

			$this->settings_form->add_field( $settings_provider->field( 'app_push_notification_custom_notice', array(
				'type'  => 'desc',
				'value' => sprintf( __( 'You can register your own automatic notifications using <a href="%s" target="_blank">custom code</a>. Once registered, they will show up on this page.', 'buddyboss-app' ), "https://www.buddyboss.com/resources/dev-docs/app-development/extending-the-buddyboss-app-plugin/creating-automatic-push-notifications/" ),
			) ) );
		}
	}

	/**
	 * Saves the settings
	 *
	 * @param $settings
	 *
	 * @return bool
	 */
	public function save_settings( $settings ) {
		bbapp_set_network_option( $this->option_setting, $settings );

		return true;
	}

	/**
	 * Gets the settings
	 */
	public function get_settings() {
		$settings = bbapp_get_network_option( $this->option_setting );

		return $settings;
	}

	/**
	 * Function will call _init_admin of each app selected push service on init_admin.
	 */
	public function load_service_push_admin() {
		$push_instance = bbapp_get_app_push_instance();

		if ( $push_instance ) {
			$push_instance->_init_admin();
		}
	}

	/**
	 * Return the sub settings.
	 *
	 * @return array
	 */
	public function sub_settings() {

		$return = array();

		if ( bbapp_is_admin_page() ) {
			$return["list"] = __( 'Push Notifications', 'buddyboss-app' );
			$return["new"]  = __( 'Send New', 'buddyboss-app' );
		}

		return $return;
	}

	/**
	 * Return the current setting page from active screen.
	 *
	 * @return string
	 */
	public function get_current_sub_tab() {

		$default = "list";

		foreach ( $this->sub_settings() as $k => $v ) {
			$default = $k;
			break;
		}

		$setting      = ( isset( $_GET["setting"] ) ) ? $_GET["setting"] : $default;
		$sub_settings = $this->sub_settings();

		if ( isset( $sub_settings[ $setting ] ) ) {
			return $setting;
		}

		return $default;
	}

	/**
	 * Return the sub settings.
	 *
	 * @return array
	 */
	public function sub_sub_settings() {

		$return = array();

		if ( bbapp_is_admin_page() ) {
			$return["manual"]    = __( 'Manual', 'buddyboss-app' );
			$return["automatic"] = __( 'Automatic', 'buddyboss-app' );
		}

		return $return;
	}

	/**
	 * Return the current setting page from active screen.
	 *
	 * @return string
	 */
	public function get_current_sub_sub_tab() {
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'bbapp-notification' ) {
			$default = "manual";
			$setting = ( isset( $_GET["sub-setting"] ) ) ? $_GET["sub-setting"] : $default;
			$sub_settings = $this->sub_sub_settings();

			if ( isset( $sub_settings[ $setting ] ) ) {
				return $setting;
			}

			return $default;
		}

		return null;
	}

	/**
	 * Render Setting Form.
	 */
	public function render_settings() {
		$this->settings_form->render_form();
	}

	/**
	 * Renders the setting screen.
	 */
	public function render_screen() {

		echo '<div class="wrap">';

		$this->render_subtabs( $this->sub_settings(), $this->get_current_sub_tab() );

		if ( $this->get_current_sub_tab() == 'list' ) {
			Notifications::instance()->render();
		}

		if ( $this->get_current_sub_tab() == 'new' ) {
			Compose::instance()->render();
		}

		echo '</div>';

	}

	/**
	 * @param        $sub_settings
	 * @param        $current_tab
	 * @param string $param_key
	 *
	 * @return bool
	 */
	public function render_subtabs( $sub_settings, $current_tab, $param_key = "setting" ) {

		// only render something when there is more than 1 sub menu.
		if ( empty( $sub_settings ) || count( $sub_settings ) < 2 ) {
			return false;
		}
		if ( isset( $_GET['push_id'] ) ) {
			?>
            <a class="bbapp-back-to-notification"
               href="<?php echo admin_url( 'admin.php?page=bbapp-notification' ); ?>">
				<?php _e( 'Back to Notifications', 'buddyboss-app' ); ?>
            </a>
			<?php
		} else {
			$page = isset( $_GET["page"] ) ? $_GET["page"] : "";
			if ( 'new' === $current_tab ) {
				$sub_tab       = 'list';
				$tab_title     = $sub_settings['new'];
				$sub_tab_title = $sub_settings['list'];

			} else {
				$sub_tab       = 'new';
				$tab_title     = $sub_settings['list'];
				$sub_tab_title = $sub_settings['new'];
			}
			?>
            <div class="flex" style="position: relative">
                <h1 class="wp-heading-inline"><?php echo esc_html( $tab_title ); ?></h1>
                <div class="flex align-center bbapp-sub-nav">
                    <a class="page-title-action button button-primary" href="<?php echo esc_url( add_query_arg( array(
						'page'     => $page,
						$param_key => $sub_tab
					), bbapp_get_admin_url( 'admin.php' ) ) ); ?>"><?php echo esc_html( $sub_tab_title ); ?></a>
                    <a class="page-title-action button" href="<?php echo esc_url( add_query_arg( array(
						'page'    => 'bbapp-settings',
						'setting' => 'push_notifications'
					), bbapp_get_admin_url( 'admin.php' ) ) ); ?>"><?php esc_html_e( 'View Settings', 'buddyboss-app' ) ?></a>
                </div>
                <a class="button button-secondary bbapp-tutorial-btn" target="_blank"
                   href="<?php echo esc_url( "https://www.buddyboss.com/resources/docs/app/push-notifications/" ); ?>"><?php _e( 'View Tutorial', 'buddyboss-app' ); ?></a>
            </div>
			<?php
		}
		if ( ( ! isset( $_GET['setting'] ) || 'new' !== $_GET['setting'] ) && ! isset( $_GET['push_id'] ) ) {
			\BuddyBossApp\Admin\SetupAdmin::instance()->render_subtabs( $this->sub_sub_settings(), $this->get_current_sub_sub_tab(), 'sub-setting' );
		}
	}

}
