<?php

namespace BuddyBossApp\Admin;

class Appearance {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return Settings
	 */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
	}

	public function _load() {

		Appearance\Branding::instance();
        Appearance\Styling::instance();
		Appearance\Typography::instance();
		Appearance\Menu::instance();
		Appearance\Preview::instance();

		add_action("admin_init", array($this, "load_init"));

	}

	public function load_init() {

		if (SetupAdmin::instance()->get_page_now() == "admin.php" && $_GET['page'] == 'bbapp-appearance') {

			if ($this->get_current_sub_tab() == 'branding') {
				Appearance\Branding::instance()->will_render(true); // tell the class that it will render.
			}
            
            if ($this->get_current_sub_tab() == 'styling') {
				Appearance\Styling::instance()->will_render(true); // tell the class that it will render.
			}

			if ($this->get_current_sub_tab() == 'typography') {
				Appearance\Typography::instance()->will_render(true); // tell the class that it will render.
			}

			if ($this->get_current_sub_tab() == 'app_menu') {
				Appearance\Menu::instance()->will_render(true); // tell the class that it will render.
			}

		}

	}

	/**
	 * Saved branding platform preview.
	 *
	 * @param string $platform
	 */
	public function save_branding_platform_preview( $platform = 'ios' ) {
		$platform       = isset( $_GET['platform'] ) ? $_GET['platform'] : $platform;
		$saved_platform = get_option( 'bbapp_branding_platform_preview' );
		if ( empty( $saved_platform ) || ( ! empty( $platform ) && $saved_platform !== $platform ) ) {
			update_option( 'bbapp_branding_platform_preview', $platform );
		}
	}

	/**
	 * Get the branding platform preview.
	 *
	 * @return false|mixed|string|void
	 */
	public function get_branding_platform_preview() {
		$bbapp_branding_platform_preview = get_option( 'bbapp_branding_platform_preview' );
		$bbapp_branding_platform_preview = empty( $bbapp_branding_platform_preview ) ? 'ios' : $bbapp_branding_platform_preview;

		return isset( $_GET['platform'] ) ? $_GET['platform'] : $bbapp_branding_platform_preview;
	}

	public function footer()
	{
		$all_menu_array     = !empty($all_menu_array) ? array_unique($all_menu_array) : array();
		$tabbar_icons_array = !empty($tabbar_icons_array) ? array_unique($tabbar_icons_array) : array();

		$other_menu_array = array();
		if (!empty($all_menu_array) && !empty($tabbar_icons_array)) {
			$other_menu_array = array_diff($all_menu_array, $tabbar_icons_array);
		}

		$stylingOptionColors  = bbapp_get_default_tab_color();
		$default_color        = $stylingOptionColors['default_color'];
		$default_active_color = $stylingOptionColors['default_active_color'];

		// Localize.
		wp_localize_script('bbapp_js', 'tabbar_icons', array(
			'all_menus'            => array_values($all_menu_array),
			'tabbar_menus'         => array_values($tabbar_icons_array),
			'more_menus'           => array_values(array_unique($other_menu_array)),
			'current_screen'       => isset($safeGET['screen']) ? $safeGET['screen'] : 'home',
			'default_color'        => $default_color,
			'default_active_color' => $default_active_color,
		));
		// Localize Icon picker.
		wp_localize_script('bbapp_js', 'icons_picker', array(
			'bbapp_icons_path'        => \BuddyBossApp\Common\IconPicker::instance()->icon_picker_app_icon_url(),
			'bbapp_custom_icons_path' => \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_dir(),
			'bbapp_custom_icons_url'  => \BuddyBossApp\Common\IconPicker::instance()->icon_picker_custom_icon_url(),
			'bbapp_default_tab_color' => bbapp_get_default_tab_color(),
		));
	}

	/**
	 * Saves the settings
	 *
	 * @param $settings
	 *
	 * @return bool
	 */
	public function save_settings($settings) {

		$app_settings = \BuddyBossApp\ManageApp::instance()->get_app_settings();

		\BuddyBossApp\ManageApp::instance()->update_app_settings($app_settings);

		return true;
	}

	/**
	 * Gets the settings
	 */
	public function get_settings() {

		$settings = \BuddyBossApp\ManageApp::instance()->get_app_settings();

		return $settings;

	}

    /**
     * Return the sub settings.
     *
     * @return array
     */
	public function sub_settings() {

        $return = array(
            'branding' => __('Images', 'buddyboss-app'),
            'styling' => __('Colors', 'buddyboss-app'),
            'typography' => __('Typography', 'buddyboss-app'),
            'app_menu' => __('Tab Bar', 'buddyboss-app'),
        );

		// Hide the Tab Bar(app_menu) from super admin dashboard(so called "Network Admin Area")
        if(!bbapp_is_admin_page() && bbapp_is_super_admin_page()) {
	        unset($return["styling"]);
	        unset($return["app_menu"]);
        }

		return $return;
	}

	/**
	 * Return the current setting page from active screen.
	 *
	 * @return string
	 */
	public function get_current_sub_tab() {

		if (!isset($_GET['page']) || $_GET['page'] == 'bbapp-build') {
			return null;
		}

		$default = "branding";
		$setting = (isset($_GET["setting"])) ? $_GET["setting"] : $default;
		$sub_settings = $this->sub_settings();

		if (isset($sub_settings[$setting])) {
			return $setting;
		}

		return $default;
	}

	/**
	 * Renders the setting screen.
	 */
	public function render_screen() {

		add_action('admin_footer', array($this, 'footer'), 50);
		
        \BuddyBossApp\Admin\SetupAdmin::instance()->render_subtabs($this->sub_settings(),$this->get_current_sub_tab());

		if ($this->get_current_sub_tab() == 'branding') {
			Appearance\Branding::instance()->render();
		}
        
        if ($this->get_current_sub_tab() == 'styling') {
			Appearance\Styling::instance()->render();
		}

		if ($this->get_current_sub_tab() == 'typography') {
			Appearance\Typography::instance()->render();
		}

		if ($this->get_current_sub_tab() == 'app_menu') {
			Appearance\Menu::instance()->render();
		}

	}


}
