<?php
namespace BuddyBossApp\Admin\Fields;

use BuddyBossApp\Admin\FieldAbstract;
use BuddyBossApp\Helpers\BBAPP_File;

/**
 * Class Upload
 *
 * available settings
 * allowed_ext = array();
 * upload_dir = ''; default 'bbapp-upload'
 *
 * @package BuddyBossApp\Admin\Fields
 */

class Upload extends FieldAbstract {

	/**
	 * Upload constructor.
	 */
	public function __construct() {
		$this->setting_id = uniqid();
	}

	/**
	 * @return array
	 */
	public function get_settings() {
		$settings = parent::get_settings();

		if (!is_array($settings)) {
			$settings = array();
		}

		return $settings;
	}

	/**
	 *
	 */
	public function render() {

		echo '<div class="bbapp-upload-field">';

		$field_name = $this->get_field_name();

		$value = $this->get_value();

		$upload_btn_text = esc_html__("Upload File", 'buddyboss-app');

		if (!empty($value)) {
			$upload_btn_text = esc_html__("Replace File", 'buddyboss-app');
			// Paste after triming hash value.
			echo '<span class="bbapp-uploaded-file-name">' . preg_replace('/(.*?)-(.*)/', '$2', basename($value)) . '</span>';
		}

		$settings = $this->get_settings();

		if ( ! empty( $settings['upload_btn_text'] ) && ! isset( $settings['show_file_link'] ) ) {
			$upload_btn_text = $settings['upload_btn_text'];
		}

		if (!isset($settings["allowed_ext"])) {
			$settings["allowed_ext"] = array();
		}

		$upload_field_name = "upload_" . uniqid() . rand(99, 9999); // unique id.

		$extentions = implode(", ", $settings["allowed_ext"]);

		if ( isset( $settings['show_file_link'] ) && true === $settings['show_file_link'] && ! empty( $value ) ) {
			$upload_dir = wp_upload_dir();
			$url = $upload_dir['baseurl'];
			$file_url = $url . $value;
			$file_name = trim(substr($value, strrpos($value, '/') + 1));
			echo '<p class="show_preview"><span class="bbapp-notice-box bbapp-notice-box--info"><a href="' . $file_url . '" target="_blank" class="show_preview__name">' . $file_name . ' </a><a href="#" class="bbapp-upload-field-delete-btn" title="' . __("Delete", "buddyboss-app") . '"><span class="dashicons dashicons-no"></span><span></a></p>';
		}
		?>
		<a href="#" class="bbapp-upload-field-upload-btn button"><?php echo $upload_btn_text; ?></a>
        <input style="display:none" name="<?php echo esc_attr("{$upload_field_name}"); ?>" type='file' />
        <input name="<?php echo esc_attr("{$field_name}"); ?>[value]" type='hidden' value="<?php echo esc_attr($value); ?>" />
        <input name="<?php echo esc_attr("{$field_name}"); ?>[delete]" type='hidden' value="0" class="delete-field" />
        <input name="<?php echo esc_attr("{$field_name}"); ?>[field_name]" type='hidden' value="<?php echo esc_attr($upload_field_name); ?>" />
		<p style="font-size:12px"><?php echo sprintf(__("Allowed file extension(s): %s", "buddyboss-app"), $extentions); ?></p>
        <?php

		echo '</div>';
	}

	/**
	 * Filtering the data and everything will go there :).
	 *
	 * @param $post_value
	 *
	 * @return mixed
	 */
	public function save($post_value) {

		// Create key from the setting name and setup into global to check the extention invalid.
		$field_name_slug             = str_replace( '-', '_', sanitize_title( str_replace( '[', '_', $this->get_field_name() ) ) ) . '_invalid_file';
		$GLOBALS[ $field_name_slug ] = false;

		$upload_name = $post_value["field_name"];

		$settings = $this->get_settings();

		if (!isset($settings["allowed_ext"])) {
			$settings["allowed_ext"] = array();
		}

		$upload = $_FILES[$upload_name];
		$do_delete = isset($_POST[$upload_name]["delete"])?$_POST[$upload_name]["delete"]:"";

		$old_value = $this->get_value();

		// When request to delete file.
		if(isset($post_value["delete"]) && $post_value["delete"] == "1") {
			$old_file = $old_value;
			$upload_dir = wp_upload_dir();
			if (!empty($old_file) && file_exists($upload_dir['basedir'] . "/" . $old_file)) {
				@unlink($upload_dir["basedir"] . "/" . $old_file);
			}
			return '';
        }

		// New File Update..
		if (isset($upload['tmp_name']) && !empty($upload['tmp_name'])) {

			$upload_dir = wp_upload_dir();
			$dir = "bbapp/uploads";

			if (isset($settings["upload_dir"])) {
				$dir = $settings["upload_dir"];
			}

			$dir = "{$upload_dir['basedir']}/{$dir}";

			BBAPP_File::CreateDir( $dir );

			/**
			 * Securing the upload directory from indexing
			 */
			if (!file_exists($dir . "/index.html")) {
				touch($dir . "/index.html");
			}

			$salt = bbapp_generate_password( 30 );
			$hash = hash('sha1', microtime() . uniqid() . rand() . $salt);

			$file_name = $hash . "-" . $upload["name"];

			/**
			 * Delete the old file.
			 */
			$old_file = $old_value;

			if (!empty($old_file) && file_exists($upload_dir['basedir'] . "/" . $old_file)) {
				@unlink($upload_dir["basedir"] . "/" . $old_file);
			}

			$upload_file = $dir . "/" . $file_name;

			/**
			 * File Extension Validation
			 */
			$ext = pathinfo($file_name, PATHINFO_EXTENSION);

			if (!in_array($ext, $settings["allowed_ext"])) {
				$GLOBALS[ $field_name_slug ] = true; // Setup global variable to true when the invalid file extension.
				return $old_value;
			}

			if (move_uploaded_file($upload["tmp_name"], $upload_file)) {

				// keep only relative path to upload dir
				$upload_file = str_replace($upload_dir["basedir"], '', $upload_file);

				return $upload_file;

			}

		}

		return $old_value; // return old value if new was nt uploaded.
	}
}
