<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\Admin\SetupAdmin;
use BuddyBossApp\AppLanguages as BuddyBossAppLanguages;
use BuddyBossApp\ManageApp;

class AppLanguages
{

    private static $instance;
    private $is_current_page;
    private $_messages;

    /**
     * Get the instance of the class.
     *
     * @return AppLanguages
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class = __CLASS__;
            self::$instance = new $class;
            self::$instance->_load();
        }

        return self::$instance;
    }

    /**
     * AppLanguages constructor.
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function _load()
    {
        add_action('wp_ajax_bbapp_update_languages', array($this, "ajax_submit"));
        add_action('wp_ajax_nopriv_bbapp_update_languages', array($this, "ajax_submit"));
    }


    /**
     * Renders the branding screen
     * @return bool|mixed
     */
    public function render()
    {
        if (!current_user_can("manage_options")) {
            echo '<p>' . __( "You don't have permission to access this page.", "buddyboss-app") . '</p>';
            return false;
        }

        include bbapp()->plugin_dir . "views/settings/app_languages.php";

    }

    /**
     * Output the error or update messages to render.
     */
    public function show_messages()
    {

        if (!empty($this->_messages)) {
            foreach ($this->_messages as $message) {
                echo "<div id='message' class='{$message['type']}'><p>{$message['message']}</p></div>";
            }
        }

    }

    /**
     * Ajax Submit for App Languages Save Changes.
     */
    public function ajax_submit()
    {

        if (isset($_POST["bbapp_save_languages_form"])
            && wp_verify_nonce($_POST['bbapp_save_languages_form'], 'bbapp_save_languages_form')) {

            if (!current_user_can("manage_options")) {
                wp_send_json_error( "You don't have permission", "buddyboss-app" );
                exit;
            }

            // get original server language for comparision.
            $languages = (array)BuddyBossAppLanguages::instance()->get_merged_languages();

            if (empty($languages)) {
                wp_send_json_error(__( "Error while saving languages.", 'buddyboss-app' ));
            }

            $languages_post_data = (isset($_POST["lang_data"])) ? $_POST["lang_data"] : '{}';
            $languages_post_data = (array)json_decode(stripslashes($languages_post_data));

            // check if it's csv data.
            // if yes than keep it on priority
            if (isset($_FILES["language_upload"]["tmp_name"]) && !empty($_FILES["language_upload"]["tmp_name"])) {

                $file = fopen($_FILES["language_upload"]["tmp_name"], "r");
                $imported_langs = array();

                $i = 0;
                while (!feof($file)) {
                	$i++;
                    $data = fgetcsv($file);
                    if (isset($data[0]) && isset($data[1]) && $i != 1) {
                        $imported_langs[sanitize_text_field(trim($data[0]))] = sanitize_text_field(trim($data[2]));
                    }

                    // validate the csv file.
	                if ( $i == 1 && ($data[0] != "Source Text ID" || $data[1] != "Source Text" || $data[2] != "Translation") ) { // if we found incorrect format of column.
		                 wp_send_json_error( __( "Uploaded CSV is not compatible with BuddyBoss App", 'buddyboss-app' ) );
	                }

                }

                fclose($file);
                $languages_post_data[$_POST["lang_name_csv"]] = $imported_langs;

            }

            if (!$languages_post_data) {
                $languages_post_data = array();
            }

            $languages_post_data = (array)$languages_post_data;

            //Get Saved languages
            $saved_languages = BuddyBossAppLanguages::instance()->get_languages();

            // Trim all unwanted language strings & keep only changed one.
            foreach ($languages_post_data as $lang_name => $language) {

                $language = (array)$language;

                $languages_post_data[$lang_name] = (array)$languages_post_data[$lang_name];

                foreach ($language as $lang_key => $lang_value) {
                    if (
                        isset($languages[$lang_name][$lang_key]) && $languages[$lang_name][$lang_key] == $lang_value
                    ) {
                        unset($language[$lang_key]);
                    }
                }

	            if ( isset( $saved_languages[ $lang_name ] ) ) {
	                //Delete languages string if it's removed from imported csv
	                foreach ( $saved_languages[ $lang_name ] as $s_lang_key => $s_lang_value ) {
		                if ( isset( $saved_languages[ $lang_name ][ $s_lang_key ] ) && ! isset( $languages_post_data[ $lang_name ][ $s_lang_key ] ) ) {
			                unset( $saved_languages[ $lang_name ][ $s_lang_key ] );
		                }
	                }
                }

                $languages_post_data[$lang_name] = (array)$language;

                if (empty($saved_languages[$lang_name])) {
                    $saved_languages[$lang_name] = array();
                }

                if (empty($languages_post_data[$lang_name])) {
                    $languages_post_data[$lang_name] = array();
                }

                //Merge new changes with saved languages string
                $languages_post_data[$lang_name] = array_merge($saved_languages[$lang_name], $languages_post_data[$lang_name]);
            }

            // Save Uploads
            BuddyBossAppLanguages::instance()->update_languages( $languages_post_data);

            wp_send_json_success(__( "Language has been saved.", 'buddyboss-app' ));

        }

        die(0);

    }

}
