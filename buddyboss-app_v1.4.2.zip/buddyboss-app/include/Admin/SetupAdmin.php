<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\InAppPurchases\SubscriptionGroupTaxonomy;
use BuddyBossApp\Permissions;

class SetupAdmin {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return SetupAdmin
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	public function _load() {

		// Initiate hooks
		$this->hooks();

		// Load the required classes.
		Components::instance();
		Settings::instance();
		Integrations::instance();
		Appearance::instance();
		AppLanguages::instance();
		if ( bbapp_is_active( "iap" ) ) {
			InAppPurchases::instance();
		}
		if ( bbapp_is_active( "push_notification" ) ) {
			Notification::instance();
		}
		Build::instance();
		BuildUpload::instance();
		Configure::instance();
		Publish::instance();
		ManageApp::instance();
		Debug::instance();

	}

	public function hooks() {
		if ( is_admin() ) {
			add_action( 'admin_menu', array( $this, 'setup_menus' ), 21 );

			// Only render the BuddyBossApp Nav on Network Dashboard when it's a Network Enabled.
			if ( bbapp()->is_network_activated() ) {
				add_action( 'network_admin_menu', array( $this, 'setup_menus' ), 21 );
			}

			add_action( 'admin_init', array( $this, 'adjust_the_menus' ) );
			add_action( 'admin_notices', array( $this, 'admin_notices' ) );
			add_action( 'all_admin_notices', array( $this, 'render_tabs' ) );
			add_filter( 'parent_file', array($this,'bbapp_set_current_menu') );
			// About Screens
			add_action( 'admin_footer', array( $this, 'about_bbapp_screen' ) );
			add_action( 'admin_init', array( $this, 'do_activation_redirect' ) );

			// Add link to settings page.
			add_filter( 'plugin_action_links', array( $this, 'actions_links' ), 10, 2 );
			add_filter( 'network_admin_plugin_action_links', array( $this, 'actions_links' ), 10, 2 );

			// Admin notice dismiss js.
			add_action( 'admin_footer', array( $this, 'admin_notices_dismiss_js' ) );

		}
	}

	/**
	 * Register new cpt,taxonomy in buddyboss-app menu.
	 *
	 * @param $parent_file
	 *
	 * @return string
	 */
	public function bbapp_set_current_menu( $parent_file ) {
		global $current_screen;
		if ( $current_screen->post_type === 'app_page' ) {
			$parent_file = 'bbapp-settings';
		}

		return $parent_file;
	}

	/**
	 * Show admin notice for connect app
	 */
	public function admin_notices() {
		global $pagenow;

		if ( ( $pagenow == "edit.php" && isset( $_GET["post_type"] ) && $_GET["post_type"] === "app_page" )
		     || ( $pagenow == "admin.php" && isset( $_GET["page"] ) && substr( $_GET["page"], 0, strlen( 'bbapp-' ) ) === 'bbapp-' ) ) {

			//Notice for all connect
			if ( ! $this->is_current_app_connected() ) {
				$class = 'notice notice-info';

				$linkurl = bbapp_get_admin_url( "admin.php?page=bbapp-connect" );

				if ( isset( $_GET['app'] ) && ! empty( $_GET['app'] ) ) {
					$linkurl = add_query_arg( 'app', $_GET['app'], $linkurl );
				}
				$message = sprintf( __( 'Your app is not yet connected. <a href="%s">Manage your app connection.</a>', "buddyboss-app" ), $linkurl );
				printf( '<div id="bbapp-site-connect-notice" class="%1$s"><p>%2$s</p></div>', esc_attr( $class ), $message );
			}

			do_action('bbapp_admin_notice');
		}
	}

	/**
	 * Setup all admin menus found available in plugin.
	 */
	public function setup_menus() {

		$bbapp = \BuddyBossApp\ManageApp::instance()->get_app();

		$bbapp_sub_menus = array();

		// Settings Menu
		$menu_label                          = __( 'Components', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-components"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-components',
			array( $this, 'ComponentsScreen' )
		);

		// Settings Menu
		$menu_label                        = __( 'Settings', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-settings"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-settings',
			array( $this, 'SettingScreen' )
		);

		// Integrations Menu
		$menu_label                            = __( 'Integrations', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-integrations"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-integrations',
			array( $this, 'IntegrationsScreen' )
		);

		// Appearance Menu
		$menu_label                          = __( 'Branding', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-appearance"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-appearance',
			array( $this, 'AppLayoutScreen' )
		);

		// Translations Menu
		$menu_label                            = __( 'Translations', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-translations"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-translations',
			array( $this, 'TranslationsScreen' )
		);

		// Tools Menu
		$menu_label = __( 'Tools', 'buddyboss-app' );

		$bbapp_sub_menus["bbapp-tools"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-tools',
			array( $this, 'bbapp_import_export_screen' ),
		);


		// Help menu
		$menu_label                    = __( 'Help', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-help"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-help',
			array( $this, 'HelpScreen' )
		);

		// Separator
		$bbapp_sub_menus["bbapp-first-sap"] = array(
			'bbapp-settings',
			'',
			'',
			'manage_options',
			'bbapp-plugin-separator-notice',
			''
		);


		// App Pages Menu
		$native_pages                   = 'edit.php?post_type=app_page';
		$menu_label                     = __( 'App Pages', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-pages"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			$native_pages
		);

		// Notifications Menu
		if ( bbapp_is_active( "push_notification" ) ) {
			$menu_label                            = __( 'Push Notifications', 'buddyboss-app' );
			$bbapp_sub_menus["bbapp-notification"] = array(
				'bbapp-settings',
				$menu_label,
				$menu_label,
				'manage_options',
				'bbapp-notification',
				array( $this, 'NotificationScreen' )
			);
		}

		// InApp Purchases Menu
		if ( bbapp_is_active( "iap" ) ) {
			$menu_label                   = __( 'In-App Purchases', 'buddyboss-app' );
			$bbapp_sub_menus["bbapp-iap"] = array(
				'bbapp-settings',
				$menu_label,
				$menu_label,
				'manage_options',
				'bbapp-iap',
				array( $this, 'IapScreen' )
			);
		}


		// Separator
		$bbapp_sub_menus["bbapp-second-sap"] = array(
			'bbapp-settings',
			'',
			'',
			'manage_options',
			'bbapp-plugin-separator-notice',
			''
		);

		// Connect Menu
		$manage_app_label                 = __( 'Connect', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-connect"] = array(
			'bbapp-settings',
			$manage_app_label,
			$manage_app_label,
			'manage_options',
			'bbapp-connect',
			array( $this, 'ManageScreen' )
		);

		// Configure Menu.
		$manage_app_label                   = __( 'Configure', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-configure"] = array(
			'bbapp-settings',
			$manage_app_label,
			$manage_app_label,
			'manage_options',
			'bbapp-configure',
			array( $this, 'ManageConfiguration' )
		);

		// Build Menu.
		$menu_label                     = __( 'Build', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-build"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-build',
			array( $this, 'BuildScreen' )
		);

		$menu_label                            = __( 'Upload', 'buddyboss-app' );
		$menu_title                            = __( 'Build Upload', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-build-upload"] = array(
			'bbapp-settings',
			$menu_title,
			$menu_label,
			'manage_options',
			'bbapp-build-upload',
			array( $this, 'UploadScreen' )
		);

		// Separator
		$bbapp_sub_menus["bbapp-third-sap"] = array(
			'bbapp-settings',
			'',
			'',
			'manage_options',
			'bbapp-plugin-separator-notice',
			''
		);

		// Publish menu
		$menu_label                     = __( 'Publishing Service', 'buddyboss-app' );
		$bbapp_sub_menus["bbapp-publish-page"] = array(
			'bbapp-settings',
			$menu_label,
			$menu_label,
			'manage_options',
			'bbapp-publish',
			array( $this, 'PublishScreen' )
		);

		/**
		 * Only regular wp admin dashboard
		 */
		if ( ! bbapp_is_admin_page() ) {

            // Remove Branding & Translation tab in network admin.
			unset( $bbapp_sub_menus["bbapp-appearance"] );
			unset( $bbapp_sub_menus["bbapp-translations"] );
			unset( $bbapp_sub_menus["bbapp-notification"] );
			unset( $bbapp_sub_menus["bbapp-pages"] );
		}

		/**
		 * Super admin dashboard. or Wp Admin dashboard.
		 */
		if ( bbapp_is_admin_page() && ! bbapp_is_super_admin_page() ) {

			unset( $bbapp_sub_menus["bbapp-integrations"] );
			if ( isset( $bbapp_sub_menus["bbapp-help"] ) ) {
				unset( $bbapp_sub_menus["bbapp-help"] );
			}

			unset( $bbapp_sub_menus["bbapp-second-sap"] );
			unset( $bbapp_sub_menus["bbapp-build"] );
			unset( $bbapp_sub_menus["bbapp-build-upload"] );
			unset( $bbapp_sub_menus["bbapp-connect"] );
			unset( $bbapp_sub_menus["bbapp-configure"] );
			//unset( $bbapp_sub_menus["bbapp-logs"] );
			unset( $bbapp_sub_menus["bbapp-tools"] );

		}

		foreach ( $bbapp_sub_menus as $k => $menu ) {
			if ( ! isset( $menu[5] ) ) {
				add_submenu_page(
					$menu[0],
					$menu[1],
					$menu[2],
					$menu[3],
					$menu[4] );
			} else {
				add_submenu_page(
					$menu[0],
					$menu[1],
					$menu[2],
					$menu[3],
					$menu[4],
					$menu[5] );
			}
		}
	}

	public function adjust_the_menus() {
		global $menu;

		/**
		 * Remove any sap before bbapp menu.
		 */
		$bbapp_found = false;
		$saps          = array();

		if ( is_array( $menu ) ) {

			foreach ( $menu as $index => $m ) {
				// remove sap after buddyboss menu.
				if ( $m[2] == "separator1" ) {
					$saps[] = $index;
				}
				if ( $m[2] == "bbapp-settings" ) {
					$bbapp_found = $index;
					break;
				}
			}
		}


		if ( $bbapp_found ) {
			foreach ( $saps as $sap_index ) {
				unset( $menu[ $sap_index ] );
			}
		}

		/**
		 * Fix the index. Solving index contains decimals.
		 */
		$tmp = array();
		if ( is_array( $menu ) ) {

			foreach ( $menu as $m ) {
				$tmp[] = $m;
			}
		}

		$menu = $tmp;

		/**
		 * Here we will forcefully add separator after bbapp menu.
		 */
		$bbapp_found = false;

		if ( is_array( $menu ) ) {

			// Add Separator after BuddyBossApp Menu.
			foreach ( $menu as $index => $m ) {
				if ( $bbapp_found ) {
					array_splice( $menu, $index, 0, array( "sap" ) );
					break;
				}

				if ( $m[2] == "bbapp-settings" ) {
					$bbapp_found = $index;
				}
			}
		}

		// convert all sap into separator.
		foreach ( $menu as $index => $m ) {
			if ( $m == "sap" ) {
				$menu[ $index ] = array(
					'',
					'read',
					'separator1',
					'',
					'wp-menu-separator'
				);
			}
		}


	}

	function bp_core_modify_admin_menu_highlight() {
		global $plugin_page, $submenu_file;

		// This tweaks the Settings subnav menu to show only one BuddyPress menu item.
		if ( ! in_array( $plugin_page, array( 'bp-activity', 'bp-general-settings', ) ) ) {
			$submenu_file = 'bp-components';
		}

		// Network Admin > Tools.
		if ( in_array( $plugin_page, array( 'bp-tools', 'available-tools' ) ) ) {
			$submenu_file = $plugin_page;
		}
	}

	/**
	 * Render the bbapp tabs on the pages which wordpress controls.
	 */
	public function render_tabs() {
		global $pagenow;

		if ( ! in_array( $pagenow, array( 'edit.php', 'admin.php', 'edit-tags.php' ) ) ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return false;
		}

		$render_tabs     = false;
		// WordPress Core Pages Logic Overrides.
		global $pagenow;

		/**
		 * Native Pages Tab.
		 */
		if ( $pagenow == "edit.php" && isset( $_GET["post_type"] ) && $_GET["post_type"] === "app_page" ) {
			$render_tabs      = true;
			$current_page_var = "bbapp-pages";
		}

		if ( ! $render_tabs ) {
			return false;
		}

		$old_page_var = isset( $_GET["page"] ) ? $_GET["page"] : "";
		$_GET["page"] = $current_page_var;
		?>
        <div class="wrap">
			<?php $this->primary_tabs(); ?>
        </div>
		<?php
		$_GET["page"] = $old_page_var;
		?>
        <style>
            .bbapp-subsubsub {
                width: 100%;
                border-bottom: 1px solid #e6e6e6;
                padding-bottom: 10px;
                margin-bottom: 5px;
            }
        </style>
		<?php
		$old_page_var = isset( $_GET["page"] ) ? $_GET["page"] : "";
		$_GET["page"] = $current_page_var;
		$_GET["page"] = $old_page_var;

	}

	/**
	 * @param $subsettings
	 * @param $current_tab
	 * @param string $param_key
	 *
	 * @return bool
	 */
	public function render_subtabs( $subsettings, $current_tab, $param_key = "setting" ) {

		$sub_settings = $subsettings;

		// only render something when there is more than 1 sub menu.
		if ( empty( $sub_settings ) || count( $sub_settings ) < 2 ) {
			return false;
		}

		echo '<ul class="subsubsub bbapp-subsubsub">';
		$i = 1;
		foreach ( $sub_settings as $sub_name => $sub_label ) {
			$sap = '|';
			if ( $i == count( $sub_settings ) ) {
				$sap = '';
			}
			$current = '';
			if ( $current_tab == $sub_name ) {
				$current = ' class="current"';
			}

			$page = isset( $_GET["page"] ) ? $_GET["page"] : "";

			$link = bbapp_get_admin_url( 'admin.php?page=' . $page . '&' . $param_key . '=' . $sub_name );

			if ( bbapp_is_valid_url( $sub_name ) ) {
				$link = $sub_name;
			}

			// Redirect type sub setting..
			if ( bbapp_is_valid_url( $sub_name ) ) {
				$link = $sub_name;
			}

			echo '<li><a href="' . $link . '"' . $current . '>' . $sub_label . '</a> ' . $sap . '</li>';
			$i ++;
		}
		echo '</ul>';

		echo '<div class="clear"></div>';


	}

	/**
	 * Renders Components Screen
	 */
	public function ComponentsScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Components::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * Renders Setting Screen
	 */
	public function SettingScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Settings::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * Renders Setting Screen
	 */
	public function IntegrationsScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Integrations::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * Renders Build Screen
	 */
	public function BuildScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Build::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * Renders Upload Screen
	 */
	public function UploadScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php BuildUpload::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * Renders Piblish Screen
	 */
	public function PublishScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php Publish::instance()->render_screen(); ?>
        </div>
		<?php

	}

	/**
	 * Branding Setting Screen
	 */
	public function AppLayoutScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Appearance::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * Appearance Setting Screen
	 */
	public function TranslationsScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php AppLanguages::instance()->render(); ?>

        </div>
		<?php

	}

	/**
	 * Help Setting Screen
	 */
	public function HelpScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Help::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * NotificationScreen Setting Screen
	 */
	public function NotificationScreen() {

		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Notification::instance()->render_screen(); ?>

        </div>
		<?php

	}

	/**
	 * In-App Purchase Screens
	 */
	public function IapScreen() {
		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php InAppPurchases::instance()->render_screen(); ?>

        </div>
		<?php
	}

	/**
	 * BuddyBossApp Debug Screen.
	 */
	public function bbapp_import_export_screen() {
		?>
        <div class="wrap buddyboss-app-screen">

            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>
	        <?php Debug::instance()->render_screen(); ?>
			<?php  //ImportExport::instance()->render_screen(); ?>
        </div>
		<?php
	}
	/**
	 * BuddyBossApp Debug Screen.
	 */
	public function DebugScreen() {
		?>
		<div class="wrap buddyboss-app-screen">

			<h1 style="display: none;">
				<div id="icon-options-general" class="icon32"><br></div>
			</h1>

			<?php $this->primary_tabs(); ?>

			<?php Debug::instance()->render_screen(); ?>
		</div>
		<?php
	}

	/**
	 * App Configuration Screen.
	 */
	public function ManageConfiguration() {
		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php Configure::instance()->render_screen(); ?>
        </div>
		<?php
	}

	/**
	 * App Manage Screen.
	 */
	public function ManageScreen() {
		?>
        <div class="wrap buddyboss-app-screen">
            <h1 style="display: none;">
                <div id="icon-options-general" class="icon32"><br></div>
            </h1>

			<?php $this->primary_tabs(); ?>

			<?php ManageApp::instance()->render_screen(); ?>
        </div>
		<?php
	}

	public function primary_tabs() {

		$settings_group = array(
			'bbapp-components',
			'bbapp-settings',
			'bbapp-integrations',
			'bbapp-appearance',
			'bbapp-translations',
			'bbapp-tools',
			'bbapp-help'
		);

		if ( in_array( $_GET["page"], $settings_group ) ) {
			$tabsGroups = $settings_group;
		}

		$content_group = array(
			'app_page', // for in_array logic.
			SubscriptionGroupTaxonomy::$taxonomy,
			'bbapp-pages',
			'bbapp-notification',
			'bbapp-iap',
			'bbapp-reporting'
		);

		if ( isset( $_GET["page"] ) && in_array( $_GET["page"], $content_group ) ) {
			$tabsGroups = $content_group;
		}

		if ( isset( $_GET["post_type"] ) && in_array( $_GET["post_type"], $content_group ) ) {
			$tabsGroups = $content_group;
		}

		if ( isset( $_GET["taxonomy"] ) && in_array( $_GET["taxonomy"], $content_group ) ) {
			$tabsGroups = $content_group;
		}

		$manage_group = array(
			'bbapp-build',
			'bbapp-build-upload',
			'bbapp-connect',
			'bbapp-configure'
		);

		if ( in_array( $_GET["page"], $manage_group ) ) {
			$tabsGroups = $manage_group;
		}

		/**
		 * Super admin OR regular admin Dashboard.
		 */
		if ( bbapp_is_super_admin_page() ) {

			$tabs['components'] = array(
				"label"        => __( 'Components', 'buddyboss-app' ),
				"setting_page" => "bbapp-components",
			);

			$tabs['settings'] = array(
				"label"        => __( 'Settings', 'buddyboss-app' ),
				"setting_page" => "bbapp-settings",
			);

			$tabs['integrations'] = array(
				"label"        => __( 'Integrations', 'buddyboss-app' ),
				"setting_page" => "bbapp-integrations",
			);

		}

		/**
		 * Only Regular Admin Dashboard
		 */
		if ( bbapp_is_admin_page() ) {

			$tabs['settings'] = array(
				"label"        => __( 'Settings', 'buddyboss-app' ),
				"setting_page" => "bbapp-settings",
			);

			$tabs['integrations'] = array(
				"label"        => __( 'Integrations', 'buddyboss-app' ),
				"setting_page" => "bbapp-integrations",
			);

			$tabs['appearance'] = array(
				"label"        => __( 'Branding', 'buddyboss-app' ),
				"setting_page" => "bbapp-appearance",
			);

			$tabs['translations'] = array(
				"label"        => __( 'Translations', 'buddyboss-app' ),
				"setting_page" => "bbapp-translations",
			);

			$appPageTabLink    = admin_url( "edit.php?post_type=app_page" );
			$tabs['app_pages'] = array(
				"label"        => __( 'App Pages', 'buddyboss-app' ),
				"setting_page" => "bbapp-pages",
				"link"         => $appPageTabLink
			);

			if ( bbapp_is_active( "push_notification" ) ) {
				$tabs['notification'] = array(
					"label"        => __( 'Push Notifications', 'buddyboss-app' ),
					"setting_page" => "bbapp-notification",
				);
			}

			if ( bbapp_is_active( "iap" ) ) {
				$tabs['iap'] = array(
					"label"        => __( 'In-App Purchases', 'buddyboss-app' ),
					"setting_page" => "bbapp-iap",
				);
			}

		}

		/**
		 * Super admin OR regular admin Dashboard.
		 */
		if ( bbapp_is_super_admin_page() ) {

			if ( Permissions::instance()->can_manage_app( get_current_user_id() ) ) {
				$tabs['import-export'] = array(
					"label"        => __( 'Tools', 'buddyboss-app' ),
					"setting_page" => "bbapp-tools",
					"class"        => "status",
				);
			}

		}

		/**
		 * Only Regular Admin Dashboard
		 */
		if ( bbapp_is_admin_page() ) {

			if (Permissions::instance()->can_manage_app(get_current_user_id())) {
				$tabs['help'] = array(
					"label"        => __('Help', 'buddyboss-app'),
					"setting_page" => "bbapp-help",
					"class"        => "help",
				);
			}

		}

		if ( Permissions::instance()->can_manage_app( get_current_user_id() ) && bbapp_is_super_admin_page() ) {

			$tabs['manage'] = array(
				"label"        => __( 'Connect', 'buddyboss-app' ),
				"setting_page" => "bbapp-connect",
				"class"        => 'manage',
			);

			$tabs['configure'] = array(
				"label"        => __( 'Configure', 'buddyboss-app' ),
				"setting_page" => "bbapp-configure",
				"class"        => 'manage',
			);

			$tabs['build'] = array(
				"label"        => __( 'Build', 'buddyboss-app' ),
				"setting_page" => "bbapp-build",
				"class"        => 'manage',
			);

			$tabs['build-upload'] = array(
				"label"        => __( 'Upload', 'buddyboss-app' ),
				"setting_page" => "bbapp-build-upload",
				"class"        => 'manage',
			);

		}

		/**
		 * Super admin dashboard on Network Activated or Wp Admin dashboard on Normal.
		 */
		if ( bbapp_is_admin_page() && ! bbapp_is_super_admin_page() ) {

			if ( isset( $tabs["help"] ) ) {
				unset( $tabs["help"] );
			}
			if ( isset( $tabs["integrations"] ) ) {
				unset( $tabs["integrations"] );
			}

		}

		if ( ! bbapp_is_admin_page() && bbapp_is_super_admin_page() ) {

			if ( isset( $tabs["appearance"] ) ) {
				unset( $tabs["appearance"] );
			}

			if ( isset( $tabs["translations"] ) ) {
				unset( $tabs["translations"] );
			}

			if ( isset( $tabs["notification"] ) ) {
				unset( $tabs["notification"] );
			}

			if ( isset( $tabs["app_pages"] ) ) {
				unset( $tabs["app_pages"] );
			}

		}

		?>
        <h2 class="nav-tab-wrapper bbapp-tabs">

			<?php

			foreach ( $tabs as $tab_key => $tab ) {


				if ( ! in_array( $tab["setting_page"], $tabsGroups ) ) {
					continue;
				}

				$active_class = '';

				if ( $tab["setting_page"] == $_GET["page"] && ! isset( $tab["can_active"] ) ) {
					$active_class = 'nav-tab-active';
				}

				$class = ( isset( $tab['class'] ) ) ? $tab['class'] : '';

				$tab_link = bbapp_get_admin_url( 'admin.php?page=' . $tab["setting_page"] );

				if ( isset( $tab["link"] ) ) {
					$tab_link = $tab["link"];
				}

				$dashicon = ( isset( $tab['dashicon'] ) ) ? "<span class=\"dashicons {$tab['dashicon']}\"></span> " : "";

				?>

                <a href="<?php echo esc_attr( $tab_link ); ?>"
                   class="nav-tab <?php echo esc_attr( $active_class ); ?> <?php echo esc_attr( $class ); ?>">
					<?php echo $dashicon;
					echo esc_html( $tab["label"] ); ?>
                </a>

			<?php } ?>

        </h2>
		<?php

	}

	/**
     * Tells if app is connected or not.
	 * @return bool
	 */
	public function is_current_app_connected() {
		$app = \BuddyBossApp\ManageApp::instance()->get_app();
		return isset( $app['verified'] ) && ! empty( $app['verified'] );
	}

	/**
	 * Returns which page is currently in.
	 * @return string
	 */
	public function get_page_now() {
		global $pagenow;

		return $pagenow;
	}

	/**
	 * About BuddyBossApp Popup Screen.
	 * This is shown when BuddyBoss App Plugin is Activated.
	 */
	public function about_bbapp_screen() {
		if ( 0 !== strpos( get_current_screen()->id, 'dashboard' ) || empty( $_GET['about'] ) || $_GET['about'] !== 'bbapp' ) {
			return;
		}
		include bbapp()->plugin_dir . 'views/admin/about-buddyboss-app.php';
	}

	/**
	 * Redirect on activation.
	 */
	public function do_activation_redirect() {

		// Bail if no activation redirect.
		if ( ! get_transient( '_bbapp_activation_redirect' ) ) {
			return;
		}

		// Delete the redirect transient.
		delete_transient( '_bbapp_activation_redirect' );

		// Bail if activating from network, or bulk.
		if ( isset( $_GET['activate-multi'] ) || bbapp()->is_network_activated() ) {
			return;
		}

		wp_safe_redirect( add_query_arg( array(), admin_url( '?about=bbapp' ) ) );
		exit;
	}

	/**
	 * Add Settings link to plugins area.
	 *
	 * @param $links
	 * @param $file
	 *
	 * @return array
	 */
	public function actions_links( $links, $file ) {
		// Return normal links if not BuddyPress.
		if ( plugin_basename( bbapp()->root_file ) != $file ) {
			return $links;
		}

		// Add a few links to the existing links array.
		return array_merge(
			$links,
			array(
				'settings' => '<a href="' . esc_url( bbapp_get_super_admin_url( 'admin.php?page=bbapp-settings' ) ) . '">' . __( 'Settings', 'buddyboss-app' ) . '</a>',
				'about'    => '<a href="' . esc_url( bbapp_get_super_admin_url( '?about=bbapp' ) ) . '">' . __( 'About', 'buddyboss-app' ) . '</a>',
			) );
	}

	/**
	 * Admin notice dismiss.
	 */
	public function admin_notices_dismiss_js() {
		?>
        <script type="text/javascript">
            jQuery(document).on('click', '.bbapp-is-dismissible .notice-dismiss', function (e) {
                var $notice = jQuery(this).closest('.notice');
                var notice_id = $notice.data('noticeid');
                jQuery.post(
                    {
                        url: ajaxurl,
                        data: {
                            action: 'bbapp_dismiss_notice',
                            nonce: jQuery('#bbapp-dismissible-nonce-' + notice_id).val(),
                            notice_id: notice_id
                        }
                    }
                );
            });
        </script>
		<?php
	}

}
