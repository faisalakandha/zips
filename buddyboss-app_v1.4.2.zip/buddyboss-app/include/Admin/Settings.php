<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\AppStores\Apple;
use BuddyBossApp\Auth\Auth;
use BuddyBossApp\ManageApp;
use BuddyBossApp\Performance\BuddyBossApp_Performance;

class Settings {

	private static $instance;
	public $settings_form;

	/**
	 * Get the instance of the class.
	 *
	 * @return Settings
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	public function _load() {
		// Update performance components setting on active / deactivate component.
		add_action( "bbapp_components_activate", array( $this, "update_performance_component_setting" ) );
		add_action( "bbapp_components_deactivate", array( $this, "update_performance_component_setting" ) );

		add_action( 'admin_init', array( $this, 'load_init' ), 0 );
	}

	public function load_init() {
		global $pagenow;

		$buildLink = bbapp_get_admin_url( "admin.php?page=bbapp-build" );

		/**
		 * Only load on bbapp-settings page.
		 */
		if ( SetupAdmin::instance()->get_page_now() != "admin.php" || $_GET['page'] != 'bbapp-settings' ) {
			return false;
		}

		// If the current subtab is link redirect it.
		if ( bbapp_is_valid_url( $this->get_current_sub_tab() ) && ! isset( $_GET["setting"] ) ) {
			wp_redirect( $this->get_current_sub_tab() );
			exit;
		}

		$this->settings_form = new FormProvider( 'settings' );

		// holds app settings storage handle.
		$app_settings_provider = new SettingProvider( 'app_settings' );

		// holds global settings storage handle.
		$app_global_settings_provider = new SettingProvider( 'app_global_settings' );

		// register app settings storing & receiving
		$app_global_settings_provider->save_setting_hook( array( $this, 'save_global_settings' ) );
		$app_global_settings_provider->get_setting_hook( array( $this, 'get_global_settings' ) );

		// register app settings storing & receiving
		$app_settings_provider->save_setting_hook( array( $this, 'save_settings' ) );
		$app_settings_provider->get_setting_hook( array( $this, 'get_settings' ) );

		// Link Provider In Form Provider
		$this->settings_form->link_setting_provider( $app_global_settings_provider );
		$this->settings_form->link_setting_provider( $app_settings_provider );

		//Handle cache purge event if cache code exist.
		if ( bbapp_is_active( 'performance' ) && class_exists( '\BuddyBoss\Performance\Settings' ) ) {
			// Performance Settings Provider
			$performance_settings_provider = new SettingProvider( 'performance_settings' );

			// register Performance storing & receiving
			$performance_settings_provider->save_setting_hook( array( $this, 'performance_save_settings' ) );
			$performance_settings_provider->get_setting_hook( array( $this, 'performance_get_settings' ) );
			$this->settings_form->link_setting_provider( $performance_settings_provider );

			add_action( "admin_init", array( $this, "handle_purge_cache" ) );
		}

		add_action( "admin_init", array( $this->settings_form, "save" ) );

		/**
		 * General
		 */
		if ( $this->get_current_sub_tab() == 'general' ) {

			/**
			 * Registration
			 */
			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-registration',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'app_registration_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Registration', 'buddyboss-app' ),
				'desc'         => '',
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121791' ),
			) ) );


			$signup_desc = ( bbapp()->is_network_activated() ) ? __( 'This feature requires enabling WordPress registration at <a href="%s">Network Settings</a>.', 'buddyboss-app' ) : __( 'This feature requires enabling WordPress registration at <a href="%s">General Settings</a>.', 'buddyboss-app' );
			if ( bbapp()->is_network_activated() ) {
				$signup_desc = sprintf( $signup_desc, bbapp_get_super_admin_url( "settings.php" ) );
			} else {
				$signup_desc = sprintf( $signup_desc, bbapp_get_super_admin_url( "options-general.php" ) );
			}

			$args = array(
				'label'          => __( 'Enable Registration', 'buddyboss-app' ),
				'label_checkbox' => __( 'Allow registering a new account from within the app', 'buddyboss-app' ),
				'desc'           => $signup_desc,
				'type'           => 'checkbox',
				'value'          => false,
			);

			if ( ! Auth::instance()->is_registration_available() ) {
				$args["disabled"]       = true;
				$args["override_value"] = false;
			}

			$this->settings_form->add_field( $app_global_settings_provider->field( 'app_auth.enable_signup', $args ) );

			if ( defined( 'BP_PLATFORM_VERSION' ) ) {
				// Added new option for the registration section.
				$this->settings_form->add_field( $app_global_settings_provider->field( 'app_auth.signup_form', array(
					'label'   => __( 'Registration Form', 'buddyboss-app' ),
					'type'    => 'select',
					'options' => array( 'buddyboss_registration' => __( 'BuddyBoss Registration', 'buddyboss-app' ), 'wordpress_registration' => __( 'WordPress Registration', 'buddyboss-app' ) ),
					'desc'    =>  function () {
						$desc = '';
						$desc .= sprintf( '<div id="buddyboss_registration" class="registration_description">%s</div>', __( 'Use the BuddyBoss Platform registration process in the app.', 'buddyboss-app' ) );
						$desc .= sprintf( '<div id="wordpress_registration" class="registration_description">%s</div>', __( 'Use the default WordPress registration process in the app.', 'buddyboss-app' ) );
						return $desc;
					},
				) ) );	
			}

			if ( function_exists( 'bp_enable_site_registration' ) && Auth::instance()->is_registration_available() ) {

				$this->settings_form->add_field( $app_global_settings_provider->field( 'app_auth.email_activation_body', array(
					'label'  => __( 'Activation Email Body', 'buddyboss-app' ),
					'desc'   => sprintf( __( 'This text will be appended to the activation email sent from BuddyBoss Platform. Make sure to include the following tags: %s', 'buddyboss-app' ), '<code>{{KEY_CODE}}</code> <code>{{KEY_CODE_LINK}}</code>' ),
					'type'   => 'textarea',
					'value'  => '',
					'filter' => function ( $value ) {
						return $value;
					},
				) ) );

			}

			/**
			 * Privacy
			 */

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-privacy',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'privacy_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Privacy', 'buddyboss-app' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121745' ),
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'private_app.enabled', array(
				'label'          => __( 'Private App', 'buddyboss-app' ),
				'label_checkbox' => __( 'Restrict app access to only logged-in members', 'buddyboss-app' ),
				'desc'           => function() {
					$desc = __( 'Require users to log into the app to view all content. When disabled, public app content will be visible while logged out, and users will be prompted to log in or register when trying to interact with content.', 'buddyboss-app' );
					if ( defined( 'BP_PLATFORM_VERSION' ) ) {
						$desc .= '<p class="bbapp-notice-box bbapp-notice-box--info">';
						if ( true === bbapp_is_private_app_enabled() ) {
							$desc .= sprintf(
								wp_kses_post(
								/* translators: Settings link. */
									__( 'To restrict access to your REST APIs for members who are not logged in, enable Private REST APIs in the %s.', 'buddyboss-app' )
								),
								sprintf(
									'<a href="%s">' . esc_html__( 'BuddyBoss Platform\' settings', 'buddyboss' ) . '</a>',
									esc_url(
										add_query_arg(
											array( 'page' => 'bp-settings&tab=bp-general' ),
											admin_url( 'admin.php' )
										)
									)
								)
							);
						} else {
							$desc .= sprintf(
								wp_kses_post(
								/* translators: Settings link. */
									__( 'Once your app is private, you can restrict access to your REST APIs for logged-out members in the %s.', 'buddyboss-app' )
								),
								sprintf(
									'<a href="%s">' . esc_html__( 'BuddyBoss Platform\' settings', 'buddyboss' ) . '</a>',
									esc_url(
										add_query_arg(
											array( 'page' => 'bp-settings&tab=bp-general' ),
											admin_url( 'admin.php' )
										)
									)
								)
							);
						}
						$desc .= '</p>';
					}
					return $desc;
				},
				'type'           => 'checkbox',
				'value'          => false,
			) ) );

			/**
			 * Website Password
			 */

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'browser_auth_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Website Authentication', 'buddyboss-app' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121749' ),
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'browser_auth.enabled', array(
				'label'          => __( 'Require Password', 'buddyboss-app' ),
				'label_checkbox' => __( 'Require password to view website', 'buddyboss-app' ),
				'desc'           => __( 'Website content will be blocked from visitors until entering a password. Only the Login page will be publicly accessible. Other web/HTTP authentication systems may block the app from receiving API data, so please disable them and use this option instead to test your app on a restricted website.', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => false,
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'browser_auth.password', array(
				'label'  => __( 'Website Password', 'buddyboss-app' ),
				'desc'   => __( 'The required password to view the website.', 'buddyboss-app' ),
				'type'   => 'password',
				'filter' => function ( $value ) {
					return $value;
				},
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'browser_auth.message', array(
				'label'  => __( 'Website Notice', 'buddyboss-app' ),
				'desc'   => __( 'Display this notice to site visitors who did not enter the password yet.', 'buddyboss-app' ),
				'type'   => 'textarea',
				'value'  => __( 'This website requires a password. Please enter your password below.', 'buddyboss-app' ),
				'filter' => function ( $value ) {
					return $value;
				},
			) ) );
		}

		/**
		 * Feedback
		 */
		if ( $this->get_current_sub_tab() == 'feedback' ) {

			/**
			 * Send us Feedback
			 */

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-feedback',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'app_feedback_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Send us Feedback', 'buddyboss-app' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121753' ),
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'support_email.enabled', array(
				'label'          => __( 'Send us Feedback', 'buddyboss-app' ),
				'label_checkbox' => __( 'Enable "Send us Feedback" menu in app', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'desc'           => __( 'In the app interface, users can go into "Settings" and tap "Send us Feedback" to submit feedback.', 'buddyboss-app' ),
				'value'          => true,
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'support_email.email', array(
				'label'  => __( 'Feedback Email', 'buddyboss-app' ),
				'type'   => 'text',
				'desc'   => __( 'Enter the email address to send feedback to. If left empty the <strong>Administration Email Address</strong> from your WordPress settings will be used instead.', 'buddyboss-app' ),
				'value'  => get_option( 'admin_email' ),
				'filter' => function ( $value ) {
					if ( ! is_email( $value ) ) {
						return '';
					}

					return $value;
				},
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'support_email.subject', array(
				'label' => __( 'Email Subject', 'buddyboss-app' ),
				'type'  => 'text',
				'desc'  => __( 'Enter the subject line for all of the feedback emails.', 'buddyboss-app' ),
				'value' => sprintf( __( '[%s] Send us Feedback', 'buddyboss-app' ), get_option( 'blogname' ) ),
			) ) );

			/**
			 * Report a Bug
			 */

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-report_bug',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'app_report_bug_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Report a Bug', 'buddyboss-app' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121754' ),
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'bugs_email.enabled', array(
				'label'          => __( 'Report a Bug', 'buddyboss-app' ),
				'label_checkbox' => __( 'Enable "Report a Bug" menu in app', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'desc'           => __( 'In the app interface, users can go into "Settings" and tap "Report a Bug" to submit a bug report.', 'buddyboss-app' ),
				'value'          => false,
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'bugs_email.email', array(
				'label'  => __( 'Bug Report Email', 'buddyboss-app' ),
				'type'   => 'text',
				'desc'   => __( 'Enter the email address to send bug reports to. If left empty the <strong>Administration Email Address</strong> from your WordPress settings will be used instead.', 'buddyboss-app' ),
				'value'  => get_option( 'admin_email' ),
				'filter' => function ( $value ) {
					if ( ! is_email( $value ) ) {
						return '';
					}

					return $value;
				},
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'bugs_email.subject', array(
				'label' => __( 'Email Subject', 'buddyboss-app' ),
				'type'  => 'text',
				'desc'  => __( 'Enter the subject line for all of the bug report emails.', 'buddyboss-app' ),
				'value' => sprintf( __( '[%s] Report a Bug', 'buddyboss-app' ), get_option( 'blogname' ) ),
			) ) );

			/**
			 * App Rating
			 */

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-rating',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'app_rating_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Rate this App', 'buddyboss-app' ),
				'desc'         => __( 'When activated, members can go into "Settings" and tap "Rate this App" to be sent to the Apple App Store or Google Play Store to leave a rating. Disabling this option will <strong><em>not</em></strong> turn off ratings in these stores. It is recommended you only activate Rate this App after your app is published as the option will link to your store listings.', 'buddyboss-app' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=122283' ),
			) ) );

			$ios_app_id = Apple::instance()->get_ios_store_app_id();
			if ( ! empty( $ios_app_id ) ) {
				$app_rating_ios_enabled = array(
					'label'          => __( 'Enable on iOS', 'buddyboss-app' ),
					'label_checkbox' => __( 'Enable "Rate this App" on iOS apps', 'buddyboss-app' ),
					'type'           => 'checkbox',
					'value'          => false,
				);
			} else {
				$app_rating_ios_enabled = array(
					'label' => __( 'Enable on iOS', 'buddyboss-app' ),
					'value' => sprintf( __( 'Enter an App ID in the <a href="%s">iOS settings</a> to enable on your iOS app', 'buddyboss-app' ), bbapp_get_super_admin_url( 'admin.php?page=bbapp-configure&setting=ios' ) ),
					'type'  => 'html',
				);
			}
			$this->settings_form->add_field( $app_settings_provider->field( 'app_rating.ios.enabled', $app_rating_ios_enabled ) );

			$android_application_id = Configure::instance()->option( 'publish.android.namespace', false );
			if ( ! empty( $android_application_id ) ) {
				$app_rating_android_enabled = array(
					'label'          => __( 'Enable on Android', 'buddyboss-app' ),
					'label_checkbox' => __( 'Enable "Rate this App" on Android apps', 'buddyboss-app' ),
					'type'           => 'checkbox',
					'value'          => false,
				);
			} else {
				$app_rating_android_enabled = array(
					'label' => __( 'Enable on Android', 'buddyboss-app' ),
					'value' => sprintf( __( 'Enter an Application ID in the <a href="%s">Android settings</a> to enable on your Android app', 'buddyboss-app' ), bbapp_get_super_admin_url( 'admin.php?page=bbapp-configure&setting=android' ) ),
					'type'  => 'html',
				);
			}
			$this->settings_form->add_field( $app_settings_provider->field( 'app_rating.android.enabled', $app_rating_android_enabled ) );
		}

		/**
		 * Smart Banner
		 */
		if ( $this->get_current_sub_tab() == 'smart_banner' ) {

			/**
			 * Smart Banner
			 */

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-banner smart-banner-settings_form',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'smart_banner_heading', array(
				'type'         => 'heading',
				'value'        => __( 'Smart Banner', 'buddyboss-app' ),
				'desc'         => sprintf( __( 'When viewing this website from a mobile browser, a <a href="%s" target="_blank">smart banner</a> can be displayed to promote your app to your members. It is recommended you only activate Smart Banner after your app is published as the banner will link to your store listings.', 'buddyboss-app' ), 'https://developer.apple.com/library/archive/documentation/AppleApplications/Reference/SafariWebContent/PromotingAppswithAppBanners/PromotingAppswithAppBanners.html' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=122282' ),
			) ) );

			$ios_app_id = Apple::instance()->get_ios_store_app_id();
			if ( ! empty( $ios_app_id ) ) {
				$app_smartbanner_ios_enabled = array(
					'label'          => __( 'Enable on iOS', 'buddyboss-app' ),
					'label_checkbox' => __( 'Enable smart banner on iOS web browsers', 'buddyboss-app' ),
					'type'           => 'checkbox',
					'value'          => false,
				);
			} else {
				$app_smartbanner_ios_enabled = array(
					'label' => __( 'Enable on iOS', 'buddyboss-app' ),
					'value' => sprintf( __( 'Enter an App ID in the <a href="%s">iOS settings</a> to enable on iOS mobile browsers', 'buddyboss-app' ), bbapp_get_super_admin_url( 'admin.php?page=bbapp-configure&setting=ios' ) ),
					'type'  => 'html',
				);
			}
			$this->settings_form->add_field( $app_settings_provider->field( 'app_smartbanner.ios.enabled', $app_smartbanner_ios_enabled ) );

			$android_application_id = Configure::instance()->option( 'publish.android.namespace', false );
			if ( ! empty( $android_application_id ) ) {
				$app_smartbanner_android_enabled = array(
					'label'          => __( 'Enable on Android', 'buddyboss-app' ),
					'label_checkbox' => __( 'Enable smart banner on Android web browsers', 'buddyboss-app' ),
					'type'           => 'checkbox',
					'value'          => false,
				);
			} else {
				$app_smartbanner_android_enabled = array(
					'label' => __( 'Enable on Android', 'buddyboss-app' ),
					'value' => sprintf( __( 'Enter an Application ID in the <a href="%s">Android settings</a> to enable on iOS mobile browsers', 'buddyboss-app' ), bbapp_get_super_admin_url( 'admin.php?page=bbapp-configure&setting=android' ) ),
					'type'  => 'html',
				);
			}
			$this->settings_form->add_field( $app_settings_provider->field( 'app_smartbanner.android.enabled', $app_smartbanner_android_enabled ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'app_smartbanner.logged_in_only', array(
				'label'          => __( 'Only to logged in users', 'buddyboss-app' ),
				'label_checkbox' => __( 'Require users to be logged into your website to see the smart banner', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => false,
			) ) );
		}

		/**
		 * Push Notification
		 */
		if ( $this->get_current_sub_tab() == 'push_notifications' ) {
			Notification::instance()->loadSettings();
		}

		/**
		 * InApp Purchase
		 */
		if ( $this->get_current_sub_tab() == 'inapp_purchases' ) {
			InAppPurchases::instance()->loadSettings();
		}

		if ( $this->get_current_sub_tab() == 'compatibility' ) {
			/**
			 * Compatibility  Settings
			 */
			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-compatibility',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'compatibility.custom_tab.header', array(
				'type'  => 'heading',
				'value' => __( 'Custom Tabs','buddyboss-app' ),
				'desc'  => '',
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=124848' ),
			) ) );

			// Lock App if user has not purchased a product
			$this->settings_form->add_field( $app_settings_provider->field( 'compatibility.custom_tab.profile', array(
				'label'          => __( 'Custom Profile Tabs', 'buddyboss-app' ),
				'label_checkbox' => __( 'Enable custom profile tabs in BuddyBoss App', 'buddyboss-app' ),
				'desc'           => __( 'Show profile tabs added by unsupported third-party plugins or code in your app. If a tab doesn\'t have an associated native screen, it will load in a web fallback.', 'buddyboss-app' ),
				'type'           => 'checkbox',
			) ) );

			// Purchase before registration.
			$this->settings_form->add_field( $app_settings_provider->field( 'compatibility.custom_tab.group', array(
				'label'          => __( 'Custom Group Tabs', 'buddyboss-app' ),
				'label_checkbox' => __( 'Enable custom group tabs in BuddyBoss App.', 'buddyboss-app' ),
				'desc'           => __( 'Show groups tabs added by unsupported third-party plugins or code in your app. If a tab doesn\'t have an associated native screen, it will load in a web fallback.', 'buddyboss-app' ),
				'type'           => 'checkbox',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-admin-link-compatibility',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'compatibility.link.header', array(
				'type'         => 'heading',
				'value'        => __( 'Link Handling', 'buddyboss-app' ),
				'desc'         => '',
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=124902' ),
			) ) );

			// Open links in.
			$this->settings_form->add_field( $app_settings_provider->field( 'compatibility.open_link_in', array(
				'label'   => __( 'Open Links in', 'buddyboss-app' ),
				'desc'    => __( 'Select whether external links should open in the in-app-browser, an external browser, or left to the member to decide.', 'buddyboss-app' ),
				'type'    => 'select',
				'options' => array(
					'in_app_browser'   => __( 'In-App Browser', 'buddyboss-app' ),
					'external_browser' => __( 'External Browser', 'buddyboss-app' ),
					'ask_member'       => __( 'Ask Member', 'buddyboss-app' )
				),
			) ) );

		}

		/**
		 * Cache Support - Settings
		 */
		if ( bbapp_is_active( 'performance' ) && $this->get_current_sub_tab() == 'cache_support' && class_exists( '\BuddyBoss\Performance\Settings' ) ) {


			$purge_nonce = \BuddyBoss\Performance\Settings::get_purge_nonce();

			// Introduction
			$this->settings_form->add_field( $performance_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-caching-card',
			) ) );

			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_support_heading_introduction', array(
				'type'         => 'heading',
				'value'        => __( 'API Caching', 'buddyboss-app' ),
				'desc'         => sprintf( __( 'API Caching improves the response time for API requests. Third party plugins or custom code that interacts with API data  may conflict with the cache. This can be resolved by disabling the cache for that component, or by adding your own <a href="%s" target="_blank">custom code</a> for supporting additional API data in the cache.', 'buddyboss-app' ), "https://www.buddyboss.com/resources/dev-docs/app-development/extending-the-buddyboss-app-plugin/extending-api-caching-to-support-new-api-endpoints/" ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121851' ),
			) ) );

            // BuddyBoss App
			$this->settings_form->add_field( $performance_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-caching-card',
			) ) );
			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_support_heading_bbapp', array(
				'type'  => 'heading',
				'value' => __( 'BuddyBoss App', 'buddyboss-app' ),
				'desc'  => '<a class="button button-primary purge-all-btn" href="' . bbapp_get_super_admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=bbapp&component=all&nonce=' . $purge_nonce ) . '">' . __( 'Purge All', 'buddyboss-app' ) . '</a>',
			) ) );
			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_app_core', array(
				'label'          => __( 'App Core', 'buddyboss-app' ),
				'label_checkbox' => __( 'Cache App Core', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => true,
				'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=bbapp&component=app_core&nonce=' . $purge_nonce ),
			) ) );

			// WordPress
			$this->settings_form->add_field( $performance_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card bbapp-caching-card',
			) ) );

			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_support_heading_wordpress', array(
				'type'  => 'heading',
				'value' => __( 'Pages and Posts', 'buddyboss-app' ),
				'desc'  => '<a class="button button-primary purge-all-btn" href="' . bbapp_get_super_admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=wordpress&component=all&nonce=' . $purge_nonce ) . '">' . __( 'Purge All', 'buddyboss-app' ) . '</a>',
			) ) );

			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_app_page', array(
				'label'          => __( 'App Pages', 'buddyboss-app' ),
				'label_checkbox' => __( 'Cache App Pages', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => true,
				'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=wordpress&component=app_page&nonce=' . $purge_nonce ),
			) ) );

			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_blog_post', array(
				'label'          => __( 'Blog Posts', 'buddyboss-app' ),
				'label_checkbox' => __( 'Cache Blog Posts', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => true,
				'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=wordpress&component=blog_post&nonce=' . $purge_nonce ),
			) ) );

			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_post_comment', array(
				'label'          => __( 'Blog Comments', 'buddyboss-app' ),
				'label_checkbox' => __( 'Cache Blog Comments', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => true,
				'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=wordpress&component=post_comment&nonce=' . $purge_nonce ),
			) ) );

			$this->settings_form->add_field( $performance_settings_provider->field( 'cache_categories', array(
				'label'          => __( 'Blog Categories', 'buddyboss-app' ),
				'label_checkbox' => __( 'Cache Blog Categories', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => true,
				'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=wordpress&component=categories&nonce=' . $purge_nonce ),
			) ) );

			if ( class_exists( 'BuddyBossApp\Performance\BuddyBossApp_Performance' ) ) {
				$custom_supports = BuddyBossApp_Performance::get_custom_setting();
				if ( ! empty( $custom_supports ) ) {
					foreach ( $custom_supports as $custom_support ) {
						$this->settings_form->add_field( $performance_settings_provider->field( 'cache_' . $custom_support['slug'], array(
							'label'          => $custom_support['label'],
							'label_checkbox' => $custom_support['label_checkbox'],
							'type'           => 'checkbox',
							'value'          => isset( $custom_support['default_enabled'] ) ? $custom_support['default_enabled'] : true,
							'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=wordpress&component=' . $custom_support['slug'] . '&nonce=' . $purge_nonce ),
						) ) );
					}
				}
			}

			// BuddyBoss Platform
			if ( function_exists( 'buddypress' ) && isset( buddypress()->buddyboss ) && buddypress()->buddyboss ) {

				$bp_platform_api_setting = \BuddyBoss\Performance\Settings::get_performance_components();

				$this->settings_form->add_field( $performance_settings_provider->field( false, array(
					'type'    => 'table-open',
					'classes' => 'buddyboss-app-admin-card bbapp-caching-card',
				) ) );

				foreach ( $bp_platform_api_setting as $groupSettingKey => $group_setting ) {
					$this->settings_form->add_field( $performance_settings_provider->field( 'cache_support_heading_' . $groupSettingKey, array(
						'type'  => 'heading',
						'value' => $group_setting['title'],
						'desc'  => '<a class="button button-primary purge-all-btn" href="' . $group_setting['purge_url'] . '">' . __( 'Purge All', 'buddyboss-app' ) . '</a>',
					) ) );

					foreach ( $group_setting['settings'] as $performance_setting_key => $performance_setting ) {
						$field_setting = array();
						if ( isset( $performance_setting['label'] ) ) {
							$field_setting['label'] = $performance_setting['label'];
						}
						if ( isset( $performance_setting['label_checkbox'] ) ) {
							$field_setting['label_checkbox'] = $performance_setting['label_checkbox'];
						}
						if ( isset( $performance_setting['desc'] ) ) {
							$field_setting['desc'] = $performance_setting['desc'];
						}
						if ( isset( $performance_setting['type'] ) ) {
							$field_setting['type'] = $performance_setting['type'];
						}
						if ( isset( $performance_setting['value'] ) ) {
							$field_setting['value'] = $performance_setting['value'];
						}
						if ( isset( $performance_setting['purge_url'] ) ) {
							$field_setting['purge_url'] = $performance_setting['purge_url'];
						}
						$this->settings_form->add_field( $performance_settings_provider->field( $performance_setting_key, $field_setting ) );
					}
				}
			}

			// LearnDash
			if ( defined( 'LEARNDASH_VERSION' ) ) {

				$this->settings_form->add_field( $performance_settings_provider->field( false, array(
					'type'    => 'table-open',
					'classes' => 'buddyboss-app-admin-card bbapp-caching-card',
				) ) );

				$this->settings_form->add_field( $performance_settings_provider->field( 'cache_support_heading_learndash', array(
					'type'  => 'heading',
					'value' => __( 'LearnDash', 'buddyboss-app' ),
				) ) );

				$this->settings_form->add_field( $performance_settings_provider->field( 'cache_ld', array(
					'label'          => __( 'LearnDash', 'buddyboss-app' ),
					'label_checkbox' => __( 'Cache LearnDash Courses', 'buddyboss-app' ),
					'type'           => 'checkbox',
					'value'          => true,
					'purge_url'      => admin_url( 'admin.php?page=bbapp-settings&setting=cache_support&group=learndash&component=sfwd-courses,sfwd-lessons,sfwd-topic,sfwd-quiz&nonce=' . $purge_nonce ),
				) ) );

			}

		} // API Cache Settings End.

		if ( $this->get_current_sub_tab() == 'api_cdn' ) {

			// Rest API CDN
			$this->settings_form->add_field( $app_settings_provider->field( false, array(
				'type'    => 'table-open',
				'classes' => 'buddyboss-app-admin-card',
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'cdn_support_heading_rest_api', array(
				'type'         => 'heading',
				'value'        => __( 'API &ndash; Content Delivery Network', 'buddyboss-app' ),
				'tutorial_url' => admin_url( 'admin.php?page=bbapp-help&article=121834' ),
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'cdn.enabled', array(
				'label'          => __( 'CDN', 'buddyboss-app' ),
				'label_checkbox' => __( 'Enable API CDN', 'buddyboss-app' ),
				'desc'           => __( 'Using a CDN (Content Delivery Network) improves the response time for downloading static assets, such as images, files and videos. Most WordPress CDN plugins only work on the website, and do not work within API requests. Enter a CDN URL below to be used for pulling CDN assets within API requests.', 'buddyboss-app' ),
				'type'           => 'checkbox',
				'value'          => false,
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'cdn.error', array(
				'label' => '&nbsp;',
				'type'  => 'html',
				'value' => '<div class="bbapp-notice-box bbapp-notice-box--error">' . __( 'Failed to load assets using CDN URL provided. Please enter a valid CDN URL and try again.', 'buddyboss-app' ) . '</div>',
				'class' => function () {
					global $bbapp_cdn_error;
					if ( empty( $bbapp_cdn_error ) ) {
						return 'hidden';
					}
					return '';
				},
			) ) );

			$this->settings_form->add_field( $app_settings_provider->field( 'cdn.url', array(
				'label' => __( 'CDN URL', 'buddyboss-app' ),
				'desc'  => __( 'Enter the URL to your CDN, with https:// and without a trailing slash at the end.', 'buddyboss-app' ),
				'type'  => 'text',
				'value' => get_site_url(),
				'class' => function () {
					$global_settings = $this->get_global_settings();
					$class = 'api_cdn_url';
					if ( empty( $global_settings ) || empty( $global_settings['cdn.enabled'] ) ) {
						$class .= ' hidden';
					}
					return $class;
				},
			) ) );
		}

		do_action( 'bbapp_admin_settings', $this );
	}

	/**
	 * Saves the settings which are not app id specific.
	 *
	 * @param $settings
	 *
	 * @return bool
	 */
	public function save_global_settings( $settings ) {
		ManageApp::instance()->update_settings( $settings );

		return true;
	}

	/**
	 * Gets the settings which are not app id specific.
	 */
	public function get_global_settings() {
		return ManageApp::instance()->get_settings();
	}

	/**
	 * Saves the settings which are app id specific.
	 *
	 * @param $settings
	 *
	 * @return bool
	 */
	public function save_settings( $settings ) {
		if ( $this->get_current_sub_tab() == 'api_cdn' ) {
			global $bbapp_cdn_error;

			$bbapp_cdn_error = false;
			$cdn       = isset( $settings['cdn.enabled'] ) ? $settings['cdn.enabled'] : '';
			$cdn_url   = isset( $settings['cdn.url'] ) ? $settings['cdn.url'] : '';

			if ( ! empty( $cdn_url ) && ! empty( $cdn ) ) {

				$parsed = parse_url( $cdn_url );

				if ( ! empty( $parsed ) ) {
					if ( isset( $parsed['scheme'] ) ) {
						unset( $parsed['scheme'] );
					}
					$cdn_url = untrailingslashit( 'https://' . implode( '', $parsed ) );
				}

				$settings['cdn.url'] = $cdn_url;

				/**
				 * Validate the CDN by fetching the media in same site.
				 */
				$media = get_posts(
					array(
						'post_type'      => 'attachment',
						'posts_per_page' => 1,
						'order'          => 'ASC',
						'orderby'        => 'rand',
						'meta_query'     => array(
							'relation' => 'AND',
							array(
								'key'     => 'bp_media_saved',
								'compare' => 'NOT EXISTS',
							),
							array(
								'key'     => 'bp_document_saved',
								'compare' => 'NOT EXISTS',
							),
						),
					)
				);

				if ( ! empty( $media ) ) {
					$media_id         = current( $media )->ID;
					$media_url        = wp_get_attachment_url( $media_id );
					$cdn_media_url    = str_replace( home_url(), $cdn_url, $media_url );
					$request          = bbapp_remote_get( $cdn_media_url );
					$response_code    = wp_remote_retrieve_response_code( $request );
					$response_message = wp_remote_retrieve_response_message( $request );

					if ( 200 !== $response_code || 'OK' !== strtoupper( $response_message ) || is_wp_error( $request ) ) {
						$settings['cdn.enabled'] = '';
						$settings['cdn.url']     = '';
						$bbapp_cdn_error         = true;
					}
				}

			} else {
				$settings['cdn.enabled'] = '';
				$settings['cdn.url']     = '';
			}
		}

		ManageApp::instance()->update_app_settings( $settings );
		return true;
	}

	/**
	 * Gets the settings which are app id specific.
	 *
	 * @param bool $network
	 *
	 * @return array|bool
	 */
	public function get_settings( $network = false ) {
		$settings = ManageApp::instance()->get_app_settings( $network );

		return $settings;

	}

	/**
	 * Saves the settings for Performance
	 *
	 * @param $settings
	 *
	 * @return bool
	 */
	public function performance_save_settings( $settings ) {

		if ( ! class_exists( '\BuddyBoss\Performance\Settings' ) ) {
			require_once dirname( __FILE__, 2 ) . '/Performance/class-settings.php';
		}

		return \BuddyBoss\Performance\Settings::save_settings( $settings, 'buddyboss-app' );
	}

	/**
	 * Gets the settings for Performance
	 * @return array
	 */
	public function performance_get_settings() {
		if ( ! class_exists( '\BuddyBoss\Performance\Settings' ) ) {
			require_once dirname( __FILE__, 2 ) . '/Performance/class-settings.php';
		}

		return \BuddyBoss\Performance\Settings::get_settings( 'buddyboss-app' );

	}

	/**
	 * Update `cache_component` setting.
	 *
	 * @param $active_components
	 */
	public function update_performance_component_setting( $active_components ) {
		$settings = $this->performance_get_settings();

		if ( empty( $settings ) ) {
			$settings = array();
		}

		//components setting save to check components is active or not on MU level while components update.
		$settings['cache_component'] = isset( $active_components['performance'] ) ? $active_components['performance'] : 0;

		$this->performance_save_settings( $settings );
	}

	/**
	 * Saves the settings for auth
	 *
	 * @param $settings
	 *
	 * @return bool
	 */
	public function auth_save_settings( $settings ) {
		return bbapp_set_network_option( 'bbapp_auth_settings',
			$settings );
	}

	/**
	 * Gets the settings for auth
	 */
	public function auth_get_settings() {

		$settings = bbapp_get_network_option( 'bbapp_auth_settings' );

		if ( ! is_array( $settings ) ) {
			$settings = array();
		}

		return $settings;

	}

	/**
	 * Return the sub settings.
	 *
	 * @return array
	 */
	public function sub_settings() {

		$tabs = array(
			'general'            => __( 'General', 'buddyboss-app' ),
			'feedback'           => __( 'Feedback', 'buddyboss-app' ),
			'smart_banner'       => __( 'Smart Banner', 'buddyboss-app' ),
			'push_notifications' => __( 'Push Notifications', 'buddyboss-app' ),
			'inapp_purchases'    => __( 'In-App Purchases', 'buddyboss-app' ),
			'compatibility'      => __( 'Compatibility', 'buddyboss-app' ),
			'cache_support'      => __( 'API Caching', 'buddyboss-app' ),
			'api_cdn'            => __( 'API CDN', 'buddyboss-app' ),
		);

		if ( ! bbapp_is_active( 'push_notification' ) || is_network_admin() ) {
			unset( $tabs['push_notifications'] );
		}

		if ( ! bbapp_is_active( 'iap' ) ) {
			unset( $tabs['inapp_purchases'] );
		}

		if ( ! bbapp_is_active( 'performance' ) ) {
			unset( $tabs['cache_support'] );
			unset( $tabs['api_cdn'] );
		}

		return apply_filters( 'bbapp_admin_setting_tabs', $tabs );
	}

	/**
	 * Return the current setting page from active screen.
	 *
	 * @return string
	 */
	public function get_current_sub_tab() {

		$default = "";
		// Capture first tab which is default
		foreach ( $this->sub_settings() as $k => $v ) {
			$default = $k;
			break;
		}

		$setting      = ( isset( $_GET['setting'] ) ) ? $_GET['setting'] : $default;
		$sub_settings = $this->sub_settings();

		if ( isset( $sub_settings[ $setting ] ) ) {
			return $setting;
		}

		return $default;
	}

	/**
	 * Renders the setting screen.
	 */
	public function render_screen() {

		\BuddyBossApp\Admin\SetupAdmin::instance()->render_subtabs( $this->sub_settings(), $this->get_current_sub_tab() );

		if ( bbapp_is_active( 'push_notification' ) && $this->get_current_sub_tab() == 'push_notifications' ) {

			Notification::instance()->render_settings();

		} else if ( bbapp_is_active( 'iap' ) && $this->get_current_sub_tab() == 'inapp_purchases' ) {

			InAppPurchases::instance()->render_settings();

		} else {

			if ( isset( $this->settings_form ) && $this->settings_form ) {
				$this->settings_form->render_form();
			}

		}
		if ( $this->get_current_sub_tab() == 'api_cdn' ) {
		?>
		<script>
			jQuery( document ).ready( function() {
				jQuery( document ).on( 'change', 'input[name="app_settings[cdn.enabled]"]', function() {
					if ( jQuery( this ).prop( 'checked' ) ) {
						jQuery( '.api_cdn_url' ).removeClass( 'hidden' );
					} else {
						jQuery( '.api_cdn_url' ).addClass( 'hidden' );
					}
				} );
			} );
		</script>
		<?php
		}

	}

	/**
	 * Handle Purge Cache actions
	 */
	public function handle_purge_cache() {
		return \BuddyBoss\Performance\Settings::handle_purge_cache();
	}
}
