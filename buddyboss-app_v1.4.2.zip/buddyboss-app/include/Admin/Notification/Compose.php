<?php

namespace BuddyBossApp\Admin\Notification;

use BuddyBossApp\Notification\Push;
use BuddyBossApp\UserSegment;

class Compose {

	private static $instance;
	private $is_current_page;
	private $_messages;
	private $_per_page_user = 20;

	/**
	 * Get the instance of the class.
	 *
	 * @return Compose
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
	}

	public function _load() {

		add_action( 'admin_init', array( $this, 'admin_init' ) );

		/**
		 * Ajax Hooks
		 */
		add_action( 'wp_ajax_nopriv_bbapp_push_submit', array( $this, "push_submit" ) );
		add_action( 'wp_ajax_bbapp_push_submit', array( $this, "push_submit" ) );
		add_action( 'wp_ajax_bbapp_search_users', array( $this, "bbapp_search_users" ) );
		add_action( 'wp_ajax_bbapp_output_selected_users', array( $this, "output_selected_users" ) );
		add_action( 'wp_ajax_bbapp_output_selected_users_count', array( $this, "output_selected_users_count" ) );
		add_action( 'wp_ajax_bbapp_remove_specific_user', array( $this, "remove_specific_user" ) );
		add_action( 'wp_ajax_bbapp_add_specific_user', array( $this, "add_specific_user" ) );

	}

	/**
	 * Functions tells & sets that's if current page is one where it's will render.
	 *
	 * @param bool $set
	 *
	 * @return bool
	 */
	public function will_render( $set = false ) {

		if ( $set ) {
			$this->is_current_page = true;
		}

		return $this->is_current_page;
	}

	public function admin_init() {

		if ( $this->will_render() ) {

			if ( ! current_user_can( "manage_options" ) ) {
				wp_die( __( "You don't have permissions to make changes.", 'buddyboss-app' ) );
			}

			$this->push_compose(); // make a unique compose ID when visit the compose page.

		}
	}

	/**
	 * Renders the branding screen
	 * @return bool|mixed
	 */
	public function render() {

		if ( ! current_user_can( "manage_options" ) ) {
			echo '<p>' . __( "You don't have permissions to access this page." ) . '</p>';

			return false;
		}

		include bbapp()->plugin_dir . 'views/push-notifications/new.php';

	}

	public function entry_data( $field ) {
		return isset( $_POST[ $field ] ) ? $_POST[ $field ] : '';
	}

	/**
	 * Renders Warnings, Success, Notices on admin screens.
	 */
	public function show_messages() {

		if ( isset( $_GET['settings-updated'] ) ) {
			$this->_messages[] = array( 'type' => 'updated', 'message' => __( 'Settings Updated!', 'buddyboss-app' ) );
		}

		if ( ! empty( $this->_messages ) ) {
			foreach ( $this->_messages as $message ) {
				if ( $message['type'] == "error" ) {
					$message['message'] = sprintf( __( "<b>Push Notification Error:</b> %s", "buddyboss-app" ), $message['message'] );
				}
				echo "<div class='{$message[ 'type' ]}'><p>{$message[ 'message' ]}</p></div>";
			}
		}
	}

	/**
	 * Look & create new compose draft for sending push notification.
	 * Main reason is to have unique id for each compose to store unique value on multiple compose screen on same user.
	 */
	function push_compose() {

		// check if user is on push compose screen.
		if ( isset( $_GET["page"] ) && isset( $_GET["setting"] ) && $_GET["page"] == "bbapp-notification" && $_GET["setting"] == "new" ) {

			$push_compose_id = $this->get_compose_id();
			if ( empty( $push_compose_id ) ) {
				$uniqueid = time();
				wp_redirect( admin_url( "admin.php?page=bbapp-notification&setting=new&compose_id=" . $uniqueid ) );
				exit;
			}

		}

	}

	/**
	 * Returns push compose id.
	 * @return int
	 */
	function get_compose_id() {
		$push_compose_id = (int) ( isset( $_GET["compose_id"] ) ) ? $_GET["compose_id"] : 0;
		if ( empty( $push_compose_id ) ) {
			$push_compose_id = (int) ( isset( $_POST["compose_id"] ) ) ? $_POST["compose_id"] : 0;
		}

		return $push_compose_id;
	}


	/**
	 * @param      $error
	 * @param bool $focus
	 *
	 * @return void
	 */
	public function send_json_error_push_submit( $error, $focus = false ) {
		return wp_send_json_error( array(
			"focus" => $focus,
			"error" => $error
		) );
	}

	/**
	 * Manual Push Notification Process Code.
	 * This code triggers when manual push form is submitted.
	 */
	public function push_submit() {

		if ( ! isset( $_POST['_wpnonce'] ) ) {
			$this->send_json_error_push_submit( __( "You don't have permission to access this page.", "buddyboss-app" ) );
		}

		check_admin_referer( 'manual_push_nonce' );

		if ( ! current_user_can( "manage_options" ) ) {
			$this->send_json_error_push_submit( __( "You don't have permission to access this page.", "buddyboss-app" ) );

			return false;
		}

		$primary_text   = isset( $_POST['primary_text'] ) ? trim( $_POST['primary_text'] ) : '';
		$secondary_text = isset( $_POST['secondary_text'] ) ? trim( $_POST['secondary_text'] ) : '';
		$sent_as        = isset( $_POST['send_as'] ) ? trim( $_POST['send_as'] ) : 1;
		$send_to        = isset( $_POST['send_to'] ) ? trim( $_POST['send_to'] ) : 'all_users';
		$link_url       = isset( $_POST['link_url'] ) ? trim( $_POST['link_url'] ) : '';

		if ( empty( $secondary_text ) ) {
			$this->send_json_error_push_submit( __( "Message cannot be empty.", "buddyboss-app" ), 'bbapp-message-text' );

			return;
		}

		if ( ! empty( $link_url ) && ! bbapp_is_valid_url( $link_url ) ) {
			$this->send_json_error_push_submit( __( "Given link URL is not a valid URL format.", "buddyboss-app" ), 'bbapp-link-url' );

			return;
		}

		$user_ids = $this->get_users_by_send_to();

		if ( empty( $user_ids["total"] ) ) {
			$this->send_json_error_push_submit( __( "No recipients found with current send to user rules.", "buddyboss-app" ), 'bbapp-send-to' );

			return;
		}


		$schedule_date = false;

		if ( isset( $_POST["schedule"] ) && $_POST["schedule"] == "1" ) {

			if ( ! isset( $_POST["date_schedule"] ) || empty( $_POST["date_schedule"] ) ) {
				$this->send_json_error_push_submit( __( "Please select the schedule date.", "buddyboss-app" ), 'schedule_date_container' );
			}

			if ( ! isset( $_POST["date_schedule_time"] ) || empty( $_POST["date_schedule_time"] ) ) {
				$this->send_json_error_push_submit( __( "Please select the schedule date.", "buddyboss-app" ), 'schedule_date_container' );
			}

			$schedule_date = $_POST["date_schedule"] . " " . $_POST["date_schedule_time"]; // this date should be wordpress local timezone.

			if ( ! isset( $_POST["date_schedule_timezone"] ) ) {
				$this->send_json_error_push_submit( __( "#1 Schedule timezone is invalid.", "buddyboss-app" ), 'schedule_date_container' );

				return;
			}

			// Update Timezone Value if offset is given.
			if ( ! empty( $_POST['date_schedule_timezone'] ) && preg_match( '/^UTC[+-]/', $_POST['date_schedule_timezone'] ) ) {
				$offset     = preg_replace( '/UTC\+?/', '', $_POST['date_schedule_timezone'] );
				$offset_sec = $offset * 60 * 60;
				$tz         = timezone_name_from_abbr( '', $offset_sec, 1 );
				if ( $tz === false ) {
					$tz = timezone_name_from_abbr( '', $offset_sec, 0 );
				}
				$_POST['date_schedule_timezone'] = $tz;
			}

			try {
				$datetime = date_create( $schedule_date, new \DateTimeZone( $_POST["date_schedule_timezone"] ) );
				if ( ! $datetime ) {
					$this->send_json_error_push_submit( __( "#2 Schedule timezone is invalid.", "buddyboss-app" ), 'schedule_date_container' );

					return;
				}
				$datetime->setTimezone( new \DateTimeZone( "UTC" ) );
				$UTC_schedule_date = $datetime->format( 'Y-m-d H:i:s' );

			} catch ( \Exception $e ) {
				$this->send_json_error_push_submit( __( "#3 Schedule timezone is invalid.", "buddyboss-app" ), 'schedule_date_container' );

				return;
			}

			$schedule_date = gmdate( 'Y-m-d H:i:s', strtotime( $UTC_schedule_date ) );

			// Validate that if date is in future.
			if ( strtotime( $schedule_date ) < strtotime( gmdate( 'Y-m-d H:i:s' ) ) ) {
				$this->send_json_error_push_submit( __( "Your selected date must be in the future.", "buddyboss-app" ), 'schedule_date_container' );

				return;
			}

		}

		$segment_id = $this->get_user_segment_id();

		$target_type = "specific_users";

		if ( $send_to == "all_users" ) {
			$target_type = "all_users";
		}

		if ( $send_to == "filter_users" ) {
			$target_type = "filtered_users";
		}

		if ( $send_to == "specific_users" ) {

			$target_type = "specific_users";
			$segment_id  = $this->get_user_segment_id( "specific" );

		}


		/**
		 * Make sure segment id is there.
		 */
		if ( $send_to != "all_users" && empty( $segment_id ) ) {
			$this->send_json_error_push_submit( __( "No recipients found with current send to user rules.", "buddyboss-app" ), 'bbapp-send-to' );

			return;
		}

		$notification = array(
			'primary_text'        => sanitize_text_field( $primary_text ),
			'secondary_text'      => sanitize_text_field( $secondary_text ),
			'sent_as'             => $sent_as,
			'agent'               => 'manual_push_notification',
			'data'                => array(
				'segment_id' => $segment_id,
				'timezone'   => $_POST['date_schedule_timezone']
			),
			'push_data'           => array(),
			'normal_notification' => true,
			/**
			 * @todo: Have to finish a real target type support for schedule .
			 *        So we will use this to know if user has to be taken live from DB or from user_ids array.
			 **/
			'target_type'         => $target_type // specific_users , all_users , filtered_users
		);

		/**
		 * Add the Link URL into Push Data.
		 */
		if ( ! empty( $link_url ) ) {
			$notification["push_data"]["link"] = $link_url;
			$notification["data"]["link"]      = $link_url;
		}

		if ( $schedule_date ) {
			$notification["date_schedule"] = $schedule_date;
		}

		/**
		 * Notification Filters
		 * Using these filter we can alter the compose manual push notification data.
		 */

		$notification["push_data"] = apply_filters( 'bbapp_manual_push_notification_compose_push_data', $notification["push_data"], $notification );
		$notification["data"]      = apply_filters( 'bbapp_manual_push_notification_compose_data', $notification["data"], $notification );

		// Validate Data Return from Filters.
		foreach ( array( $notification["push_data"], $notification["data"] ) as $_validate_data ) {
			/**
			 * Using is_wp_error we can trigger manual error on compose screen.
			 */
			if ( is_wp_error( $_validate_data ) ) { // When it returned the wp error.
				/**
				 * @var $get_callback_value \WP_Error
				 */
				$this->send_json_error_push_submit( $_validate_data->get_error_message() );

				return;

			} elseif ( ! is_array( $_validate_data ) || ! isset( $_validate_data ) ) { // when it's not wp error nor a valid format.
				$this->send_json_error_push_submit( __( 'Notification has not been sent because the selected notification type has an invalid value format.', 'buddyboss-app' ) );

				return;
			}
		}

		$segments = UserSegment::instance();
		if ( $target_type != "all_users" ) {
			$notification['data']['send_to'] = $segments->get_total_users( $segment_id, true );
		} else {
			$fetch_users                     = Push::instance()->get_all_users( 1, 1 );
			$notification['data']["send_to"] = $fetch_users['total'];
		}

		$push_id = $this->save_to_db( $notification );

		// Push has been added into db it will trigger automatic.
		if ( is_wp_error( $push_id ) || empty( $push_id ) ) {
			$this->send_json_error_push_submit( __( "Unexpected error while sending push notification.", 'buddyboss-app' ) );

			return;
		}
		$delivery = false;
		if ( ! $schedule_date ) {
			// Start the delivery of push notification.
			$delivery = Push::instance()->do_push_delivery( $push_id );
		}

		if ( is_wp_error( $delivery ) ) {
			$this->send_json_error_push_submit( $delivery->get_error_message() );

			return;
		}

		$compose_id = $this->get_compose_id();

		if ( ! $schedule_date ) {
			wp_send_json_success( array( "url" => admin_url( "admin.php?page=bbapp-notification&setting=new&notification_sent=1&compose_id={$compose_id}" ) ) );
		} else {
			wp_send_json_success( array( "url" => admin_url( "admin.php?page=bbapp-notification&setting=new&notification_sent=2&compose_id={$compose_id}" ) ) );
		}

		exit();
	}

	/**
	 * Returns the admin send as users.
	 * @return array
	 */
	public function admin_users_options() {
		$options = array();
		$users   = get_users( 'orderby=nicename&role=administrator' );

		if ( ! empty( $users ) && ! is_wp_error( $users ) ) {
			foreach ( $users as $user ) {
				$options[] = array(
					'id'     => $user->ID,
					'name'   => $user->display_name,
					'avatar' => get_avatar_url( $user->ID )
				);
			}
		}

		return $options;
	}

	/**
	 * Allow users to search & display on select2 on push screen.
	 * Ajax Handler.
	 */
	public function bbapp_search_users() {

		$term   = ! empty( $_REQUEST['term'] ) ? $_REQUEST['term'] : '';

		//global $wpdb;

		/*$devices_table = bbapp_get_network_table( 'bbapp_user_devices' );

		$wp_user_level = "{$wpdb->prefix}user_level"; // this will force to collect user from correct blog.

		$sql = $wpdb->prepare(
			"SELECT DISTINCT u.ID as user_id, u.user_nicename, u.display_name, u.user_login "
			. " FROM {$wpdb->users} as u,  {$wpdb->usermeta} as um , {$devices_table} as devices WHERE
			u.ID = um.user_id AND u.ID = devices.user_id AND
			u.user_status = '0' AND devices.app_id=%s
			AND ( u.display_name LIKE %s OR u.user_login LIKE %s ) AND (um.meta_key = %s) ",
			$app_id,
			'%'.$wpdb->esc_like( $term['term'] ).'%',
			'%'.$wpdb->esc_like( $term['term'] ).'%',
			$wp_user_level
		);

		$users = $wpdb->get_results(
			$sql
		);*/

		$args = array(
			'search'         => '*' . $term['term'] . '*',
			'search_columns' => array( 'user_login', 'display_name' )
		);
		// Get the results
		$response   = $items = array();
		$user_query = new \WP_User_Query( $args );
		$users      = $user_query->get_results();
		if ( ! empty( $users ) && ! is_wp_error( $users ) ) {
			foreach ( $users as $user ) {
				$items[] = array(
					'id'            => $user->ID,
					'name'          => $user->display_name,
					'avatar'        => get_avatar_url( $user->ID ),
					'avatarHtml'    => get_avatar( $user->ID, 16 ),
					'link'          => admin_url( "user-edit.php?user_id={$user->ID}" ),
					'loginName'     => $user->user_login,
					'app_installed' => false
				);
			}
		}

		$response['items'] = $items;

		wp_send_json( $response );

	}

	/**
	 * Returns User ID based on Send To Information Form Provided.
	 * Expects Sent to Field Information In $_POST
	 * @return array
	 */
	function get_users_by_send_to( $page = 1, $limit = 20 ) {

		$send_to = isset( $_POST['send_to'] ) ? trim( $_POST['send_to'] ) : 'all_users';

		if ( 'all_users' == $send_to ) {

			$users = Push::instance()->get_all_users( $page, $limit );

			return array( "users" => $users["users"], "total" => $users["total"] );

		} else {

			$segment_id = $this->get_user_segment_id();

			if ( $send_to == "specific_users" ) {
				$segment_id = $this->get_user_segment_id( "specific" );
			}

			$user_segment = \BuddyBossApp\UserSegment::instance();

			$user_ids   = $user_segment->get_users( $segment_id, $page, $limit, true );
			$user_count = $user_segment->get_total_users( $segment_id, true );

			return array( "users" => $user_ids, "total" => $user_count );

		}

		return array( "users" => array(), "total" => 0 );

	}

	/**
	 * Return the Selected Users Based on Send To Field.
	 */
	function get_selected_users() {

		$temp_work_key = '_abb_push_temp_users_work_' . $this->get_compose_id();
		$user_ids      = (array) get_transient( $temp_work_key );

		return $user_ids;

	}

	/**
	 * Return the ID to be used on user segment.
	 * @return string
	 */
	function get_user_segment_id( $postfix = "" ) {
		$compose_id = $this->get_compose_id();
		if ( ! empty( $postfix ) ) {
			$postfix = "_" . $postfix;
		}

		return "push_" . $compose_id . $postfix;
	}


	/**
	 * Output the list based on given users array on param.
	 *
	 * @param     $user_ids
	 *
	 * @param int $current_page
	 * @param int $total_pages
	 *
	 * @return string
	 */
	private function get_user_list_markup( $user_ids, $current_page = 1, $total_pages = 1 ) {

		if ( empty( $user_ids ) ) {
			return false;
		}

		$send_to = isset( $_POST['send_to'] ) ? trim( $_POST['send_to'] ) : 'all_users';

		$users = get_users( array( 'include' => $user_ids ) );

		// Sometime get users returns duplicates users let's fix them.
		$_tmp = array();
		foreach ( $users as $user ) {
			$_tmp[ $user->ID ] = $user;
		}
		$users = $_tmp;
		unset( $_tmp );

		ob_start();

		echo '<div id="bbapp_push_users" data-current_page="' . $current_page . '">';

		foreach ( $users as $user ) {
			$link     = admin_url( "user-edit.php?user_id={$user->ID}" );
			$userName = get_user_meta( $user->ID, 'first_name', true ) . " " . get_user_meta( $user->ID, 'last_name', true );
			if ( empty( trim( $userName ) ) ) {
				$userName = $user->user_login;
			}
			?>
			<div class="username">

				<?php if ( $send_to !== "all_users" ): ?>
					<a href="#" title="<?php echo esc_attr( "Remove", "buddyboss-app" ); ?>"
						data-user_id="<?php echo esc_attr( $user->ID ); ?>" class="bbapp-delete-user"><span
							class="dashicons dashicons-no-alt"></span></a>
				<?php endif; ?>

				<span>
                    <?php echo get_avatar( $user->ID, 16 ) ?>
                    <a class="bbapp-username-link" href="<?php echo $link; ?>"
	                    target="_blank"><?php echo esc_html( $userName ); ?></a>
                </span>

			</div>
			<?php
		}

		echo '</div>';

		echo '<ul class="pagination">';

		$big = 999999999; // need an unlikely integer

		echo paginate_links( array(
			'base'    => str_replace( $big, '%#%', "#" . $big ),
			'format'  => '?paged=%#%',
			'current' => max( 1, $current_page ),
			'total'   => $total_pages,
			'type'    => 'list'
		) );


		echo '</ul>';

		return ob_get_clean();
	}


	/**
	 * Return the bbapp filters user ids list with pagination.
	 */
	public function output_selected_users() {

		$current_page = isset( $_POST["page"] ) ? $_POST["page"] : 1;
		$current_page = max( $current_page, 1 );

		$user_ids = $this->get_users_by_send_to( $current_page, $this->_per_page_user );

		if ( empty( $user_ids["total"] ) ) {
			wp_send_json_error( array(
				'type'    => 'error',
				'message' => __( 'No members found.',
					'buddyboss-app' )
			) );
		}

		$max_page = ceil( $user_ids["total"] / $this->_per_page_user );

		$markup = $this->get_user_list_markup( $user_ids["users"], $current_page, $max_page );

		wp_send_json_success( array( 'total' => (int) $user_ids["total"], 'max_page' => $max_page, 'html' => $markup ) );

	}

	/**
	 * Return the bbapp filters user ids list with pagination.
	 */
	public function output_selected_users_count() {
		$user_ids = $this->get_users_by_send_to( 1, 1 );
		wp_send_json_success( array( 'total' => (int) $user_ids["total"] ) );
	}

	/**
	 * Add specific user id into user segment.
	 */
	public function add_specific_user() {

		$user_id = (int) $_POST["add_user_id"];

		if ( false === (bool) $this->user_has_device_token( $user_id ) ) {
			$user = get_userdata( $user_id );
			wp_send_json_error( array(
				'type'    => 'error',
				'message' => sprintf( __( "<b>%s</b> cannot receive push notifications until they have downloaded and logged into the app.", 'buddyboss-app' ), $user->display_name )
			) );
		}

		$segment_id = $this->get_user_segment_id( "specific" );

		if ( empty( $segment_id ) ) {
			wp_send_json_error( array(
				'type'    => 'error',
				'message' => __( 'Invalid user segment. Please refresh the page and try again.',
					'buddyboss-app' )
			) );
		}

		$user_segment = \BuddyBossApp\UserSegment::instance();

		$current_page = isset( $_POST["page"] ) ? $_POST["page"] : 1;
		$current_page = max( $current_page, 1 );

		$add_user = $user_segment->add_user( $segment_id, $user_id );

		if ( ! $add_user ) {
			wp_send_json_error( array(
				'type'    => 'error',
				'message' => __( 'There was an error while deleting the user. The user might have been deleted already.', 'buddyboss-app' )
			) );
		}

		$user_ids = $this->get_users_by_send_to( $current_page, $this->_per_page_user );
		$max_page = ceil( $user_ids["total"] / $this->_per_page_user );

		$markup = $this->get_user_list_markup( $user_ids["users"], $current_page, $max_page );

		wp_send_json_success( array( 'total' => (int) $user_ids["total"], 'html' => $markup ) );
	}

	/**
	 * Specific user check the device token exists or not.
	 *
	 * @param int $user_id
	 *
	 * @return false|string|null
	 */
	public function user_has_device_token( $user_id = 0 ) {
		global $wpdb;
		$devices_table = bbapp_get_network_table( 'bbapp_user_devices' );
		if ( ! empty( $user_id ) ) {
			$wp_user_level = "{$wpdb->prefix}user_level"; // this will force to collect user from correct blog.

			// Query only users who have device token registered.
			$sql = $wpdb->prepare( "SELECT DISTINCT u.ID as user_id FROM {$wpdb->users} as u, {$wpdb->usermeta} as um , {$devices_table} as devices WHERE u.ID = um.user_id AND u.ID = devices.user_id AND u.user_status = '0' AND devices.user_id=%s AND (um.meta_key = %s) order by u.id ASC", $user_id, $wp_user_level );

			return $wpdb->get_var( $sql );
		}

		return false;

	}

	/**
	 * Remove the specific user from user segment.
	 */
	public function remove_specific_user() {

		$segment_id = $this->get_user_segment_id();
		$send_to    = isset( $_POST['send_to'] ) ? trim( $_POST['send_to'] ) : 'all_users';

		if ( $send_to == "specific_users" ) {
			$segment_id = $this->get_user_segment_id( "specific" );
		}

		if ( empty( $segment_id ) ) {
			wp_send_json_error( array(
				'type'    => 'error',
				'message' => __( 'Invalid user segment. Please refresh the page and try again.',
					'buddyboss-app' )
			) );
		}

		$user_segment = \BuddyBossApp\UserSegment::instance();

		$user_id = (int) $_POST["remove_user_id"];

		$current_page = isset( $_POST["page"] ) ? $_POST["page"] : 1;
		$current_page = max( $current_page, 1 );

		$remove_user = $user_segment->remove_user( $segment_id, $user_id );

		if ( ! $remove_user ) {
			wp_send_json_error( array(
				'type'    => 'error',
				'message' => __( 'There was an error while deleting the user. The user might have been deleted already.',
					'buddyboss-app' )
			) );
		}

		$user_ids = $this->get_users_by_send_to( $current_page, $this->_per_page_user );
		$max_page = ceil( $user_ids["total"] / $this->_per_page_user );

		$markup = $this->get_user_list_markup( $user_ids["users"], $current_page, $max_page );

		wp_send_json_success( array( 'html' => $markup ) );

	}

	/**
	 * Store Manual Push Notification.
	 *
	 * @param $notification
	 *
	 * @return false|true|int
	 */
	function save_to_db( $notification ) {
		global $wpdb;

		$defaults = array(
			'primary_text'             => '',
			'secondary_text'           => '',
			'user_ids'                 => array(),
			'sent_as'                  => 1,
			'agent'                    => 'event',// whether this notification was triggered manually or by any event
			'status'                   => 'pending',
			'date_updated'             => current_time( 'mysql', 1 ),
			'date_created'             => current_time( 'mysql', 1 ),
			'blog_id'                  => get_current_blog_id(),
			'topic'                    => '',
			'target_type'              => 'specific_users', // specific_users , all , filter
			'date_schedule'            => false,
			'data'                     => array(),
			'push_data'                => array(),
			'normal_notification'      => false, // should create notification or not.
			'normal_notification_data' => array()
		);

		$notification = wp_parse_args( $notification, $defaults );

		if ( $notification["target_type"] != "all_users" ) {
			$segment_id = ( isset( $notification["data"]["segment_id"] ) ) ? $notification["data"]["segment_id"] : false;

			if ( empty( $segment_id ) ) {
				return false;
			}
		}

		$table_name = bbapp_get_network_table( 'bbapp_push_notifications' );

		// 0 means all users, -1 means multiple users.
		$target = ( count( $notification['user_ids'] ) == 1 ) ? reset( $notification['user_ids'] ) : - 1;

		$_data                             = $notification["data"];
		$_data["user_ids"]                 = $notification['user_ids'];
		$_data["push_data"]                = $notification['push_data'];
		$_data["normal_notification"]      = $notification['normal_notification'];
		$_data["normal_notification_data"] = $notification['normal_notification_data'];

		$data = array(
			"primary_text"   => stripcslashes( $notification['primary_text'] ),
			"secondary_text" => stripcslashes( $notification['secondary_text'] ),
			"target"         => $target,
			"sent_as"        => $notification['sent_as'],
			"data"           => maybe_serialize( $_data ),
			"agent"          => $notification['agent'],
			"status"         => 'processing', // default status when push trigger.
			"date_updated"   => $notification['date_updated'],
			"date_created"   => $notification['date_created'],
			"blog_id"        => $notification['blog_id'],
			'target_type'    => $notification['target_type']
		);

		if ( $notification["date_schedule"] ) {
			$data["status"]        = "pending";
			$data["is_schedule"]   = 1;
			$data["date_schedule"] = $notification["date_schedule"];
			// Expire date so it shouldn't be treated after that.
			$data["date_expire"] = gmdate( "Y-m-d H:i:s", strtotime( "+3 hours", strtotime( $notification["date_schedule"] ) ) );
		}

		$insert_push_db = $wpdb->insert( $table_name, $data );

		if ( ! $insert_push_db ) {
			return false;
		}

		return $wpdb->insert_id;
	}

	/**
	 * Get the users list based on single push.
	 *
	 * @param     $push_id
	 * @param int $page
	 * @param int $limit
	 *
	 * @return array
	 */
	public function get_users_by_send_to_in_single_push( $push_id, $page = 1, $limit = 20 ) {
		$push_data         = Push::instance()->get_push_notification_meta( $push_id );
		$single_push_users = '';
		if ( isset( $push_data ) && ! empty( $push_data ) ) {
			foreach ( $push_data as $key => $single_push_meta ) {
				$single_push_users .= $single_push_meta['meta_value'];
			}
			$single_push_meta      = array_filter( explode( ',', $single_push_users ) );
			$offset                = ( $page - 1 ) * $limit;
			$single_push_users_ids = array_unique( array_slice( $single_push_meta, $offset, $limit ) );

			return array( "users" => $single_push_users_ids, "total" => count( array_unique( $single_push_meta ) ) );
		}

		return array( "users" => array(), "total" => 0 );
	}
}
