<?php

namespace BuddyBossApp\Admin;

use BuddyBossApp\Permissions;

class Components {

	private static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return Settings
	 */
	public static function instance() {

		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	public function __construct() {
		//Using Singleton, see instance()
	}

	public function _load() {
		add_action( 'init', array( $this, 'load_init' ) );
	}

	public function load_init() {

		/**
		 * Only load on bbapp-settings page.
		 */
		if ( SetupAdmin::instance()->get_page_now() != "admin.php" || ( isset( $_GET['page'] ) && $_GET['page'] != 'bbapp-components' ) ) {
			return false;
		}

		/**
		 * Permission check.
		 */
		if ( ! \BuddyBossApp\Permissions::instance()->can_manage_app() ) {
			wp_die( "You don't have permission to access this page.", "buddyboss-app" );
		}

		/**
		 * Deactivate Component.
		 */
		if ( isset( $_GET["do_action"] ) && $_GET["do_action"] == "deactivate" && check_admin_referer( 'bbapp-admin-component-activation' ) ) {

			$component_id = $_GET["bbapp_component"];
			$update       = \BuddyBossApp\Components::instance()->deactivate_components( array( $component_id ) );

			if ( $update ) {

				$link = bbapp_get_super_admin_url(
					add_query_arg(
						array(
							'page'               => 'bbapp-components',
							'action'             => isset( $_GET["all"] ) ? $_GET["all"] : '',
							'component_disabled' => true
						),
						"admin.php"
					)
				);

				wp_redirect( $link );
				exit;

			}

		}

		/**
		 * Activate Component
		 */
		if ( isset( $_GET["do_action"] ) && $_GET["do_action"] == "activate" && check_admin_referer( 'bbapp-admin-component-activation' ) ) {

			$component_id = $_GET["bbapp_component"];
			$update       = \BuddyBossApp\Components::instance()->activate_components( array( $component_id ) );

			if ( $update ) {

				$link = bbapp_get_super_admin_url(
					add_query_arg(
						array(
							'page'              => 'bbapp-components',
							'action'            => isset( $_GET["all"] ) ? $_GET["all"] : '',
							'component_enabled' => true
						),
						"admin.php"
					)
				);

				wp_redirect( $link );
				exit;

			}

		}

		/**
		 * Bulk Activate Deactivate Component.
		 */
		if ( isset( $_POST["bbapp-admin-component-bulk"] ) && wp_verify_nonce( $_POST['bbapp-admin-component-bulk'], 'bbapp-admin-component-bulk' ) ) {

			$all_components    = \BuddyBossApp\Components::instance()->get_components();
			$action_components = array();
			$post_components   = isset( $_POST["bbapp_components"] ) && is_array( $_POST["bbapp_components"] ) ? $_POST["bbapp_components"] : array();

			foreach ( $post_components as $component_id => $v ) {
				if ( isset( $all_components[ $component_id ] ) && ! $all_components[ $component_id ]["required"] ) {
					$action_components[] = $component_id;
				}
			}

			$action = isset( $_POST["action1"] ) ? $_POST["action1"] : "";
			if ( isset( $_POST["action2"] ) && ! empty( $_POST["action2"] ) ) {
				$action = $_POST["action2"];
			}

			$update = false;
			if ( $action == "active" ) {
				$update = \BuddyBossApp\Components::instance()->activate_components( $action_components );
			}
			if ( $action == "inactive" ) {
				$update = \BuddyBossApp\Components::instance()->deactivate_components( $action_components );
			}

			if ( $update ) {
				$link = bbapp_get_super_admin_url(
					add_query_arg(
						array(
							'page'           => 'bbapp-components',
							'action'         => isset( $_GET["all"] ) ? $_GET["all"] : '',
							'component_bulk' => true
						),
						"admin.php"
					)
				);
				wp_redirect( $link );
				exit;
			}

		}


	}

	/**
	 * Return the sub settings.
	 *
	 * @return array
	 */
	public function sub_settings() {

		$all_components      = \BuddyBossApp\Components::instance()->get_components();
		$active_components   = \BuddyBossApp\Components::instance()->get_active_components();
		$inactive_components = \BuddyBossApp\Components::instance()->get_inactive_components();
		$required_components = \BuddyBossApp\Components::instance()->get_required_components();

		$tabs = array(
			'all'      => sprintf( __( 'All %s', 'buddyboss-app' ), '<span class="count">(' . count( $all_components ) . ')</span>' ),
			'active'   => sprintf( __( 'Active %s', 'buddyboss-app' ), '<span class="count">(' . count( $active_components ) . ')</span>' ),
			'inactive' => sprintf( __( 'Inactive %s', 'buddyboss-app' ), '<span class="count">(' . count( $inactive_components ) . ')</span>' ),
			'required' => sprintf( __( 'Required %s', 'buddyboss-app' ), '<span class="count">(' . count( $required_components ) . ')</span>' ),
		);

		/**
		 * Menus which will be available to Subsite on BuddyBossApp Multisite Mode.
		 */
		$none_super_admin_menus = array();

		if ( ! bbapp_is_super_admin_page() ) {

			foreach ( $tabs as $k => $v ) {
				if ( ! in_array( $k, $none_super_admin_menus ) ) {
					unset( $tabs[ $k ] );
				}
			}

		}

		return $tabs;
	}

	/**
	 * Return the current setting page from active screen.
	 *
	 * @return string
	 */
	public function get_current_sub_tab() {

		$default = "";
		// Capture first tab which is default
		foreach ( $this->sub_settings() as $k => $v ) {
			$default = $k;
			break;
		}

		$setting      = ( isset( $_GET['action'] ) ) ? $_GET['action'] : $default;
		$sub_settings = $this->sub_settings();

		if ( isset( $sub_settings[ $setting ] ) ) {
			return $setting;
		}

		return $default;
	}

	/**
	 * Return Components.
	 *
	 * @return mixed|void
	 */
	public function get_components() {
		$all_components      = \BuddyBossApp\Components::instance()->get_components();
		$active_components   = \BuddyBossApp\Components::instance()->get_active_components();
		$inactive_components = \BuddyBossApp\Components::instance()->get_inactive_components();

		if ( isset( $_GET["action"] ) && in_array( $_GET["action"], array(
				"all",
				"active",
				"inactive",
				"required"
			) ) ) {

			foreach ( $all_components as $component_id => $component ) {

				if ( $_GET["action"] == "active" ) {
					if ( ! isset( $active_components[ $component_id ] ) || ! $active_components[ $component_id ] ) {
						if(!$component["required"]) {
							unset( $all_components[ $component_id ] );
						}
					}
				}
				if ( $_GET["action"] == "inactive" ) {
					if ( ! isset( $inactive_components[ $component_id ] ) || isset( $active_components[ $component_id ] ) || $component["required"] ) {
						unset( $all_components[ $component_id ] );
					}
				}
				if ( $_GET["action"] == "required" ) {
					if ( ! $component["required"] ) {
						unset( $all_components[ $component_id ] );
					}
				}

			}
		}

		return $all_components;
	}

	/**
	 * Renders the setting screen.
	 */
	public function render_screen() {

		if ( ! Permissions::instance()->can_manage_app() ) {
			echo '<p>' . __( "You don't have permission to access this page." ) . '</p>';

			return false;
		}

		\BuddyBossApp\Admin\SetupAdmin::instance()->render_subtabs( $this->sub_settings(), $this->get_current_sub_tab(), "action" );

		include bbapp()->plugin_dir . 'views/settings/components.php';

	}

}