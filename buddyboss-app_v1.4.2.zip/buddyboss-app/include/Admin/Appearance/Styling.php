<?php

namespace BuddyBossApp\Admin\Appearance;

use BuddyBossApp\Permissions;
use BuddyBossApp\Styling as BuddyBossAppStyling;

class Styling
{

    private static $instance;
    private $is_current_page;

    /**
     * Get the instance of the class.
     *
     * @return Styling
     */
    public static function instance()
    {
        if (!isset(self::$instance)) {
            $class = __CLASS__;
            self::$instance = new $class;
            self::$instance->_load();
        }

        return self::$instance;
    }

    /**
     * Styling constructor.
     */
    public function __construct()
    {
    }

    /**
     *
     */
    public function _load()
    {
        add_action('wp_ajax_bbapp_styling_submit', array($this, 'process_submit'));
        add_action('wp_ajax_nopriv_bbapp_styling_submit', array($this, 'process_submit'));
	    add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_assets'));
    }

    /**
     * Functions tells & sets thats if current page is one where it's will render.
     *
     * @param bool $set
     * @return bool
     */
    public function will_render($set = false)
    {
        if ($set) {
            $this->is_current_page = true;
        }

        return $this->is_current_page;
    }

    /**
     * Returns the fields to be used in template.
     */
    public function get_fields()
    {
        $fields = BuddyBossAppStyling::instance()->get_app_styling_fields();
        $fields = (array)$fields;
        return $fields;
    }

    /**
     * Renders the styling screen
     * @return bool|mixed
     */
    public function render()
    {
        if (!current_user_can("manage_options")) {
            echo '<p>' . __("You don't have permission to access these settings.") . '</p>';
            return false;
        }

        $styling_options = BuddyBossAppStyling::instance()->get_options();
	    $fields = BuddyBossAppStyling::instance()->get_app_styling_fields();
	    $values = isset($styling_options["styles"]) ? $styling_options["styles"] : array();

	    $fields = (array)$fields;
	    $styling_fields_array = (array)$fields['fields'];
	    include bbapp()->plugin_dir . "views/branding/colors.php";
    }

	/**
	 * Render screen fields.
	 * @param $fields
	 * @param $screen_name
	 * @param $values
	 */
	public function render_screen_fields_html( $fields, $screen_name, $values ) {
		?>
		<table class="widefat" cellspacing="0" id="status">
			<?php
			$i = 0;
			foreach ( $fields as $field ) {
				$field = (array) $field;

				if ( $field["screen"] != $screen_name ) {
					continue;
				}
				$i ++;
				$class_name = strtolower( str_replace( ".", "_", $field["name"] ) );
				?>
				<tr class="<?php echo ( ( $i % 2 ) ? 'alternate' : '' ) . ' ' . $class_name . ' ' . $field["type"] ?> option_field entry-row">
					<td>
						<div class="option_field_label"><?php echo esc_html( $field["label"] ) ?></div>
						<?php if ( isset( $field["description"] ) ) { ?>
							<span class="option_field_info"><?php echo wp_kses_post( $field["description"] ); ?></span>
						<?php } ?>
					</td>
					<td>
						<?php $this->render_field( $field, $values ); ?>
					</td>
				</tr>
				<?php
			}
			?>
		</table>
		<?php
	}

    /**
     * Renders the styling singular field.
     * @param $field
     * @param $values
     */
    public function render_field($field, $values)
    {
        $field_name = $field["name"];
        $field_value = (isset($values[$field_name])) ? $values[$field_name] : $field["value"];

        $quick_field_attr = '';
        $class = array("bbapp-field-item");

        $class[] = 'quick-field';
        $quick_field_default = 'data-default="' . esc_attr( $field["value"] ) . '"';
	    if ( $field["name"] == 'styles.colors.authFieldBgColor' || $field["name"] == 'styles.colors.regFieldBgColor' ) {
		    $class[]                 = 'color-picker';
		    $quick_field_alpha       = 'data-alpha-enabled="true"';
		    $quick_field_alpha_width = 'data-alpha-custom-width="1"';
		    $quick_field_alpha_type  = 'data-alpha-color-type="rgba"';
	    } else {
		    $quick_field_alpha       = 'data-alpha-enabled="false"';
		    $quick_field_alpha_width = 'data-alpha-custom-width="false"';
		    $quick_field_alpha_type  = 'data-alpha-color-type="hex"';
	    }

	    $input_link = md5($field_name . "link");
        $class[] = $input_link;
        $class = 'class="' . esc_attr(implode(" ", $class)) . '"';

        if ($field["type"] == "select") {

            $options = (array)$field["options"];

            echo '<select name="styles[' . $field_name . ']" data-link="' . $input_link . '">';
            foreach ($options as $option) {
                $option = (array)$option;
                echo '<option ' . $class . ' ' . selected($field_value, $option["value"]) . ' value="' . $option["value"]
                    . '">' . $option["label"] . '</option>';
            }
            echo '</select>';

        }

        if ($field["type"] == "color") {
            echo '<input ' . $class . ' ' . $quick_field_alpha . ' ' . $quick_field_alpha_type . ' ' . $quick_field_alpha_width . '  ' . $quick_field_default . ' name="styles[' . $field_name . ']" type="text" value="' . $field_value . '"  data-link="' . $input_link . '"/>';
        }

    }

    /**
     * Save styling settings.
     */
    public function process_submit()
    {

        if (isset($_POST["bbapp_save_styling_options"])
            && wp_verify_nonce($_POST['bbapp_save_styling_options'], 'bbapp_save_styling_options')) {

            if (!Permissions::instance()->can_manage_app()) {
                wp_send_json_error(__("You don't have permission to access this page.","buddyboss-app"));
            }

            $styling_options = BuddyBossAppStyling::instance()->get_options();

            // Sanitize Styles
            foreach ((array)$_POST["styles"] as $k => $v) {
                if (!is_string($_POST["styles"][$k])) {
                    continue;
                }
                $_POST["styles"][$k] = sanitize_text_field($v);
            }

            $styling_options["styles"] = $_POST["styles"];
            BuddyBossAppStyling::instance()->set_options($styling_options);

            wp_send_json_success(__("Changes Saved", 'buddyboss-app'));
        } else {
            wp_send_json_error(__("Security Token Error", 'buddyboss-app'));
        }
    }

	/**
	 *
	 */
    public function admin_enqueue_assets(){
        global $pagenow;

        /**
         * Just load it on pages we are using it.
         */
        if ($pagenow == "admin.php" && isset($_GET["page"]) && $_GET["page"] == "bbapp-appearance") {
            $styling_fields = BuddyBossAppStyling::instance()->get_app_styling_fields();
            // Localize.
            wp_localize_script( 'bbapp-script', 'styling_fields', array(
                'fields' => $styling_fields->fields,
            ) );
        }

    }
}
