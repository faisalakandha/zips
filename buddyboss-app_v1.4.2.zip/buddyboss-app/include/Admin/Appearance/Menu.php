<?php

namespace BuddyBossApp\Admin\Appearance;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'AppMenu' ) ):

	class Menu {

		private $_messages = array();

		private $is_current_page = false;

		private static $instance;

		/**
		 * Get the instance of the class.
		 *
		 * @return Menu
		 */
		public static function instance() {
			if ( ! isset( self::$instance ) ) {
				$class          = __CLASS__;
				self::$instance = new $class;
				self::$instance->_load();
			}

			return self::$instance;
		}

		/**
		 * AppMenu constructor.
		 */
		public function __construct() {
		}

		/**
		 *
		 */
		public function _load() {
			add_action( 'wp_ajax_add-appmenu-item', array( $this, 'wp_ajax_add_menu_item' ) );
			add_action( "admin_init", array( $this, "admin_init" ) );
			add_action( 'bbapp_filter_app_menu_by_dependency', array( $this, '_filter_app_menu_by_dependency' ), 99, 2 );
			add_filter( 'bbapp_app_menu_filter', array( $this, '_exclude_menu_from_menu_list' ), 99, 2 );
			add_action( 'bbapp_render_menu_metabox', array( $this, 'render_menu_metabox' ), 10 );
		}

		/**
		 * Functions tells & sets thats if current page is one where it's will render.
		 *
		 * @param bool $set
		 *
		 * @return bool
		 */
		public function will_render( $set = false ) {

			if ( $set ) {
				$this->is_current_page = true;
			}

			return $this->is_current_page;
		}

		/**
		 *
		 */
		public function admin_init() {

			if ( ( ! is_admin() && ! is_network_admin() ) || ! current_user_can( 'manage_options' ) ) {
				return;
			}
			$this->process_submit();
			add_filter( 'admin_body_class', array( $this, 'custom_body_class' ), 99 );
		}

		/**
		 * Renders the app menu backend page.
		 */
		public function render() {
			include bbapp()->plugin_dir . '/views/branding/menu.php';
		}

		/**
		 * Output the error or update messages to render.
		 */
		public function show_messages() {

			if ( ! empty( $this->_messages ) ) {
				foreach ( $this->_messages as $message ) {
					echo "<div id='message' class='{$message['type']}'><p>{$message['message']}</p></div>";
				}
			}

		}

		/**
		 * Renders all menu metaboxes.
		 */
		public function render_menu_metabox() {
			$register_meta_boxes = apply_filters( 'bbapp_register_menu_metaboxes', array() );
			if ( ! empty( $register_meta_boxes ) ) {
				foreach ( $register_meta_boxes as $register_meta_box ) {
					$screen = sanitize_title_with_dashes( $register_meta_box['title'] );
					$callback = ! empty( $register_meta_box['callback'] ) ? $register_meta_box['callback'] : array(
						$this,
						'render_items_markup'
					);
					add_meta_box( "bbapp-{$screen}-metabox", $register_meta_box['title'], $callback, 'nav-menus', 'side', 'default', $register_meta_box['args'] );
				}
			}
		}
		/**
		 * Render items markup.
		 */
		public function render_items_markup( $post, $metabox ) {
			$all_menus = apply_filters( 'bbapp_get_all_menus', array() );
			if ( isset( $metabox['args']['screen_group'] ) ) {
				$screen_group     = $metabox['args']['screen_group'];
				$menus         = isset( $all_menus[ $screen_group ] ) ? $all_menus[ $screen_group ] : array();
				$menu_desc     = '';
				$is_hide       = false;
				$deeplink_base = '';
				if ( ! empty( $metabox['args'] ) ) {
					if ( isset( $metabox['args']['desc'] ) ) {
						$menu_desc = $metabox['args']['desc'];
					}
					if ( isset( $metabox['args']['is_hide'] ) ) {
						$is_hide = $metabox['args']['is_hide'];
					}
					if ( isset( $metabox['args']['deeplink_base'] ) ) {
						$deeplink_base = $metabox['args']['deeplink_base'];
					}
				}
				include bbapp()->plugin_dir . "views/appearance/appmenu-markup.php";
			}
		}

		/**
		 * Saves app menu settings.
		 *
		 * @return bool|void
		 */
		public function process_submit() {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( - 1 );
			}

			if ( ! isset( $_POST['update-nav-appmenu-nonce'] ) ) {
				return;
			}

			if ( ! check_admin_referer( 'update-nav_appmenu', 'update-nav-appmenu-nonce' ) ) {
				$this->_messages[] = array(
					'type'    => 'error',
					'message' => __( 'Something unexpected happened. Please try again later.', 'buddyboss-app' ),
				);
			}

			$menu_items   = isset($_POST['appmenu-item']) && is_array($_POST['appmenu-item'])?$_POST['appmenu-item']:array();
			$bbapp_menu_type = isset( $_POST['menu'] ) ? $_POST['menu'] : 'tabbar';

			// Trim Invalid Items
			foreach ( $menu_items as $k => $menu_item ) {
				if ( empty( $menu_item['type'] ) ) {
					unset( $menu_items[ $k ] );
				}

				if ( 0 === (int) $menu_item['data']['id'] ) {
					if ( isset( $menu_item['data']['old-id'] ) ) {
						$menu_item['data']['id'] = $menu_item['data']['old-id'];
						unset( $menu_item['data']['old-id'] );
					}
					if ( 'custom' === $menu_item['object'] ) {
						$menu_item['data']['link'] = esc_url_raw( $menu_item['data']['link'] );
					}
				}
				$menu_item['label']    = stripslashes_deep( $menu_item['label'] );
				$menu_item['original'] = stripslashes_deep( $menu_item['original'] );
				$menu_items[ $k ]      = $menu_item;
			}

			if ( ! empty( $menu_items ) ) {
				if ( 'more' === $bbapp_menu_type ) {
					foreach ( $menu_items as $m => $menu_item ) {

						if ( 'section' === $menu_item['type'] ) {
							$menu_item_section = array();
							foreach ( $menu_items as $k => $m_item ) {
								if ( $m_item['data']['parent'] === $menu_item['id']) {
									$menu_item_section[] = $m_item;
									unset( $menu_items[ $k ] );
								}
							}
							$menu_items[ $m ]['section'] = ! empty( $menu_item_section ) ? array_values( $menu_item_section ) : '1';
						}

					}
				}
			} else {
				$menu_items = array();
			}

			$menu_items    = array_values( $menu_items );
			$app_menu_data = get_option( 'bbapp_menus' );
			if ( ! is_array( $app_menu_data ) ) {
				$app_menu_data = array();
			}

			if ( isset( $app_menu_data ) && ! empty( $app_menu_data ) ) {
				if ( 'more' === $bbapp_menu_type && empty( $menu_items ) ) {
					$more_menu = end( $app_menu_data['tabbar'] );
					if ( ! empty( $more_menu['object'] ) && 'more' === $more_menu['object'] ) {
						array_pop( $app_menu_data['tabbar'] );
					}
				}
			}
			$app_menu_data[ $bbapp_menu_type ] = $menu_items;

			// Save Menu Settings.
			$menu_settings = isset( $_POST['appmenu_settings'] ) ? $_POST['appmenu_settings'] : array();

			if ( ! is_array( $menu_settings ) ) {
				$menu_settings = array();
			}

			// Settings key allowed to be saved.
			$whitelist_settings_key = array();

			if ( 'more' === $bbapp_menu_type ) {
				$whitelist_settings_key['more_icon_style'] = "string";
			} else {
				$whitelist_settings_key['tab_bar_icon_style'] = "string";
				$whitelist_settings_key['tab_bar_visibility'] = "string";
				$whitelist_settings_key['appmenu_labels']     = "bool";
			}
			$app_settings = \BuddyBossApp\ManageApp::instance()->get_app_settings();
			if ( ! empty( $whitelist_settings_key ) ) {
				foreach ( $whitelist_settings_key as $setting_key => $type ) {
					$setting_value = ( isset( $menu_settings[ $setting_key ] ) ) ? $menu_settings[ $setting_key ] : "";
					// correct the type of data.
					if ( $type === "bool" ) {
						if ( $setting_value == "1" ) {
							$setting_value = true;
						} else {
							$setting_value = false;
						}
					}
					$app_settings["app_menu.{$setting_key}"] = $setting_value;
				}
			}

			update_option( 'bbapp_menus', $app_menu_data );
			\BuddyBossApp\ManageApp::instance()->update_app_settings( $app_settings );

			$this->_messages[] = array(
				'type'    => 'updated',
				'message' => __( '<strong>Tab Bar</strong> has been updated.', 'buddyboss-app' ),
			);

			return true;
		}

		/**
		 * Set a custom css on body of the page where current render will initiate.
		 *
		 * @param $classes
		 *
		 * @return string
		 */
		public function custom_body_class( $classes ) {

			if ( $this->will_render() ) {
				if ( strpos( $classes, 'nav-appmenu' ) == false ) {
					$classes .= ' nav-appmenu bbapp-menu buddyboss-app-menu';
				}
			}

			return $classes;
		}

		/**
		 * Called when new app menu is added.
		 */
		public function wp_ajax_add_menu_item() {
			check_ajax_referer( 'add-appmenu_item', 'menu-settings-column-nonce' );
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( - 1 );
			}

			$current_menu_type = isset( $_POST['current_menu'] ) ? $_POST['current_menu'] : 'tabbar';
			$menu_items        = array();
			foreach ( (array) $_POST['menu-item'] as $menu_item_data ) {

				// Or other menu type
				if ( ! empty( $menu_item_data['menu-item-type'] ) ) {

					$object = isset( $menu_item_data['menu-item-object'] ) ? $menu_item_data['menu-item-object'] : $menu_item_data['menu-item-type'];
					$deeplink_path = isset( $menu_item_data['menu-item-deeplink-path'] ) ? $menu_item_data['menu-item-deeplink-path'] : $object;

					if ( $menu_item_data['menu-item-type'] == "core" ) {
						$menu_item_data['menu-item-object-id'] = "";
					}

					$object_item                      = array();
					$object_item['current_menu_type'] = $current_menu_type;
					$object_item['id']                = uniqid();
					$object_item['object']            = $object;
					$object_item['label']             = stripslashes_deep( $menu_item_data['menu-item-title'] );
					$object_item['type']              = $menu_item_data['menu-item-type'];
					$object_item['data']              = array();


					if ( 'section' == $menu_item_data['menu-item-object'] ) {
						$menu_item_data['menu-item-object-id'] = uniqid();
					}

					if ( $object_item['type'] == "custom" ) {
						$object_item['url'] = $menu_item_data["menu-item-url"];
					}

					$object_item['data']['id']     = $menu_item_data['menu-item-object-id'];
					$object_item['data']['parent'] = isset( $menu_item_data['menu-item-parent-id'] ) ? $menu_item_data['menu-item-parent-id'] : "";
					$object_item['data']['link']   = ! empty( $menu_item_data['menu-item-url'] ) ? urldecode( esc_url_raw($menu_item_data['menu-item-url'] ) ) : '#';
					$object_item['data']['deeplink_path']   = $deeplink_path;
					$object_item['section']        = 'section' == $menu_item_data['menu-item-object'] ? '1' : '0';

					$object_item['icon'] = bbapp_get_menu_icon( $object_item['object'], $object_item['type'] );
					$object_item['icon']['monochrome_setting'] = wp_json_encode(array(
						'icon_monochrome_checkbox' => 'yes',
						'monochrome_option'        => 'default',
						'icon_monochrome_color'    => bbapp_get_default_color('bottomTabsColor'),
					));

					$menu_items[] = $object_item;
				}

			}
			ob_start();
			foreach ( $menu_items as $menu_item ) {
				switch ( $menu_item['type'] ) {
					case 'section':
						$this->render_appmenu_page( $menu_item, $menu_item['data']['id'] );
						break;
					default :
						$this->render_appmenu_page( $menu_item, uniqid() );
						break;
				}
			}
			echo ob_get_clean();

			wp_die();
		}

		/**
		 * @param        $menu_item
		 * @param string $index
		 */
		public function render_appmenu_page( $menu_item, $index = '' ) {

			global $section_loop,$section_id,$menu_parent_id;
			
			$depth = 0;

			if ( $menu_item['type'] == "section" ) {
				$section_loop = true;
				$section_id   = $menu_item['id'];
			} else {
				if ( isset( $section_loop ) && $section_loop && ! empty( $menu_item['data']['parent'] ) && $menu_item['data']['parent'] === $section_id ) {
					$depth                       = 1;
					$menu_parent_id = $menu_item['data']['parent']; // fix the parent id.
					$menu_item['data']['parent'] = $section_id; // fix the parent id.
				} else {
					$section_loop                = false;
					$menu_item['data']['parent'] = "";
				}
			}

			$screen_group           = $menu_item['type'];
			$register_meta_boxes = apply_filters( 'bbapp_register_menu_metaboxes', array() );
			if ( $menu_item['object'] == "more" ) {
				$screen_group_label = __( 'More Tab', 'buddyboss-app' );
			} elseif ( $screen_group == 'post_type' ) {
				if ( $menu_item['object'] == "page" ) {
					$screen_group_label = __( 'WordPress Page', 'buddyboss-app' );
				} elseif ( $menu_item['object'] == "app_page" ) {
					$screen_group_label = __( 'App Page', 'buddyboss-app' );
				} else {
					$post_type_object = get_post_type_object( $menu_item['object'] );
					$screen_group_label  = ! empty( $post_type_object ) ? $post_type_object->label : __( 'Custom Post Type', 'buddyboss-app' );
				}
			} elseif ( isset( $register_meta_boxes[ $screen_group ] ) ) {
				$screen_group_label = $register_meta_boxes[ $screen_group ]['title'];
			} else {
				$screen_group_label = $screen_group;
			}

			$menu_section = 0;
			if ( ! empty( $menu_item['section'] ) ) {
				if ( is_array( $menu_item['section'] ) ) {
					$menu_section = 1;
				}
			}

			$branding_options = \BuddyBossApp\Branding::instance()->get_options();
			$branding_values  = isset( $branding_options["styles"] ) ? $branding_options["styles"] : array();

			$icon_style_id = ( ! empty( $menu_item['current_menu_type'] ) && 'more' === $menu_item['current_menu_type'] ) ? '#more_icon_style' : '#tab_bar_icon_style';

			$menu_item_argument = array(
				"id"          => isset( $menu_item['id'] ) ? $menu_item['id'] : uniqid(),
				"original"    => isset( $menu_item['original'] ) ? $menu_item['original'] : $menu_item['label'],
				"index"       => ! empty( $index ) ? $index : 0,
				"label"       => $menu_item['label'],
				"type"        => $menu_item['type'],
				"type_label"  => $screen_group_label,
				"object"      => $menu_item['object'],
				'depth'       => $depth,
				'data'        => array(
					'id'          => ! empty( $menu_item['data']['id'] ) ? $menu_item['data']['id'] : "",
					'link'        => ! empty( $menu_item['data']['link'] ) ? urldecode( $menu_item['data']['link'] ) : '',
					'parent'      => isset( $menu_item['data']['parent'] ) ? $menu_item['data']['parent'] : $index,
					'external'    => ! empty( $menu_item['data']['open_external'] ) ? $menu_item['data']['open_external'] : '',
					'is_readonly' => false,
					'deeplink_path' => ! empty( $menu_item['data']['deeplink_path'] ) ? $menu_item['data']['deeplink_path'] : '',
				),
				"icon"        => array(
					'uri'           => ! empty( $menu_item['icon']['uri'] ) ? str_replace('appboss/','bbapp/',$menu_item['icon']['uri']) : '',
					"settings"      => ! empty( $menu_item['icon']['monochrome_setting'] ) ? $menu_item['icon']['monochrome_setting'] : $this->default_monochrome_setting(),
					'icon_style'    => ! empty( $menu_item['icon']['icon_style'] ) ? $menu_item['icon']['icon_style'] : 'filled',
					'icon_style_id' => ! empty( $menu_item['icon']['icon_style_id'] ) ? $menu_item['icon']['icon_style_id'] : $icon_style_id,
				),
				'has_disable' => ( isset( $menu_item['has_disable'] ) && $menu_item['has_disable'] === true ),
			);

			/**
			 * Check unlinked menu items for CPT.
			 */
			$linked = true;
			$cpt_menu_type = apply_filters( 'bbapp_app_menus_allowed_post_types', array(
				'page',
				'post',
				'app_page',
			) );
			if ( 'post_type' === $menu_item['type'] && in_array( $menu_item['object'], $cpt_menu_type ) ) {
				$post = get_post( $menu_item['data']['id'] );
				if ( empty( $post ) || is_wp_error( $post ) || $post->post_status != "publish" ) {
					$linked                            = false;
					$menu_item_argument['has_disable'] = true;
				} else {
					$menu_item_argument['label']               = ! empty( $menu_item['label'] ) ? $menu_item['label'] : $post->post_title;
					$menu_item_argument['data']['link']        = get_permalink( $post );
					$menu_item_argument['data']['is_readonly'] = true;
					$menu_item_argument["original"]            = $post->post_title;
				}
			}

			$menu_item_argument['deeplink_url'] = $this->get_menus_deeplinking_url( $menu_item_argument );

			include bbapp()->plugin_dir . "/views/appearance/menu/markup.php";
		}

		/**
		 * Get deeplinking url
		 *
		 * @param $menu
		 *
		 * @return string|void
		 */
		public function get_menus_deeplinking_url( $menu ) {

			switch ( $menu['type'] ) {
				case 'core':
				case 'custom_screen':
				case 'bb_logged_in':
				case 'app_settings':
						$deeplinking_url = home_url( 'bbapp/' . $menu['data']['deeplink_path'] );
					break;
				case 'post_type':
					if ( $menu['object'] === 'app_page' ) {
						$deeplinking_url = home_url( 'bbapp/page/' . $menu['data']['id'] );
					} else {
						$deeplinking_url = $menu['data']['link'];
					}
					break;
				default:
					$deeplinking_url = '';
			}

			return $deeplinking_url;
		}

		/**
		 * Default monochrome setting.
		 * @return string|array
		 */
		public function default_monochrome_setting() {
			return wp_json_encode(array(
				'icon_monochrome_checkbox' => 'yes',
				'monochrome_option'        => 'default',
				'icon_monochrome_color'    => bbapp_get_default_color( 'bottomTabsColor' ),
			));
		}

		/**
		 * @param bool   $app_id
		 * @param string $app_menu_type
		 *
		 * @return array|bool
		 */
		public function get_core_appmenu( $app_menu_type = 'tabbar' ) {

			$app_menu = apply_filters( 'bbapp_app_menu', array() );

			$app_menu = apply_filters( "bbapp_app_menu_filter", $app_menu, $app_menu_type );

			//Remove duplicate items form menu
			$app_menu = array_intersect_key( $app_menu, array_unique( array_map( 'serialize', $app_menu ) ) );

			return $app_menu;
		}
		/**
		 * Menu dependency added.
		 *
		 * @param bool  $status status of menu.
		 * @param array $menu   menu item.
		 *
		 * @return false
		 */
		public function _filter_app_menu_by_dependency( $status, $menu ) {
			if ( empty( $menu ) ) {
				return $status;
			}
			$type      = $menu['type'];
			$menu_name = $menu['object'];

			if ( in_array( $type, array( 'section', 'custom', 'post_type' ) ) ) {
				return $status;
			}

			if ( in_array( $menu_name, array( 'more' ) ) ) {
				return $status;
			}

			$all_menus = apply_filters( 'bbapp_get_all_menus', array() );

			if ( ! isset( $all_menus[ $type ][ $menu_name ] ) ) {
				return false;
			}

			if ( 'post_type' === $type ) {
				$post = get_post( $menu['data']['id'] );
				if ( empty( $post ) || is_wp_error( $post ) || $post->post_status != "publish" ) {
					return false;
				}
			}

			return $status;
		}

		/**
		 * If feature is disable then exclude the menu from menu list.
		 *
		 * @param array  $app_menus     All menus.
		 * @param string $app_menu_type App menu type (tabbar|more)
		 *
		 * @return mixed
		 */
		public function _exclude_menu_from_menu_list( $app_menus, $app_menu_type ) {
			if ( ! is_array( $app_menus ) ) {
				return array();
			}
			$all_menus = apply_filters( 'bbapp_get_all_menus', array() );
			if ( ! empty( $app_menus ) ) {
				foreach ( $app_menus as $key => $app_menu ) {
					if ( ! bbapp_is_rest() ) {
						$app_menus[ $key ] = $this->bbapp_deeplink_path( $app_menu,$all_menus );
					}
					$type = $app_menu['type'];

					if ( ! is_user_logged_in() && 'bb_logged_in' === $type ) {
						unset( $app_menus[ $key ] );
					}

					if ( in_array( $type, array( 'custom', 'post_type' ) ) ) {
						if ( $this->bbapp_is_not_published_post_type_menu( $app_menu['data']['id'], $type, bbapp_is_rest() ) ) {
							unset( $app_menus[ $key ] );
						}
						continue;
					}

					$menu_name = $app_menu['object'];
					if ( 'section' === $menu_name ) {
						$_exclude_section_menus       = $this->_exclude_menu_from_menu_list( $app_menu['section'], $app_menu_type );
						$app_menus[ $key ]['section'] = $_exclude_section_menus;
					} else {
						if ( ! isset( $all_menus[ $type ][ $menu_name ] ) && ! ( 'core' === $type && 'more' === $menu_name ) ) {
							unset( $app_menus[ $key ] );
						}
					}
				}

			}

			return $app_menus;
		}

		/**
		 * Check post type menu is not published so exclude from menu api.
		 *
		 * @param int    $id      Post id
		 * @param string $type    Menu type
		 * @param false  $is_rest is rest api or not.
		 *
		 * @return bool return true if provided post id is not published.
		 */
		public function bbapp_is_not_published_post_type_menu( $id, $type, $is_rest = false ) {
			$is_not_published = false;
			if ( $is_rest && 'post_type' === $type ) {
				$post = get_post( $id );
				if ( empty( $post ) || is_wp_error( $post ) || $post->post_status != "publish" ) {
					$is_not_published = true;
				}
			}

			return $is_not_published;
		}

		/**
		 * Create deeplinking path.
		 *
		 * @param $app_menu
		 *
		 * @return mixed
		 */
		public function bbapp_deeplink_path( $app_menu, $all_menus ) {
			$register_meta_boxes = apply_filters( 'bbapp_register_menu_metaboxes', array() );
			$menu_type           = isset( $app_menu['type'] ) ? $app_menu['type'] : '';
			if ( isset( $menu_type ) && ! empty( $register_meta_boxes[ $menu_type ] ) && ! empty( $register_meta_boxes[ $menu_type ]['args'] ) ) {
				$meta_boxes_args                   = $register_meta_boxes[ $menu_type ]['args'];
				$slug                              = isset( $all_menus[ $menu_type ][ $app_menu['object'] ] ) ? $all_menus[ $menu_type ][ $app_menu['object'] ]['slug'] : '';
				$app_menu['data']['deeplink_path'] = ( $slug !== $meta_boxes_args['deeplink_base'] ) ? $meta_boxes_args['deeplink_base'] . '/' . $slug : $slug;
			}

			return $app_menu;
		}


	}

endif;