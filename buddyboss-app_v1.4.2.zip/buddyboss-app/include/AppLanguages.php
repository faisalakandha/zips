<?php
namespace BuddyBossApp;

// Exit if accessed directly
if (!defined('ABSPATH')) {
	exit;
}

use BuddyBossApp\Helpers\BBAPP_File;
use BuddyBossApp\Helpers\File;

class AppLanguages {

	public static $instance;

	/**
	 * Get the instance of the class.
	 *
	 * @return AppLanguages
	 */
	public static function instance() {
		if (!isset(self::$instance)) {
			$class = __CLASS__;
			self::$instance = new $class;
			self::$instance->_load();
		}

		return self::$instance;
	}

	/**
	 * AppLanguages constructor.
	 */
	public function __construct() {
	}

	/**
	 *
	 */
	public function _load() {}

	/**
	 * Return Languages of App.
	 * @param $app_id
	 *
	 * @return array|mixed
	 */
	public function get_languages() {
		$data = get_option( "bbapp_languages" );

		// Merge main site language when empty on network enabled.
		if ( bbapp()->is_network_activated() && ! is_main_site() && empty( $data ) ) {
			$current_blog_id = get_current_blog_id();
			$main_site_id    = get_main_site_id();
			switch_to_blog( $main_site_id );
			$main_site_data = get_option( "bbapp_languages" );
			switch_to_blog( $current_blog_id );

			if ( ! empty( $main_site_data ) ) {
				update_option( "bbapp_languages", $main_site_data );
			}
		}

		$data = isset( $data ) ? $data : array();

		return $data;
	}

	/**
	 * Update Languages of App.
	 *
	 * @param $options
	 */
	public function update_languages($options) {
		if(is_array($options)) {
			update_option( "bbapp_languages", $options );
		}
	}

	/**
	 * Return the all languages string.
	 *
	 *
	 * @return array|bool
	 */
	public function get_merged_languages() {
		static $languages;

		if ( isset( $languages ) ) {
			return $languages;
		}

		$current_language = get_locale();
		$json             = BBAPP_File::readFile( bbapp()->plugin_dir . 'include/App/Format/default_langs.json' );
		$languages        = json_decode( $json, true );

		$languages = array_key_exists( $current_language, $languages ) ? $languages[ $current_language ] : $languages['en_US'];
		foreach ( $languages as $kk => $vv ) {
			$languages[ $kk ] = array(
				"source"     => $vv,
				"translate"  => "",
				"only_in_db" => false
			);
		}

		// Merge the translate which are available on DB but not in current language file.
		// This we needed to make sure to support leftover lang string for older apps.

		$saved_languages = $this->get_languages();
		if ( ! empty( $saved_languages[ $current_language ] ) ) {
			foreach ( $saved_languages[ $current_language ] as $kk => $vv ) {
				if ( ! isset( $languages[ $kk ] ) ) {
					$languages[ $kk ] = array(
						"source"     => $saved_languages[ $current_language ][ $kk ],
						"translate"  => $saved_languages[ $current_language ][ $kk ],
						"only_in_db" => true
					);
				} else {
					$languages[ $kk ]['translate'] = $saved_languages[ $current_language ][ $kk ];
				}
			}
		}

		return array( $current_language => $languages );
	}

	/**
	 * Transform the language for rest API output.
	 *
	 * @return array|\WP_Error
	 */
	public function get_languages_for_rest() {
		static $json_languages;

		if ( isset( $json_languages ) ) {
			return $json_languages;
		}

		$json_languages = $this->get_merged_languages();
		// Exclude the languages which don't have translates.
		foreach ( $json_languages as $k => $v ) {
			if ( ! empty( $json_languages[ $k ] ) ) {
				foreach ( $json_languages[ $k ] as $kk => $vv ) {
					if ( empty( $json_languages[ $k ][ $kk ]["translate"] ) ) {
						unset( $json_languages[ $k ][ $kk ] );
					}
				}
			}
		}

		$new_json_languages = array(
			'en_US' => array()
		);

		$current_language                        = get_locale();
		$new_json_languages[ $current_language ] = [];

		// normalize the language into key val;
		foreach ( $json_languages as $k => $v ) {
			foreach ( $json_languages[ $k ] as $kk => $vv ) {
				// Current languages pass to array.
				$new_json_languages['en_US'][ $kk ] = $new_json_languages[ $k ][ $kk ] = $json_languages[ $k ][ $kk ]["translate"];
			}
		}

		return (array) $new_json_languages; // Only return saved language data.
	}
}
