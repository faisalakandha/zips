<?php

namespace BuddyBossApp\Builds;

use BuddyBossApp\Build;
use BuddyBossApp\ManageApp;

class InstallerScreen {
	private static $instance;
	var $load_screen = false;
	var $build = false;

	/**
	 * Using Singleton, see instance()
	 */
	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 * @return InstallerScreen
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$class_name     = __CLASS__;
			self::$instance = new $class_name;
			self::$instance->load();
		}

		return self::$instance;
	}

	/**
	 *
	 */
	public function load() {
		add_action( 'init', array( $this, 'load_installer_screen' ), 99 );
	}

	/*
	 * Renders the app installer screen.
	 */
	public function load_installer_screen() {
		if ( isset( $_GET["bbapp_installer_screen"] ) && $_GET["bbapp_installer_screen"] == "1" ) {

			$build_id = $this->get_build_id();
			$app_id   = ManageApp::instance()->get_app_id();

			if ( empty( $build_id ) ) {
				wp_redirect( home_url("?bbapp-error-installing=1") );
				exit;
			}

			$builds = Build::instance()->get_app_builds( '', '', array( $build_id ) );
			$fullfill_req = true;

			if ( ! isset( $builds["data"][0] ) || ! isset( $builds["data"][0]["env"] ) ) {
				$fullfill_req = false;
			} else {
				$this->build = $builds["data"][0];
			}

			add_theme_support( 'title-tag' );
			add_filter( 'wp_title', array( $this, "wp_title" ), 99, 2 );
			remove_action( 'wp_head', '_wp_render_title_tag', 1 );
			add_filter( 'wp_head', array( $this, "wp_render_title_tag" ), 99 );
			add_filter( 'body_class', array( $this, 'body_class' ) );
			show_admin_bar(false);

			$iPod    = stripos($_SERVER['HTTP_USER_AGENT'],"iPod");
			$iPhone  = stripos($_SERVER['HTTP_USER_AGENT'],"iPhone");
			$iPad    = stripos($_SERVER['HTTP_USER_AGENT'],"iPad");
			$safari = stripos( $_SERVER['HTTP_USER_AGENT'], 'Safari');
            $android = stristr($_SERVER['HTTP_USER_AGENT'],'android');

			if($this->get_app_platform() == "ios") {
				if ( $safari === false || $android == true ) {
			        $fullfill_req = false;
                }
            }
			if($this->get_app_platform() == "android") {
			    if(!$android || !($iPod === false && $iPhone === false && $iPad === false)) {
			        $fullfill_req = false;
                }
            }

			if (!$fullfill_req) {
				$this->installer_downfall();
            } else {
				$this->installer_screen();
            }

			exit;
		}
	}

	/**
	 * Return the app icon url
	 */
	public function get_app_icon() {
		$app_icon = \BuddyBossApp\Admin\Appearance\Branding::instance()->get_upload_file_info( 'app_icon_ios.png');
		if(!isset($app_icon["fileurl"])) {
			$app_icon["fileurl"] = false;
        }
		return $app_icon["fileurl"];
	}

	public function body_class( $classes ) {
		$classes[] = 'bbapp-app-installation-page';
		return $classes;
	}

	/**
	 * Change the installer screen title.
	 *
	 * @param $title
	 * @param $sep
	 *
	 * @return string
	 */
	public function wp_title( $title, $sep ) {
		$title      .= get_bloginfo( 'name' );
		$title_text = sprintf( __( 'Installing %1$s %2$s', "buddyboss-app" ), $this->get_app_platform(), $this->get_app_version() );
		$title      = "$title $sep $title_text";

		return $title;
	}

	/**
	 * Change the installer screen title.
	 *
	 * @return string
	 */
	public function wp_render_title_tag() {
		?>
        <title>
			<?php wp_title( '|', true, 'right' ); ?>
        </title>
		<?php
	}

	/**
	 * Installer Screen.
	 */
	public function installer_screen() {
		include bbapp()->plugin_dir . 'views/app-installer/install-screen.php';
		exit;
	}
    public function installer_downfall() {
		include bbapp()->plugin_dir . 'views/app-installer/install-downfall.php';
		exit;
	}

	/**
	 * Return app platform
	 * @return bool
	 */
	public function get_app_platform() {
		return ( isset( $this->build ["type"] ) ) ? $this->build ["type"] : false;
	}

	/**
	 * Return app platform
	 * @return bool
	 */
	public function get_app_platform_label() {
		$labels = array(
			"android" => __( "Android", "buddyboss-app" ),
			"ios"     => __( "iOS", "buddyboss-app" )
		);
		if ( isset( $labels[ $this->get_app_platform() ] ) ) {
			return $labels[ $this->get_app_platform() ];
		} else {
			return $this->get_app_platform();
		}
	}

	/**
	 * Return app platform
	 * @return bool
	 */
	public function get_build_id() {
		return (int) ( isset( $_GET["build_id"] ) ) ? $_GET["build_id"] : false;
	}

	/**
	 * Return app platform
	 * @return bool
	 */
	public function get_app_version() {
		return ( isset( $this->build ["build_version"] ) ) ? $this->build ["build_version"] : false;
	}

	/**
	 * Return app platform
	 * @return bool
	 */
	public function get_app_version_code() {
		if ( $this->build ) {
			return ( isset( $this->build ["build_version_code"] ) ) ? $this->build ["build_version_code"] : false;
		}

		return false;
	}

	/**
	 * Return App NAme.
	 * @return mixed|string
	 */
	public function get_app_name() {
		$get_app_settings = ManageApp::instance()->get_app_settings( true );
		return $get_app_settings["publish.general.appname"];
	}

	/**
	 * Return the build download URL.
	 */
	public function get_build_download_url() {

		if ( $this->build ) {

			if ( $this->get_app_platform() == "ios" ) {
				return Installer::instance()->get_ios_plist_link( $this->build["id"] );
			}

			return $this->build["build_url"];
		}

		return false;
	}

}