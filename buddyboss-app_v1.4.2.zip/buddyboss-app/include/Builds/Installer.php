<?php

namespace BuddyBossApp\Builds;

use BuddyBossApp\AppStores\Apple;
use BuddyBossApp\Branding;
use BuddyBossApp\Build;
use BuddyBossApp\ClientCommon;
use BuddyBossApp\ManageApp;

class Installer {
	private static $instance;
	var $load_screen = false;
	var $build = false;

	/**
	 * Using Singleton, see instance()
	 */
	public function __construct() {
		//Using Singleton, see instance()
	}

	/**
	 * Get the instance of the class.
	 * @return Installer
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			$class_name     = __CLASS__;
			self::$instance = new $class_name;
			self::$instance->load();
		}

		return self::$instance;
	}

	/**
	 * Load
	 */
	public function load() {
		InstallerScreen::instance();
		add_action( 'init', array( $this, 'ios_plist_output' ), 99 );
		add_action( 'init', array( $this, 'register_device' ), 99 );
	}

	/**
	 * Register Device
	 */
	public function register_device() {

		if ( isset( $_GET["register_ios_device"] ) ) {

			$uuid        = isset( $_GET["uuid"] ) ? sanitize_title($_GET["uuid"]) : false;
			$device_name = isset( $_GET["device_name"] ) && !empty($_GET["device_name"]) ? $_GET["device_name"] : "iPhone";
			$device_owner_name = isset( $_GET["device_owner_name"] ) && !empty($_GET["device_owner_name"]) ? $_GET["device_owner_name"] : "";
			$bbapp_app_id      = isset( $_GET["bbapp_app_id"] ) ? $_GET["bbapp_app_id"] : false;
			$token      = isset( $_GET["bbapp_token"] ) ? $_GET["bbapp_token"] : false;

			if ( empty( $uuid ) || empty( $device_name ) || empty( $bbapp_app_id ) ) {
				die( __("#1 There was an error while registering your device. Please try again later.", "buddyboss-app") );
			}

			$app = ManageApp::instance()->get_app();
			if ( $app["bbapp_app_id"] != $bbapp_app_id ) {
				die( __("#2 There was an error while registering your device. Please try again later.", "buddyboss-app") );
			}

			// Validate Auth
			if ( $token != ManageApp::instance()->get_auth_app_key() ) {
				die( __("#3 There was an error while registering your device. Please try again later.", "buddyboss-app") );
			}

			$device_name = "$device_owner_name ($device_name)";

			$is_registered = Apple::instance()->register_development_device( $device_name, $uuid );

            // Create new provisioning profile.
            if($is_registered) {
	            Apple::instance()->update_provisioning_profile( true );
            }

			add_filter( 'body_class', function($classes) {
				$classes[] = 'bbapp-app-device-registered-page';
				return $classes;
			} );

			show_admin_bar(false);

			include bbapp()->plugin_dir . 'views/app-installer/device-registered.php';
			exit;

		}
	}

	/**
	 * Get pList Install Link.
	 *
	 * @param $build_id
	 *
	 * @return string
	 */
	public function get_ios_plist_link( $build_id ) {
		$plist        = wp_nonce_url( home_url( "?build_id={$build_id}" ), 'bbapp_ios_plist', 'bbapp_ios_plist' );
		// make sure download URL is always https. because apple don't allow to install app from insecure connection.
		$plist = str_replace( "http://", "https://", $plist );
		// Encode for URL safe.
		$plist = str_replace( "amp%3B", "", rawurlencode( $plist ) );

		return "itms-services://?action=download-manifest&url={$plist}";
	}

	/**
	 * Output the iOS install plist.
	 */
	public function ios_plist_output() {

		if ( ! isset( $_GET["bbapp_ios_plist"] ) ) {
			return false;
		}

		// security check.
		if ( ! wp_verify_nonce( $_GET["bbapp_ios_plist"], 'bbapp_ios_plist' ) ) {
			die( __( 'Installation Expired.', 'buddyboss-app' ) );
		}

		$app    = ManageApp::instance()->get_app();

		$build_id  = isset( $_GET["build_id"] ) ? $_GET["build_id"] : false;

		if ( empty( $build_id ) ) {
			die( "404" );
		}

		$builds   = Build::instance()->get_app_builds( '', '', array($build_id) );

		if(!isset($builds["data"][0]) || !isset($builds["data"][0]["env"]) || $builds["data"][0]["env"] != "dev"){
			die( "404" );
		}

		$build = $builds["data"][0];

		$settings = ManageApp::instance()->get_app_settings( true );

		$app_icon = \BuddyBossApp\Admin\Appearance\Branding::instance()->get_upload_file_info( 'app_icon_ios.png' );

		$app_name = isset( $settings["publish.general.appname"] ) ? $settings["publish.general.appname"] : $app["bbapp_app_id"];

		$bundle_id = $this->get_build_bundle_id( $build_id );

		if ( false === $bundle_id ) {
			die( "404" );
		}

		if ( ! $build || ! isset( $build["build_url"] ) ) {
			die( "404" );
		}

		header( "Content-Type:text/xml" );

		ob_start();
		?>
		<plist version="1.0">
		<dict>
			<key>items</key>
			<array>
				<dict>
					<key>assets</key>
					<array>
						<dict>
							<key>kind</key>
							<string>software-package</string>
							<key>url</key>
							<string><?php echo esc_html( $build["build_url"] ); ?></string>
						</dict>
						<dict>
							<key>kind</key>
							<string>display-image</string>
							<key>needs-shine</key>
							<false/>
							<key>url</key>
							<string><?php echo esc_html( $app_icon["fileurl"] ); ?></string>
						</dict>
					</array>
					<key>metadata</key>
					<dict>
						<key>bundle-identifier</key>
						<string><?php echo esc_html( $bundle_id ); ?></string>
						<key>bundle-version</key>
						<string><?php echo esc_html( $build["build_version_code"] ); ?></string>
						<key>subtitle</key>
						<string><?php echo esc_html( $build["build_version"] ); ?>
							(<?php echo esc_html( $build["build_version_code"] ); ?>)
						</string>
						<key>title</key>
						<string><?php echo esc_html( $app_name ); ?></string>
						<key>kind</key>
						<string>software</string>
					</dict>
				</dict>
			</array>
		</dict>
		</plist><?php
		$xml = ob_get_contents();
		ob_end_clean();
		$xml = str_replace( array( "   ", "\r", "\n" ), '', $xml );
		echo $xml;
		exit;
	}

	/**
	 * Get bundle id by build id.
	 *
	 * @param $build_id
	 *
	 * @return false|mixed
	 */
	public function get_build_bundle_id( $build_id ) {
		$args['bbapp_id']  = ManageApp::instance()->get_app_id();
		$args['bbapp_key'] = ManageApp::instance()->get_auth_app_key();
		$args['build_id']  = $build_id;
		$api_url           = ClientCommon::instance()->get_center_api_url( 'v1', 'api-get/get-build-details' );

		$request = bbapp_remote_get(
			$api_url,
			array(
				'timeout' => 45,
				'body'    => $args,
			)
		);

		$response         = wp_remote_retrieve_body( $request );
		$response         = json_decode( $response, true );
		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );

		if (
			'OK' === $response_message
			&& 200 === $response_code
			&& ! empty( $response )
		) {
			if ( isset( $response['id'] ) && $response['id'] === $build_id ) {
				if ( isset( $response['ios'] ) ) {
					return isset( $response['ios']['bundleid'] ) ? $response['ios']['bundleid'] : false;
				}
			}
		}

		return false;
	}

	/**
	 * @param $platform
	 * @param $version
	 * @param $env
	 *
	 * @return string|void
	 */
	public function get_installer_link( $build_id ) {
		$link = home_url( "?bbapp_installer_screen=1&build_id={$build_id}" );

		return $link;
	}

	/**
	 * Register URL.
	 *
	 * @return string
	 */
	public function get_device_register_url() {
		$bbapp_id = ManageApp::instance()->get_app_id();
		$cc_url   = ClientCommon::instance()->get_center_api_url();
		$site_url = home_url();
		$site_url = str_replace( "amp%3B", "", rawurlencode( $site_url ) );
		$link     = "{$cc_url}/device-enroll-start?client_url={$site_url}&bbapp_id={$bbapp_id}";

		return $link;
	}

}