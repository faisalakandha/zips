<?php

namespace BuddyBossApp;

/**
 * Class Jobs
 * Class helps to execute jobs on wordpress.
 */
class Jobs {

	protected static $instance;
	private $table = "bbapp_queue";
	protected $max_item_per_batch = 20;
	protected $max_memory_limit = '2000M';
	protected $min_memory_limit = '256M';
	protected $exec_start_time = 0;
	protected $max_execution_time = 20; // 20 sec.

	/**
	 * Jobs constructor.
	 */
	public function __construct() {
	}

	/**
	 * @return Jobs
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) ) {
			$class          = __CLASS__;
			self::$instance = new $class;
			self::$instance->load(); // run the hooks.
		}

		return self::$instance;
	}

	/**
	 * Load the class required code.
	 */
	public function load() {

		// Prefix Table Name
		$this->table = bbapp_get_network_table( $this->table );

		add_action( 'wp_ajax_bbapp_queue', array( $this, 'runProcess' ) );
		add_action( 'wp_ajax_nopriv_bbapp_queue', array( $this, 'runProcess' ) );
		add_action( 'bbapp_every_5min', array( $this, 'rescueTheRunner' ) );


	}

	/**
	 * Start background job.
	 */
	public function rescueTheRunner() {
		$this->start(); //starts if it's requires.
	}

	/**
	 * Add Queue Entry on Database.
	 *
	 * @param     $type
	 * @param     $data
	 * @param int $priority
	 *
	 * @return bool
	 */
	public function add( $type, $data = array(), $priority = 5 ) {
		global $wpdb;

		if ( empty( $type ) || empty( $priority ) ) {
			return false;
		}

		$insert = $wpdb->insert(
			$this->table,
			array(
				"created"  => current_time( 'mysql', 1 ),
				"modified" => current_time( 'mysql', 1 ),
				"type"     => $type,
				"data"     => serialize( $data ),
				"blog_id"  => get_current_blog_id(),
				"priority" => $priority
			)
		);

		return $insert;
	}

	/**
	 * Delete queue item from database.
	 *
	 * @param $id
	 *
	 * @return bool
	 */
	public function delete( $id ) {
		global $wpdb;

		if ( empty( $id ) ) {
			return false;
		}

		return $wpdb->delete(
			$this->table,
			array( "id" => $id )
		);
	}

	/**
	 * Return the count of how many items are in queue for type.
	 *
	 * @param $type
	 *
	 * @return int
	 */
	public function has_process_items( $type ) {
		global $wpdb;

		$count = $wpdb->get_var( $wpdb->prepare( "
		SELECT count(type) FROM {$this->table} WHERE type = %s AND blog_id = %s
		", $type, get_current_blog_id() ) );

		return (int) $count;
	}

	/**
	 * Get job types.
	 *
	 * @return array
	 */
	private function get_types() {
		global $wpdb;

		return $wpdb->get_col( $wpdb->prepare( "SELECT type FROM {$this->table} WHERE blog_id = %s", get_current_blog_id() ) );
	}

	/**
	 * Logs information.
	 *
	 * @param $text
	 */
	public function log( $text ) {
		Logger::instance()->add(
			"bbapp_queue",
			$text
		);
	}

	/**
	 * @param string $job_type job type.
	 *
	 * @return bool
	 */
	public function determine_process_running( $job_type ) {
		$process = get_site_transient( 'bbapp_queue_process_lk_' . $job_type );

		$retVal = false;

		if ( $process ) {
			$retVal = true;
		}

		return $retVal;
	}

	/**
	 * @param string $job_type job type.
	 *
	 * @return bool
	 */
	public function lock_process( $job_type ) {
		$this->exec_start_time = time();
		$lock_limit            = 60 * 2; // 2 min

		return set_site_transient( 'bbapp_queue_process_lk_' . $job_type, microtime(), $lock_limit );
	}

	/**
	 * @param string $job_type job type.
	 *
	 * @return bool
	 */
	public function unlock_process( $job_type ) {
		delete_site_transient( 'bbapp_queue_process_lk_' . $job_type );

		return true;
	}

	/**
	 * Return the items to be process per batch
	 *
	 * @param string $job_type job type.
	 *
	 * @return array|null|object
	 */
	public function get_processing_items( $job_type ) {
		global $wpdb;

		if ( empty( $job_type ) ) {
			return false;
		}

		return $wpdb->get_results( $wpdb->prepare( "
		SELECT *FROM {$this->table} WHERE type = %s AND blog_id = %s ORDER BY `created`, `priority` LIMIT %d
		", $job_type, get_current_blog_id(), $this->max_item_per_batch ) );

	}

	/**
	 * Process tasks
	 */
	public function runProcess() {

		$job_type = filter_input( INPUT_GET, 'type', FILTER_SANITIZE_STRING );
		if ( empty( $job_type ) ) {
			return;
		}

		$time_start = microtime( true );

		global $bbapp_queue_debug;

		if ( ! is_array( $bbapp_queue_debug ) ) {
			$bbapp_queue_debug = array();
		}

		session_write_close();

		register_shutdown_function( array( $this, "shutdown" ) );

		$this->lock_process( $job_type );

		$this->log( __( "BuddyBoss App queue batch has been started." ) );

		$process = $this->get_processing_items( $job_type );

		$task_count = 0;

		$did_completed_smoothly = true;

		if ( empty( $process ) ) {
			$this->log( __( "All items have been finished closing batch process." ) );
			$this->unlock_process( $job_type );
			exit;
		}

		foreach ( $process as $task ) {

			$bbapp_queue_debug["running_task"] = $task;

			$this->delete( $task->id ); // delete task if it's not finished or anything processor is responsible for adding new if not finished.

			do_action( "bbapp_queue_task_{$task->type}", $task );

			$task_count ++;

			$bbapp_queue_debug["running_task"]->done = true;

			if ( $this->php_limits_reached() ) {
				$did_completed_smoothly = false;
				$this->log( sprintf( __( "Maximum PHP limit reached. Stopping batch after running %s tasks..." ), $task_count ) );
				break;
			}

		}

		if ( $did_completed_smoothly ) {
			$this->log( sprintf( __( "Finished %s tasks smoothly on this batch." ), $task_count ) );
		} else {
			$this->log( __( "batch was not finished smoothly due to some reasons check above." ) );
		}

		$this->unlock_process( $job_type );

		$this->start(); // start another batch

		$time_end       = microtime( true );
		$execution_time = ( $time_end - $time_start );

		echo '<b>Total Execution Time:</b> ' . $execution_time . ' Sec';

		die( "Success" );
	}

	/**
	 * Checks if we have more resources in php to continue.
	 * @return bool
	 */
	public function php_limits_reached() {

		$retval = false;

		/**
		 * Check Memory Limits.
		 */

		$memory_limit = ( function_exists( 'ini_get' ) ) ? ini_get( 'memory_limit' ) : $this->min_memory_limit;

		if ( intval( $memory_limit ) === - 1 || ! $memory_limit ) {
			$memory_limit = $this->max_memory_limit;
		}
		// mb to bytes
		$memory_limit = intval( $memory_limit ) * pow( 1024, 2 );
		// Reduce it to some amount to be safe.
		$memory_limit   *= 0.8;
		$current_memory = memory_get_usage( true );

		if ( $current_memory >= $memory_limit ) {
			$retval = true;
		}

		if ( $retval ) {
			return $retval;
		}

		/**
		 * Check Timeout Limits.
		 */
		$executed_time = $this->exec_start_time + $this->max_execution_time;

		if ( time() >= $executed_time ) {
			$retval = true;
		}

		return $retval;

	}

	/**
	 * Dispatch the queue for processing.
	 */
	public function start() {

		$job_types = $this->get_types();
		if ( ! empty( $job_types ) ) {
			foreach ( $job_types as $job_type ) {

				if ( $this->determine_process_running( $job_type ) ) {
					return false;
				}

				$this->lock_process( $job_type ); // lock so we don't create duplicate process.

				$args = array(
					'timeout'   => apply_filters( 'bbapp_jobs_start_timeout', 0.01 ),
					'blocking'  => false,
					'body'      => array(),
					'cookies'   => $_COOKIE,
					'sslverify' => false,
				);

				$job_url = esc_url_raw( admin_url( 'admin-ajax.php' ) . "?action=bbapp_queue&type=" . $job_type );
				wp_remote_post( $job_url, $args );
			}
		}

		return true;
	}

	/**
	 * Handles any fatal error occurs while running tasks.
	 */
	public function shutdown() {

		global $bbapp_queue_debug;

		$job_type = filter_input( INPUT_GET, 'type', FILTER_SANITIZE_STRING );
		if ( empty( $job_type ) ) {
			return;
		}

		$last_error = error_get_last();

		if ( isset( $bbapp_queue_debug["running_task"] ) && ! isset( $bbapp_queue_debug["running_task"]->done ) ) {

			$debug_info = array(
				"task"      => $bbapp_queue_debug["running_task"],
				"env_error" => $last_error
			);

			$prepare_log = sprintf( __( "There was an error while running tasks, debug info below \n ---- \n %s",
				bbapp()->domain ), print_r( $debug_info, true ) );
			$this->log( $prepare_log );

			if ( $last_error['type'] === E_ERROR ) {
				$this->log( __( "Restarting queue processes due to fatal error.",
					bbapp()->domain ) );
				$this->unlock_process( $job_type );
				$this->start(); // start another batch
			}

		}

	}
}
