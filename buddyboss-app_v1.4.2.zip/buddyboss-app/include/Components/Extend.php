<?php

namespace BuddyBossApp\Components;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * This class is used to add the components into BuddyBossApp.
 * Class Extend
 * @package BuddyBossApp\Notification
 */
abstract class Extend {
	private static $instances = false;
	private $name = false;
	private $id = false;
	private $desc = "";
	private $enabled_default = false;
	private $required = false;

	function __construct() {
		/** Nothing here */
	}

	static public function instance() {
		$class = get_called_class();
		if ( ! isset( self::$instances[ $class ] ) ) {
			self::$instances[ $class ] = new $class();
			self::$instances[ $class ]->_load();
		}

		return self::$instances[ $class ];
	}

	function _load() {
		$this->load();
		if ( $this->id ) {
			add_filter( "bbapp_get_components", array( $this, "bbapp_get_components" ) );
			add_action( 'bbapp_components_loaded', array( $this, 'components_loaded' ), 99 );
		}
	}

	/**
	 * This function is must needed to call.
	 *
	 * @param string $id Components ID
	 * @param string $name Components Name ( Will used as Component Label or Title on Components Settings )
	 * @param string $desc
	 * @param bool $enabled_by_default
	 *
	 * @param bool $required
	 *
	 * @return void
	 */
	function start( $id, $name, $desc = "", $enabled_by_default = false, $required = false ) {
		if ( ! empty( $id ) && ! empty( $name ) ) {
			$this->id              = $id;
			$this->name            = $name;
			$this->desc            = $desc;
			$this->enabled_default = $enabled_by_default;
			$this->required        = $required;
		}
	}

	/**
	 * Returns the component id.
	 * @return bool
	 */
	function get_component_id() {
		return $this->component_name;
	}

	/**
	 * Returns the component name.
	 * @return bool
	 */
	function get_component_name() {
		return $this->component_name;
	}

	abstract function load();

	/**
	 * This class shouldn't be override.
	 *
	 * @param $components
	 *
	 * @return mixed
	 */
	function bbapp_get_components( $components ) {
		$components[ $this->id ] = array(
			"id"              => $this->id,
			"name"            => $this->name,
			"desc"            => $this->desc,
			"enabled_default" => $this->enabled_default,
			"required"        => $this->required,
			"instance"        => $this
		);

		return $components;
	}

	/**
	 * Provide setting links by components.
	 *
	 * @param $app_id
	 *
	 * @return mixed
	 */
	abstract function settings_links();

	/**
	 * Return the settings link.
	 *
	 * @param $app_id
	 *
	 * @return array
	 */
	function get_settings_link() {
		$setting_links = array();
		if ( method_exists( $this, 'settings_links' ) ) {
			$setting_links = $this->settings_links();
			if ( ! is_array( $setting_links ) ) {
				$setting_links = array();
			}
		}

		return $setting_links;
	}

	/**
	 * Safe point to load all codes.
	 * @return mixed
	 */
	abstract public function components_loaded();

}

