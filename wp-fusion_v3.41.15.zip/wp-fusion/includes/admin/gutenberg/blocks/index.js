/**
 * Import blocks
 */
import './secure-block/js/index';
import './secure-block-inner-secure/js/index';
import './secure-block-inner-unsecure/js/index';
