<?php

$getresponse_fields = array();

$getresponse_fields['first_name'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'name',
);

$getresponse_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email',
);
