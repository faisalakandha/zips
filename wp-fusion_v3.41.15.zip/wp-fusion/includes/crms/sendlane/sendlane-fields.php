<?php

$sendlane_fields = array();

$sendlane_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'first_name',
);

$sendlane_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'last_name',
);

$sendlane_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email',
);

$sendlane_fields['billing_phone'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'phone',
);
