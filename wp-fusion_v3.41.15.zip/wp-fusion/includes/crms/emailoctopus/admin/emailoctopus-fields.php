<?php

$emailoctopus_fields = array();

$emailoctopus_fields['user_login'] = array(
	'crm_label' => 'Name',
	'crm_field' => 'FirstName',
);

$emailoctopus_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'FirstName',
);

$emailoctopus_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'LastName',
);

$emailoctopus_fields['user_email'] = array(
	'crm_label' => 'Email Address',
	'crm_field' => 'email_address',
);