<?php

namespace WeDevs\PM_Pro\Modules\Gantt\Core\Permission;

use WeDevs\PM\Core\Permissions\Abstract_Permission;
use Reflection;
use WP_REST_Request;
use WeDevs\PM\Common\Models\Boardable;

class Permission extends Abstract_Permission {

    public function check() {

    }
}
