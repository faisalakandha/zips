# Local Installation Guide

Navigate to the plugin directory and run the following commands

1. `git clone https://bitbucket.org/wedevs/cpm-pro-module.git`
2. `cd <plugin-dir-name>`
3. `composer install` 
4. `composer dumpautoload -o`
5. `npm install`
6. `npm run start`
7. Activate plugin
