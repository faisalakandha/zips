<?php
namespace BuddyBoss\Zoom\Firebase\JWT;

class BeforeValidException extends \UnexpectedValueException
{
}
