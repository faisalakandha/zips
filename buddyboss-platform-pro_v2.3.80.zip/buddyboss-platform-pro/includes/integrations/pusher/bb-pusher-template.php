<?php
/**
 * BuddyBoss Pusher Template Functions.
 *
 * @package BuddyBossPro\Pusher\Templates
 * @since 2.1.6
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;
