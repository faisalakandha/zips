/**
 * LearnDash Question Context
 *
 * @since 4.0.0
 * @package LearnDash
 */

import { createContext } from 'react';

export const QuestionContext = createContext( {} );