<?php
/**
 * Deprecated functions from LD 3.5.1
 * The functions will be removed in a later version.
 *
 * @package LearnDash\Deprecated
 * @since 3.5.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Other deprecated class functions.
 */
/**
 * includes/course/ld-course-progress.php apply_filters( 'learndash_quiz_complete_essay_grded' )
 */

