jQuery(function ($) {
	var bbl_video_uploader, $wrapper;
	$(document).on('click', '.bbl-field-label-type-video-upload-btn', function (e) {

		e.preventDefault();

		var $this = $(this);

		$wrapper = $this.parents('.bbl-form-field-type-video-container');

		var oldFieldID = BuddyBlog_Pro.currentMediaFieldID;
		BuddyBlog_Pro.currentMediaFieldID = $wrapper.data('field-key');

		// If the uploader object has already been created, reopen the dialog.
		if (bbl_video_uploader) {

			if( oldFieldID == BuddyBlog_Pro.currentMediaFieldID ) {
				bbl_video_uploader.open();
				return;
			}
			// Note, for Ravi.
			bbl_video_uploader.detach();
		}
		var allowedTypes = $this.data('allowed-types');
		if ( !allowedTypes) {
			allowedTypes = '*';//['*']
		}
		allowedTypes = allowedTypes.split(',');
		// Extend the wp.media object.
		bbl_video_uploader = wp.media.frames.file_frame = wp.media({
			title: $this.data('uploader-title'),
			button: {
				text: $this.data('btn-title')
			},
			library: {
				type: allowedTypes
			},
			allowedTypes: allowedTypes,
			multiple: false
		});

		//When a file is selected, grab the URL and set it as the text field's value
		bbl_video_uploader.on('select', function () {
			var attachment = bbl_video_uploader.state().get('selection').first().toJSON();
			var mime = attachment.mime, matched = false;
			for ( var i =0; i< allowedTypes.length; i++ ) {
				if( mime === allowedTypes[i]) {
					matched = true;
					break;
				}
			}
			if( !matched ) {
				return;
			}

			$wrapper.find('input[type="hidden"]').val(attachment.id);
			$wrapper.find('.bbl-field-type-video-preview').html('<a href="' + attachment.url + '">' +attachment.filename +'</a><a href="#" class="bbl-field-type-video-delete-btn">X</a>');
			BuddyBlog_Pro.currentMediaFieldID = null;
		});

		bbl_video_uploader.on('close', function () {
			BuddyBlog_Pro.currentMediaFieldID = null;
		});

		// Open the uploader dialog.
		bbl_video_uploader.open();

		return false;
	});

	$(document).on('click', '.bbl-field-type-video-delete-btn', function () {

		var $this = $(this);

		$wrapper = $this.parents('.bbl-form-field-type-video-container');

		$wrapper.find('input[type="hidden"]').val('');
		$wrapper.find('.bbl-field-type-video-preview').html('');

		return false;
	});
});
