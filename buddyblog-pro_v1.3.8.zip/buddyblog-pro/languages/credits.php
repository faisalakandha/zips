<?php
//// Do not allow direct access over web.
defined( 'ABSPATH' ) || exit;
?>

Contributions:-
German Translation:- Thorsten Wollenhöfer
